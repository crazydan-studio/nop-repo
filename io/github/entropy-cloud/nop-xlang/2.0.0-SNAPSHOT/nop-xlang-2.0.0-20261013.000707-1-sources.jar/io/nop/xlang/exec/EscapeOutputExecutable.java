/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.xlang.exec;

import io.nop.api.core.util.Guard;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.text.RawText;
import io.nop.commons.util.StringHelper;
import io.nop.core.lang.eval.EvalRuntime;
import io.nop.core.lang.eval.IEvalOutput;
import io.nop.core.lang.eval.IExecutableExpression;
import io.nop.core.lang.eval.IExecutableExpressionVisitor;
import io.nop.core.lang.eval.IExpressionExecutor;
import io.nop.xlang.ast.XLangEscapeMode;

public class EscapeOutputExecutable extends AbstractExecutable {
    private final XLangEscapeMode escapeMode;
    private final IExecutableExpression valueExpr;

    public EscapeOutputExecutable(SourceLocation loc, XLangEscapeMode escapeMode, IExecutableExpression valueExpr) {
        super(loc);
        this.escapeMode = Guard.notNull(escapeMode, "escapeMode");
        this.valueExpr = Guard.notNull(valueExpr, "valueExpr");
    }

    @Override
    public boolean allowBreakPoint() {
        return false;
    }

    @Override
    public void display(StringBuilder sb) {
        sb.append("escape:");
        sb.append(escapeMode);
        sb.append(",");
        valueExpr.display(sb);
    }

    @Override
    public Object execute(IExpressionExecutor executor, EvalRuntime rt) {
        Object value = executor.execute(valueExpr, rt);
        XLangSemantics.escapeOutput(getLocation(), rt.getOut(), escapeMode, value);
        return null;
    }

    @Override
    public void visit(IExecutableExpressionVisitor visitor) {
        if (visitor.onVisitExpr(this)) {
            valueExpr.visit(visitor);
            visitor.onEndVisitExpr(this);
        }
    }

    public XLangEscapeMode getEscapeMode() {
        return escapeMode;
    }

    public IExecutableExpression getValueExpr() {
        return valueExpr;
    }
}
