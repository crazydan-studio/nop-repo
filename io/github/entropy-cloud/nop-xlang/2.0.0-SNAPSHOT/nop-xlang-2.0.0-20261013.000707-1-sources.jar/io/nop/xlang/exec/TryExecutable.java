/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.xlang.exec;

import io.nop.api.core.util.Guard;
import io.nop.api.core.util.SourceLocation;
import io.nop.core.lang.eval.EvalRuntime;
import io.nop.core.lang.eval.IExecutableExpression;
import io.nop.core.lang.eval.IExecutableExpressionVisitor;
import io.nop.core.lang.eval.IExpressionExecutor;

public class TryExecutable extends AbstractExecutable {
    private final IExecutableExpression bodyExpr;
    private final int exceptionSlot;
    private final IExecutableExpression catchExpr;
    private final IExecutableExpression finallyExpr;

    public TryExecutable(SourceLocation loc, IExecutableExpression bodyExpr, int exceptionSlot,
                         IExecutableExpression catchExpr, IExecutableExpression finallyExpr) {
        super(loc);
        this.bodyExpr = Guard.notNull(bodyExpr, "bodyExpr is null");
        this.exceptionSlot = exceptionSlot;
        this.catchExpr = catchExpr;
        this.finallyExpr = finallyExpr;
    }

    @Override
    public void display(StringBuilder sb) {
        sb.append("try{}");
    }

    @Override
    public Object execute(IExpressionExecutor executor, EvalRuntime rt) {
        if (catchExpr != null) {
            try {
                return executor.execute(bodyExpr, rt);
            } catch (Exception e) {
                if (exceptionSlot >= 0) {
                    rt.getCurrentFrame().setStackValue(exceptionSlot, e);
                }
                // catch体执行完成后吞掉异常，继续执行后续代码。如果需要重抛，在catch体中显式throw
                return executor.execute(catchExpr, rt);
            } finally {
                if (finallyExpr != null) {
                    executor.execute(finallyExpr, rt);
                }
            }
        } else {
            try {
                return executor.execute(bodyExpr, rt);
            } finally {
                if (finallyExpr != null) {
                    executor.execute(finallyExpr, rt);
                }
            }
        }
    }

    @Override
    public boolean containsReturnStatement() {
        if (bodyExpr.containsReturnStatement())
            return true;
        if (catchExpr != null && catchExpr.containsReturnStatement())
            return true;
        return finallyExpr != null && finallyExpr.containsReturnStatement();
    }

    @Override
    public boolean containsBreakStatement() {
        if (bodyExpr.containsBreakStatement())
            return true;
        if (catchExpr != null && catchExpr.containsBreakStatement())
            return true;
        return finallyExpr != null && finallyExpr.containsBreakStatement();
    }

    @Override
    public void visit(IExecutableExpressionVisitor visitor) {
        if (visitor.onVisitExpr(this)) {
            bodyExpr.visit(visitor);
            if (catchExpr != null)
                catchExpr.visit(visitor);
            if (finallyExpr != null)
                finallyExpr.visit(visitor);
            visitor.onEndVisitExpr(this);
        }
    }

    public IExecutableExpression getBodyExpr() {
        return bodyExpr;
    }

    public int getExceptionSlot() {
        return exceptionSlot;
    }

    public IExecutableExpression getCatchExpr() {
        return catchExpr;
    }

    public IExecutableExpression getFinallyExpr() {
        return finallyExpr;
    }
}
