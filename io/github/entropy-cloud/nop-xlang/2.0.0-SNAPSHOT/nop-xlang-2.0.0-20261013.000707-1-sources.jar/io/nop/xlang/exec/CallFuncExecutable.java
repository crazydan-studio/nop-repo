/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.xlang.exec;

import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.SourceLocation;
import io.nop.core.lang.eval.EvalFrame;
import io.nop.core.lang.eval.EvalRuntime;
import io.nop.core.lang.eval.IExecutableExpression;
import io.nop.core.lang.eval.IExecutableExpressionVisitor;
import io.nop.core.lang.eval.IExpressionExecutor;

import static io.nop.xlang.XLangErrors.ERR_EXEC_CALL_FUNC_FAIL;

public class CallFuncExecutable extends AbstractExecutable {
    private final String funcName;
    private final String[] slotNames;
    private final IExecutableExpression[] argExprs;
    private IExecutableExpression bodyExpr;
    private boolean allowBreakpoint = true;

    public CallFuncExecutable(SourceLocation loc, String funcName, String[] slotNames, IExecutableExpression[] argExprs,
                              IExecutableExpression bodyExpr) {
        super(loc);
        this.funcName = funcName;
        this.slotNames = slotNames;
        this.argExprs = argExprs;
        this.bodyExpr = bodyExpr;
    }

    public void setBodyExpr(IExecutableExpression bodyExpr) {
        this.bodyExpr = bodyExpr;
    }

    public String getFuncName() {
        return funcName;
    }

    public String[] getSlotNames() {
        return slotNames;
    }

    public IExecutableExpression[] getArgExprs() {
        return argExprs;
    }

    public IExecutableExpression getBodyExpr() {
        return bodyExpr;
    }

    @Override
    public boolean allowBreakPoint() {
        return allowBreakpoint;
    }

    public void setAllowBreakpoint(boolean allowBreakpoint) {
        this.allowBreakpoint = allowBreakpoint;
    }

    // tell cpd to start ignoring code - CPD-OFF
    @Override
    public void display(StringBuilder sb) {
        sb.append(funcName).append('(');
        for (int i = 0, n = argExprs.length; i < n; i++) {
            argExprs[i].display(sb);
            if (i != n - 1)
                sb.append(',');
        }
        sb.append(")");
    }

    @Override
    public Object execute(IExpressionExecutor executor, EvalRuntime rt) {
        EvalFrame current = rt.getCurrentFrame();
        EvalFrame frame = new EvalFrame(current, slotNames);
        frame.setDisplayInfo(getLocation(), funcName);
        for (int i = 0, n = argExprs.length; i < n; i++) {
            Object arg = executor.execute(argExprs[i], rt);
            frame.setArg(i, arg);
        }
        try {
            rt.pushFrame(frame);
            return executor.execute(bodyExpr, rt);
        } catch (Exception e) {
            throw XLangSemantics.wrapCallFuncException(this, getLocation(), display(), e);
        } finally {
            rt.setExitMode(null);
            rt.popFrame();
        }
    }
    // resume CPD analysis - CPD-ON

    @Override
    public void visit(IExecutableExpressionVisitor visitor) {
        if (visitor.onVisitExpr(this)) {
            for (IExecutableExpression argExpr : argExprs) {
                argExpr.visit(visitor);
            }

            bodyExpr.visit(visitor);
            visitor.onEndVisitExpr(this);
        }
    }
}