/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.xlang.exec;

import io.nop.api.core.util.SourceLocation;
import io.nop.core.lang.eval.EvalRuntime;
import io.nop.core.lang.eval.IEvalScope;
import io.nop.core.lang.eval.IExecutableExpression;
import io.nop.core.lang.eval.IExecutableExpressionVisitor;
import io.nop.core.lang.eval.IExpressionExecutor;
import io.nop.core.reflect.IPropertyGetter;


public class GetterGetPropertyExecutable extends AbstractExecutable {
    private final IExecutableExpression objExpr;
    private final String propName;
    private final IPropertyGetter getter;

    public GetterGetPropertyExecutable(SourceLocation loc, IExecutableExpression objExpr, String propName,
                                       IPropertyGetter getter) {
        super(loc);
        this.objExpr = objExpr;
        this.propName = propName;
        this.getter = getter;
    }

    @Override
    public void display(StringBuilder sb) {
        objExpr.display(sb);
        sb.append('.');
        sb.append(propName);
    }

    protected Object returnNull() {
        return null;
    }

    @Override
    public void visit(IExecutableExpressionVisitor visitor) {
        if (visitor.onVisitExpr(this)) {
            objExpr.visit(visitor);
            visitor.onEndVisitExpr(this);
        }
    }

    @Override
    public Object execute(IExpressionExecutor executor, EvalRuntime rt) {
        Object o = eval(objExpr, executor, rt);
        if (o == null)
            return returnNull();

        return readProp(o, getter, rt.getScope());
    }

    protected Object readProp(Object obj, IPropertyGetter reader, IEvalScope scope) {
        return XLangSemantics.readPropValue(getLocation(), display(), propName, obj, reader, scope);
    }
    public String getPropName() {
        return propName;
    }

    public IExecutableExpression getObjExpr() {
        return objExpr;
    }

}
