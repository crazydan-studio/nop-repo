/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.xlang.exec;

import io.nop.api.core.util.Guard;
import io.nop.api.core.util.SourceLocation;
import io.nop.core.lang.eval.EvalRuntime;
import io.nop.core.lang.eval.IExecutableExpression;
import io.nop.core.lang.eval.IExecutableExpressionVisitor;
import io.nop.core.lang.eval.IExpressionExecutor;
import io.nop.core.reflect.IMethodModelCollection;

public class StaticFunctionExecutable extends AbstractExecutable {
    private final String className;
    private final String funcName;
    private final IMethodModelCollection methodCollection;
    private final IExecutableExpression[] argExprs;
    private final boolean optional;

    public StaticFunctionExecutable(SourceLocation loc, String className, String funcName, boolean optional,
                                    IMethodModelCollection methodCollection, IExecutableExpression[] argExprs) {
        super(loc);
        this.className = Guard.notEmpty(className, "className");
        this.funcName = Guard.notEmpty(funcName, "funcName");
        this.optional = optional;
        this.methodCollection = Guard.notNull(methodCollection, "methodCollection");
        this.argExprs = Guard.notNull(argExprs, "argExprs");
    }

    public String getClassName() {
        return className;
    }

    public String getFuncName() {
        return funcName;
    }

    public boolean isOptional() {
        return optional;
    }

    public IMethodModelCollection getMethodCollection() {
        return methodCollection;
    }

    public IExecutableExpression[] getArgExprs() {
        return argExprs;
    }

    @Override
    public void display(StringBuilder sb) {
        sb.append(className);
        sb.append('.').append(funcName);
        addArgExprs(sb, argExprs);
    }

    @Override
    public Object execute(IExpressionExecutor executor, EvalRuntime rt) {
        Object[] argValues = evaluateArgs(argExprs, executor, rt);
        return XLangSemantics.invokeStaticMethod(getLocation(), display(), className, funcName, optional,
                methodCollection, argValues, rt.getScope());
    }

    @Override
    public void visit(IExecutableExpressionVisitor visitor) {
        if (visitor.onVisitExpr(this)) {
            for (IExecutableExpression argExpr : argExprs) {
                argExpr.visit(visitor);
            }
            visitor.onEndVisitExpr(this);
        }
    }
}
