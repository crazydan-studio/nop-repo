/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://github.com/entropy-cloud/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.flow.builder;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ACTUAL_STREAM_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ATTR_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ATTR_VALUE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ELEMENT;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_EXPECTED_STREAM_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_REF_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_REF_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NOT_IMPLEMENTED;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_REF_UNKNOWN;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_REQUIRED_ATTR;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_REQUIRED_BODY;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UPSTREAM_NULL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UPSTREAM_NOT_STREAM;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UPSTREAM_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_WINDOW_ATTR_UNSUPPORTED;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.nop.stream.cep.CEP;
import io.nop.stream.cep.PatternStream;
import io.nop.stream.cep.functions.PatternProcessFunction;
import io.nop.stream.cep.model.CepPatternModel;
import io.nop.stream.cep.model.builder.CepPatternBuilder;
import io.nop.stream.cep.pattern.Pattern;
import io.nop.stream.core.common.functions.AggregateFunction;
import io.nop.stream.core.common.functions.KeyedProcessFunction;
import io.nop.stream.core.common.functions.ProcessFunction;
import io.nop.stream.core.common.functions.ReduceFunction;
import io.nop.stream.core.common.eventtime.TimestampAssigner;
import io.nop.stream.core.common.eventtime.TimestampAssignerSupplier;
import io.nop.stream.core.common.eventtime.WatermarkGenerator;
import io.nop.stream.core.common.eventtime.WatermarkGeneratorSupplier;
import io.nop.stream.core.common.eventtime.WatermarkOutput;
import io.nop.stream.core.common.eventtime.WatermarkStrategy;
import io.nop.stream.core.common.typeinfo.TypeInformation;
import io.nop.stream.core.common.typeinfo.UnknownTypeInformation;
import io.nop.stream.core.model.JoinSideRecord;
import io.nop.stream.core.datastream.DataStream;
import io.nop.stream.core.datastream.KeyedStream;
import io.nop.stream.core.datastream.SingleOutputStreamOperator;
import io.nop.stream.core.datastream.WindowedStream;
import io.nop.stream.core.environment.StreamExecutionEnvironment;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.operators.OneInputStreamOperator;
import io.nop.stream.core.operators.join.EquiJoinOperator;
import io.nop.stream.core.util.Collector;
import io.nop.stream.core.windowing.AccumulationMode;
import io.nop.stream.core.windowing.assigners.WindowAssigner;
import io.nop.stream.flow.builder.functions.JoinSideKeySelector;
import io.nop.stream.flow.builder.functions.JoinSideTagFunction;
import io.nop.stream.flow.builder.functions.XplReduceFunction;
import io.nop.stream.flow.model.StreamAggregateModel;
import io.nop.stream.flow.model.StreamCepModel;
import io.nop.stream.flow.model.StreamJoinModel;
import io.nop.stream.flow.model.StreamJoinSpecModel;
import io.nop.stream.flow.model.StreamCustomModel;
import io.nop.stream.flow.model.StreamProcessModel;
import io.nop.stream.flow.model.StreamReduceModel;
import io.nop.stream.flow.model.StreamSideOutputModel;
import io.nop.stream.flow.model.StreamTimestampsAndWatermarksModel;
import io.nop.stream.flow.model.StreamTransformModel;
import io.nop.stream.flow.model.StreamAggregatorModel;
import io.nop.stream.flow.model.StreamUnionModel;
import io.nop.stream.flow.spi.IAggregatorFunctionResolver;
import io.nop.stream.flow.model.StreamWindowModel;
import io.nop.stream.flow.model.WindowingStrategyModel;

/**
 * Implements the advanced transform translations declared in {@code stream.xdef} that
 * {@link StreamModelDslBuilder} does not handle inline.
 *
 * <p>Every branch is either a real DataStream-API call or fails fast with a
 * {@link StreamException} carrying an {@code ERR_STREAM_*} code — no silent no-ops. The
 * {@code <union>} transform (WI6) builds a real multi-input merge over the declared
 * edges. {@code <sideOutput>} still fails fast: the side-output extraction API
 * ({@code SingleOutputStreamOperator.getSideOutput} / {@code SideOutputDataStream})
 * already exists in {@code nop-stream-core}, but an XDSL {@code <sideOutput>} node would
 * need a graph-level side-output edge, and side-output edges have no routing in the
 * execution graph yet — side-output views are consumable only via
 * {@code sink/print/collect}.
 *
 * <p>P1-XDSL-6 (updated WI10/D9): window strategy declarations ({@code triggerId}/
 * {@code accumulationMode}) and window node-level {@code triggerId} children are rejected
 * at build time when they differ from the xdef defaults. allowedLateness was released by
 * D9: consumed by buildWindow and passed to the operator.
 */
final class AdvancedTransforms {

    private static final org.slf4j.Logger LOG =
            org.slf4j.LoggerFactory.getLogger(AdvancedTransforms.class);

    private static final long XDEF_DEFAULT_ALLOWED_LATENESS = 0L;

    private AdvancedTransforms() {
    }

    static Object build(StreamModelDslBuilder owner, StreamExecutionEnvironment env,
                        StreamTransformModel t, Set<String> upstreamIds,
                        Map<String, Object> streamRegistry) {
        if (t instanceof StreamWindowModel) {
            return buildWindow(owner, t, upstreamIds, streamRegistry, (StreamWindowModel) t);
        }
        if (t instanceof StreamAggregateModel) {
            return buildAggregate(owner, t, upstreamIds, streamRegistry, (StreamAggregateModel) t);
        }
        if (t instanceof StreamJoinModel) {
            return buildJoin(owner, t, upstreamIds, streamRegistry, (StreamJoinModel) t);
        }
        if (t instanceof StreamReduceModel) {
            return buildReduce(owner, t, upstreamIds, streamRegistry, (StreamReduceModel) t);
        }
        if (t instanceof StreamProcessModel) {
            return buildProcess(owner, t, upstreamIds, streamRegistry, (StreamProcessModel) t);
        }
        if (t instanceof StreamUnionModel) {
            return buildUnion(owner, t, upstreamIds, streamRegistry);
        }
        if (t instanceof StreamCustomModel) {
            return buildCustom(owner, t, upstreamIds, streamRegistry, (StreamCustomModel) t);
        }
        if (t instanceof StreamCepModel) {
            return buildCep(owner, t, upstreamIds, streamRegistry, (StreamCepModel) t);
        }
        if (t instanceof StreamSideOutputModel) {
            return buildSideOutput((StreamSideOutputModel) t);
        }
        if (t instanceof StreamTimestampsAndWatermarksModel) {
            return buildTimestampsAndWatermarks(owner, t, upstreamIds, streamRegistry,
                    (StreamTimestampsAndWatermarksModel) t);
        }
        throw new StreamException(ERR_STREAM_NOT_IMPLEMENTED)
                .param(ARG_DETAIL, "unknown transform type " + t.getClass().getName())
                .loc(t.getLocation());
    }

    // ----------------------------------------------------------------
    // window / aggregate / reduce
    // ----------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T, K> WindowedStream<?, ?, ?> buildWindow(StreamModelDslBuilder owner,
                                                               StreamTransformModel t,
                                                               Set<String> upstreamIds,
                                                               Map<String, Object> streamRegistry,
                                                               StreamWindowModel m) {
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (!(in instanceof KeyedStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "KeyedStream")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        if (m.getStrategyRef() == null) {
            throw new StreamException(ERR_STREAM_REQUIRED_ATTR)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "strategyRef")
                    .loc(t.getLocation());
        }
        // Item 29: <window> is a virtual build point — it wraps the upstream
        // KeyedStream and produces NO vertex of its own (the window function
        // operator belongs to the following <aggregate>/<reduce>/<process> element,
        // which declares its own parallelism). A parallelism declaration here has
        // no consumer and would silently retarget the upstream keyBy vertex if
        // applied — fail fast instead (same policy as the FL-1 declarations).
        if (t.getParallelism() != null && t.getParallelism() > 0) {
            throw new StreamException(ERR_STREAM_NOT_IMPLEMENTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "parallelism")
                    .param(ARG_DETAIL, "<window> is a virtual element with no execution vertex; "
                            + "declare parallelism on the <aggregate>/<reduce>/<process> "
                            + "element that owns the window operator instead")
                    .loc(t.getLocation());
        }
        WindowingStrategyModel strategy = owner.model().getStrategy(m.getStrategyRef());
        if (strategy == null) {
            throw new StreamException(ERR_STREAM_REF_UNKNOWN)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_REF_TYPE, "<windowingStrategies>/<strategy>")
                    .param(ARG_REF_NAME, m.getStrategyRef())
                    .loc(t.getLocation());
        }
        failFastOnUnsupportedWindowStrategy(t, strategy);
        failFastOnUnsupportedWindowNodeAttrs(t, m);
        WindowAssigner assigner = (WindowAssigner) resolveWindowAssigner(owner, t, strategy);
        KeyedStream keyed = (KeyedStream<T, K>) in;
        io.nop.stream.core.datastream.WindowedStreamImpl<?, ?, ?> windowed =
                (io.nop.stream.core.datastream.WindowedStreamImpl<?, ?, ?>) keyed.window(assigner);
        // WI10/D9: consume the merged allowedLateness (node-level explicit Long
        // overrides strategy-level long; null node means strategy value applies).
        long lateness = m.getAllowedLateness() != null
                ? m.getAllowedLateness()
                : strategy.getAllowedLateness();
        if (lateness > 0) {
            windowed.allowedLateness(lateness);
        }
        return windowed;
    }

    /**
     * P1-XDSL-6 (updated WI10/D9): strategy-level windowing attributes that the core
     * pipeline cannot express (triggers would require a trigger registry) must fail fast
     * on non-default values. allowedLateness was released by D9 (WI10): consumed by
     * buildWindow and passed to the operator. xdef defaults: allowedLateness=0,
     * accumulationMode=DISCARDING, triggerId unset.
     */
    private static void failFastOnUnsupportedWindowStrategy(StreamTransformModel t,
                                                            WindowingStrategyModel strategy) {
        if (strategy.getTriggerId() != null) {
            throw new StreamException(ERR_STREAM_WINDOW_ATTR_UNSUPPORTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "triggerId").param(ARG_ATTR_VALUE, strategy.getTriggerId())
                    .loc(t.getLocation());
        }
        // WI10/D9: allowedLateness is now released — consumed by buildWindow.

        if (strategy.getAccumulationMode() != null
                && strategy.getAccumulationMode() != AccumulationMode.DISCARDING) {
            throw new StreamException(ERR_STREAM_WINDOW_ATTR_UNSUPPORTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "accumulationMode")
                    .param(ARG_ATTR_VALUE, strategy.getAccumulationMode())
                    .loc(t.getLocation());
        }
    }

    /**
     * AR-12 (updated WI10/D9): window node-level {@code triggerId} children fail fast.
     * allowedLateness was released by D9 — consumed by buildWindow.
     */
    private static void failFastOnUnsupportedWindowNodeAttrs(StreamTransformModel t,
                                                             StreamWindowModel m) {
        // WI10/D9: node-level allowedLateness is now released — consumed by buildWindow.
        if (m.getTriggerId() != null) {
            throw new StreamException(ERR_STREAM_WINDOW_ATTR_UNSUPPORTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "triggerId").param(ARG_ATTR_VALUE, m.getTriggerId())
                    .loc(t.getLocation());
        }
    }

    private static WindowAssigner<? super Object, ?> resolveWindowAssigner(
            StreamModelDslBuilder owner, StreamTransformModel t, WindowingStrategyModel strategy) {
        String windowFnId = strategy.getWindowFnId();
        // WI10: bean takes priority over the parameterized path (review m1: bean
        // precedes duration conflict check to preserve existing semantics).
        if (owner.beanResolver().contains(windowFnId)) {
            return owner.resolveBean(t, windowFnId, WindowAssigner.class);
        }
        // WI10: duration + legacy id together is a conflict (no silent ignore).
        if (strategy.getDuration() != null && isLegacyWindowId(windowFnId))
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "duration")
                    .param(ARG_DETAIL, "windowingStrategies: duration cannot be combined with legacy windowFnId="
                            + windowFnId + " (declare windowFnId=\"tumbling-event-time\" + duration instead)")
                    .loc(t.getLocation());
        // WI10: parameterized kind + duration declaration — arbitrary window size
        // without pre-registered beans or whitelisted ids. Exact match (not
        // startsWith) so legacy tumbling-event-time-1s/5s fall through to the
        // whitelist below.
        if (windowFnId.equals("tumbling-event-time")) {
            if (strategy.getDuration() == null)
                throw new StreamException(ERR_STREAM_INVALID_ARG)
                        .param(ARG_ARG_NAME, "duration")
                        .param(ARG_DETAIL, "windowingStrategies: parameterized windowFnId="
                                + windowFnId + " requires a duration declaration (e.g. duration=\"2s\")")
                        .loc(t.getLocation());
            long millis = parseDurationMillis(strategy.getDuration());
            return io.nop.stream.core.windowing.assigners.TumblingEventTimeWindows.of(millis);
        }
        // A small builtin catalog for backward compatibility (legacy ids without duration).
        switch (windowFnId) {
            case "tumbling-global":
            case "global":
                return io.nop.stream.core.windowing.assigners.GlobalWindows.create();
            case "tumbling-event-time-1s":
                return io.nop.stream.core.windowing.assigners.TumblingEventTimeWindows.of(1000L);
            case "tumbling-event-time-5s":
                return io.nop.stream.core.windowing.assigners.TumblingEventTimeWindows.of(5000L);
            default:
                throw new StreamException(ERR_STREAM_REF_UNKNOWN)
                        .param(ARG_ELEMENT, "windowingStrategies")
                        .param(ARG_REF_TYPE, "windowFnId").param(ARG_REF_NAME, windowFnId)
                        .loc(t.getLocation());
        }
    }

    static boolean isLegacyWindowId(String windowFnId) {
        switch (windowFnId) {
            case "tumbling-global":
            case "global":
            case "tumbling-event-time-1s":
            case "tumbling-event-time-5s":
                return true;
            default:
                return false;
        }
    }

    /**
     * WI10: parses a duration string with ms/s/m suffix into milliseconds.
     * Plain numbers are interpreted as milliseconds.
     */
    static long parseDurationMillis(String duration) {
        if (duration == null || duration.isEmpty())
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "duration").param(ARG_DETAIL, "duration must not be empty");
        String unit = "ms";
        String num = duration;
        if (duration.endsWith("ms")) {
            num = duration.substring(0, duration.length() - 2);
        } else if (duration.endsWith("s") || duration.endsWith("m")) {
            unit = duration.substring(duration.length() - 1);
            num = duration.substring(0, duration.length() - 1);
        }
        long value;
        try {
            value = Long.parseLong(num.trim());
        } catch (NumberFormatException e) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "duration").param(ARG_DETAIL, "invalid duration: " + duration);
        }
        // WI10/M-C: non-positive values are rejected (zero or negative window
        // size is a semantic error, not a valid parameterization).
        if (value <= 0)
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "duration").param(ARG_DETAIL, "duration must be positive: " + duration);
        switch (unit) {
            case "s":
                return value * 1000L;
            case "m":
                return value * 60_000L;
            case "ms":
                return value;
            default:
                throw new StreamException(ERR_STREAM_INVALID_ARG)
                        .param(ARG_ARG_NAME, "duration").param(ARG_DETAIL, "unknown duration unit: " + duration);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T, ACC, R> SingleOutputStreamOperator<R> buildAggregate(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamAggregateModel m) {
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (!(in instanceof WindowedStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "WindowedStream")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        // WI8c exactly-one adjudication: bean and aggregatorRef are mutually exclusive
        // and at least one must be declared — both together or neither fail fast (this
        // replaces the former bean-required error).
        if ((m.getBean() == null) == (m.getAggregatorRef() == null)) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_DETAIL, "<aggregate> requires exactly one of bean or aggregatorRef, found "
                            + (m.getBean() == null ? "neither" : "both"))
                    .loc(t.getLocation());
        }
        WindowedStream windowed = (WindowedStream) in;
        AggregateFunction fn;
        if (m.getBean() != null) {
            fn = owner.resolveBean(t, m.getBean(), AggregateFunction.class);
        } else {
            fn = resolveAggregatorRef(owner, t, m);
        }
        return StreamModelDslBuilder.applyDeclaredParallelism(
                (SingleOutputStreamOperator<R>) windowed.aggregate(fn), t);
    }

    /**
     * WI8c: resolves an {@code aggregatorRef} declaration in the A4 order — the
     * registry entry lookup (unknown id fails fast), then the A4 bean-first check
     * ({@code beanResolver.contains(fnId)} keeps custom aggregate beans usable), and
     * finally the {@link IAggregatorFunctionResolver} provider looked up by type in
     * the BeanContainer. No provider (including an uninitialized container) fails
     * fast naming the missing nop-stream-sql dependency — never a silent fallback.
     */
    private static AggregateFunction<?, ?, ?> resolveAggregatorRef(
            StreamModelDslBuilder owner, StreamTransformModel t, StreamAggregateModel m) {
        StreamAggregatorModel entry = owner.model().getAggregator(m.getAggregatorRef());
        if (entry == null) {
            throw new StreamException(ERR_STREAM_REF_UNKNOWN)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_REF_TYPE, "<aggregators>/<aggregator>")
                    .param(ARG_REF_NAME, m.getAggregatorRef())
                    .loc(t.getLocation());
        }
        String fnId = entry.getFnId();
        // A4 ordering: an explicitly registered aggregate bean for the fnId wins over
        // the builtin catalog.
        if (owner.beanResolver().contains(fnId)) {
            return owner.resolveBean(t, fnId, AggregateFunction.class);
        }
        if (!io.nop.api.core.ioc.BeanContainer.isInitialized()) {
            throw noProvider(m);
        }
        IAggregatorFunctionResolver resolver =
                io.nop.api.core.ioc.BeanContainer.instance()
                        .tryGetBeanByType(IAggregatorFunctionResolver.class);
        if (resolver == null) {
            throw noProvider(m);
        }
        return resolver.resolve(fnId, entry.getExpr(), owner.columnTypeLookup(entry.getSchemaId()));
    }

    private static StreamException noProvider(StreamAggregateModel m) {
        // param()/loc() are declared on NopException; the chain returns this
        return (StreamException) new StreamException(ERR_STREAM_INVALID_ARG)
                .param(ARG_DETAIL, "aggregate '" + m.getId() + "' declares aggregatorRef='"
                        + m.getAggregatorRef() + "' but no " + IAggregatorFunctionResolver.class.getName()
                        + " provider is registered; add io.github.entropy-cloud:nop-stream-sql to the classpath")
                .loc(m.getLocation());
    }

    /**
     * D1=(a) SEMANTICS ANNOTATION (WI11): the windowless {@code <reduce>} transform
     * maps SQL continuous GROUP BY to keyBy + reduce with LAST-VALUE-WINS final-value
     * semantics — the output emits the running reduction per input element and is
     * NOT append-only and NOT a retract stream. See
     * sql-subset-and-semantics.md §1.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T> SingleOutputStreamOperator<T> buildReduce(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamReduceModel m) {
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        ReduceFunction<T> fn;
        if (m.getBean() != null) {
            fn = owner.resolveBean(t, m.getBean(), ReduceFunction.class);
        } else if (m.getSource() != null) {
            fn = new XplReduceFunction<>(m.getSource());
        } else {
            throw new StreamException(ERR_STREAM_REQUIRED_BODY)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .loc(t.getLocation());
        }
        if (in instanceof KeyedStream) {
            KeyedStream<T, Object> keyed = (KeyedStream<T, Object>) in;
            return StreamModelDslBuilder.applyDeclaredParallelism(
                    (SingleOutputStreamOperator<T>) keyed.reduce((ReduceFunction) fn), t);
        }
        if (in instanceof WindowedStream) {
            WindowedStream windowed = (WindowedStream) in;
            return StreamModelDslBuilder.applyDeclaredParallelism(
                    (SingleOutputStreamOperator<T>) windowed.reduce((ReduceFunction) fn), t);
        }
        throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                .param(ARG_EXPECTED_STREAM_TYPE, "KeyedStream or WindowedStream")
                .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                .loc(t.getLocation());
    }

    /**
     * WI13: consumes the validated joinRef declaration (WI8d's build-time validation
     * has already guaranteed: spec exists, joinType set, equal-arity non-empty key
     * sets, exactly two upstream edges, no HASH edge, windowStrategyRef resolvable
     * and window join restricted to INNER/LEFT). Assembles the runtime:
     *
     * <pre>left --- map(side-tag) ---\
     *                              union --- keyBy(equiKey) --- EquiJoinOperator</pre>
     *
     * <pre>right -- map(side-tag) ---/</pre>
     *
     * The side-tag map evaluates the side's key expressions once per record (the
     * operator itself evaluates nothing); keyBy on the pre-computed equi-key
     * co-locates same-key records from both sides on one keyed subtask. Key
     * expression format: comma-separated XLang expressions with {@code event} bound
     * to the record (the same binding as {@code <keyBy keyExpr>}), compiled with
     * {@link io.nop.xlang.api.XLang} — flow needs no SQL-expression dependency.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object buildJoin(StreamModelDslBuilder owner, StreamTransformModel t,
                                    Set<String> upstreamIds, Map<String, Object> streamRegistry,
                                    StreamJoinModel m) {
        StreamJoinSpecModel spec = owner.model().getJoinSpec(m.getJoinRef());
        // defensive lookup (validated non-null, but never dereference without a check)
        if (spec == null) {
            throw new StreamException(ERR_STREAM_REF_UNKNOWN)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_REF_TYPE, "<joins>/<joinSpec>")
                    .param(ARG_REF_NAME, m.getJoinRef())
                    .loc(m.getLocation());
        }

        // declared edge order determines left/right; DECLARED EDGES, not distinct
        // upstream ids — a self-join declares two edges from the same source
        // (roadmap WI8d completion criterion) and joins that stream with itself
        List<String> ordered = new ArrayList<>(2);
        for (io.nop.stream.flow.model.StreamEdgeModel e : owner.model().getEdges()) {
            if (t.getId().equals(e.getTo()) && upstreamIds.contains(e.getFrom())) {
                ordered.add(e.getFrom());
            }
        }
        if (ordered.size() != 2) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_DETAIL, "<join id='" + t.getId() + "'> requires exactly two "
                            + "upstream edges (left/right), resolved " + ordered.size())
                    .loc(m.getLocation());
        }
        DataStream left = joinInput(owner, t, streamRegistry, ordered.get(0));
        DataStream right = joinInput(owner, t, streamRegistry, ordered.get(1));

        List<io.nop.core.lang.eval.IEvalAction> leftKeys = compileJoinKeyExprs(spec, true);
        List<io.nop.core.lang.eval.IEvalAction> rightKeys = compileJoinKeyExprs(spec, false);

        Long windowDuration = null;
        long timeout = 0L;
        if (spec.getWindowStrategyRef() != null) {
            // window join: duration is mandatory (parameterized tumbling), timeout
            // reuses the WI10 duration parser (D9-released lateness grace)
            WindowingStrategyModel strategy = owner.model().getStrategy(spec.getWindowStrategyRef());
            if (strategy == null || strategy.getDuration() == null) {
                throw new StreamException(ERR_STREAM_INVALID_ARG)
                        .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                        .param(ARG_DETAIL, "join spec '" + spec.getJoinId() + "' window join requires "
                                + "windowingStrategies/<strategy> with a parameterized duration "
                                + "(windowFnId=\"tumbling-event-time\" + duration=\"...\"), found "
                                + (strategy == null ? "missing strategy" : "strategy without duration"))
                        .loc(m.getLocation());
            }
            windowDuration = parseDurationMillis(strategy.getDuration());
            if (spec.getTimeout() != null) {
                timeout = parseDurationMillis(spec.getTimeout());
            }
        }

        DataStream<JoinSideRecord<Object>> tagged = left
                .map(new JoinSideTagFunction(true, leftKeys))
                .union(right.map(new JoinSideTagFunction(false, rightKeys)));
        KeyedStream<JoinSideRecord<Object>, Object> keyed = tagged.keyBy(JoinSideKeySelector.INSTANCE);
        EquiJoinOperator joinOp = new EquiJoinOperator(spec.getJoinType(), windowDuration, timeout);
        return StreamModelDslBuilder.applyDeclaredParallelism(
                (SingleOutputStreamOperator) keyed.transform("Join:" + m.getId(),
                        UnknownTypeInformation.INSTANCE, joinOp), t);
    }

    private static DataStream<?> joinInput(StreamModelDslBuilder owner, StreamTransformModel t,
                                           Map<String, Object> streamRegistry, String upstreamId) {
        Object in = streamRegistry.get(upstreamId);
        if (!(in instanceof DataStream) || in instanceof KeyedStream || in instanceof WindowedStream) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "DataStream (non-keyed, non-windowed)")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        return owner.applyEdgePartition((DataStream<?>) in, upstreamId, t.getId(), t.getParallelism());
    }

    /**
     * Compiles the side's comma-separated key expressions into XLang actions
     * ({@code event} binding). Compilation failure fails fast with the side named.
     */
    private static List<io.nop.core.lang.eval.IEvalAction> compileJoinKeyExprs(StreamJoinSpecModel spec, boolean left) {
        String exprs = left ? spec.getLeftKeyExprs() : spec.getRightKeyExprs();
        String[] parts = exprs.split(",");
        List<io.nop.core.lang.eval.IEvalAction> actions = new ArrayList<>(parts.length);
        // key expressions reference the runtime-bound record ({@code event}, the
        // same binding as <keyBy keyExpr>) — the compile-time scope check must not
        // reject it as unresolved
        io.nop.xlang.api.XLangCompileTool tool = io.nop.xlang.api.XLang.newCompileTool()
                .allowUnregisteredScopeVar(true);
        for (int i = 0; i < parts.length; i++) {
            String text = parts[i].trim();
            try {
                actions.add(tool.compileSimpleExpr(spec.getLocation(), text));
            } catch (Exception e) {
                throw new StreamException(ERR_STREAM_INVALID_ARG)
                        .param(ARG_ELEMENT, "joinSpec '" + spec.getJoinId() + "'")
                        .param(ARG_DETAIL, (left ? "leftKeyExprs" : "rightKeyExprs") + "[" + i + "]='"
                                + text + "' is not a valid expression: " + e.getMessage())
                        .loc(spec.getLocation());
            }
        }
        return actions;
    }

    // ----------------------------------------------------------------
    // process
    // ----------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T, R> SingleOutputStreamOperator<R> buildProcess(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamProcessModel m) {
        if (m.getBean() == null) {
            throw new StreamException(ERR_STREAM_REQUIRED_ATTR)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "bean")
                    .loc(t.getLocation());
        }
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (in instanceof KeyedStream) {
            KeyedProcessFunction<Object, T, R> fn = owner.resolveBean(t, m.getBean(), KeyedProcessFunction.class);
            KeyedStream<T, Object> keyed = (KeyedStream<T, Object>) in;
            return StreamModelDslBuilder.applyDeclaredParallelism(
                    (SingleOutputStreamOperator<R>) keyed.process((KeyedProcessFunction) fn), t);
        }
        if (in instanceof DataStream) {
            ProcessFunction<T, R> fn = owner.resolveBean(t, m.getBean(), ProcessFunction.class);
            DataStream<T> dataStream = (DataStream<T>) in;
            return StreamModelDslBuilder.applyDeclaredParallelism(
                    (SingleOutputStreamOperator<R>) dataStream.process((ProcessFunction) fn), t);
        }
        throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                .param(ARG_EXPECTED_STREAM_TYPE, "DataStream or KeyedStream")
                .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                .loc(t.getLocation());
    }

    // ----------------------------------------------------------------
    // union — WI6: real multi-input merge over the declared edges
    // ----------------------------------------------------------------

    /**
     * WI6: builds the union stream from every upstream edge, in edge declaration
     * order (the registry's upstream ids are an unordered Set). Every upstream must
     * be a plain {@link DataStream} — KeyedStream/WindowedStream shapes are rejected
     * (key partitioning is declared AFTER the union, see the HASH-edge fail-fast in
     * {@code StreamModelDslBuilder.validateEdgeDeclarations}); each upstream still
     * runs through {@code applyEdgePartition} so undeclared non-HASH edges pass
     * through untouched and the registry-level guard stays in one place.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object buildUnion(StreamModelDslBuilder owner, StreamTransformModel t,
                                     Set<String> upstreamIds, Map<String, Object> streamRegistry) {
        if (upstreamIds.isEmpty()) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "upstream edges")
                    .param(ARG_DETAIL, "<union id='" + t.getId() + "'> requires at least one "
                            + "upstream edge, found none")
                    .loc(t.getLocation());
        }
        // Preserve the declared edge order for deterministic merge order. A source
        // declaring TWO edges into the same <union> merges twice (self-union) — each
        // declared edge is one merge input, matching the runtime's one-channel-per-
        // declared-edge contract (WI6 constraint 2); silently dropping the duplicate
        // edge would violate the builder's no-silent-drop rule.
        List<String> ordered = new ArrayList<>(upstreamIds.size());
        for (io.nop.stream.flow.model.StreamEdgeModel e : owner.model().getEdges()) {
            if (t.getId().equals(e.getTo()) && upstreamIds.contains(e.getFrom())) {
                ordered.add(e.getFrom());
            }
        }
        // Registry ids that no declared edge reaches (defensive — validateDag derives
        // upstreamIds from the same edge list, so this stays empty in practice).
        for (String id : upstreamIds) {
            if (!ordered.contains(id)) {
                ordered.add(id);
            }
        }

        DataStream merged = null;
        for (String upstreamId : ordered) {
            Object in = streamRegistry.get(upstreamId);
            if (!(in instanceof DataStream) || in instanceof KeyedStream || in instanceof WindowedStream) {
                throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                        .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                        .param(ARG_EXPECTED_STREAM_TYPE, "DataStream (non-keyed, non-windowed)")
                        .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                        .loc(t.getLocation());
            }
            DataStream input = owner.applyEdgePartition((DataStream<?>) in, upstreamId,
                    t.getId(), t.getParallelism());
            merged = merged == null ? input : merged.union(input);
        }
        return StreamModelDslBuilder.applyDeclaredParallelism(merged, t);
    }

    // ----------------------------------------------------------------
    // custom
    // ----------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T, R> SingleOutputStreamOperator<R> buildCustom(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamCustomModel m) {
        if (m.getCustomType() == null) {
            throw new StreamException(ERR_STREAM_REQUIRED_ATTR)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "customType")
                    .loc(t.getLocation());
        }
        // Item 11 FL-1 (custom side, mirrors the source/sink fail-fast in the builder):
        // <params> has no execution consumer and must not be silently dropped.
        if (m.hasParams()) {
            throw new StreamException(ERR_STREAM_NOT_IMPLEMENTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "params")
                    .param(ARG_DETAIL, "<params> on <custom> has no execution consumer; "
                            + "configure the custom operator bean constructor instead")
                    .loc(t.getLocation());
        }
        // R5-AR-02: the <custom><source> xpl body is xdef-declared and parsed into
        // the model but has no execution consumer — the custom operator bean is
        // resolved purely from customType. Fail fast instead of silently dropping
        // the declared transformation logic.
        if (m.getSource() != null) {
            throw new StreamException(ERR_STREAM_NOT_IMPLEMENTED)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "source")
                    .param(ARG_DETAIL, "<source> on <custom> has no execution consumer; the custom "
                            + "operator bean resolved from customType receives the upstream input "
                            + "directly. Implement the transformation inside the operator bean or "
                            + "use <map>/<filter> with an inline xpl body instead")
                    .loc(t.getLocation());
        }
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (!(in instanceof DataStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "DataStream")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        OneInputStreamOperator<T, R> operator = owner.resolveBean(t, m.getCustomType(), OneInputStreamOperator.class);
        DataStream<T> dataStream = (DataStream<T>) in;
        TypeInformation<R> outType = (TypeInformation<R>) UnknownTypeInformation.INSTANCE;
        return StreamModelDslBuilder.applyDeclaredParallelism(
                (SingleOutputStreamOperator<R>) dataStream.transform(
                        "Custom:" + m.getCustomType(), outType, (OneInputStreamOperator) operator), t);
    }

    // ----------------------------------------------------------------
    // CEP
    // ----------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T, K, R> SingleOutputStreamOperator<R> buildCep(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamCepModel m) {
        // R5 CEP-2: event-time CEP requires an upstream watermark supply. Scan
        // the model for a <timestampsAndWatermarks> node; without one the
        // pipeline never emits watermarks and every in-flight match stays
        // buffered forever (silent no-output + unbounded state). Build-time
        // WARN per the audit's 起步 ruling; typed rejection is the end state.
        boolean hasWatermarkSupply = owner.model().getTransforms() != null && owner.model().getTransforms().stream()
                .anyMatch(x -> x instanceof io.nop.stream.flow.model.StreamTimestampsAndWatermarksModel);
        if (!hasWatermarkSupply) {
            LOG.warn("CEP pattern [{}] runs in event-time mode but the pipeline declares no"
                    + " <timestampsAndWatermarks> node — no watermark will ever fire and"
                    + " matches will never complete (R5 CEP-2)", m.getId());
        }
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (!(in instanceof KeyedStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "KeyedStream")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        if (m.getPatternRef() == null) {
            throw new StreamException(ERR_STREAM_REQUIRED_ATTR)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "patternRef")
                    .loc(t.getLocation());
        }
        CepPatternModel patternModel = owner.model().getPattern(m.getPatternRef());
        if (patternModel == null) {
            throw new StreamException(ERR_STREAM_REF_UNKNOWN)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_REF_TYPE, "<patterns>/<pattern>").param(ARG_REF_NAME, m.getPatternRef())
                    .loc(t.getLocation());
        }
        Pattern<T, ?> pattern = (Pattern<T, ?>) new CepPatternBuilder().buildFromModel(patternModel);
        KeyedStream<T, K> keyed = (KeyedStream<T, K>) in;
        PatternStream<T> patternStream = CEP.pattern((DataStream) keyed, (Pattern) pattern);
        if (m.getBean() == null) {
            throw new StreamException(ERR_STREAM_REQUIRED_ATTR)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ATTR_NAME, "bean")
                    .loc(t.getLocation());
        }
        PatternProcessFunction<T, R> selectFn = owner.resolveBean(t, m.getBean(), PatternProcessFunction.class);
        TypeInformation<R> outType = (TypeInformation<R>) UnknownTypeInformation.INSTANCE;
        return StreamModelDslBuilder.applyDeclaredParallelism(
                (SingleOutputStreamOperator<R>) patternStream.process(
                        (PatternProcessFunction) selectFn, outType), t);
    }

    // ----------------------------------------------------------------
    // sideOutput — XDSL <sideOutput> nodes are not buildable: the core
    // extraction API (SingleOutputStreamOperator.getSideOutput) exists,
    // but a side-output edge has no graph-level routing yet, so the
    // declared transform cannot become a deployable downstream vertex
    // ----------------------------------------------------------------

    private static Object buildSideOutput(StreamSideOutputModel m) {
        throw new StreamException(ERR_STREAM_NOT_IMPLEMENTED)
                .param(ARG_DETAIL, "Stream DSL <sideOutput id='" + m.getId() + "' tag='" + m.getTag()
                        + "'> is not supported yet: the side-output extraction API "
                        + "(SingleOutputStreamOperator.getSideOutput) is already available in "
                        + "nop-stream-core, but a side-output edge has no graph-level routing, "
                        + "so the <sideOutput> transform cannot be deployed as a downstream "
                        + "vertex. Consume side outputs from Java API views via "
                        + "sink(...)/print()/collect(...) instead.")
                .loc(m.getLocation());
    }

    // ----------------------------------------------------------------
    // timestampsAndWatermarks
    // ----------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T> SingleOutputStreamOperator<T> buildTimestampsAndWatermarks(
            StreamModelDslBuilder owner, StreamTransformModel t, Set<String> upstreamIds,
            Map<String, Object> streamRegistry, StreamTimestampsAndWatermarksModel m) {
        Object in = requireSingleInput(upstreamIds, streamRegistry, owner, t);
        if (!(in instanceof DataStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_TYPE)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_EXPECTED_STREAM_TYPE, "DataStream")
                    .param(ARG_ACTUAL_STREAM_TYPE, in == null ? "null" : in.getClass().getName())
                    .loc(t.getLocation());
        }
        // R5 FLOW-4: three-source-all-missing guard — an all-empty declaration
        // assembles a NoOp pass-through operator that never emits a watermark,
        // silently starving every downstream event-time consumer (windows/CEP).
        if (m.getWatermarkStrategyBean() == null && m.getTimestampAssigner() == null
                && m.getWatermarkGenerator() == null) {
            throw new StreamException(io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_REQUIRED_BODY)
                    .param(io.nop.stream.core.exceptions.NopStreamErrors.ARG_ELEMENT,
                            "timestampsAndWatermarks[" + t.getId() + "]")
                    .param(io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL,
                            "at least one of watermarkStrategyBean / timestampAssigner /"
                            + " watermarkGenerator must be declared (R5 FLOW-4)")
                    .loc(t.getLocation());
        }
        WatermarkStrategy<T> strategy;
        if (m.getWatermarkStrategyBean() != null) {
            strategy = owner.resolveBean(t, m.getWatermarkStrategyBean(), WatermarkStrategy.class);
        } else {
            strategy = new XplWatermarkStrategy<>(m.getTimestampAssigner(), m.getWatermarkGenerator());
        }
        DataStream<T> dataStream = (DataStream<T>) in;
        // F-04a (plan 1326-2 Phase 4): the node-level watermarkInterval declaration is
        // now WIRED — the declared value (default 200, or 0 = per-event emission)
        // reaches the operator instead of being silently replaced by the env-level
        // interval. Quickstart topologies declaring watermarkInterval="0" get real
        // per-event watermarks as their comments promise.
        return StreamModelDslBuilder.applyDeclaredParallelism(
                (SingleOutputStreamOperator<T>) dataStream.assignTimestampsAndWatermarks(
                        (WatermarkStrategy) strategy, m.getWatermarkInterval()), t);
    }

    // ----------------------------------------------------------------
    // helpers
    // ----------------------------------------------------------------

    private static DataStream<?> requireSingleInput(Set<String> upstreamIds,
                                                    Map<String, Object> streamRegistry,
                                                    StreamModelDslBuilder owner,
                                                    StreamTransformModel t) {
        if (upstreamIds.size() != 1) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "upstream edges")
                    .param(ARG_DETAIL, "exactly one upstream edge required, found " + upstreamIds.size())
                    .loc(t.getLocation());
        }
        String upstream = upstreamIds.iterator().next();
        Object in = streamRegistry.get(upstream);
        if (in == null) {
            throw new StreamException(ERR_STREAM_UPSTREAM_NULL)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .loc(t.getLocation());
        }
        if (!(in instanceof DataStream) && !(in instanceof KeyedStream) && !(in instanceof WindowedStream)) {
            throw new StreamException(ERR_STREAM_UPSTREAM_NOT_STREAM)
                    .param(ARG_ELEMENT, StreamModelDslBuilder.elementDesc(t))
                    .param(ARG_ACTUAL_STREAM_TYPE, in.getClass().getName())
                    .loc(t.getLocation());
        }
        // P1-XDSL-5: apply the declared edge partition (HASH + keyExpr) to the input stream.
        // Item 29: the target's declared parallelism rides along so a HASH edge into a
        // wider target spreads across the target's subtasks (see applyEdgePartition).
        return owner.applyEdgePartition((DataStream<?>) in, upstream, t.getId(), t.getParallelism());
    }

    /**
     * {@link WatermarkStrategy} backed by parsed xpl bodies for the timestamp assigner and
     * watermark generator. Either may be {@code null} (falls back to a no-op).
     */
    private static final class XplWatermarkStrategy<T> implements WatermarkStrategy<T> {

        private static final long serialVersionUID = 1L;

        private final io.nop.core.lang.eval.IEvalFunction timestampAssignerBody;
        private final io.nop.core.lang.eval.IEvalFunction watermarkGeneratorBody;

        XplWatermarkStrategy(io.nop.core.lang.eval.IEvalFunction timestampAssignerBody,
                             io.nop.core.lang.eval.IEvalFunction watermarkGeneratorBody) {
            this.timestampAssignerBody = timestampAssignerBody;
            this.watermarkGeneratorBody = watermarkGeneratorBody;
        }

        @Override
        public TimestampAssigner<T> createTimestampAssigner(TimestampAssignerSupplier.Context context) {
            if (timestampAssignerBody == null) {
                // A missing <timestampAssigner> must not NPE downstream in
                // TimestampsAndWatermarksOperator.processElement (item 11 FL-3):
                // mirror the NoOp fallback the watermark generator already has —
                // records keep their stream-record timestamp.
                return new NoOpTimestampAssigner<>();
            }
            return (event, recordTimestamp) -> io.nop.api.core.convert.ConvertHelper.toLong(
                    timestampAssignerBody.call2(null, event, recordTimestamp,
                            io.nop.stream.flow.builder.functions.XplFunctionSupport.newCallScope()));
        }

        @Override
        public WatermarkGenerator<T> createWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
            if (watermarkGeneratorBody == null) {
                return new NoOpWatermarkGenerator<>();
            }
            return new XplWatermarkGenerator<>(watermarkGeneratorBody);
        }
    }

    private static final class NoOpWatermarkGenerator<T> implements WatermarkGenerator<T> {
        @Override
        public void onEvent(T event, long eventTimestamp, WatermarkOutput output) {
        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {
        }
    }

    /**
     * Item 11 FL-3: pass-through assigner used when the DSL declares a
     * {@code <timestampsAndWatermarks>} node without a {@code <timestampAssigner>} body.
     * Keeping the record's existing (or NO) timestamp preserves the pre-assigner
     * behaviour instead of NPE-ing at execute time.
     */
    private static final class NoOpTimestampAssigner<T> implements TimestampAssigner<T> {
        @Override
        public long extractTimestamp(T element, long recordTimestamp) {
            return recordTimestamp;
        }
    }

    private static final class XplWatermarkGenerator<T> implements WatermarkGenerator<T> {

        private final io.nop.core.lang.eval.IEvalFunction body;

        XplWatermarkGenerator(io.nop.core.lang.eval.IEvalFunction body) {
            this.body = body;
        }

        @Override
        public void onEvent(T event, long eventTimestamp, WatermarkOutput output) {
            body.call3(null, event, eventTimestamp, output,
                    io.nop.stream.flow.builder.functions.XplFunctionSupport.newCallScope());
        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {
        }
    }
}
