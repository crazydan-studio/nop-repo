package io.nop.metadata.dao.entity;

import io.nop.api.core.annotations.biz.BizObjName;
import io.nop.metadata.dao.entity._gen._NopMetaManifest;


@BizObjName("NopMetaManifest")
public class NopMetaManifest extends _NopMetaManifest{


}
