package io.nop.metadata.dao.entity;

import io.nop.api.core.annotations.biz.BizObjName;
import io.nop.metadata.dao.entity._gen._NopMetaLineageEdge;


@BizObjName("NopMetaLineageEdge")
public class NopMetaLineageEdge extends _NopMetaLineageEdge{


}
