
package io.nop.metadata.biz;

import io.nop.metadata.dao.dto.CredentialBindResultDTO;
import io.nop.metadata.dao.dto.CredentialMigrationResultDTO;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.core.context.IServiceContext;
import io.nop.metadata.api.dto.CollectCatalogResultDTO;
import io.nop.metadata.api.dto.SyncExternalTablesResultDTO;
import io.nop.metadata.api.dto.TestConnectionResultDTO;
import io.nop.metadata.dao.entity.NopMetaDataSource;
import io.nop.orm.biz.ICrudBiz;


/**
 * NopMetaDataSource BizModel 契约接口。
 *
 * <p>跨模块 {@code @Inject INopMetaDataSourceBiz} 调用入口：
 * testConnection / syncExternalTables / collectCatalog / collectCatalogForTable。
 *
 * <p>接口返回具体 {@code @DataBean} DTO 供 GraphQL schema 推导强类型字段。
 */
public interface INopMetaDataSourceBiz extends ICrudBiz<NopMetaDataSource> {

    // P2-18（plan 2026-08-16-0226-3）：只读探测（无任何写操作），注解由变更类修正为查询类
    // （对齐同模块 judgeByRuleId / checkContractReadOnly 同类探测）；语义说明见
    // 实现类同名方法 javadoc 与 owner doc 安全契约段。
    @BizQuery
    TestConnectionResultDTO testConnection(@Name("dataSourceId") String dataSourceId, IServiceContext context);

    @BizMutation
    SyncExternalTablesResultDTO syncExternalTables(@Name("dataSourceId") String dataSourceId,
                                                    @Optional @Name("schemaPattern") String schemaPattern,
                                                    IServiceContext context);

    @BizMutation
    CollectCatalogResultDTO collectCatalog(@Name("dataSourceId") String dataSourceId,
                                            @Optional @Name("schemaPattern") String schemaPattern,
                                            IServiceContext context);

    @BizMutation
    CollectCatalogResultDTO collectCatalogForTable(@Name("metaEntityId") String metaEntityId,
                                                    @Optional @Name("schemaPattern") String schemaPattern,
                                                    IServiceContext context);

    @BizMutation
    CredentialBindResultDTO bindCredential(@Name("dataSourceId") String dataSourceId,
                                           @Name("credentialId") String credentialId,
                                           IServiceContext context);

    @BizMutation
    CredentialBindResultDTO unbindCredential(@Name("dataSourceId") String dataSourceId, IServiceContext context);

    @BizMutation
    CredentialMigrationResultDTO migrateDataSourcesCredential(IServiceContext context);
}
