/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.connector.file;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.core.resource.impl.FileResource;
import io.nop.stream.core.source.SourceReader;
import io.nop.stream.core.source.SourceReaderContext;
import io.nop.stream.core.source.coordinator.LocalSourceCoordinator;

/**
 * Stage 49 Phase 3: {@link SourceReader} for {@link FileSplit}. Reads a text file line by
 * line within the split's byte range, emitting each line as a {@code String} record.
 *
 * <p>Multiple splits may be assigned to one reader (parallelism < number of files). The
 * reader processes them in FIFO order; per-split cursor is tracked on the {@link FileSplit}
 * instance itself, which is what gets snapshot/restored through operator state.
 *
 * <p>The reader reports each split as finished once its cursor reaches the end offset, and
 * then requests more splits via the {@link io.nop.stream.core.source.SplitAssignmentProxy}
 * (pull model, Stage 49 D3/D4). When no more splits are available and all held splits are
 * finished, {@link #pollNext()} keeps returning empty (the operator main loop will exit on
 * its own once the bounded source signals exhaustion — for v1 we rely on the enumerator
 * marking all splits finished before signaling end-of-input via the empty-poll contract).
 */
public final class FileSourceReader implements SourceReader<String, FileSplit> {

    private static final long serialVersionUID = 1L;

    private static final Logger LOG = LoggerFactory.getLogger(FileSourceReader.class);

    /**
     * R5-CON-07: default upper bound for one aggregated line in
     * {@link #readNextLine()}. A split's byte cap is the whole file (v1 splits
     * one file per split), so an unterminated multi-GB input would otherwise
     * be buffered into the heap in a single poll. Configurable per source via
     * {@link FileSource#FileSource(String, long)}.
     */
    public static final long DEFAULT_MAX_LINE_BYTES = 16L * 1024 * 1024;

    private final SourceReaderContext context;

    /**
     * R5-CON-10: the source directory every assigned split path must be
     * contained in (defence against tampered legacy checkpoints whose split
     * payloads carry no checksum). {@code null} disables the check — only the
     * legacy test constructor allows this; {@link FileSource#createReader}
     * always supplies the directory.
     */
    private final String sourceDirectory;

    /** R5-CON-07: max bytes buffered for a single line before fail-fast. */
    private final long maxLineBytes;

    private final Deque<FileSplit> assignedSplits = new ArrayDeque<>();
    private final List<FileSplit> finishedSplits = new ArrayList<>();

    /** Currently-open split (lazy-open on first poll). */
    private transient FileSplit activeSplit;
    private transient InputStream activeReader;
    private transient long activeBytesConsumed;

    /**
     * Chunked-read buffer for {@link #readNextLine()}: one bulk
     * {@link InputStream#read(byte[])} per ~8KB instead of one synchronized
     * per-byte stream read. Cursor semantics are byte-identical to the previous
     * per-byte loop — a byte leaves this buffer exactly when it was counted as
     * consumed from the stream, and {@link #unreadBuffered()} rewinds the lone
     * lookahead byte (same contract the one-slot PushbackInputStream served).
     *
     * <p>Transient WITHOUT an inline initializer: this class is Serializable
     * (via the {@code SourceReader} contract), and Java deserialization does
     * not run field initializers — an inline {@code = new byte[8192]} would
     * deserialize as {@code null} and NPE on first read. The buffer is
     * allocated in {@link #openSplit(FileSplit)} together with the
     * pos/limit reset.
     */
    private transient byte[] readBuf;
    private transient int readBufPos;
    private transient int readBufLimit;

    /** Whether the reader has ever received at least one split (avoids premature finish). */
    private transient boolean everAssigned;

    /** Whether the reader has asked the enumerator for more splits (avoid re-request storms). */
    private transient boolean requestedMoreSplits;

    public FileSourceReader(SourceReaderContext context) {
        this(context, null, DEFAULT_MAX_LINE_BYTES);
    }

    /**
     * Full constructor: {@code sourceDirectory} enables the R5-CON-10 split-path
     * containment check; {@code maxLineBytes} bounds the R5-CON-07 line
     * aggregation buffer. {@link FileSource#createReader} always uses this
     * constructor; the single-arg variant stays for existing tests.
     */
    public FileSourceReader(SourceReaderContext context, String sourceDirectory, long maxLineBytes) {
        this.context = context;
        this.sourceDirectory = sourceDirectory;
        this.maxLineBytes = maxLineBytes;
    }

    @Override
    public void start() {
        requestMoreSplitsIfNeeded();
    }

    @Override
    public void addSplits(List<FileSplit> splits) {
        if (splits == null || splits.isEmpty()) {
            return;
        }
        synchronized (this) {
            assignedSplits.addAll(splits);
            everAssigned = true;
            requestedMoreSplits = false;
        }
        LOG.debug("FileSourceReader subtask={} assigned {} splits (total pending={})",
                context == null ? "?" : context.getSubtaskIndex(), splits.size(), assignedSplits.size());
    }

    @Override
    public boolean isFinished() {
        synchronized (this) {
            boolean consumedAllAssigned = everAssigned
                    && activeSplit == null
                    && assignedSplits.isEmpty();
            // Empty-source early-exit: if the reader has been started and asked the
            // coordinator for splits, and the coordinator confirms the enumerator is
            // exhausted (no splits were ever discovered for this source), terminate.
            // Without this, an empty-directory source would loop forever.
            if (!consumedAllAssigned && !everAssigned && context != null
                    && context.getAssignmentProxy() instanceof LocalSourceCoordinator.ReaderChannel) {
                LocalSourceCoordinator.ReaderChannel<?> channel =
                        (LocalSourceCoordinator.ReaderChannel<?>) context.getAssignmentProxy();
                if (requestedMoreSplits && channel.isEnumeratorExhausted()) {
                    return true;
                }
            }
            return consumedAllAssigned;
        }
    }

    @Override
    public Optional<String> pollNext() throws Exception {
        for (;;) {
            String line;
            synchronized (this) {
                if (activeReader == null) {
                    FileSplit next = assignedSplits.poll();
                    if (next == null) {
                        // No active split and no pending splits. Request more once; if
                        // still none, the operator main loop exits on the empty-poll signal.
                        requestMoreSplitsIfNeeded();
                        return Optional.empty();
                    }
                    openSplit(next);
                }
                line = readNextLine();
                if (line != null && activeSplit != null) {
                    // AR-15-②: the cursor advance runs INSIDE the same monitor that
                    // snapshotState uses — the checkpoint thread can never observe a
                    // torn cursor (line emitted but cursor still at the line start, or
                    // vice versa). Previously this write sat outside the monitor (JMM
                    // race with concurrent snapshotState).
                    //
                    // Cursor is computed from the exact number of bytes consumed from the
                    // stream (including the line terminator), so it is correct for both
                    // LF and CRLF line endings on any platform.
                    long newOffset = activeSplit.getStartOffset() + activeBytesConsumed;
                    activeSplit = activeSplit.withCurrentOffset(newOffset);
                }
            }

            if (line != null) {
                return Optional.of(line);
            }

            // Reached EOF on the active reader
            synchronized (this) {
                closeActiveReader();
                if (activeSplit != null) {
                    finishedSplits.add(activeSplit.withCurrentOffset(activeSplit.getEndOffset()));
                    reportFinishedToCoordinator(activeSplit.splitId());
                    activeSplit = null;
                }
                // Loop back to open the next split (if any)
            }
        }
    }

    private void openSplit(FileSplit split) throws IOException {
        Path path = Paths.get(split.getFilePath());
        // R5-CON-10: containment check. A split's path travels through the
        // checkpoint payload; v1 legacy checkpoint bytes carry no checksum, so a
        // tampered/corrupted payload could otherwise point the reader at any
        // readable file on the machine. Only paths under the configured source
        // directory are accepted (checked before existence, so probing for
        // out-of-sandbox files yields the containment failure, not a file probe).
        if (sourceDirectory != null) {
            Path base = Paths.get(sourceDirectory).toAbsolutePath().normalize();
            Path normalized = path.toAbsolutePath().normalize();
            if (!normalized.startsWith(base)) {
                throw new IOException("Split path escapes the source directory — refusing to open "
                        + split.getFilePath() + " (source directory: " + sourceDirectory
                        + "; tampered or foreign checkpoint payload?)");
            }
        }
        if (!Files.exists(path)) {
            throw new IOException("File not found for split: " + split);
        }
        // ST-7: the read entry goes through the IResource abstraction (FileResource over
        // the local file) — the local-file contract is preserved; the reader merely gains
        // VFS resource semantics. FileResource.getInputStream opens a FileInputStream,
        // which the exact channel positioning below requires.
        FileResource resource = new FileResource(path.toString(), path.toFile());
        FileInputStream fis = (FileInputStream) resource.getInputStream();
        // Seek to the cursor (for restored splits, resume from checkpointed offset).
        // AR-15-①: an unfulfillable seek is a typed failure, never a silent read from
        // the wrong position — mirrors the DirectoryFileSourceFunction.emitRemaining
        // paradigm (skipped != cursor → IOException). Implemented via exact channel
        // positioning + size validation because FileInputStream.skip(n) may position
        // PAST EOF via lseek and still report n skipped, hiding a truncated file.
        long cursor = split.getCurrentOffset();
        java.nio.channels.FileChannel channel = fis.getChannel();
        long fileSize;
        try {
            fileSize = channel.size();
        } catch (IOException e) {
            fis.close();
            throw e;
        }
        if (cursor > fileSize || split.getEndOffset() > fileSize) {
            fis.close();
            throw new IOException("Failed to seek to cursor " + cursor + " of " + path
                    + " (file size " + fileSize + ", split endOffset " + split.getEndOffset()
                    + " — truncated file or stale cursor?)");
        }
        try {
            channel.position(cursor);
        } catch (IOException e) {
            fis.close();
            throw new IOException("Failed to seek to cursor " + cursor + " of " + path
                    + " (positioned only " + channel.position() + " bytes — truncated file?)", e);
        }
        activeReader = fis;
        // Allocate/reset the chunk buffer here (NOT via a field initializer —
        // a deserialized reader has no initializer run and must not NPE on
        // first read).
        readBuf = new byte[8192];
        readBufPos = 0;
        readBufLimit = 0;
        activeSplit = split;
        // Seed the byte counter with the bytes already consumed before this open (the
        // skip above positioned the stream at the split's cursor). pollNext computes the
        // new cursor as startOffset + activeBytesConsumed, so seeding with
        // (currentOffset - startOffset) keeps the restored cursor as the base instead of
        // silently regressing it to startOffset on the first post-restore snapshot.
        activeBytesConsumed = split.getCurrentOffset() - split.getStartOffset();
        LOG.debug("FileSourceReader opened split {} at offset {}",
                split.getFilePath(), split.getCurrentOffset());
    }

    /**
     * Reads one text line while counting the exact number of bytes consumed from the
     * underlying stream (including the terminator). Supports LF, CRLF and lone CR as
     * line terminators, so the resulting cursor offset is platform-independent.
     *
     * <p>AR-15-③: reading is capped at {@code split.getEndOffset()} — if the file grew
     * after the split was enumerated, bytes beyond the split's byte range are never
     * emitted (the split boundary is the contract; a later split covers the grown
     * region).
     *
     * <p>R5-CON-07: the aggregation buffer is bounded by {@code maxLineBytes}. A
     * multi-GB file without a single line terminator would otherwise be buffered
     * into the heap in one poll (per parallel subtask); exceeding the bound is a
     * typed failure, never a silent truncation.
     */
    private String readNextLine() throws IOException {
        long cap = activeSplit.getEndOffset() - activeSplit.getStartOffset();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        while (activeBytesConsumed < cap) {
            int b = readBuffered();
            if (b == -1) {
                break;
            }
            activeBytesConsumed++;
            if (b == '\n') {
                return out.toString(StandardCharsets.UTF_8);
            }
            if (b == '\r') {
                if (activeBytesConsumed < cap) {
                    int next = readBuffered();
                    if (next != -1) {
                        activeBytesConsumed++;
                        if (next != '\n') {
                            // Lone CR terminator: rewind the non-newline byte to
                            // the start of the following line (it never counted).
                            unreadBuffered();
                            activeBytesConsumed--;
                        }
                    }
                }
                return out.toString(StandardCharsets.UTF_8);
            }
            if (out.size() >= maxLineBytes) {
                throw new IOException("Line exceeds maxLineBytes=" + maxLineBytes
                        + " in split " + activeSplit + " (" + out.size()
                        + " bytes buffered with no line terminator) — fail fast instead of "
                        + "buffering an unbounded line; fix the input or raise the limit");
            }
            out.write(b);
        }
        // EOF (real end-of-file or the endOffset cap) reached: if no bytes were
        // collected this is the end of the stream, otherwise the final unterminated
        // line is returned.
        return out.size() == 0 ? null : out.toString(StandardCharsets.UTF_8);
    }

    /** One byte from the chunk buffer, refilling from the stream when drained. */
    private int readBuffered() throws IOException {
        if (readBufPos >= readBufLimit) {
            readBufLimit = activeReader.read(readBuf);
            readBufPos = 0;
            if (readBufLimit <= 0) {
                return -1;
            }
        }
        return readBuf[readBufPos++] & 0xFF;
    }

    /** Rewinds the single lookahead byte (only valid immediately after {@link #readBuffered()}). */
    private void unreadBuffered() {
        readBufPos--;
    }

    private void closeActiveReader() {
        if (activeReader != null) {
            try {
                activeReader.close();
            } catch (IOException e) {
                LOG.warn("Failed to close reader for split {}", activeSplit, e);
            }
            activeReader = null;
        }
    }

    private void requestMoreSplitsIfNeeded() {
        if (requestedMoreSplits) {
            return;
        }
        if (context == null || context.getAssignmentProxy() == null) {
            return;
        }
        if (assignedSplits.isEmpty() && activeSplit == null) {
            context.getAssignmentProxy().requestSplits(
                    context.getSubtaskIndex(), Optional.empty());
            requestedMoreSplits = true;
        }
    }

    private void reportFinishedToCoordinator(String splitId) {
        if (context == null || context.getAssignmentProxy() == null) {
            return;
        }
        List<String> finished = new ArrayList<>();
        finished.add(splitId);
        context.getAssignmentProxy().reportFinishedSplits(context.getSubtaskIndex(), finished);
    }

    @Override
    public List<FileSplit> snapshotState(long checkpointId) {
        synchronized (this) {
            List<FileSplit> snapshot = new ArrayList<>();
            // Active split (with current cursor) + all pending assigned splits.
            if (activeSplit != null) {
                snapshot.add(activeSplit);
            }
            snapshot.addAll(assignedSplits);
            return snapshot;
        }
    }

    @Override
    public void restoreState(List<FileSplit> splits) {
        if (splits == null || splits.isEmpty()) {
            return;
        }
        synchronized (this) {
            closeActiveReader();
            activeSplit = null;
            assignedSplits.clear();
            finishedSplits.clear();
            assignedSplits.addAll(splits);
        }
        LOG.debug("FileSourceReader restored {} splits", splits.size());
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) {
        // v1: no external-side acks needed for file reads (file offset is naturally idempotent).
    }

    @Override
    public void close() {
        synchronized (this) {
            closeActiveReader();
        }
    }

    // ====================== Test accessors ======================

    int getPendingSplitCount() {
        synchronized (this) {
            return assignedSplits.size();
        }
    }

    int getFinishedSplitCount() {
        synchronized (this) {
            return finishedSplits.size();
        }
    }

    /** Test helper: returns a defensive copy of currently-held split ids (active + pending). */
    List<String> getHeldSplitIds() {
        synchronized (this) {
            List<String> ids = new ArrayList<>();
            if (activeSplit != null) ids.add(activeSplit.splitId());
            for (FileSplit s : assignedSplits) ids.add(s.splitId());
            return ids;
        }
    }
}
