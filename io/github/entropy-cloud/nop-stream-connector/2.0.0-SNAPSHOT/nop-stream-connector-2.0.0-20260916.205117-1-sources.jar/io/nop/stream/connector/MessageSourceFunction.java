/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.connector;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import io.nop.api.core.message.IMessageConsumeContext;
import io.nop.api.core.message.IMessageConsumer;
import io.nop.api.core.message.IMessageService;
import io.nop.api.core.message.IMessageSubscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.stream.core.common.functions.source.SourceConsistencyCapability;
import io.nop.stream.core.common.functions.source.SourceFunction;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ACTUAL_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_EXPECTED_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_TYPE_MISMATCH;

/**
 * Adapts nop-message's {@link IMessageService} to nop-stream's {@link SourceFunction}.
 * <p>
 * Subscribes to a message topic and emits received messages into the stream.
 * Blocks until cancelled.
 * <p>
 * Supports multi-partition subscription: when a {@code subtaskIndex} and {@code totalParallelism}
 * are provided, the function can use them to subscribe to topic partitions in a deterministic
 * manner (e.g., topic-partition-{subtaskIndex}). This enables parallel consumption across
 * multiple subtasks without overlap.
 */
public class MessageSourceFunction<T> implements SourceFunction<T> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(MessageSourceFunction.class);

    private final IMessageService messageService;
    private final String topic;
    private final Class<T> typeClass;

    /** Subtask index for partition-based subscription (-1 means no partitioning) */
    private final int subtaskIndex;
    /** Total parallelism for partition-based subscription */
    private final int totalParallelism;

    private volatile boolean running = true;
    private volatile boolean failed = false;
    /**
     * P1-9: captures the first error raised inside {@code onMessage} so {@code run()}
     * can rethrow it instead of silently returning normally. Without this, a
     * collect() failure was logged, the run loop exited cleanly, and the pipeline
     * was misreported as a successful EOS — silently losing data.
     */
    private volatile Throwable pendingError;
    private volatile IMessageSubscription subscription;
    private transient volatile CountDownLatch shutdownLatch = new CountDownLatch(1);

    /**
     * Creates a MessageSourceFunction that subscribes to a single topic.
     */
    public MessageSourceFunction(IMessageService messageService, String topic) {
        this(messageService, topic, null, -1, 0);
    }

    public MessageSourceFunction(IMessageService messageService, String topic, Class<T> typeClass) {
        this(messageService, topic, typeClass, -1, 0);
    }

    public MessageSourceFunction(IMessageService messageService, String topic,
                                  int subtaskIndex, int totalParallelism) {
        this(messageService, topic, null, subtaskIndex, totalParallelism);
    }

    public MessageSourceFunction(IMessageService messageService, String topic,
                                  Class<T> typeClass, int subtaskIndex, int totalParallelism) {
        if (messageService == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "messageService");
        }
        if (topic == null || topic.isEmpty()) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "topic");
        }
        if (subtaskIndex >= 0 && totalParallelism <= 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "totalParallelism")
                    .param(ARG_DETAIL, "must be positive when subtaskIndex is set");
        }
        if (subtaskIndex >= 0 && subtaskIndex >= totalParallelism) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "subtaskIndex")
                    .param(ARG_DETAIL, "must be < totalParallelism");
        }
        this.messageService = messageService;
        this.topic = topic;
        this.typeClass = typeClass;
        this.subtaskIndex = subtaskIndex;
        this.totalParallelism = totalParallelism;
    }

    /**
     * Returns the effective topic for this subtask. When partition-aware,
     * returns "{topic}-{subtaskIndex}"; otherwise returns the base topic.
     */
    public String getEffectiveTopic() {
        if (subtaskIndex >= 0) {
            return topic + "-" + subtaskIndex;
        }
        return topic;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void run(final SourceContext<T> ctx) throws Exception {
        // Reset lifecycle state: a region restart reuses this instance (the rebuilt
        // operator chain shares the source function) after cancel() set running=false.
        // Without this reset the wait loop below exits immediately and the source is
        // silently treated as EOS (data flow stall). pendingError/failed from a prior
        // failed run must also be cleared, and the shutdown latch must be fresh because
        // the previous cancel() already counted it down.
        this.pendingError = null;
        this.failed = false;
        this.running = true;
        this.shutdownLatch = new CountDownLatch(1);

        String effectiveTopic = getEffectiveTopic();
        subscription = messageService.subscribe(effectiveTopic, new IMessageConsumer() {
            @Override
            public Object onMessage(String t, Object msg, IMessageConsumeContext context) {
                if (typeClass != null && msg != null && !typeClass.isInstance(msg)) {
                    // P1-9: capture-and-rethrow. The subscriber thread propagates the
                    // failure to run() via pendingError so the pipeline fails instead
                    // of silently marking EOS as a success.
                    StreamException typeMismatch = new StreamException(ERR_STREAM_TYPE_MISMATCH);
                    typeMismatch.param(ARG_EXPECTED_TYPE, typeClass.getName())
                            .param(ARG_ACTUAL_TYPE, msg.getClass().getName());
                    if (pendingError == null) {
                        pendingError = typeMismatch;
                    }
                    failed = true;
                    if (shutdownLatch != null) {
                        shutdownLatch.countDown();
                    }
                    return null;
                }
                synchronized (ctx) {
                    try {
                        ctx.collect((T) msg);
                    } catch (Exception e) {
                        // P1-9: do NOT swallow the failure. Record it as the pending
                        // error so run() rethrows after the loop exits, surfacing the
                        // pipeline as FAILED rather than a false-success EOS. No LOG here:
                        // the pendingError rethrow from run() is the single observability
                        // channel (log-and-throw would double-report the same failure).
                        if (pendingError == null) {
                            pendingError = e;
                        }
                        failed = true;
                        if (shutdownLatch != null) {
                            shutdownLatch.countDown();
                        }
                        return null;
                    }
                }
                return null;
            }
        });

        while (running && !failed) {
            shutdownLatch.await(1, TimeUnit.SECONDS);
        }

        // P1-9: surface the captured error to the invokable so the task is
        // recognized as FAILED rather than completing normally (silent data loss).
        if (pendingError != null) {
            if (pendingError instanceof Exception) {
                throw (Exception) pendingError;
            }
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "Message source failed: " + pendingError.getMessage());
        }
    }

    @Override
    public void cancel() {
        running = false;
        if (shutdownLatch != null) {
            shutdownLatch.countDown();
        }
        if (subscription != null) {
            subscription.cancel();
        }
    }

    @Override
    public SourceConsistencyCapability getSourceConsistency() {
        return SourceConsistencyCapability.AT_LEAST_ONCE;
    }
}
