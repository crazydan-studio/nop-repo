/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.connector;

import io.nop.api.core.message.IMessageService;

import io.nop.stream.core.common.functions.sink.SinkConsistencyCapability;
import io.nop.stream.core.common.functions.SinkFunction;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;

/**
 * Adapts nop-message's {@link IMessageService} to nop-stream's {@link SinkFunction}.
 * <p>
 * Each consumed record is sent synchronously to the specified message topic.
 */
public class MessageSinkFunction<T> implements SinkFunction<T> {

    private static final long serialVersionUID = 1L;

    private final IMessageService messageService;
    private final String topic;

    public MessageSinkFunction(IMessageService messageService, String topic) {
        if (messageService == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "messageService");
        }
        if (topic == null || topic.isEmpty()) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "topic");
        }
        this.messageService = messageService;
        this.topic = topic;
    }

    @Override
    public void consume(T value) {
        messageService.send(topic, value);
    }

    @Override
    public SinkConsistencyCapability getSinkConsistency() {
        return SinkConsistencyCapability.AT_LEAST_ONCE;
    }
}
