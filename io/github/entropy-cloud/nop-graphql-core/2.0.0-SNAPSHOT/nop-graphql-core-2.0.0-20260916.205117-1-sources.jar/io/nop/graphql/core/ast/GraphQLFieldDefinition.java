/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.graphql.core.ast;

import io.nop.api.core.annotations.biz.BizMakerCheckerMeta;
import io.nop.api.core.annotations.meta.PropMeta;
import io.nop.api.core.auth.ActionAuthMeta;
import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.convert.ITypeConverter;
import io.nop.api.core.convert.IdentityTypeConverter;
import io.nop.auth.api.mfa.MfaRequiredMeta;
import io.nop.commons.type.StdDataType;
import io.nop.commons.util.DateHelper;
import io.nop.commons.util.StringHelper;
import io.nop.core.context.IServiceContext;
import io.nop.core.context.action.IServiceAction;
import io.nop.core.reflect.IClassModel;
import io.nop.core.reflect.IFunctionModel;
import io.nop.core.type.IGenericType;
import io.nop.graphql.core.GraphQLConstants;
import io.nop.graphql.core.IDataFetcher;
import io.nop.graphql.core.ast._gen._GraphQLFieldDefinition;
import io.nop.graphql.core.engine.GraphQLActionAuthChecker;
import io.nop.graphql.core.reflection.IGraphQLArgsNormalizer;
import io.nop.xlang.xmeta.IObjPropMeta;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static io.nop.graphql.core.GraphQLConfigs.CFG_GRAPHQL_IGNORE_MILLIS_IN_TIMESTAMP;

public class GraphQLFieldDefinition extends _GraphQLFieldDefinition implements IGraphQLFieldDefinition {
    private IDataFetcher fetcher;

    private boolean autoCreate;

    /**
     * 如果graphql的对象定义是从IObjMeta转换得到，则这里可以保存原始的propMeta，从而获得更多的扩展配置。
     * 如果把所有propMeta上的信息都转换为GraphQL的directive定义，则会产生很多重复性工作。
     */
    private IObjPropMeta propMeta;

    private PropMeta beanPropMeta;

    private Boolean lazy;

    private IFunctionModel functionModel;

    private IServiceAction serviceAction;

    private GraphQLOperationType operationType;

    private ActionAuthMeta auth;

    private String operationName;

    private IClassModel sourceClassModel;

    /**
     * 如果开启maker checker机制，则在执行mutation操作之前，会先尝试执行tryAction。 如果要求审批，则会插入审批记录，并抛出异常，从而中断实际修改动作
     */
    private IServiceAction tryAction;

    private BizMakerCheckerMeta makerCheckerMeta;

    /**
     * 操作级 MFA 元数据（@MfaRequired，存在即敏感操作）。executor 检查点据此调用
     * IOperationMfaChecker；非 null 才参与拦截。deepClone拷贝对齐 makerCheckerMeta 先例
     * （元数据字段随克隆传播，见deepClone注释中的执行绑定排除清单）。
     */
    private MfaRequiredMeta mfaRequiredMeta;

    private IGraphQLArgsNormalizer argsNormalizer;

    private int propId;

    private IGenericType javaType;

    private ITypeConverter typeConverter;

    @Override
    public GraphQLFieldDefinition deepClone() {
        GraphQLFieldDefinition field = super.deepClone();
        field.setPropMeta(propMeta);
        field.setBeanPropMeta(beanPropMeta);
        field.setPropId(propId);
        field.setJavaType(javaType);
        field.setFunctionModel(functionModel);
        field.setSourceClassModel(sourceClassModel);
        field.setArgsNormalizer(argsNormalizer);
        field.setAuth(auth);
        field.setMfaRequiredMeta(mfaRequiredMeta);
        field.setMakerCheckerMeta(makerCheckerMeta);
        field.setOperationName(operationName);
        // fetcher/tryAction/serviceAction是运行时装配的执行绑定（闭包/bean引用），刻意不随
        // deepClone复制——克隆体用于schema导出等非执行场景，混入执行绑定会造成隐性执行入口。
        // 若未来克隆体需要参与执行，须显式补齐这三个字段并重新评估
        return field;
    }

    public ITypeConverter getTypeConverter() {
        if (typeConverter == null) {
            if (CFG_GRAPHQL_IGNORE_MILLIS_IN_TIMESTAMP.get() && javaType != null) {
                if (javaType.getRawClass() == Timestamp.class) {
                    typeConverter = (v, errorFactory) -> {
                        if (propMeta != null) {
                            String pattern = (String) propMeta.prop_get(GraphQLConstants.ATTR_GRAPHQL_DATE_PATTERN);
                            if (!StringHelper.isEmpty(pattern))
                                return DateHelper.formatTimestamp(ConvertHelper.toTimestamp(v, errorFactory), pattern);
                        }
                        return DateHelper.formatTimestampNoMillis(ConvertHelper.toTimestamp(v, errorFactory));
                    };
                    return typeConverter;
                }
            }

            if (getType().isScalarType()) {
                StdDataType dataType = getType().getStdDataType();
                typeConverter = dataType.getConverter();
            } else {
                typeConverter = IdentityTypeConverter.INSTANCE;
            }
        }
        return typeConverter;
    }

    public boolean isAllowAccess(IServiceContext context) {
        return GraphQLActionAuthChecker.isAllowAccess(auth, context);
    }

    public boolean isAutoCreate() {
        return autoCreate;
    }

    public void setAutoCreate(boolean autoCreate) {
        this.autoCreate = autoCreate;
    }

    public String getDisplayName() {
        if (propMeta != null)
            return propMeta.getDisplayName();

        if (beanPropMeta != null) {
            if (!StringHelper.isEmpty(beanPropMeta.displayName()))
                return beanPropMeta.displayName();
        }

        return getName();
    }

    public IGenericType getJavaType() {
        return javaType;
    }

    public void setJavaType(IGenericType javaType) {
        this.javaType = javaType;
    }

    public List<GraphQLArgumentDefinition> cloneArguments() {
        List<GraphQLArgumentDefinition> args = this.getArguments();
        if (args == null)
            return null;
        if (args.isEmpty())
            return Collections.emptyList();

        return args.stream().map(GraphQLArgumentDefinition::deepClone).collect(Collectors.toList());
    }

    public int getPropId() {
        return propId;
    }

    public void setPropId(int propId) {
        this.propId = propId;
    }

    public int getPropIdFromMeta() {
        if (propMeta != null) {
            Integer propId = propMeta.getPropId();
            if (propId == null)
                return 0;
            return propId;
        }
        if (beanPropMeta != null)
            return beanPropMeta.propId();
        return 0;
    }

    public void initArgPropId() {
        List<GraphQLArgumentDefinition> args = getArguments();
        if (args != null) {
            for (int i = 0, n = args.size(); i < n; i++) {
                args.get(i).setPropId(i + 1);
            }
        }
    }

    public IGraphQLArgsNormalizer getArgsNormalizer() {
        return argsNormalizer;
    }

    public void setArgsNormalizer(IGraphQLArgsNormalizer argsNormalizer) {
        this.argsNormalizer = argsNormalizer;
    }

    public Boolean getLazy() {
        return lazy;
    }

    public void setLazy(Boolean lazy) {
        this.lazy = lazy;
    }

    public IClassModel getSourceClassModel() {
        return sourceClassModel;
    }

    public void setSourceClassModel(IClassModel sourceClassModel) {
        this.sourceClassModel = sourceClassModel;
    }

    public BizMakerCheckerMeta getMakerCheckerMeta() {
        return makerCheckerMeta;
    }

    public void setMakerCheckerMeta(BizMakerCheckerMeta makerCheckerMeta) {
        this.makerCheckerMeta = makerCheckerMeta;
    }

    public MfaRequiredMeta getMfaRequiredMeta() {
        return mfaRequiredMeta;
    }

    public void setMfaRequiredMeta(MfaRequiredMeta mfaRequiredMeta) {
        this.mfaRequiredMeta = mfaRequiredMeta;
    }

    public String getTryMethod() {
        return makerCheckerMeta != null ? makerCheckerMeta.getTryMethod() : null;
    }

    public String getCancelMethod() {
        return makerCheckerMeta != null ? makerCheckerMeta.getCancelMethod() : null;
    }

    public String getOperationName() {
        return operationName;
    }

    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }

    public ActionAuthMeta getAuth() {
        return auth;
    }

    public void setAuth(ActionAuthMeta auth) {
        this.auth = auth;
    }

    public IServiceAction getTryAction() {
        return tryAction;
    }

    public void setTryAction(IServiceAction tryAction) {
        this.tryAction = tryAction;
    }

    public GraphQLOperationType getOperationType() {
        return operationType;
    }

    public void setOperationType(GraphQLOperationType operationType) {
        this.operationType = operationType;
    }

    public IFunctionModel getFunctionModel() {
        return functionModel;
    }

    public void setFunctionModel(IFunctionModel functionModel) {
        checkAllowChange();
        this.functionModel = functionModel;
    }

    public IServiceAction getServiceAction() {
        return serviceAction;
    }

    public void setServiceAction(IServiceAction serviceAction) {
        checkAllowChange();
        this.serviceAction = serviceAction;
    }

    public IDataFetcher getFetcher() {
        return fetcher;
    }

    public void setFetcher(IDataFetcher fetcher) {
        checkAllowChange();
        this.fetcher = fetcher;
    }

    public IObjPropMeta getPropMeta() {
        return propMeta;
    }

    public void setPropMeta(IObjPropMeta propMeta) {
        checkAllowChange();
        this.propMeta = propMeta;
    }

    public PropMeta getBeanPropMeta() {
        return beanPropMeta;
    }

    public void setBeanPropMeta(PropMeta beanPropMeta) {
        checkAllowChange();
        this.beanPropMeta = beanPropMeta;
    }

    public GraphQLArgumentDefinition getArg(String name) {
        List<GraphQLArgumentDefinition> args = getArguments();
        if (args == null)
            return null;
        for (GraphQLArgumentDefinition arg : args) {
            if (arg.getName().equals(name))
                return arg;
        }
        return null;
    }

    public List<String> getArgNames() {
        List<GraphQLArgumentDefinition> args = getArguments();
        if (args == null)
            return null;
        return args.stream().map(GraphQLArgumentDefinition::getName).collect(Collectors.toList());
    }
}