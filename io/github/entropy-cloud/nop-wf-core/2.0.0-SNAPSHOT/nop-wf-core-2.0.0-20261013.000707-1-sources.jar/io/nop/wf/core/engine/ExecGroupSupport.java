package io.nop.wf.core.engine;

import io.nop.wf.core.IWorkflowStep;
import io.nop.wf.core.NopWfCoreConstants;
import io.nop.wf.core.impl.IWorkflowStepImplementor;
import io.nop.wf.core.model.WfExecGroupType;

import java.util.List;

public class ExecGroupSupport {
    public static boolean isSameExecGroup(IWorkflowStepImplementor stepA, IWorkflowStepImplementor stepB) {
        if (stepA.getRecord().getExecGroup() != null)
            return stepA.getRecord().getExecGroup().equals(stepB.getRecord().getExecGroup());
        return false;
    }

    /**
     * 当步骤结束时判断是否整个execGroup也应该结束
     */
    public static boolean shouldExecGroupComplete(IWorkflowStepImplementor step) {
        WfExecGroupType execGroupType = step.getExecGroupType();
        if (execGroupType == WfExecGroupType.OR_GROUP)
            return true;

        if (execGroupType == WfExecGroupType.VOTE_GROUP) {
            return isVoteGroupComplete(step);
        }

        // 其他执行分组类型需要所有组内步骤都结束
        return step.getStepsInSameExecGroup(false, false).isEmpty();
    }

    private static boolean isVoteGroupComplete(IWorkflowStepImplementor step) {
        List<? extends IWorkflowStep> steps = step.getStepsInSameExecGroup(true, true);
        int totalWeight = 0;
        int completeWeight = 0;

        for (IWorkflowStep member : steps) {
            // 排除判定是成员级语义（已取消/已转交的成员不计票）；原step.引用恒为当前触发步骤
            // （ACTIVATED态恒false），转办场景下同一人新旧实例双重计数使阈值分母虚高
            if (member.isExcludeInExecGroup())
                continue;

            Integer weight = member.getRecord().getVoteWeight();
            if (weight == null)
                weight = 1;

            totalWeight += weight;

            // 仅考虑成功完成的步骤。member == step 为当前正在执行 agree 的步骤，
            // 调用本方法时尚未 doExitStep，但语义上应视为已完成
            if (member == step || member.isCompleted())
                completeWeight += weight;
        }

        Integer passWeight = step.getModel().getPassWeight();
        if (passWeight != null) {
            if (completeWeight >= passWeight)
                return true;
        }

        Double passPercent = step.getModel().getPassPercent();
        // 缺省要求半数以上通过
        if (passPercent == null && passWeight == null)
            passPercent = 0.5;

        if (passPercent != null) {
            return completeWeight * 1.0 / totalWeight >= passPercent;
        }

        return false;
    }

    /**
     * 当本步骤拒绝的时候判断是否整个execGroup也应该拒绝
     */
    public static boolean shouldExecGroupReject(IWorkflowStepImplementor step) {
        WfExecGroupType execGroupType = step.getExecGroupType();
        if (execGroupType == WfExecGroupType.VOTE_GROUP) {
            return isVoteGroupReject(step);
        }

        return true;
    }

    private static boolean isVoteGroupReject(IWorkflowStepImplementor step) {
        List<? extends IWorkflowStep> steps = step.getStepsInSameExecGroup(true, true);
        int totalWeight = 0;
        int rejectWeight = 0;

        for (IWorkflowStep member : steps) {
            // 排除判定是成员级语义（已取消/已转交的成员不计票）；原step.引用恒为当前触发步骤
            // （ACTIVATED态恒false），转办场景下同一人新旧实例双重计数使阈值分母虚高
            if (member.isExcludeInExecGroup())
                continue;

            Integer weight = member.getRecord().getVoteWeight();
            if (weight == null)
                weight = 1;

            totalWeight += weight;

            // member == step: 当前步骤正在 reject，不会通过，计入 rejectWeight
            if (member == step) {
                rejectWeight += weight;
                continue;
            }

            if (member.isCompleted() || member.isActivated() || member.isWaiting())
                continue;

            // 已经完成，且没有成功的步骤
            rejectWeight += weight;
        }

        Integer passWeight = step.getModel().getPassWeight();
        if (passWeight != null) {
            // 剩下的步骤已经不足以通过
            if (totalWeight - rejectWeight < passWeight)
                return true;
        }

        Double passPercent = step.getModel().getPassPercent();
        // 缺省要求半数以上通过
        if (passPercent == null && passWeight == null)
            passPercent = 0.5;

        if (passPercent != null) {
            return (1.0 - rejectWeight * 1.0 / totalWeight) < passPercent;
        }

        return false;
    }

    public static void skipExecGroupMembers(WorkflowEngineImpl engine, IWorkflowStepImplementor step, WfRuntime wfRt) {
        List<? extends IWorkflowStep> members = step.getStepsInSameExecGroup(false, false);
        for (IWorkflowStep member : members) {
            engine.doExitStep((IWorkflowStepImplementor) member, NopWfCoreConstants.WF_STEP_STATUS_SKIPPED, wfRt);
        }
    }

    /**
     * SEQ_GROUP 顺序推进：当组内某个步骤正常完成时，激活同组中 execOrder 仅次于它的 WAITING 步骤。
     * 仅在 doExitStep 且 status=COMPLETED 的路径上调用（不包括 reject/withdraw/kill）。
     */
    public static void activateNextSeqStep(WorkflowEngineImpl engine, IWorkflowStepImplementor step, WfRuntime wfRt) {
        List<? extends IWorkflowStep> members = step.getStepsInSameExecGroup(false, false);
        Integer currentOrder = step.getRecord().getExecOrder();
        if (currentOrder == null)
            return;

        IWorkflowStepImplementor nextStep = null;
        Integer nextOrder = null;
        for (IWorkflowStep member : members) {
            if (!member.isWaiting())
                continue;
            Integer memberOrder = member.getRecord().getExecOrder();
            if (memberOrder == null)
                continue;
            if (memberOrder > currentOrder) {
                if (nextOrder == null || memberOrder < nextOrder) {
                    nextOrder = memberOrder;
                    nextStep = (IWorkflowStepImplementor) member;
                }
            }
        }

        if (nextStep != null) {
            engine.activateSeqStep(nextStep);
        }
    }
}
