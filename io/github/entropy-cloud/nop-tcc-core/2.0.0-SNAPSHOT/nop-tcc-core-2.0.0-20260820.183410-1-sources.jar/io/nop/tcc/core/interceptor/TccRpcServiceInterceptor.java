/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.tcc.core.interceptor;

import io.nop.api.core.beans.ApiRequest;
import io.nop.api.core.beans.ApiResponse;
import io.nop.api.core.rpc.IRpcServiceInterceptor;
import io.nop.api.core.rpc.IRpcServiceInvocation;
import io.nop.api.core.util.ApiHeaders;
import io.nop.core.context.TccContext;
import io.nop.tcc.api.ITccEngine;
import io.nop.tcc.api.TccBranchRequest;
import io.nop.tcc.core.impl.TccHelper;
import io.nop.tcc.core.meta.ITccServiceMetaLoader;
import io.nop.tcc.core.meta.TccMethodMeta;
import jakarta.inject.Inject;

import java.util.concurrent.CompletionStage;

public class TccRpcServiceInterceptor implements IRpcServiceInterceptor {

    private final ITccEngine tccEngine;
    private final ITccServiceMetaLoader serviceMetaLoader;

    @Inject
    public TccRpcServiceInterceptor(ITccEngine engine, ITccServiceMetaLoader serviceMetaLoader) {
        this.tccEngine = engine;
        this.serviceMetaLoader = serviceMetaLoader;
    }

    @Override
    public CompletionStage<ApiResponse<?>> interceptAsync(IRpcServiceInvocation inv) {
        TccContext tccContext = TccContext.getCurrent();
        return runWithTccContext(tccContext, inv);
    }

    private CompletionStage<ApiResponse<?>> runWithTccContext(TccContext tccContext, IRpcServiceInvocation inv) {
        TccMethodMeta methodMeta = serviceMetaLoader.getMethodMeta(inv.getServiceName(),
                inv.getServiceMethod(), inv.getRequest());

        // 对于不支持tcc事务的方法，直接返回
        if (methodMeta == null) {
            return inv.proceedAsync();
        }

        if (tccContext != null) {
            // 如果事务分组不匹配，则忽略tccContext
            if (!TccHelper.isSameTxnGroup(methodMeta.getTxnGroup(), tccContext.getTxnGroup()))
                tccContext = null;
        }

        ApiRequest<?> request = inv.getRequest();
        String txnGroup = methodMeta.getTxnGroup();
        String txnId = null;
        if (tccContext != null) {
            txnId = tccContext.getTxnId();
        }

        TccContext finalContext = tccContext;
        return tccEngine.runInTransactionAsync(txnGroup, txnId, txn -> {
            if (shouldStartBranch(inv.isInbound(), txn.isInitiator(), methodMeta)) {
                TccBranchRequest req = buildBranchRequest(inv.getServiceName(), methodMeta, finalContext, request);
                return tccEngine.runBranchTransactionAsync(txn, req, t -> {
                    ApiHeaders.setTxnBranchId(request, t.getBranchId());
                    ApiHeaders.setTxnBranchNo(request, t.getBranchNo());
                    return inv.proceedAsync();
                });
            }
            return inv.proceedAsync();
        });
    }

    protected boolean shouldStartBranch(boolean inbound, boolean txnInitiator, TccMethodMeta methodMeta) {
        if (methodMeta.getCancelMethod() == null)
            return false;

        if (inbound) {
            // 总是由客户端负责记录branch信息，并负责回滚。因此服务端只要不是事务的启动者就不记录branch信息
            if (!txnInitiator)
                return false;
        }

        return true;
    }

    private TccBranchRequest buildBranchRequest(String serviceName, TccMethodMeta methodMeta, TccContext tccContext,
                                                ApiRequest<?> request) {
        TccBranchRequest req = new TccBranchRequest();
        req.setServiceName(serviceName);
        req.setTxnGroup(methodMeta.getTxnGroup());
        req.setServiceMethod(methodMeta.getServiceMethod());
        req.setCancelMethod(methodMeta.getCancelMethod());
        req.setConfirmMethod(methodMeta.getConfirmMethod());

        if (tccContext != null) {
            req.setParentBranchId(tccContext.getBranchId());
            req.setParentBranchNo(tccContext.getBranchNo());
        }
        req.setRequest(request);
        return req;
    }
}