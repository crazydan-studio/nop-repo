/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.tcc.core.impl;

import io.nop.api.core.beans.ApiResponse;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.FutureHelper;
import io.nop.core.lang.json.JsonTool;
import io.nop.tcc.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CompletionStage;

public class TccTransaction implements ITccTransaction {
    static final Logger LOG = LoggerFactory.getLogger(TccTransaction.class);

    private final TccEngine tccEngine;
    private final ITccRecord tccRecord;
    private final boolean initiator;

    public TccTransaction(boolean initiator, ITccRecord tccRecord, TccEngine tccEngine) {
        this.initiator = initiator;
        this.tccRecord = tccRecord;
        this.tccEngine = tccEngine;
    }

    public String toString() {
        return "TccTransaction[txnId=" + getTxnId() + ",txnGroup=" + getTxnGroup() + ",status=" + tccRecord.getTccStatus() + "]";
    }

    public ITccRecord getTccRecord() {
        return tccRecord;
    }

    @Override
    public boolean isInitiator() {
        return initiator;
    }

    protected ITccRecordStore getRepository() {
        return tccEngine.getTccRecordRepository();
    }

    @Override
    public CompletionStage<Void> beginAsync() {
        LOG.info("nop.tcc.begin:txn={}", this);
        return getRepository().saveTccRecordAsync(tccRecord, TccStatus.TRYING);
    }

    @Override
    public CompletionStage<Void> endAsync(boolean timeout, ApiResponse<?> response, Throwable ex) {
        return tccEngine.loadBranchTransactionsAsync(this).thenCompose(branchTxns -> {
            // confirm阶段已经开始的事务必须继续confirm直到成功（TCC语义：confirm开始后不允许回滚）。
            // 此前CONFIRMING/CONFIRM_FAILED全局事务被分支的rollbackOnly导向cancel路径，又被doCancelAsync
            // 的confirm状态守卫拦截为no-op，崩溃恢复时事务永久卡死在中间态
            TccStatus curStatus = tccRecord.getTccStatus();
            if (curStatus == TccStatus.CONFIRMING || curStatus == TccStatus.CONFIRM_FAILED) {
                return doConfirmAsync(branchTxns);
            }

            if (isRollbackOnly(branchTxns) || isFailed(response, ex)) {
                if (ex != null) {
                    LOG.info("nop.tcc.exec-fail", ex);
                } else if (response != null && !response.isOk()) {
                    LOG.info("nop.tcc.response:{}", JsonTool.stringify(response));
                }
                return doCancelAsync(timeout, branchTxns);
            } else {
                return doConfirmAsync(branchTxns);
            }
        }).whenComplete((ret, err2) -> {
            // 补偿(confirm/cancel)阶段产生的异常记录到日志，避免业务异常覆盖时丢失诊断信息
            if (err2 != null && ex != null) {
                LOG.error("nop.tcc.end-compensate-fail:txn={}", this, err2);
            }
            // 出现异常时避免业务异常被补偿阶段的返回值吃掉
            if (ex != null)
                throw NopException.adapt(ex);
        });
    }

    private CompletionStage<Void> doCancelAsync(boolean timeout, List<ITccBranchTransaction> branchTxns) {
        LOG.info("nop.tcc.cancel:txn={},branches={}", this, branchTxns);

        TccStatus curStatus = tccRecord.getTccStatus();
        // 如果事务正在或已经 confirm，则不允许 cancel，避免与 confirm 路径互相覆盖中间态。
        // curStatus为null（status列为null的脏数据）时不命中任何拦截条件，按普通cancel路径处理
        if (curStatus == TccStatus.CONFIRMING || curStatus == TccStatus.CONFIRM_FAILED
                || (curStatus != null && curStatus.isConfirmed()))
            return FutureHelper.success(null);

        if (curStatus != null && (curStatus.isCancelled() || curStatus.isFinished()))
            return FutureHelper.success(null);

        CompletionStage<Void> future = getRepository().updateTccStatusAsync(tccRecord, TccStatus.CANCELLING, null)
                .thenCompose(r -> TccRunner.cancelAllAsync(branchTxns, timeout, tccEngine.getServiceInvoker()));

        return FutureHelper.whenCompleteAsync(future, (response, err) -> {
            TccStatus status = TccRunner.aggregateCancelBranchStatus(branchTxns);
            return getRepository().updateTccStatusAsync(tccRecord, status, err);
        });
    }

    private CompletionStage<Void> doConfirmAsync(List<ITccBranchTransaction> branchTxns) {
        LOG.info("nop.tcc.confirm:txn={},branches={}", this, branchTxns);

        TccStatus curStatus = tccRecord.getTccStatus();
        // 如果事务正在或已经 cancel，则不允许 confirm，避免与 cancel 路径互相覆盖中间态。
        // curStatus为null（脏数据）时不命中任何拦截条件，按普通confirm路径处理
        if (curStatus == TccStatus.CANCELLING || curStatus == TccStatus.TIMEOUT_FAILED
                || (curStatus != null && curStatus.isCancelled()))
            return FutureHelper.success(null);

        if (curStatus != null && curStatus.isFinished())
            return FutureHelper.success(null);

        CompletionStage<Void> future = getRepository().updateTccStatusAsync(tccRecord, TccStatus.CONFIRMING, null)
                .thenCompose(r -> TccRunner.confirmAllAsync(branchTxns, tccEngine.getServiceInvoker()));
        return FutureHelper.whenCompleteAsync(future, (r2, err) -> {
            TccStatus status = TccRunner.aggregateConfirmBranchStatus(branchTxns);
            return getRepository().updateTccStatusAsync(tccRecord, status, err);
        });
    }

    private boolean isFailed(ApiResponse<?> response, Throwable ex) {
        if (ex != null)
            return true;
        return response != null && !response.isOk();
    }

    private boolean isRollbackOnly(List<ITccBranchTransaction> branchTxns) {
        for (ITccBranchTransaction branchTxn : branchTxns) {
            TccStatus status = branchTxn.getBranchStatus();
            // 分支状态为null（脏数据）时排除该分支，不参与决策也不NPE
            if (status == null) {
                LOG.warn("nop.tcc.ignore-branch-with-null-status:txnId={},branchId={}",
                        branchTxn.getTxnId(), branchTxn.getBranchId());
                continue;
            }
            if (status.isRollbackOnly())
                return true;
        }
        return false;
    }
}