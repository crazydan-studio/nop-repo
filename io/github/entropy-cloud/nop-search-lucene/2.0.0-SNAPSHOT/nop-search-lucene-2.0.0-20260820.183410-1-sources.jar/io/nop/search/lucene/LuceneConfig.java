/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.search.lucene;

import io.nop.api.core.annotations.data.DataBean;

@DataBean
public class LuceneConfig {
    private String indexDir = "/nop/search/indices";
    private String highlightPreTag = "<B>";
    private String highlightPostTag = "</B>";

    private int ramBufferSizeMB = 10;

    private int defaultMaxDocCharsToAnalyze = 200 * 1024;
    private int defaultMaxNumFragments = 5;
    private int defaultMaxFragmentSize = 300;

    public int getDefaultMaxFragmentSize() {
        return defaultMaxFragmentSize;
    }

    public void setDefaultMaxFragmentSize(int defaultMaxFragmentSize) {
        this.defaultMaxFragmentSize = defaultMaxFragmentSize;
    }

    public int getDefaultMaxDocCharsToAnalyze() {
        return defaultMaxDocCharsToAnalyze;
    }

    public void setDefaultMaxDocCharsToAnalyze(int defaultMaxDocCharsToAnalyze) {
        this.defaultMaxDocCharsToAnalyze = defaultMaxDocCharsToAnalyze;
    }

    public int getDefaultMaxNumFragments() {
        return defaultMaxNumFragments;
    }

    public void setDefaultMaxNumFragments(int defaultMaxNumFragments) {
        this.defaultMaxNumFragments = defaultMaxNumFragments;
    }

    public int getRamBufferSizeMB() {
        return ramBufferSizeMB;
    }

    public void setRamBufferSizeMB(int ramBufferSizeMB) {
        this.ramBufferSizeMB = ramBufferSizeMB;
    }

    public String getIndexDir() {
        return indexDir;
    }

    public void setIndexDir(String indexDir) {
        this.indexDir = indexDir;
    }

    public String getHighlightPreTag() {
        return highlightPreTag;
    }

    public void setHighlightPreTag(String highlightPreTag) {
        this.highlightPreTag = highlightPreTag;
    }

    public String getHighlightPostTag() {
        return highlightPostTag;
    }

    public void setHighlightPostTag(String highlightPostTag) {
        this.highlightPostTag = highlightPostTag;
    }

    /**
     * embedding向量的维度（例如768），用于生成mock embedding
     */
    private int embeddingDimension = 768;

    public int getEmbeddingDimension() {
        return embeddingDimension;
    }

    public void setEmbeddingDimension(int embeddingDimension) {
        this.embeddingDimension = embeddingDimension;
    }
}


