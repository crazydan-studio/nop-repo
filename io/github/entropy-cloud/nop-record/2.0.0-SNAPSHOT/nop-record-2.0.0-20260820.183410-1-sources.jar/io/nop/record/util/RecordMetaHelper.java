/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.record.util;

import io.nop.api.core.exceptions.NopException;
import io.nop.commons.bytes.ByteString;
import io.nop.commons.util.StringHelper;
import io.nop.record.codec.FieldCodecRegistry;
import io.nop.record.codec.IFieldBinaryCodec;
import io.nop.record.codec.IFieldTagBinaryCodec;
import io.nop.record.codec.IFieldTagTextCodec;
import io.nop.record.codec.IFieldTextCodec;
import io.nop.record.model.IRecordFieldsMeta;
import io.nop.record.model.RecordSimpleFieldMeta;
import io.nop.xlang.xmeta.ISchema;

import static io.nop.record.RecordErrors.ARG_CODEC;
import static io.nop.record.RecordErrors.ARG_FIELD_NAME;
import static io.nop.record.RecordErrors.ARG_LENGTH;
import static io.nop.record.RecordErrors.ARG_MAX_VALUE;
import static io.nop.record.RecordErrors.ARG_MIN_VALUE;
import static io.nop.record.RecordErrors.ERR_RECORD_FIELD_LENGTH_GREATER_THAN_MAX_VALUE;
import static io.nop.record.RecordErrors.ERR_RECORD_FIELD_LENGTH_LESS_THAN_MIN_VALUE;
import static io.nop.record.RecordErrors.ERR_RECORD_UNKNOWN_FIELD_CODEC;

public class RecordMetaHelper {
    public static void checkMaxLen(int len, RecordSimpleFieldMeta field) {
        int max = field.safeGetMaxLen();
        if (max > 0 && len > max) {
            throw new NopException(ERR_RECORD_FIELD_LENGTH_GREATER_THAN_MAX_VALUE)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_LENGTH, len)
                    .param(ARG_MAX_VALUE, max);
        }
    }

    public static void checkMinLen(int len, RecordSimpleFieldMeta field) {
        ISchema schema = field.getSchema();
        Integer minLen = schema == null ? null : schema.getMinLength();
        // 仅检查显式设置的 minLength：定长字段(length)未设 minLength 时允许短值，由 padText/padBinary 补齐
        if (minLen != null && len < minLen) {
            throw new NopException(ERR_RECORD_FIELD_LENGTH_LESS_THAN_MIN_VALUE)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_LENGTH, len)
                    .param(ARG_MIN_VALUE, minLen);
        }
    }

    public static IFieldTextCodec resolveTextCodec(RecordSimpleFieldMeta field, FieldCodecRegistry registry) {
        IFieldTextCodec resolved = field.getResolvedTextCodec();
        if (resolved != null)
            return resolved;

        String codec = field.getCodec();
        if (codec == null)
            return null;

        resolved = registry.getTextCodec(codec, field);
        if (resolved == null)
            throw new NopException(ERR_RECORD_UNKNOWN_FIELD_CODEC)
                    .source(field)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_CODEC, codec);

        field.setResolvedTextCodec(resolved);
        return resolved;
    }

    public static IFieldBinaryCodec resolveBinaryCodec(RecordSimpleFieldMeta field, FieldCodecRegistry registry) {
        IFieldBinaryCodec resolved = field.getResolvedBinaryCodec();
        if (resolved != null)
            return resolved;

        String codec = field.getCodec();
        if (codec == null)
            return null;

        resolved = registry.getBinaryCodec(codec, field);
        if (resolved == null)
            throw new NopException(ERR_RECORD_UNKNOWN_FIELD_CODEC)
                    .source(field)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_CODEC, codec);

        field.setResolvedBinaryCodec(resolved);
        return resolved;
    }

    public static IFieldTagBinaryCodec resolveTagBinaryCodec(IRecordFieldsMeta field, FieldCodecRegistry registry) {
        IFieldTagBinaryCodec resolved = field.getResolvedTagBinaryCodec();
        if (resolved != null)
            return resolved;

        String codec = field.getTagsCodec();
        if (codec == null)
            return null;

        resolved = registry.getTagBinaryCodec(codec);
        if (resolved == null)
            throw new NopException(ERR_RECORD_UNKNOWN_FIELD_CODEC)
                    .source(field)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_CODEC, codec);

        field.setResolvedTagBinaryCodec(resolved);
        return resolved;
    }

    public static IFieldTagTextCodec resolveTagTextCodec(IRecordFieldsMeta field, FieldCodecRegistry registry) {
        IFieldTagTextCodec resolved = field.getResolvedTagTextCodec();
        if (resolved != null)
            return resolved;

        String codec = field.getTagsCodec();
        if (codec == null)
            return null;

        resolved = registry.getTagTextCodec(codec);
        if (resolved == null)
            throw new NopException(ERR_RECORD_UNKNOWN_FIELD_CODEC)
                    .source(field)
                    .param(ARG_FIELD_NAME, field.getName())
                    .param(ARG_CODEC, codec);

        field.setResolvedTagTextCodec(resolved);
        return resolved;
    }

    public static String padText(String str, RecordSimpleFieldMeta field) {
        int len = str.length();
        RecordMetaHelper.checkMaxLen(len, field);
        RecordMetaHelper.checkMinLen(len, field);

        int expected = field.getLength();
        if (expected > 0) {
            if (len == expected)
                return str;

            ByteString padding = field.getPadding();
            char c = ' ';
            if (padding != null) {
                String paddingStr = padding.toString(field.getCharset());
                c = paddingStr.charAt(0);
            }

            if (field.isLeftPad()) {
                str = StringHelper.leftPad(str, expected, c);
            } else {
                str = StringHelper.rightPad(str, expected, c);
            }
        }
        return str;
    }

    public static ByteString padBinary(ByteString str, RecordSimpleFieldMeta field) {
        int len = str.length();
        RecordMetaHelper.checkMaxLen(len, field);
        RecordMetaHelper.checkMinLen(len, field);

        int expected = field.getLength();
        if (expected > 0) {
            if (len == expected)
                return str;

            ByteString padding = field.getPadding();
            byte c = (byte) 0;
            if (padding != null) {
                c = padding.at(0);
            }
            if (field.isLeftPad()) {
                str = str.leftPad(expected, c);
            } else {
                str = str.rightPad(expected, c);
            }
        }
        return str;
    }

    public static String trimText(String str, RecordSimpleFieldMeta field) {
        if (!field.isTrim())
            return str;

        ByteString padding = field.getPadding();
        char c = ' ';
        if (padding != null) {
            String paddingStr = padding.toString(field.getCharset());
            c = paddingStr.charAt(0);
        }
        if (field.isLeftPad()) {
            str = StringHelper.trimLeft(str, c);
        } else {
            str = StringHelper.trimRight(str, c);
        }
        return str;
    }

    public static ByteString trimBinary(ByteString str, RecordSimpleFieldMeta field) {
        if (!field.isTrim())
            return str;

        byte c = (byte) 0;
        if (field.getPadding() != null) {
            c = field.getPadding().at(0);
        }
        if (field.isLeftPad()) {
            str = str.trimLeft(c);
        } else {
            str = str.trimRight(c);
        }
        return str;
    }

}
