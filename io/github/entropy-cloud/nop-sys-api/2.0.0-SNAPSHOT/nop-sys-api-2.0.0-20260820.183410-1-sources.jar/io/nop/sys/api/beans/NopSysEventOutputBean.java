//__XGEN_FORCE_OVERRIDE__
    package io.nop.sys.api.beans;

    import com.fasterxml.jackson.annotation.JsonInclude;
    import io.nop.api.core.annotations.data.DataBean;
    import io.nop.api.core.annotations.meta.PropMeta;
    
    import java.util.Map;

    @DataBean
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SuppressWarnings({"PMD","java:S116","java:S115"})
    public class NopSysEventOutputBean {

    
        private Long _eventId;

    
        @PropMeta(propId=1)
    
        public Long getEventId(){
            return _eventId;
        }

        public void setEventId(Long value){
            this._eventId = value;
        }


        private String _eventTopic;

    
        @PropMeta(propId=2)
    
        public String getEventTopic(){
            return _eventTopic;
        }

        public void setEventTopic(String value){
            this._eventTopic = value;
        }


        private String _eventName;

    
        @PropMeta(propId=3)
    
        public String getEventName(){
            return _eventName;
        }

        public void setEventName(String value){
            this._eventName = value;
        }


        private String _eventHeaders;

    
        @PropMeta(propId=4)
    
        public String getEventHeaders(){
            return _eventHeaders;
        }

        public void setEventHeaders(String value){
            this._eventHeaders = value;
        }


        private String _eventData;

    
        @PropMeta(propId=5)
    
        public String getEventData(){
            return _eventData;
        }

        public void setEventData(String value){
            this._eventData = value;
        }


        private String _selection;

    
        @PropMeta(propId=6)
    
        public String getSelection(){
            return _selection;
        }

        public void setSelection(String value){
            this._selection = value;
        }


        private java.sql.Timestamp _eventTime;

    
        @PropMeta(propId=7)
    
        public java.sql.Timestamp getEventTime(){
            return _eventTime;
        }

        public void setEventTime(java.sql.Timestamp value){
            this._eventTime = value;
        }


        private Integer _eventStatus;

    
        @PropMeta(propId=8)
    
        public Integer getEventStatus(){
            return _eventStatus;
        }

        public void setEventStatus(Integer value){
            this._eventStatus = value;
        }


        private String _eventStatus_label;

    
        public String getEventStatus_label(){
            return _eventStatus_label;
        }

        public void setEventStatus_label(String value){
            this._eventStatus_label = value;
        }


        private java.sql.Timestamp _processTime;

    
        @PropMeta(propId=9)
    
        public java.sql.Timestamp getProcessTime(){
            return _processTime;
        }

        public void setProcessTime(java.sql.Timestamp value){
            this._processTime = value;
        }


        private java.sql.Timestamp _scheduleTime;

    
        @PropMeta(propId=10)
    
        public java.sql.Timestamp getScheduleTime(){
            return _scheduleTime;
        }

        public void setScheduleTime(java.sql.Timestamp value){
            this._scheduleTime = value;
        }


        private String _bizObjName;

    
        @PropMeta(propId=12)
    
        public String getBizObjName(){
            return _bizObjName;
        }

        public void setBizObjName(String value){
            this._bizObjName = value;
        }


        private String _bizKey;

    
        @PropMeta(propId=13)
    
        public String getBizKey(){
            return _bizKey;
        }

        public void setBizKey(String value){
            this._bizKey = value;
        }


        private java.time.LocalDate _bizDate;

    
        @PropMeta(propId=14)
    
        public java.time.LocalDate getBizDate(){
            return _bizDate;
        }

        public void setBizDate(java.time.LocalDate value){
            this._bizDate = value;
        }


        private Integer _partitionIndex;

    
        @PropMeta(propId=15)
    
        public Integer getPartitionIndex(){
            return _partitionIndex;
        }

        public void setPartitionIndex(Integer value){
            this._partitionIndex = value;
        }


        private Integer _retryTimes;

    
        @PropMeta(propId=16)
    
        public Integer getRetryTimes(){
            return _retryTimes;
        }

        public void setRetryTimes(Integer value){
            this._retryTimes = value;
        }


        private String _leaseOwner;

    
        @PropMeta(propId=17)
    
        public String getLeaseOwner(){
            return _leaseOwner;
        }

        public void setLeaseOwner(String value){
            this._leaseOwner = value;
        }


        private java.sql.Timestamp _leaseExpireTime;

    
        @PropMeta(propId=18)
    
        public java.sql.Timestamp getLeaseExpireTime(){
            return _leaseExpireTime;
        }

        public void setLeaseExpireTime(java.sql.Timestamp value){
            this._leaseExpireTime = value;
        }


        private Long _version;

    
        @PropMeta(propId=19)
    
        public Long getVersion(){
            return _version;
        }

        public void setVersion(Long value){
            this._version = value;
        }


        private String _createdBy;

    
        @PropMeta(propId=20)
    
        public String getCreatedBy(){
            return _createdBy;
        }

        public void setCreatedBy(String value){
            this._createdBy = value;
        }


        private java.sql.Timestamp _createTime;

    
        @PropMeta(propId=21)
    
        public java.sql.Timestamp getCreateTime(){
            return _createTime;
        }

        public void setCreateTime(java.sql.Timestamp value){
            this._createTime = value;
        }


        private String _updatedBy;

    
        @PropMeta(propId=22)
    
        public String getUpdatedBy(){
            return _updatedBy;
        }

        public void setUpdatedBy(String value){
            this._updatedBy = value;
        }


        private java.sql.Timestamp _updateTime;

    
        @PropMeta(propId=23)
    
        public java.sql.Timestamp getUpdateTime(){
            return _updateTime;
        }

        public void setUpdateTime(java.sql.Timestamp value){
            this._updateTime = value;
        }


    }
