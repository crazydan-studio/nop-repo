/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.biz.crud;

import io.nop.api.core.beans.FieldSelectionBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.BizConstants;
import io.nop.biz.api.IBizObjectManager;
import io.nop.commons.type.StdDataType;
import io.nop.commons.util.StringHelper;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.eval.IEvalFunction;
import io.nop.core.lang.eval.IEvalScope;
import io.nop.core.reflect.ReflectionManager;
import io.nop.core.reflect.bean.BeanTool;
import io.nop.core.reflect.bean.IBeanModel;
import io.nop.dao.DaoConstants;
import io.nop.dao.api.IDaoProvider;
import io.nop.dao.api.IEntityDao;
import io.nop.dao.exceptions.UnknownEntityException;
import io.nop.orm.IOrmEntity;
import io.nop.orm.IOrmEntitySet;
import io.nop.orm.OrmConstants;
import io.nop.orm.OrmEntityState;
import io.nop.orm.exceptions.OrmException;
import io.nop.orm.model.IColumnModel;
import io.nop.orm.model.IEntityJoinConditionModel;
import io.nop.orm.model.IEntityModel;
import io.nop.orm.model.IEntityPropModel;
import io.nop.orm.model.IEntityRelationModel;
import io.nop.orm.model.utils.OrmModelHelper;
import io.nop.orm.support.OrmCompositePk;
import io.nop.orm.support.OrmEntityHelper;
import io.nop.xlang.api.XLang;
import io.nop.xlang.xmeta.IObjPropMeta;
import io.nop.xlang.xmeta.ObjRelationWriteMode;
import io.nop.xlang.xmeta.IObjSchema;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import static io.nop.biz.BizErrors.ERR_BIZ_REF_ENTITY_OWNER_NOT_MATCH;
import static io.nop.biz.crud.BizSchemaHelper.getPropSchema;
import static io.nop.orm.OrmErrors.ARG_ENTITY_ID;
import static io.nop.orm.OrmErrors.ARG_ENTITY_NAME;
import static io.nop.orm.OrmErrors.ARG_OWNER;
import static io.nop.orm.OrmErrors.ARG_PROP_CLASS;
import static io.nop.orm.OrmErrors.ARG_PROP_NAME;
import static io.nop.orm.OrmErrors.ERR_ORM_COPY_ENTITY_PROP_NOT_COLLECTION;

/**
 * 实现json对象或者DTO对象与数据库实体对象之间的同步。例如前台修改实体对象之后提交到后台，利用此函数更新到对象图上。
 */
public class OrmEntityCopier {
    private final IBizObjectManager bizObjectManager;
    private final IDaoProvider daoProvider;

    private Map<String, String> relationChangeTypes;
    private IServiceContext context;
    private List<IDelayedAction> delayedActions;

    private boolean updateUseId;

    /**
     * bizObjName是接口层面看到的业务对象名，IBizObjManager根据bizObjName装载对应业务对象。
     * 指定的关联对象名会对应找到相关的meta文件，而meta中可以提供一些扩展信息，例如setter等
     *
     * @param daoProvider 用于创建或者装载关联实体对象
     */
    public OrmEntityCopier(IDaoProvider daoProvider, IBizObjectManager bizObjectManager) {
        this.bizObjectManager = bizObjectManager;
        this.daoProvider = daoProvider;
    }

    public OrmEntityCopier(IDaoProvider daoProvider) {
        this(daoProvider, null);
    }

    public void setUpdateUseId(boolean updateUseId) {
        this.updateUseId = updateUseId;
    }

    public void setServiceContext(IServiceContext context) {
        this.context = context;
    }

    public void setDelayedActions(List<IDelayedAction> delayedActions) {
        this.delayedActions = delayedActions;
    }

    public OrmEntityCopier addRelationCopyOptions(String relationName, String chgType) {
        if (relationChangeTypes == null) {
            relationChangeTypes = new HashMap<>();
        }
        relationChangeTypes.put(relationName, chgType);
        return this;
    }

    public String getRelationChangeTypes(String relationName) {
        if (relationChangeTypes == null)
            return null;
        return relationChangeTypes.get(relationName);
    }

    public void copyToEntity(Object src, IOrmEntity target, FieldSelectionBean selection, String action) {
        this.copyToEntity(src, target, selection, null, null, action, XLang.newEvalScope());
    }

    /**
     * 将java bean或者json对象上的指定属性设置到实体对象上。根据实体属性的类型，有可能创建新的实体对象，或者装载关联实体对象。
     *
     * @param src       来源数据对象
     * @param target    需要被更新的目标实体对象
     * @param selection 指定从来源对象的哪些属性读取并更新到目标实体对象的哪些属性上
     */
    public void copyToEntity(Object src, IOrmEntity target, FieldSelectionBean selection, IObjSchema objMeta,
                             String baseBizObjName, String action, IEvalScope scope) {
        IBeanModel beanModel = ReflectionManager.instance().getBeanModelForClass(src.getClass());

        IEntityModel entityModel = target.orm_entityModel();
        Set<String> ignoreAutoExprProps = new HashSet<>();
        if (entityModel.getTenantPropId() > 0) {
            String tenantProp = entityModel.getTenantColumn().getName();
            IObjPropMeta propMeta = objMeta.getProp(tenantProp);
            if (propMeta != null && (propMeta.getAutoExpr() != null || propMeta.getDefaultValue() != null)) {
                // 禁用租户id的autoExpr，它的值应该由上下文租户id指定
                ignoreAutoExprProps.add(entityModel.getTenantColumn().getName());
            }
        }

        if (selection == null) {
            if (src instanceof Map) {
                Map<String, Object> map = (Map<String, Object>) src;
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    String name = entry.getKey();
                    // 忽略_chgType属性
                    if (name.startsWith(DaoConstants.PROP_CHANGE_TYPE))
                        continue;

                    if (name.startsWith(BizConstants.PROP_WRITE_MODE + '_'))
                        continue;

                    if (name.equals(OrmConstants.PROP_ID))
                        continue;

                    IObjPropMeta propMeta = getProp(objMeta, name);
                    if (propMeta != null) {
                        // 如果明确从前台提交参数，那么以提交的值为准。如果禁止前台提交，应该设置字段的insertable=false,updatable=false
                        if (propMeta.getAutoExpr() != null || propMeta.getDefaultValue() != null) {
                            ignoreAutoExprProps.add(propMeta.getName());
                        }
                    }
                    copyField(beanModel, map, src, target, name, name, null, propMeta, baseBizObjName, scope);
                }
            } else {
                beanModel.forEachReadWriteProp(propModel -> {
                    String name = propModel.getName();
                    if (name.equals(OrmConstants.PROP_ID))
                        return;

                    IObjPropMeta propMeta = getProp(objMeta, name);
                    if (propMeta != null && (propMeta.getAutoExpr() != null || propMeta.getDefaultValue() != null)) {
                        ignoreAutoExprProps.add(propMeta.getName());
                    }
                    copyField(beanModel, null, src, target, name, name, null, propMeta, baseBizObjName, scope);
                });
            }
        } else {
            Map<String, Object> map = src instanceof Map ? (Map<String, Object>) src : null;
            for (Map.Entry<String, FieldSelectionBean> entry : selection.getFields().entrySet()) {
                String name = entry.getKey();
                FieldSelectionBean field = entry.getValue();
                String from = field.getName();
                if (from == null)
                    from = name;

                if (map != null && !map.containsKey(from)) {
                    continue;
                }

                if (name.equals(OrmConstants.PROP_ID))
                    continue;

                IObjPropMeta propMeta = getProp(objMeta, from);
                if (propMeta != null) {
                    if (propMeta.getAutoExpr() != null || propMeta.getDefaultValue() != null)
                        ignoreAutoExprProps.add(propMeta.getName());
                }
                copyField(beanModel, map, src, target, from, name, field, propMeta, baseBizObjName, scope);
            }
        }

        if (objMeta != null)
            AutoExprRunner.runAutoExpr(action, target, src, objMeta, scope, ignoreAutoExprProps);
    }

    IObjPropMeta getProp(IObjSchema objMeta, String name) {
        if (objMeta == null)
            return null;
        return objMeta.getProp(name);
    }

    private void copyField(IBeanModel beanModel, Map<String, Object> map,
                           Object src, IOrmEntity target, String from, String name,
                           FieldSelectionBean field, IObjPropMeta propMeta, String baseBizObjName, IEvalScope scope) {
        Object fromValue = beanModel.getProperty(src, from);
        if (propMeta != null) {
            // 虚拟字段不会设置到实体上
            if (propMeta.isVirtual())
                return;

            IEvalFunction setter = propMeta.getSetter();
            if (setter != null) {
                setter.call3(null, target, fromValue, propMeta,scope);
                return;
            }

            if (propMeta.getMapToProp() != null) {
                BeanTool.setComplexProperty(target, propMeta.getMapToProp(), fromValue);
                return;
            }
        }
        IEntityModel entityModel = target.orm_entityModel();

        IEntityPropModel propModel = entityModel.getProp(name, true);
        if (propModel == null) {
            // 不是实体属性，则直接认为是java bean属性设置
            target.orm_propValueByName(name, fromValue);
        } else {
            if (propModel.isToOneRelation()) {
                IObjSchema subSchema = getPropSchema(propMeta, false, bizObjectManager, baseBizObjName);
                copyRefEntity(fromValue, map, target, (IEntityRelationModel) propModel, field, propMeta,
                        subSchema, baseBizObjName, scope);
            } else if (propModel.isToManyRelation()) {
                IObjSchema subSchema = getPropSchema(propMeta, true, bizObjectManager, baseBizObjName);
                copyRefEntitySet(fromValue, map, target, (IEntityRelationModel) propModel, field, propMeta,
                        subSchema, baseBizObjName, scope);
            } else {
                target.orm_propValueByName(name, fromValue);
            }
        }
    }

    private void copyRefEntity(Object fromValue, Map<String, Object> map,
                                 IOrmEntity target, IEntityRelationModel propModel,
                                 FieldSelectionBean field, IObjPropMeta propMeta,
                                 IObjSchema objMeta, String baseBizObjName, IEvalScope scope) {
        ObjRelationWriteMode writeMode = resolveWriteMode(propMeta, map, propModel.getName());
        if (StringHelper.isEmptyObject(fromValue)) {
            if (writeMode == ObjRelationWriteMode.BIZ) {
                collectRelationBizAction(null, field, target, propModel, propMeta, objMeta);
            } else {
                target.orm_propValueByName(propModel.getName(), null);
            }
        } else {
            String propName = propModel.getName();
            if (StdDataType.fromJavaClass(fromValue.getClass()).isSimpleType()) {
                if (writeMode == ObjRelationWriteMode.BIZ) {
                    collectRelationBizAction(fromValue, field, target, propModel, propMeta, objMeta);
                } else {
                    Object refEntity = daoProvider.dao(propModel.getRefEntityName()).loadEntityById(fromValue);
                    target.orm_propValueByName(propName, refEntity);
                }
            } else {
                if (writeMode == ObjRelationWriteMode.LINK) {
                    copyRefEntityLink(fromValue, target, propModel);
                    return;
                }

                if (writeMode == ObjRelationWriteMode.BIZ) {
                    collectRelationBizAction(fromValue, field, target, propModel, propMeta, objMeta);
                    return;
                }

                String chgType = getRelationChangeTypes(OrmModelHelper.buildRelationName(propModel));
                if (chgType == null && map != null) {
                    chgType = (String) map.get(DaoConstants.PROP_CHANGE_TYPE + '_' + propName);
                }

                assignRefProps(fromValue, target, propModel);

                // 更新关联实体
                Object id = getId(fromValue, propModel.getRefEntityModel());
                if (StringHelper.isEmptyObject(id)) {
                    // 没有主键，需要新增对象
                    if (field != null && !field.hasField()) {
                        target.orm_propValueByName(propName, null);
                    } else {
                        if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_ADD)) {
                            Object refEntity = daoProvider.dao(propModel.getRefEntityName()).newEntity();
                            bindRefOwner((IOrmEntity) refEntity, target, propModel);
                            copyToEntity(fromValue, (IOrmEntity) refEntity, field, objMeta, baseBizObjName,
                                    BizConstants.METHOD_SAVE, scope);
                            target.orm_propValueByName(propName, refEntity);
                        }
                    }
                } else {
                    if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_UPDATE)) {
                        IOrmEntity refEntity = (IOrmEntity) daoProvider.dao(propModel.getRefEntityName()).loadEntityById(id);
                        checkRefEntity(refEntity, fromValue, target, propModel);
                        bindRefOwner(refEntity, target, propModel);

                        copyToEntity(fromValue, refEntity, field, objMeta, baseBizObjName,
                                BizConstants.METHOD_UPDATE, scope);

                        target.orm_propValueByName(propName, refEntity);
                    }
                }
            }
        }
    }

    private void copyRefEntitySet(Object fromValue, Map<String, Object> map, IOrmEntity target, IEntityRelationModel propModel,
                                  FieldSelectionBean field, IObjPropMeta propMeta,
                                  IObjSchema objMeta, String baseBizObjName,
                                  IEvalScope scope) {
        ObjRelationWriteMode writeMode = resolveWriteMode(propMeta, map, propModel.getName());
        if (writeMode == ObjRelationWriteMode.BIZ) {
            if (fromValue instanceof Collection) {
                for (Object item : (Collection<?>) fromValue) {
                    collectRelationBizAction(item, field, target, propModel, propMeta, objMeta);
                }
            }
            return;
        }

        String propName = propModel.getName();
        IOrmEntitySet<IOrmEntity> refSet = target.orm_refEntitySet(propName);
        // 强制加载关联实体
        refSet.orm_forceLoad();

        String chgType = getRelationChangeTypes(refSet.orm_collectionName());

        if (chgType == null && map != null) {
            chgType = (String) map.get(DaoConstants.PROP_CHANGE_TYPE + '_' + propName);
        }

        if (StringHelper.isEmptyObject(fromValue)) {
            if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_DELETE))
                refSet.clear();
        } else if (fromValue instanceof Collection) {
            Collection<?> c = (Collection<?>) fromValue;
            if (c.isEmpty()) {
                if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_DELETE))
                    refSet.clear();
            } else {
                if (writeMode == ObjRelationWriteMode.LINK) {
                    syncEntitySetInLinkMode(c, refSet, propModel.getRefEntityName(), propModel);
                } else {
                    syncEntitySet(c, refSet, propModel.getKeyProp(), field, propModel.getRefEntityName(), propModel,
                            objMeta, baseBizObjName, scope);
                }
            }
        } else {
            throw new OrmException(ERR_ORM_COPY_ENTITY_PROP_NOT_COLLECTION).param(ARG_PROP_NAME, propModel.getName())
                    .param(ARG_PROP_CLASS, fromValue.getClass());
        }
    }

    private void copyRefEntityLink(Object fromValue, IOrmEntity target, IEntityRelationModel propModel) {
        assignRefProps(fromValue, target, propModel);
        Object id = getId(fromValue, propModel.getRefEntityModel());
        if (StringHelper.isEmptyObject(id)) {
            return;
        }
        IOrmEntity refEntity = (IOrmEntity) daoProvider.dao(propModel.getRefEntityName()).loadEntityById(id);
        checkRefEntity(refEntity, fromValue, target, propModel);
        target.orm_propValueByName(propModel.getName(), refEntity);
    }

    private void syncEntitySetInLinkMode(Collection<?> c, IOrmEntitySet<IOrmEntity> refSet,
                                         String refEntityName, IEntityRelationModel refModel) {
        Set<IOrmEntity> ret = new LinkedHashSet<>();
        IEntityDao<IOrmEntity> dao = daoProvider.dao(refEntityName);
        for (Object item : c) {
            if (StringHelper.isEmptyObject(item)) {
                continue;
            }

            if (StdDataType.isSimpleType(item.getClass().getName())) {
                ret.add(dao.loadEntityById(item));
                continue;
            }

            assignRefProps(item, refSet.orm_owner(), refModel);
            Object id = getId(item, refModel.getRefEntityModel());
            if (StringHelper.isEmptyObject(id)) {
                continue;
            }

            IOrmEntity refEntity = dao.loadEntityById(id);
            checkRefEntity(refEntity, item, null, refModel);
            ret.add(refEntity);
        }
        refSet.clear();
        refSet.addAll(ret);
    }

    private ObjRelationWriteMode resolveWriteMode(IObjPropMeta propMeta, Map<String, Object> map, String propName) {
        ObjRelationWriteMode propMode = propMeta == null ? null : propMeta.getWriteMode();
        ObjRelationWriteMode requestMode = null;
        if (map != null) {
            Object mode = map.get(BizConstants.PROP_WRITE_MODE + '_' + propName);
            if (mode instanceof ObjRelationWriteMode) {
                requestMode = (ObjRelationWriteMode) mode;
            } else if (mode != null) {
                requestMode = ObjRelationWriteMode.fromText(StringHelper.toString(mode, null));
            }
        }

        if (propMode == ObjRelationWriteMode.LINK || propMode == ObjRelationWriteMode.BIZ) {
            return propMode;
        }
        if (requestMode != null) {
            return requestMode;
        }
        if (propMode != null) {
            return propMode;
        }
        return ObjRelationWriteMode.INLINE;
    }

    private void collectRelationBizAction(Object payload, FieldSelectionBean field,
                                          IOrmEntity parentEntity, IEntityRelationModel relationModel,
                                          IObjPropMeta propMeta, IObjSchema objMeta) {
        if (delayedActions == null || bizObjectManager == null || context == null) {
            return;
        }

        DelayedRelationAction action = new DelayedRelationAction(bizObjectManager, daoProvider);
        action.setPropName(relationModel.getName());
        action.setWriteMode(ObjRelationWriteMode.BIZ);
        action.setBizAction(resolveBizAction(payload, relationModel));
        action.setPayload(payload);
        action.setSelection(field != null && field.hasField() ? field : null);
        action.setParentEntity(parentEntity);
        action.setRelationModel(relationModel);
        action.setOrder(propMeta == null || propMeta.getPropId() == null ? 0 : propMeta.getPropId());
        action.setTargetBizObjName(resolveTargetBizObjName(propMeta, objMeta));
        delayedActions.add(action);
    }

    private String resolveTargetBizObjName(IObjPropMeta propMeta, IObjSchema objMeta) {
        if (propMeta != null && propMeta.getRefBizObjName() != null) {
            return propMeta.getRefBizObjName();
        }
        if (objMeta != null && objMeta.getBizObjName() != null) {
            return objMeta.getBizObjName();
        }
        return null;
    }

    private String resolveBizAction(Object payload, IEntityRelationModel relationModel) {
        if (payload == null) {
            return "unlink";
        }

        if (payload instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) payload;
            String chgType = (String) map.get(DaoConstants.PROP_CHANGE_TYPE);
            if (DaoConstants.CHANGE_TYPE_DELETE.equals(chgType)) {
                return BizConstants.METHOD_DELETE;
            }
            if (DaoConstants.CHANGE_TYPE_ADD.equals(chgType)) {
                return BizConstants.METHOD_SAVE;
            }
            if (DaoConstants.CHANGE_TYPE_UPDATE.equals(chgType)) {
                return BizConstants.METHOD_UPDATE;
            }

            Object id = getId(payload, relationModel.getRefEntityModel());
            return StringHelper.isEmptyObject(id) ? BizConstants.METHOD_SAVE : BizConstants.METHOD_UPDATE;
        }

        return BizConstants.METHOD_UPDATE;
    }

    void syncEntitySet(Collection<?> c, IOrmEntitySet<IOrmEntity> refSet, String keyProp, FieldSelectionBean field,
                       String refEntityName, IEntityRelationModel refModel, IObjSchema objMeta, String baseBizObjName, IEvalScope scope) {
        Set<IOrmEntity> ret = new LinkedHashSet<>();
        IEntityDao<IOrmEntity> dao = daoProvider.dao(refEntityName);

        IOrmEntity owner = refSet.orm_owner();
        String chgType = getRelationChangeTypes(refSet.orm_collectionName());

        for (Object item : c) {
            if (StringHelper.isEmptyObject(item))
                continue;

            boolean simple = StdDataType.isSimpleType(item.getClass().getName());
            if (simple) {
                IOrmEntity refEntity = dao.loadEntityById(item);
                ret.add(refEntity);
            } else {
                assignRefProps(item, refSet.orm_owner(), refModel);

                // 更新关联实体
                Object id = getId(item, refModel.getRefEntityModel());
                if (StringHelper.isEmptyObject(id)) {
                    // 没有主键，需要新增对象
                    if (field != null && !field.hasField()) {
                        continue;
                    } else {
                        IOrmEntity refEntity = null;
                        if (keyProp != null) {
                            String srcProp = getRefField(field, keyProp);
                            Object keyValue = BeanTool.instance().getProperty(item, srcProp);
                            // 按照keyProp查找集合中已经存在的实体
                            if (keyValue != null)
                                refEntity = (IOrmEntity) refSet.prop_get(keyValue.toString());
                        }

                        String action = null;
                        if (refEntity == null) {
                            // 如果明确配置了不允许向集合中添加元素
                            if (chgType != null && !chgType.contains(DaoConstants.CHANGE_TYPE_ADD))
                                continue;
                            refEntity = dao.newEntity();
                            bindRefOwner(refEntity, owner, refModel);
                            action = BizConstants.METHOD_SAVE;
                        } else {
                            // 如果明确配置了不允许更新集合中的元素
                            if (chgType != null && !chgType.contains(DaoConstants.CHANGE_TYPE_UPDATE)) {
                                ret.add(refEntity); // 不允许修改也需要记录到集合中，否则会被自动删除
                                continue;
                            }
                            action = BizConstants.METHOD_UPDATE;
                        }
                        bindRefOwner(refEntity, owner, refModel);
                        checkRefEntity(refEntity, item, null, null);
                        copyToEntity(item, refEntity, field, objMeta, baseBizObjName, action, scope);
                        ret.add(refEntity);
                    }
                } else {
                    if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_UPDATE)) {
                        IOrmEntity refEntity = dao.loadEntityById(id);
                        // 不检查owner
                        checkRefEntity(refEntity, item, null, refModel);
                        bindRefOwner(refEntity, owner, refModel);
                        copyToEntity(item, refEntity, field, objMeta, baseBizObjName, BizConstants.METHOD_UPDATE, scope);
                        ret.add(refEntity);
                    }
                }
            }
        }

        // 删除没有在src集合中出现的条目。所有需要保留的条目应该都在ret集合中。这里clear会导致不在ret集合中的条目会被删除
        if (chgType == null || chgType.contains(DaoConstants.CHANGE_TYPE_DELETE))
            refSet.clear();

        refSet.addAll(ret);
    }

    private void checkRefEntity(IOrmEntity refEntity, Object bean,
                                IOrmEntity owner, IEntityRelationModel refModel) {
        refEntity.orm_forceLoad();

        // 关联实体不存在，是否需要新建？
        if (refEntity.orm_state().isMissing()) {
            if (updateUseId || !StringHelper.isEmptyObject(BeanTool.getProperty(bean, OrmConstants.PROP_ID))) {
                // 如果是按照id去获取实体
                throw new UnknownEntityException(refEntity.orm_entityName(), refEntity.orm_id());
            } else {
                refEntity.orm_state(OrmEntityState.TRANSIENT);
            }
        } else if (owner != null) {
            for (IEntityJoinConditionModel join : refModel.getJoin()) {
                Object leftValue = OrmEntityHelper.getLeftValue(join, owner);
                Object rightValue = OrmEntityHelper.getRightValue(join, refEntity);
                leftValue = Objects.toString(leftValue, null);
                rightValue = Objects.toString(rightValue, null);
                if (!Objects.equals(leftValue, rightValue))
                    throw new NopException(ERR_BIZ_REF_ENTITY_OWNER_NOT_MATCH)
                            .param(ARG_ENTITY_ID, refEntity.get_id())
                            .param(ARG_ENTITY_NAME, refEntity.orm_entityName())
                            .param(ARG_OWNER, owner);
            }
        }
    }

    private void assignRefProps(Object item, IOrmEntity owner, IEntityRelationModel refModel) {
        for (IEntityJoinConditionModel join : refModel.getJoin()) {
            String rightProp = join.getRightProp();
            if (rightProp != null) {
                Object leftValue = OrmEntityHelper.getLeftValue(join, owner);
                if (leftValue != null)
                    BeanTool.instance().setProperty(item, rightProp, leftValue);
            }
        }
    }

    private void bindRefOwner(IOrmEntity refEntity, IOrmEntity owner, IEntityRelationModel refModel) {
        if (refEntity == null || owner == null) {
            return;
        }
        String refPropName = refModel.getRefPropName();
        if (StringHelper.isEmpty(refPropName)) {
            return;
        }
        refEntity.orm_propValueByName(refPropName, owner);
    }

    Object getId(Object bean, IEntityModel entityModel) {
        Object id = BeanTool.instance().getProperty(bean, OrmConstants.PROP_ID);
        if (updateUseId || !StringHelper.isEmptyObject(id))
            return id;

        if (entityModel.isCompositePk()) {
            List<? extends IColumnModel> pkCols = entityModel.getPkColumns();
            Object[] pkValues = new Object[pkCols.size()];
            for (int i = 0, n = pkCols.size(); i < n; i++) {
                IColumnModel col = pkCols.get(i);
                Object value = BeanTool.instance().getProperty(bean, pkCols.get(i).getName());
                if (value == null)
                    return null;
                value = col.getStdDataType().convert(value, err -> new NopException(err).param(ARG_PROP_NAME, col.getName()));
                pkValues[i] = value;
            }
            return OrmCompositePk.buildNotNull(entityModel.getPkColumnNames(), pkValues);
        } else {
            IColumnModel col = entityModel.getPkColumns().get(0);
            String pkName = col.getName();
            Object value = BeanTool.instance().getProperty(bean, pkName);
            if (value == null)
                return null;
            value = col.getStdDataType().convert(value, err -> new NopException(err).param(ARG_PROP_NAME, col.getName()));
            return value;
        }
    }

    String getRefField(FieldSelectionBean field, String keyProp) {
        if (field == null)
            return keyProp;
        FieldSelectionBean subField = field.getField(keyProp);
        if (subField == null) {
            return keyProp;
        }
        String name = subField.getName();
        if (name == null)
            name = keyProp;
        return name;
    }
}
