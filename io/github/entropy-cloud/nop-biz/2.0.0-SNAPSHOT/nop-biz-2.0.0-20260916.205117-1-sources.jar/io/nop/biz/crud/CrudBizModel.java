/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.biz.crud;

import io.nop.api.core.annotations.biz.BizAction;
import io.nop.api.core.annotations.biz.BizArgsNormalizer;
import io.nop.api.core.annotations.biz.BizMakerChecker;
import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Description;
import io.nop.api.core.annotations.core.Locale;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.api.core.annotations.graphql.GraphQLReturn;
import io.nop.api.core.auth.IDataAuthChecker;
import io.nop.api.core.beans.DictBean;
import io.nop.api.core.beans.DictOptionBean;
import io.nop.api.core.beans.FieldSelectionBean;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.PageBean;
import io.nop.api.core.beans.TreeBean;
import io.nop.api.core.beans.query.OrderFieldBean;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.beans.std.StdTreeEntity;
import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.FutureHelper;
import io.nop.api.core.util.Guard;
import io.nop.auth.api.utils.AuthHelper;
import io.nop.biz.BizConstants;
import io.nop.biz.api.IBizObject;
import io.nop.biz.api.IBizObjectManager;
import io.nop.commons.util.CollectionHelper;
import io.nop.commons.util.StringHelper;
import io.nop.core.context.IServiceContext;
import io.nop.core.context.action.IServiceAction;
import io.nop.core.dataset.BeanRowMapper;
import io.nop.core.lang.eval.DisabledEvalScope;
import io.nop.core.lang.sql.SQL;
import io.nop.core.reflect.bean.BeanTool;
import io.nop.dao.DaoConstants;
import io.nop.dao.api.IDaoProvider;
import io.nop.dao.api.IEntityDao;
import io.nop.dao.exceptions.UnknownEntityException;
import io.nop.dao.txn.ITransactionTemplate;
import io.nop.dao.utils.DaoHelper;
import io.nop.fsm.execution.IStateMachine;
import io.nop.fsm.model.StateModel;
import io.nop.graphql.core.GraphQLConstants;
import io.nop.graphql.core.IBizModelImpl;
import io.nop.graphql.core.biz.IBizObjectQueryProcessor;
import io.nop.graphql.core.engine.IGraphQLEngine;
import io.nop.orm.IOrmBatchLoadQueue;
import io.nop.orm.IOrmEntity;
import io.nop.orm.IOrmEntitySet;
import io.nop.orm.IOrmTemplate;
import io.nop.orm.OrmConstants;
import io.nop.orm.dao.IOrmEntityDao;
import io.nop.orm.model.IColumnModel;
import io.nop.orm.model.IEntityJoinConditionModel;
import io.nop.orm.model.IEntityModel;
import io.nop.orm.model.IEntityRelationModel;
import io.nop.orm.model.utils.ManyToManyPropMeta;
import io.nop.orm.support.OrmEntityHelper;
import io.nop.orm.utils.OrmQueryHelper;
import io.nop.xlang.filter.BizExprHelper;
import io.nop.xlang.filter.BizFilterEvaluator;
import io.nop.xlang.xdsl.ExtPropsGetter;
import io.nop.xlang.xmeta.IObjMeta;
import io.nop.xlang.xmeta.IObjPropMeta;
import io.nop.xlang.xmeta.ISchema;
import io.nop.xlang.xmeta.impl.ObjKeyModel;
import io.nop.xlang.xmeta.impl.ObjTreeModel;
import jakarta.annotation.Nullable;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static io.nop.auth.api.AuthApiErrors.ARG_BIZ_OBJ_NAME;
import static io.nop.auth.api.AuthApiErrors.ERR_AUTH_NO_DATA_AUTH;
import static io.nop.auth.api.AuthApiErrors.ERR_AUTH_NO_DATA_AUTH_AFTER_UPDATE;
import static io.nop.biz.BizConfigs.CFG_BIZ_QUERY_MAX_LEFT_JOIN_PROP_COUNT;
import static io.nop.biz.BizConstants.ACTION_ARG_ENTITY;
import static io.nop.biz.BizConstants.ACTION_doFindFirstByQueryDirectly;
import static io.nop.biz.BizConstants.BIZ_OBJ_NAME_THIS_OBJ;
import static io.nop.biz.BizConstants.METHOD_FIND_COUNT;
import static io.nop.biz.BizConstants.METHOD_FIND_FIRST;
import static io.nop.biz.BizConstants.METHOD_FIND_LIST;
import static io.nop.biz.BizConstants.METHOD_FIND_PAGE;
import static io.nop.biz.BizConstants.METHOD_FIND_TREE_LIST;
import static io.nop.biz.BizConstants.METHOD_FIND_TREE_PAGE;
import static io.nop.biz.BizConstants.METHOD_TRY_DELETE;
import static io.nop.biz.BizConstants.METHOD_TRY_SAVE;
import static io.nop.biz.BizConstants.METHOD_TRY_UPDATE;
import static io.nop.biz.BizConstants.PARAM_QUERY;
import static io.nop.biz.BizConstants.PARAM_SELECTION;
import static io.nop.biz.BizConstants.TAG_DICT;
import static io.nop.biz.BizErrors.ARG_ACTION_NAME;
import static io.nop.biz.BizErrors.ARG_CLASS_NAME;
import static io.nop.biz.BizErrors.ARG_DISPLAY_NAME;
import static io.nop.biz.BizErrors.ARG_ENTITY_NAME;
import static io.nop.biz.BizErrors.ARG_ID;
import static io.nop.biz.BizErrors.ARG_KEY;
import static io.nop.biz.BizErrors.ARG_PARAM_NAME;
import static io.nop.biz.BizErrors.ARG_PROP_NAME;
import static io.nop.biz.BizErrors.ARG_PROP_NAMES;
import static io.nop.biz.BizErrors.ARG_PROP_VALUE;
import static io.nop.biz.BizErrors.ARG_REF_ENTITY_NAME;
import static io.nop.biz.BizErrors.ERR_BIZ_EMPTY_DATA_FOR_SAVE;
import static io.nop.biz.BizErrors.ERR_BIZ_EMPTY_DATA_FOR_UPDATE;
import static io.nop.biz.BizErrors.ERR_BIZ_ENTITY_ALREADY_EXISTS;
import static io.nop.biz.BizErrors.ERR_BIZ_ENTITY_NOT_MATCH_FILTER_CONDITION;
import static io.nop.biz.BizErrors.ERR_BIZ_ENTITY_NOT_SUPPORT_LOGICAL_DELETE;
import static io.nop.biz.BizErrors.ERR_BIZ_ENTITY_WITH_SAME_KEY_ALREADY_EXISTS;
import static io.nop.biz.BizErrors.ERR_BIZ_NOT_ALLOW_DELETE_ENTITY_WHEN_REF_EXISTS;
import static io.nop.biz.BizErrors.ERR_BIZ_NOT_ALLOW_DELETE_PARENT_WHEN_CHILDREN_IS_NOT_EMPTY;
import static io.nop.biz.BizErrors.ERR_BIZ_NOT_ALLOW_GET_DELETED;
import static io.nop.biz.BizErrors.ERR_BIZ_NO_BIZ_MODEL_ANNOTATION;
import static io.nop.biz.BizErrors.ERR_BIZ_NO_ENTITY_ID;
import static io.nop.biz.BizErrors.ERR_BIZ_NO_MANDATORY_PARAM;
import static io.nop.biz.BizErrors.ERR_BIZ_NO_STATE_MACHINE;
import static io.nop.biz.BizErrors.ERR_BIZ_OBJ_NO_DICT_TAG;
import static io.nop.biz.BizErrors.ERR_BIZ_PROP_NOT_MANY_TO_MANY_REF;
import static io.nop.biz.BizErrors.ERR_BIZ_TOO_MANY_LEFT_JOIN_PROPS_IN_QUERY;
import static io.nop.graphql.core.GraphQLConfigs.CFG_GRAPHQL_MAX_PAGE_SIZE;
import static io.nop.orm.utils.OrmQueryHelper.resolveRef;

@Locale("zh-CN")
public abstract class CrudBizModel<T extends IOrmEntity>
        implements IBizModelImpl, IBizObjectQueryProcessor<T>, io.nop.orm.biz.ICrudBiz<T> {
    static final Logger LOG = LoggerFactory.getLogger(CrudBizModel.class);

    private IDaoProvider daoProvider;
    private String entityName;
    private String bizObjName;

    private IBizObjectManager bizObjectManager;

    /**
     * 自定义的query转换
     */
    private IQueryTransformer queryTransformer;

    private List<CascadePropMeta> cascadeProps;

    private ITransactionTemplate transactionTemplate;

    private CrudToolProvider crudToolProvider;

    private IGraphQLEngine graphQLEngine;

    @Inject
    public void setTransactionTemplate(ITransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    @Inject
    public void setQueryTransformer(@Named("nopGlobalQueryTransformer") @Nullable IQueryTransformer queryTransformer) {
        this.queryTransformer = queryTransformer;
    }

    @Inject
    public void setBizObjectManager(IBizObjectManager bizObjectManager) {
        this.bizObjectManager = bizObjectManager;
    }

    @Inject
    public void setCrudToolProvider(CrudToolProvider crudToolProvider) {
        this.crudToolProvider = crudToolProvider;
    }

    @Inject
    public void setGraphQLEngine(IGraphQLEngine graphQLEngine) {
        this.graphQLEngine = graphQLEngine;
    }

    public String getBizObjName() {
        if (bizObjName == null) {
            BizModel bizModel = getClass().getAnnotation(BizModel.class);
            if (bizModel == null)
                throw new NopException(ERR_BIZ_NO_BIZ_MODEL_ANNOTATION).param(ARG_CLASS_NAME, getClass().getName());

            bizObjName = bizModel.value();
        }
        return bizObjName;
    }

    @Override
    public IObjMeta getObjMeta() {
        return getThisObj().getObjMeta();
    }

    public String getAuthObjName(String action) {
        return getBizObjName();
    }

    /**
     * 如果强制指定BizObjName，则以指定的值为准
     */
    public void setBizObjName(String bizObjName) {
        this.bizObjName = bizObjName;
    }

    public IBizObject getThisObj() {
        return bizObjectManager.getBizObject(getBizObjName());
    }

    public IDaoProvider daoProvider() {
        return daoProvider;
    }

    public IBizObjectManager bizObjectManager() {
        return bizObjectManager;
    }

    @Inject
    public void setDaoProvider(IDaoProvider daoProvider) {
        this.daoProvider = daoProvider;
    }

    public void setEntityName(String entityName) {
        if (this.entityName != null && !this.entityName.equals(entityName))
            throw new IllegalArgumentException("nop.err.biz.entity-name-not-allow-change:oldEntityName=" + this.entityName + ",newEntityName=" + entityName);
        this.entityName = entityName;
    }

    public String getEntityName() {
        return entityName;
    }

    public ITransactionTemplate txn() {
        return transactionTemplate;
    }

    public IEntityDao<T> dao() {
        return daoProvider.dao(getEntityName());
    }

    @BizAction
    public final IEntityDao<T> getDao() {
        return dao();
    }

    public <R extends IOrmEntity> IEntityDao<R> daoFor(Class<R> clazz) {
        return daoProvider.daoFor(clazz);
    }

    public IOrmTemplate orm() {
        IEntityDao<T> dao = dao();
        return ((IOrmEntityDao<T>) dao).getOrmTemplate();
    }

    @Description("@i18n:biz.findCount|获取记录总数")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    public long findCount(@Optional @Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);

        return doFindCount0(query, getAuthObjName(METHOD_FIND_COUNT), this::invokeDefaultPrepareQuery, context);
    }

    @BizAction
    @Override
    public long doFindCount0(@Optional @Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                             @Name("authObjName") String authObjName, @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                             IServiceContext context) {
        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_COUNT, prepareQuery, context);

        IEntityDao<T> dao = dao();

        return dao.countByQuery(query);
    }

    @BizAction
    public long doFindCountByQueryDirectly(@Name("query") QueryBean query, IServiceContext context) {
        return dao().countByQuery(query);
    }

    @Description("@i18n:biz.findPage|分页查询")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public PageBean<T> findPage(@Optional @Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                                FieldSelectionBean selection, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);

        return doFindPage(query, this::invokeDefaultPrepareQuery, selection, context);
    }

    @BizAction
    public PageBean<T> doFindPage(@Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                                  @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery, FieldSelectionBean selection,
                                  IServiceContext context) {
        return doFindPage0(query, getAuthObjName(METHOD_FIND_PAGE), prepareQuery, selection, context);
    }

    @BizAction
    @Override
    public PageBean<T> doFindPage0(@Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                                   @Name("authObjName") String authObjName,
                                   @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                   FieldSelectionBean selection,
                                   IServiceContext context) {
        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_PAGE, prepareQuery, context);

        return doFindPageByQueryDirectly(query, selection, context);
    }

    @BizAction
    public PageBean<T> doFindPageByQueryDirectly(@Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        PageBean<T> pageBean = new PageBean<>();
        pageBean.setLimit(query.getLimit());
        pageBean.setOffset(query.getOffset());
        pageBean.setTotal(-1L);
        IEntityDao<T> dao = dao();
        if (selection != null && selection.hasSourceField(GraphQLConstants.FIELD_TOTAL)) {
            long total = dao.countByQuery(query);
            pageBean.setTotal(total);
        }

        if (selection == null || selection.hasSourceField(GraphQLConstants.FIELD_ITEMS)
                || selection.hasSourceField(GraphQLConstants.FIELD_PAGE_INFO)
                || selection.hasSourceField(GraphQLConstants.FIELD_EDGES)
                || selection.hasSourceField(GraphQLConstants.FIELD_NEXT_CURSOR)) {
            if (!StringHelper.isEmpty(query.getCursor())) {
                dao.findPageAndReturnCursor(query, pageBean);
            } else {
                List<T> ret = dao.findPageByQuery(query);
                pageBean.setItems(ret);
            }
        }
        return pageBean;
    }

    @BizAction
    public List<T> doFindListByQueryDirectly(@Name("query") QueryBean query, IServiceContext context) {
        return dao().findPageByQuery(query);
    }

    @BizAction
    protected QueryBean prepareFindPageQuery(@Name("query") QueryBean query,
                                             @Name("authObjName") String authObjName,
                                             @Name("action") String action,
                                             @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                             IServiceContext context) {
        if (authObjName == null)
            authObjName = getAuthObjName(action);

        checkAllowQuery(query, getThisObj().getObjMeta());

        query = AuthHelper.appendFilter(context.getDataAuthChecker(), query, authObjName, action,
                context);
        if (query == null)
            query = new QueryBean();

        if (query.getName() == null) {
            query.setName(authObjName + '.' + action);
        }

        IObjMeta objMeta = getThisObj().getObjMeta();
        int maxPageSize = getMaxPageSize();
        if (objMeta != null) {
            if (objMeta.getFilter() != null) {
                query.addFilter(objMeta.getFilter().cloneInstance());
            }

            if (objMeta.getOrderBy() != null) {
                query.addOrderBy(objMeta.getOrderBy());
            }
        }

        if (query.getLimit() <= 0) {
            query.setLimit(maxPageSize);
        }

        if (query.getLimit() > maxPageSize) {
            query.setLimit(maxPageSize);
        }

        appendOrderByPk(query);

        if (prepareQuery != null)
            prepareQuery.accept(query, context);

        if (query.getFilter() != null)
            BizQueryHelper.transformFilter(query, objMeta, context);

        if (queryTransformer != null)
            queryTransformer.transform(query, authObjName, action, this.getThisObj(), context);

        BizQueryHelper.transformMapToProp(query, objMeta);
        BizExprHelper.resolveBizExpr(query.getFilter(), context);
        return query;
    }

    public int getMaxPageSize() {
        int maxPageSize = CFG_GRAPHQL_MAX_PAGE_SIZE.get();
        IObjMeta objMeta = getThisObj().getObjMeta();
        if (objMeta != null) {
            Integer objMaxPageSize = ConvertHelper.toInt(objMeta.prop_get(BizConstants.EXT_MAX_PAGE_SIZE), NopException::new);
            if (objMaxPageSize != null && objMaxPageSize > maxPageSize)
                maxPageSize = objMaxPageSize;
        }
        return maxPageSize;
    }

    protected void checkAllowQuery(QueryBean query, IObjMeta objMeta) {
        if (objMeta != null && query != null) {
            if (query.getFilter() != null)
                crudToolProvider.newFilterValidator(objMeta).visit(query.getFilter(), DisabledEvalScope.INSTANCE);

            if (query.getOrderBy() != null) {
                for (OrderFieldBean field : query.getOrderBy()) {
                    String name = field.getName();
                    BizObjMetaHelper.checkPropSortable(getBizObjName(), objMeta, name);
                }
            }

            if (query.getLeftJoinProps() != null) {
                if (query.getLeftJoinProps().size() > CFG_BIZ_QUERY_MAX_LEFT_JOIN_PROP_COUNT.get())
                    throw new NopException(ERR_BIZ_TOO_MANY_LEFT_JOIN_PROPS_IN_QUERY)
                            .param(ARG_BIZ_OBJ_NAME, getBizObjName())
                            .param(ARG_PROP_NAMES, query.getLeftJoinProps());
                BizObjMetaHelper.checkAllowLeftJoinProps(query.getLeftJoinProps(), objMeta);
            }
        }
    }

    protected void appendOrderByPk(QueryBean query) {
        IEntityDao<T> dao = dao();
        List<OrderFieldBean> orderBy = query.getOrderBy();
        IObjMeta objMeta = getThisObj().getObjMeta();
        // 总是追加具有唯一性的排序条件，保证分页结果的确定性
        if (objMeta == null || !OrmQueryHelper.containsAnyKey(orderBy, objMeta.getKeys())) {
            boolean desc = false;
            orderBy = OrmQueryHelper.appendOrderByPk(orderBy, dao.getPkColumnNames(), desc);
            query.setOrderBy(orderBy);
        }
    }

    @Description("@i18n:biz.findFirst|返回符合条件的第一条数据")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T findFirst(@Optional @Name(PARAM_QUERY) @Description("@i18n:biz.query|查询条件") QueryBean query,
                       @Name(PARAM_SELECTION) FieldSelectionBean selection, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);
        return doFindFirst(query, this::invokeDefaultPrepareQuery, selection, context);
    }

    @BizAction
    public T doFindFirst(@Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                         @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                         FieldSelectionBean selection, IServiceContext context) {
        return doFindFirst0(query, getAuthObjName(METHOD_FIND_FIRST), prepareQuery, selection, context);
    }

    @BizAction
    @Override
    public T doFindFirst0(@Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                          @Name("authObjName") String authObjName,
                          @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                          FieldSelectionBean selection, IServiceContext context) {
        query = prepareFindFirstQuery(query, authObjName, METHOD_FIND_FIRST, prepareQuery, context);
        T ret = dao().findFirstByQuery(query);
        return ret;
    }

    /**
     * 跳过数据权限直接执行查询，这里相比于直接使用dao，提供了一个定制机会。BizModel可以不基于Dao来实现这个函数
     */
    @BizAction
    public T doFindFirstByQueryDirectly(@Name("query") QueryBean query, IServiceContext context) {
        return dao().findFirstByQuery(query);
    }

    @BizAction
    protected QueryBean prepareFindFirstQuery(@Name("query") QueryBean query,
                                              @Name("authObjName") String authObjName,
                                              @Name("action") String action,
                                              @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                              IServiceContext context) {
        query = prepareFindPageQuery(query, authObjName, action, prepareQuery, context);
        query.setLimit(1);
        return query;
    }

    @BizAction
    protected void defaultPrepareQuery(@Name("query") QueryBean query, IServiceContext context) {

    }

    @Description("@i18n:biz.save|保存数据")
    @BizMutation
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T save(@Name("data") Map<String, Object> data, IServiceContext context) {
        return doSave(data, null, this::invokeDefaultPrepareSave, context);
    }

    @BizAction
    public T doSave(@Name("data") Map<String, Object> data, @Name("inputSelection") FieldSelectionBean inputSelection,
                    @Name("prepareSave") BiConsumer<EntityData<T>, IServiceContext> prepareSave, IServiceContext context) {
        if (CollectionHelper.isEmptyMap(data))
            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_SAVE).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        EntityData<T> entityData = buildEntityDataForSave(data, inputSelection, context);
        checkUniqueForSave(entityData);

        crudToolProvider.newOrmEntityCopier(entityData.getObjMeta(), context, entityData.getDelayedActions()).copyToEntity(entityData.getValidatedData(),
                entityData.getEntity(), null, entityData.getObjMeta(), getBizObjName(),
                BizConstants.METHOD_SAVE, context.getEvalScope());

        if (prepareSave != null)
            prepareSave.accept(entityData, context);

        checkDataAuth(BizConstants.METHOD_SAVE, entityData.getEntity(), context);
        executeDelayedRelationActions(entityData, context);

        doSaveEntity(entityData, context);

        return entityData.getEntity();
    }

    @BizAction
    protected void checkUniqueForSave(@Name("entityData") EntityData<T> entityData) {
        IObjMeta objMeta = entityData.getObjMeta();
        if (objMeta.getKeys() != null) {
            Map<String, Object> data = entityData.getValidatedData();
            IEntityDao<T> dao = dao();
            for (ObjKeyModel keyModel : objMeta.getKeys()) {
                Set<String> props = keyModel.getProps();
                if (data.keySet().containsAll(props)) {
                    T example = dao.newEntity();
                    List<Object> keys = new ArrayList<>();
                    List<Object> displayNames = new ArrayList<>();
                    for (String propName : props) {
                        Object value = data.get(propName);
                        example.orm_propValueByName(propName, value);
                        keys.add(value);
                        displayNames.add(objMeta.getProp(propName).getDisplayName());
                    }
                    T existing = dao.findFirstByExample(example);
                    if (existing != null && existing != entityData.getEntity()) {
                        throw new NopException(ERR_BIZ_ENTITY_WITH_SAME_KEY_ALREADY_EXISTS)
                                .param(ARG_KEY, StringHelper.join(keys, ",")).param(ARG_DISPLAY_NAME, StringHelper.join(displayNames, ","))
                                .param(ARG_BIZ_OBJ_NAME, getBizObjName());
                    }
                }
            }
        }
    }

    /**
     * 检查实体在保存时是否满足唯一性约束
     */
    protected void checkUniqueForSaveEntity(T entity, IObjMeta objMeta) {
        if (objMeta.getKeys() != null) {
            IEntityDao<T> dao = dao();
            for (ObjKeyModel keyModel : objMeta.getKeys()) {
                Set<String> props = keyModel.getProps();
                T example = dao.newEntity();
                List<Object> keys = new ArrayList<>();
                List<Object> displayNames = new ArrayList<>();
                boolean allPropsSet = true;
                for (String propName : props) {
                    Object value = entity.orm_propValueByName(propName);
                    if (value == null) {
                        allPropsSet = false;
                        break;
                    }
                    example.orm_propValueByName(propName, value);
                    keys.add(value);
                    displayNames.add(objMeta.getProp(propName).getDisplayName());
                }
                if (allPropsSet) {
                    T existing = dao.findFirstByExample(example);
                    if (existing != null && existing != entity) {
                        throw new NopException(ERR_BIZ_ENTITY_WITH_SAME_KEY_ALREADY_EXISTS)
                                .param(ARG_KEY, StringHelper.join(keys, ",")).param(ARG_DISPLAY_NAME, StringHelper.join(displayNames, ","))
                                .param(ARG_BIZ_OBJ_NAME, getBizObjName());
                    }
                }
            }
        }
    }

    @BizAction
    protected void checkUniqueForUpdate(@Name("entity") T entity, IServiceContext context) {
        IObjMeta objMeta = getThisObj().getObjMeta();
        if (objMeta.getKeys() != null) {
            IEntityDao<T> dao = dao();
            for (ObjKeyModel keyModel : objMeta.getKeys()) {
                Set<String> props = keyModel.getProps();
                if (isAnyPropDirty(entity, props)) {
                    T example = dao.newEntity();
                    List<Object> keys = new ArrayList<>();
                    List<Object> displayNames = new ArrayList<>();
                    for (String propName : props) {
                        Object value = entity.orm_propValueByName(propName);
                        example.orm_propValueByName(propName, value);
                        keys.add(value);
                        displayNames.add(objMeta.getProp(propName).getDisplayName());
                    }
                    T existing = dao.findFirstByExample(example);
                    if (existing != null && existing != entity) {
                        throw new NopException(ERR_BIZ_ENTITY_WITH_SAME_KEY_ALREADY_EXISTS)
                                .param(ARG_KEY, StringHelper.join(keys, ",")).param(ARG_DISPLAY_NAME, StringHelper.join(displayNames, ","))
                                .param(ARG_BIZ_OBJ_NAME, getBizObjName());
                    }
                }
            }
        }
    }

    protected boolean isAnyPropDirty(T entity, Set<String> propNames) {
        for (String propName : propNames) {
            int propId = entity.orm_propId(propName);
            if (propId < 0)
                continue;
            if (entity.orm_propDirty(propId))
                return true;
        }
        return false;
    }

//    @BizAction
//    public void trySave(@Name("data") Map<String, Object> data, FieldSelectionBean selection, IServiceContext context) {
//        if (CollectionHelper.isEmptyMap(data))
//            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_SAVE).param(ARG_BIZ_OBJ_NAME, getBizObjName());
//
//        EntityData<T> entityData = buildEntityDataForSave(data, selection, context);
//
//        defaultPrepareSave(entityData, context);
//    }

    @BizAction
    protected EntityData<T> buildEntityDataForSave(@Name("data") Map<String, Object> data,
                                                   @Name("inputSelection") FieldSelectionBean inputSelection, IServiceContext context) {
        return buildEntityDataForSave(data, inputSelection, context, true);
    }

    /**
     * @param recoverDeleted 是否尝试恢复逻辑删除记录。save场景下按id恢复已删除记录；
     *                       copyForNew场景下data中携带的是存活源记录的id，不应触发恢复逻辑，
     *                       否则会按源id查到存活实体并误抛“记录已存在”异常
     */
    protected EntityData<T> buildEntityDataForSave(@Name("data") Map<String, Object> data,
                                                   @Name("inputSelection") FieldSelectionBean inputSelection,
                                                   IServiceContext context, boolean recoverDeleted) {
        IBizObject bizObj = getThisObj();
        IObjMeta objMeta = bizObj.requireObjMeta();

        ObjMetaBasedValidator validator = crudToolProvider.newValidator(bizObj.getBizObjName(), objMeta,
                context, true);

        Map<String, Object> validated = validator.validateForSave(data, inputSelection);

        T entity = null;
        boolean recover = false;
        if (recoverDeleted) {
            entity = recoverLogicalDeleted(data, objMeta);
            if (entity != null) {
                recover = true;
            }
        }
        if (entity == null) {
            entity = dao().newEntity();
        }

        EntityData entityData = new EntityData<>(data, validated, entity, objMeta);
        entityData.setRecoverDeleted(recover);
        return entityData;
    }

    protected T recoverLogicalDeleted(Map<String, Object> data, IObjMeta objMeta) {
        IEntityDao<T> dao = dao();
        T entity = null;
        if (dao.isUseLogicalDelete()) {
            entity = findLogicalDeleted(data, dao, objMeta);
            if (entity != null) {
                dao.resetToDefaultValues(entity);
            }
        }
        return entity;
    }

    protected T findLogicalDeleted(Map<String, Object> data, IEntityDao<T> dao, IObjMeta objMeta) {
        // 如果是逻辑删除后再次添加同样主键的对象
        Object id = getId(data, dao);
        T entity = null;
        if (id != null) {
            id = dao.castId(id);
            entity = dao.getEntityById(id);
        }

        if (entity != null) {
            if (!entity.orm_logicalDeleted()) {
                throw new NopException(ERR_BIZ_ENTITY_ALREADY_EXISTS).param(ARG_ENTITY_NAME, getEntityName())
                        .param(ARG_ID, id);
            }
        }
        return entity;
    }

    Object getId(Map<String, Object> data, IEntityDao<T> dao) {
        List<String> colNames = dao.getPkColumnNames();
        if (colNames.size() == 1) {
            return data.get(colNames.get(0));
        }

        List<Object> values = new ArrayList<>(colNames.size());
        for (String colName : colNames) {
            Object value = data.get(colName);
            if (StringHelper.isEmptyObject(value))
                return null;
            values.add(value);
        }
        return values;
    }

    protected void checkDataAuth(@Name("action") String action, @Name("entity") T entity, IServiceContext context) {
        if (context == null)
            return;
        IDataAuthChecker dataAuthChecker = context.getDataAuthChecker();
        if (dataAuthChecker == null)
            return;

        String bizObjName = getAuthObjName(action);
        if (!dataAuthChecker.isPermitted(bizObjName, action, entity, context)) {
            throw new NopException(ERR_AUTH_NO_DATA_AUTH).param(ARG_BIZ_OBJ_NAME, bizObjName);
        }
    }

    protected void checkDataAuthAfterUpdate(@Name("entity") T entity, IServiceContext context) {
        IDataAuthChecker dataAuthChecker = context.getDataAuthChecker();
        if (dataAuthChecker == null)
            return;

        String bizObjName = getAuthObjName(BizConstants.METHOD_UPDATE);
        if (!dataAuthChecker.isPermitted(bizObjName, BizConstants.METHOD_UPDATE, entity, context)) {
            throw new NopException(ERR_AUTH_NO_DATA_AUTH_AFTER_UPDATE).param(ARG_BIZ_OBJ_NAME, bizObjName);
        }
    }


    @BizAction
    protected void defaultPrepareSave(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        IStateMachine stm = getThisObj().getStateMachine();
        if (stm != null) {
            stm.initState(entityData.getEntity());
        }
    }


    @BizAction
    protected void defaultPrepareCopyForNew(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        this.invokeDefaultPrepareSave(entityData, context);
    }

    protected void triggerStateChange(T entity, String event, IServiceContext context) {
        triggerStateChange(entity, event, context, null);
    }

    protected void triggerStateChange(T entity, String event, IServiceContext context, Consumer<StateModel> action) {
        IStateMachine stm = getThisObj().getStateMachine();
        if (stm == null)
            throw new NopException(ERR_BIZ_NO_STATE_MACHINE)
                    .param(ARG_BIZ_OBJ_NAME, getBizObjName());
        stm.triggerStateChange(entity, event, context, action);
    }

    @BizAction
    protected void doSaveEntity(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        if (entityData.isRecoverDeleted()) {
            dao().updateEntity(entityData.getEntity());
        } else {
            dao().saveEntity(entityData.getEntity());
        }
        afterEntityChange(entityData.getEntity(), BizConstants.METHOD_SAVE, context);
    }

    protected void afterEntityChange(@Name("entity") T entity, @Name("action") String action, IServiceContext context) {
        afterEntityChange(entity, context);
    }

    // 使用afterEntityChage(entity, context, action)方法来代替
    @Deprecated
    protected void afterEntityChange(@Name("entity") T entity, IServiceContext context) {

    }

    protected void invokeAction(String actionName, Map<String, Object> args, IServiceContext context,
                                BizInvocation inv) {
        IBizObject bizObject = getThisObj();
        IServiceAction action = bizObject.getAction(actionName);
        if (action != null) {
            args.put(BizConstants.ACTION_ARG_INVOCATION, inv);
            action.invoke(args, null, context);
        } else {
            inv.proceed();
        }
    }

    @Description("@i18n:biz.update|更新数据")
    @BizMutation
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T update(@Name("data") Map<String, Object> data, IServiceContext context) {
        return doUpdate(data, null, this::invokeDefaultPrepareUpdate, context);
    }

    @BizAction
    public T doUpdate(@Name("data") Map<String, Object> data,
                      @Name("inputSelection") FieldSelectionBean inputSelection,
                      @Name("prepareUpdate") BiConsumer<EntityData<T>, IServiceContext> prepareUpdate, IServiceContext context) {
        if (CollectionHelper.isEmptyMap(data))
            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_UPDATE).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        EntityData<T> entityData = buildEntityDataForUpdate(data, inputSelection, context);
        if (entityData.getEntity() == null)
            throw new NopException(ERR_BIZ_NO_ENTITY_ID).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        crudToolProvider.newOrmEntityCopier(entityData.getObjMeta(), context, entityData.getDelayedActions()).copyToEntity(entityData.getValidatedData(),
                entityData.getEntity(), null, entityData.getObjMeta(), getBizObjName(),
                BizConstants.METHOD_UPDATE, context.getEvalScope());

        if (prepareUpdate != null)
            prepareUpdate.accept(entityData, context);

        checkDataAuthAfterUpdate(entityData.getEntity(), context);
        checkUniqueForUpdate(entityData.getEntity(), context);
        executeDelayedRelationActions(entityData, context);

        doUpdateEntity(entityData, context);

        return entityData.getEntity();
    }

    /**
     * 将json对象中的属性逐一拷贝到实体上，支持复杂的关联子集合对象的拷贝。并且会自动处理xmeta文件中定义的autoExpr。
     * autoExpr是根据action是save还是update来确定是否自动执行的计算表达式，比如配置orderNo的autoExpr，可以使得保存的时候自动分配订单号。
     */
    protected void copyToEntity(Map<String, Object> data, T entity, String action, IServiceContext context) {
        IObjMeta objMeta = this.getThisObj().requireObjMeta();
        EntityData<T> entityData = new EntityData<>(data, data, entity, objMeta);
        crudToolProvider.newOrmEntityCopier(objMeta, context, entityData.getDelayedActions()).copyToEntity(data,
                entity, null, objMeta, getBizObjName(), action, context.getEvalScope());
        executeDelayedRelationActions(entityData, context);
    }

    @BizAction
    protected void executeDelayedRelationActions(@Name("entityData") EntityData<T> entityData,
                                                 IServiceContext context) {
        if (entityData == null || !entityData.hasDelayedActions()) {
            return;
        }

        List<IDelayedAction> actions = new ArrayList<>(entityData.getDelayedActions());
        actions.sort(Comparator.comparingInt(IDelayedAction::getOrder));
        for (IDelayedAction action : actions) {
            action.execute(context);
        }
    }

//    @BizAction
//    public void tryUpdate(@Name("data") Map<String, Object> data,
//                          @Name("inputSelection") FieldSelectionBean inputSelection, IServiceContext context) {
//        if (CollectionHelper.isEmptyMap(data))
//            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_UPDATE).param(ARG_BIZ_OBJ_NAME, getBizObjName());
//
//        buildEntityDataForUpdate(data, inputSelection, context);
//    }

    @BizAction
    public T requireEntity(@Name("id") String id, @Name("action") String action, IServiceContext context) {
        return getEntity(id, action, false, false, context);
    }

    @BizAction
    protected T getEntity(@Name("id") String id, @Name("action") String action,
                          @Name("ignoreUnknown") boolean ignoreUnknown,
                          @Name("includeLogicalDeleted") boolean includeLogicalDeleted,
                          IServiceContext context) {
        IBizObject bizObj = getThisObj();
        IObjMeta objMeta = bizObj.requireObjMeta();

        T entity = doGetEntity(id, ignoreUnknown, context);
        if (entity == null)
            return null;

        if (!includeLogicalDeleted) {
            if (entity.orm_logicalDeleted()) {
                if (ignoreUnknown)
                    return null;
                throw new UnknownEntityException(getEntityName(), id).param("deleted", true);
            }
        }

        checkDataAuth(action, entity, context);
        checkMetaFilter(entity, objMeta, context);
        return entity;
    }

    protected T doGetEntity(@Name("id") String id,
                            @Name("ignoreUnknown") boolean ignoreUnknown,
                            IServiceContext context) {
        // 上传文件时可能使用临时对象占位
        if (BizConstants.TEMP_BIZ_OBJ_ID.equals(id))
            return null;

        IEntityDao<T> dao = dao();
        T entity = dao.getEntityById(id);
        if (entity == null || entity.orm_state().isMissing()) {
            if (ignoreUnknown)
                return null;
            if (StringHelper.isEmpty(id))
                throw new NopException(ERR_BIZ_NO_ENTITY_ID).param(ARG_BIZ_OBJ_NAME, getBizObjName());

            throw new UnknownEntityException(dao.getEntityName(), id);
        }
        return entity;
    }

    @BizAction
    protected EntityData<T> buildEntityDataForUpdate(@Name("data") Map<String, Object> data,
                                                     @Name("inputSelection") FieldSelectionBean inputSelection, IServiceContext context) {
        IBizObject bizObj = getThisObj();
        IObjMeta objMeta = bizObj.requireObjMeta();

        Object id = data.get(OrmConstants.PROP_ID);

        ObjMetaBasedValidator validator = crudToolProvider.newValidator(bizObj.getBizObjName(), objMeta,
                context, true);

        Map<String, Object> validated = validator.validateForUpdate(data, inputSelection);
        // id不允许被更新
        validated.remove(OrmConstants.PROP_ID);

        T entity = StringHelper.isEmptyObject(id) ? null : requireEntity(ConvertHelper.toString(id), BizConstants.METHOD_UPDATE, context);

        return new EntityData<>(data, validated, entity, objMeta);
    }

    protected void checkMetaFilter(T entity, IObjMeta objMeta, IServiceContext context) {
        if (context == null)
            return;
        if (objMeta != null && objMeta.getFilter() != null) {
            boolean b = new BizFilterEvaluator(context).testForEntity(objMeta.getFilter(), entity);

            if (!b)
                throw new NopException(ERR_BIZ_ENTITY_NOT_MATCH_FILTER_CONDITION)
                        .param(ARG_BIZ_OBJ_NAME, getBizObjName()).param(ARG_ID, entity.orm_id())
                        .param(ACTION_ARG_ENTITY, entity);
        }
    }

    @BizAction
    protected void defaultPrepareUpdate(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
    }

    @BizAction
    protected void doUpdateEntity(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        dao().updateEntity(entityData.getEntity());
        afterEntityChange(entityData.getEntity(), BizConstants.METHOD_UPDATE, context);
    }

    @Description("@i18n:biz.get|根据id获取单条数据")
    @BizQuery
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T get(@Name("id") @Description("@i18n:biz.id|对象的主键标识") String id,
                 @Optional @Name("ignoreUnknown") @Description("@i18n:biz.ignoreUnknown|未找到对象时是返回null还是抛出异常") boolean ignoreUnknown,
                 IServiceContext context) {
        checkMandatoryParam("get", "id", id);

        T entity = getEntity(id, BizConstants.METHOD_GET, ignoreUnknown, false, context);
        return entity;
    }

    @Description("@i18n:biz.get|根据id获取已经被逻辑删除的单条数据")
    @BizQuery
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T deleted_get(@Name("id") @Description("@i18n:biz.id|对象的主键标识") String id,
                         @Optional @Name("ignoreUnknown") @Description("@i18n:biz.ignoreUnknown|未找到对象时是返回null还是抛出异常") boolean ignoreUnknown,
                         IServiceContext context) {
        if (!isAllowGetDeleted())
            throw new NopException(ERR_BIZ_NOT_ALLOW_GET_DELETED).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        checkMandatoryParam("get", "id", id);

        T entity = getEntity(id, BizConstants.METHOD_GET, ignoreUnknown, true, context);
        return entity;
    }

    protected boolean isAllowGetDeleted() {
        IObjMeta objMeta = getThisObj().getObjMeta();
        // 无xmeta的业务对象按不允许处理，与getMaxPageSize等相邻方法的判空逻辑一致
        if (objMeta == null)
            return false;
        return ConvertHelper.toPrimitiveBoolean(objMeta.prop_get(BizConstants.BIZ_ALLOW_GET_DELETED));
    }

    @Description("@i18n:biz.batchGet|根据主键批量获取对象")
    @BizQuery
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public List<T> batchGet(@Name("ids") Collection<String> ids,
                            @Optional @Name("ignoreUnknown") boolean ignoreUnknown,
                            IServiceContext context) {
        if (CollectionHelper.isEmpty(ids))
            return Collections.emptyList();

        IEntityDao<T> dao = dao();
        List<T> list = ignoreUnknown ? dao.tryBatchGetEntitiesByIds(ids) : dao.batchRequireEntitiesByIds(ids);
        if (list.isEmpty()) {
            return list;
        }

        for (T entity : list) {
            if (entity.orm_logicalDeleted())
                throw new UnknownEntityException(dao.getEntityName(), entity.orm_id()).param("deleted", true);

            checkMetaFilter(entity, getThisObj().getObjMeta(), context);
            checkDataAuth(BizConstants.METHOD_GET, entity, context);
        }
        return list;
    }

    protected void checkMandatoryParam(String actionName, String paramName, Object value) {
        if (StringHelper.isEmptyObject(value))
            throw new NopException(ERR_BIZ_NO_MANDATORY_PARAM).param(ARG_ACTION_NAME, actionName)
                    .param(ARG_PARAM_NAME, paramName).param(ARG_BIZ_OBJ_NAME, getBizObjName());
    }

    @Description("@i18n:biz.delete|根据主键删除指定对象")
    @BizMutation
    public boolean delete(@Name("id") @Description("@i18n:biz.id|对象的主键标识") String id, IServiceContext context) {
        return doDelete(id, this.getDefaultRefNamesToCheckExists(), this::invokeDefaultPrepareDelete, context);
    }

    public Set<String> getDefaultRefNamesToCheckExists() {
        IObjMeta objMeta = getThisObj().getObjMeta();
        if (objMeta == null)
            return null;
        return ConvertHelper.toCsvSet(objMeta.prop_get(BizConstants.ATTR_REFS_NEED_TO_CHECK_WHEN_DELETE));
    }

    @BizAction
    public boolean doDelete(@Name("id") @Description("@i18n:biz.id|对象的主键标识") String id,
                            @Name("refNamesToCheck") Set<String> refNamesToCheck,
                            @Name("prepareDelete") BiConsumer<T, IServiceContext> prepareDelete, IServiceContext context) {
        checkMandatoryParam("delete", "id", id);

        T entity = dao().getEntityById(id);
        if (entity == null)
            return true;

        doDeleteEntity(entity, refNamesToCheck, prepareDelete, context);
        return true;
    }

    @BizAction
    protected void checkEntityRefsNotExists(@Name("entity") T entity, @Name("refNamesToCheck") Set<String> refNamesToCheck, IServiceContext context) {
        IEntityModel entityModel = entity.orm_entityModel();
        if (refNamesToCheck != null) {
            for (String refName : refNamesToCheck) {
                IOrmEntity refEntity = findRefEntity(entityModel, entity, refName, context);
                if (refEntity != null)
                    throw new NopException(ERR_BIZ_NOT_ALLOW_DELETE_ENTITY_WHEN_REF_EXISTS)
                            .param(ARG_REF_ENTITY_NAME, refEntity.orm_entityModel().getName());

            }
        }
    }

    protected IOrmEntity findRefEntity(IEntityModel entityModel, T entity, String refName, IServiceContext context) {
        // 无xmeta的biz对象显式传入refNamesToCheck时按语义化异常报错，而不是解引用null objMeta抛NPE
        IObjPropMeta propMeta = getThisObj().requireObjMeta().getProp(refName);
        if (propMeta != null) {
            String refBizObjName = propMeta.getBizObjName();
            if (refBizObjName == null)
                refBizObjName = propMeta.getItemBizObjName();

            TreeBean filter = ExtPropsGetter.getTreeBean(propMeta, GraphQLConstants.TAG_GRAPHQL_FILTER);
            if (filter != null && refBizObjName != null) {
                // 因为从propMeta上获取的是缓存的filter，这里又可能会修改filter的内容，为安全期间复制一份
                resolveRef(filter.cloneInstance(), entity);
                IBizObject refBizObj = bizObjectManager.getBizObject(refBizObjName);

                Map<String, Object> request = new HashMap<>();
                QueryBean query = new QueryBean();
                query.addFilter(filter);
                request.put(BizConstants.PARAM_QUERY, query);
                return (IOrmEntity) refBizObj.invoke(ACTION_doFindFirstByQueryDirectly, request, null, context);
            }
        }

        IEntityRelationModel relModel = entityModel.getRelation(refName, true);
        if (relModel == null) {
            // 实体模型上不存在这个关联
            propMeta = getThisObj().requireObjMeta().requireProp(refName);
            String leftProp = (String) propMeta.prop_get(BizConstants.EXT_JOIN_LEFT_PROP);
            String rightProp = (String) propMeta.prop_get(BizConstants.EXT_JOIN_RIGHT_PROP);

            Object refValue = BeanTool.getProperty(entity, leftProp);
            if (StringHelper.isEmptyObject(refValue))
                return null;

            String refBizObjName = propMeta.getBizObjName();
            if (refBizObjName == null)
                refBizObjName = propMeta.getItemBizObjName();

            IBizObject refBizObj = bizObjectManager.getBizObject(refBizObjName);
            Map<String, Object> request = new HashMap<>();
            QueryBean query = new QueryBean();
            query.addFilter(FilterBeans.eq(rightProp, refValue));
            request.put(BizConstants.PARAM_QUERY, query);
            return (IOrmEntity) refBizObj.invoke(ACTION_doFindFirstByQueryDirectly, request, null, context);
        }

        if (relModel.isToOneRelation() && !relModel.isReverseDepends())
            return null;

        if (relModel.isToOneRelation()) {
            IOrmEntity refEntity = entity.orm_refEntity(refName);
            if (refEntity == null)
                return null;
            if (!refEntity.orm_proxy())
                return refEntity;
        } else {
            IOrmEntitySet<?> refSet = entity.orm_refEntitySet(refName);
            if (!refSet.orm_proxy()) {
                return refSet.get__first();
            }
        }

        // 尚未通过关联加载，则直接查找
        IEntityDao<IOrmEntity> refDao = daoProvider.dao(relModel.getRefEntityName());
        IOrmEntity example = refDao.newEntity();
        for (IEntityJoinConditionModel joinModel : relModel.getJoin()) {
            Object leftValue = OrmEntityHelper.getLeftValue(joinModel, entity);
            if (StringHelper.isEmptyObject(leftValue))
                return null;
            if (joinModel.getRightPropModel() == null)
                continue;

            OrmEntityHelper.setPropValue(joinModel.getRightPropModel(), example, leftValue);
        }
        return refDao.findFirstByExample(example);
    }

    @BizAction
    public T newEntity() {
        return dao().newEntity();
    }


    @BizAction
    protected void defaultPrepareDelete(@Name("entity") T entity, IServiceContext context) {
        checkChildrenNotExistsWhenDelete(entity, context);
    }

    @BizAction
    protected void checkChildrenNotExistsWhenDelete(@Name("entity") T entity, IServiceContext context) {
        IObjMeta objMeta = getThisObj().getObjMeta();
        if (objMeta != null) {
            ObjTreeModel tree = objMeta.getTree();
            if (tree != null) {
                if (tree.getChildrenProp() != null) {
                    IObjPropMeta prop = objMeta.getProp(tree.getChildrenProp());
                    // 如果不是递归删除children，则需要检查children不存在
                    if (prop != null && !prop.containsTag(BizConstants.TAG_CASCADE_DELETE)) {
                        Collection<?> children = (Collection<?>) entity.orm_propValueByName(prop.getName());
                        if (children != null && !children.isEmpty()) {
                            throw new NopException(ERR_BIZ_NOT_ALLOW_DELETE_PARENT_WHEN_CHILDREN_IS_NOT_EMPTY)
                                    .param(ARG_BIZ_OBJ_NAME, getBizObjName())
                                    .param(ARG_ID, entity.orm_idString());
                        }
                    }
                }
            }
        }
    }

    protected void doDeleteEntity(T entity, IServiceContext context) {
        this.doDeleteEntity(entity, getDefaultRefNamesToCheckExists(), this::invokeDefaultPrepareDelete, context);
    }

    @BizAction
    protected void doDeleteEntity(@Name("entity") T entity, @Name("refNamesToCheck") Set<String> refNamesToCheck,
                                  @Name("prepareDelete") BiConsumer<T, IServiceContext> prepareDelete, IServiceContext context) {
        checkMetaFilter(entity, getThisObj().getObjMeta(), context);
        checkDataAuth(BizConstants.METHOD_DELETE, entity, context);

        if (refNamesToCheck != null)
            checkEntityRefsNotExists(entity, refNamesToCheck, context);

        if (prepareDelete != null) {
            prepareDelete.accept(entity, context);
        }
        // 先标记实体被删除，避免递归删除的时候出现死循环
        dao().deleteEntity(entity);
        deleteReferences(entity, BizConstants.METHOD_DELETE, context);
        afterEntityChange(entity, BizConstants.METHOD_DELETE, context);
    }

    /**
     * 删除所有关联对象
     */
    protected void deleteReferences(@Name("entity") T entity, @Name("action") String action, IServiceContext context) {
        IOrmBatchLoadQueue loadQueue = orm().requireSession().getBatchLoadQueue();
        boolean empty = loadQueue.isEmpty();

        for (CascadePropMeta prop : getCascadeProps()) {
            if (prop.isCascadeDelete()) {
                queueCascadeDelete(entity, prop.getPropMeta(), prop.getRefBizObjName(), context);
            }
        }

        // 如果不为空，则表示由外部调用者负责flush
        if (empty)
            loadQueue.flush();
    }

    protected void queueCascadeDelete(T entity, IObjPropMeta propMeta, String refBizObjName, IServiceContext context) {
        Object value = BizObjHelper.getProp(entity, propMeta, context);
        if (value == null)
            return;

        IOrmBatchLoadQueue loadQueue = orm().requireSession().getBatchLoadQueue();
        IBizObject refBizObj = bizObjectManager.getBizObject(refBizObjName);

        if (value instanceof IOrmEntity) {
            IOrmEntity refEntity = (IOrmEntity) value;
            // 已经标记为被删除或者不存在的记录不需要再进行进一步的处理
            if (refEntity.orm_state().isGone()) {
                LOG.info("nop.orm.delete-skip-entity-already-gone:entity={}", refEntity);
                return;
            }

            loadQueue.enqueue(refEntity);
            loadQueue.afterFlush(() -> {
                Map<String, Object> req = new HashMap<>();
                req.put(GraphQLConstants.ARG_ID, refEntity.orm_idString());
                refBizObj.invoke(BizConstants.METHOD_DELETE, req, null, context);
            });
        } else if (value instanceof IOrmEntitySet) {
            Collection<IOrmEntity> c = (Collection<IOrmEntity>) value;
            loadQueue.enqueueMany(c);
            loadQueue.afterFlush(() -> {
                for (IOrmEntity refEntity : c) {
                    if (refEntity.orm_state().isGone())
                        continue;

                    Map<String, Object> req = new HashMap<>();
                    req.put(GraphQLConstants.ARG_ID, refEntity.orm_idString());
                    refBizObj.invoke(BizConstants.METHOD_DELETE, req, null, context);
                }
            });
        }
    }

    protected List<CascadePropMeta> getCascadeProps() {
        if (cascadeProps == null) {
            this.cascadeProps = BizSchemaHelper.getCascadeProps(getThisObj().getObjMeta());
        }
        return cascadeProps;
    }

//    @BizAction
//    public void tryDelete(@Name("id") String id, IServiceContext context) {
//        checkMandatoryParam("tryDelete", "id", id);
//
//        T entity = this.requireEntity(id, BizConstants.METHOD_DELETE, context);
//        checkEntityRefsNotExists(entity, getDefaultRefNamesToCheckExists(), context);
//    }

    @Description("@i18n:biz.batchUpdate|批量修改")
    @BizMutation
    public void batchUpdate(@Name("ids") Set<String> ids, @Name("data") Map<String, Object> data,
                            @Optional @Name("ignoreUnknown") boolean ignoreUnknown,
                            IServiceContext context) {
        if (CollectionHelper.isEmpty(ids) || CollectionHelper.isEmptyMap(data))
            return;

        List<T> entityList = ignoreUnknown ?
                dao().tryBatchGetEntitiesByIds(ids) : dao().batchGetEntitiesByIds(ids);
        for (T entity : entityList) {
            // 某些dao实现对不存在的id会返回null元素，与batchDelete的防御保持一致
            if (entity == null) {
                if (ignoreUnknown)
                    continue;
                throw new UnknownEntityException(getEntityName(), null);
            }
            Map<String, Object> copy = new LinkedHashMap<>(data);
            copy.put(GraphQLConstants.PROP_ID, entity.orm_idString());
            update(copy, context);
        }
    }

    @Description("@i18n:biz.batchDelete|根据主键批量删除对象")
    @BizMutation
    public Set<String> batchDelete(@Name("ids") Set<String> ids, IServiceContext context) {
        if (CollectionHelper.isEmpty(ids))
            return Collections.emptySet();

        List<T> entities = dao().batchGetEntitiesByIds(ids);
        Set<String> ret = new LinkedHashSet<>();
        Set<String> deletedIds = new LinkedHashSet<>();
        for (T entity : entities) {
            // 对不存在的id，dao可能返回null元素，对应id在下面按原始ids补记
            if (entity == null)
                continue;
            if (entity.orm_state().isMissing()) {
                ret.add(entity.orm_idString());
            } else {
                deletedIds.add(entity.orm_idString());
                delete(entity.orm_idString(), context);
            }
        }
        // 返回值是未删除的id集合，缺失的id从原始入参中补记，避免向返回集合写入null元素
        for (String id : ids) {
            if (!deletedIds.contains(id) && !ret.contains(id))
                ret.add(id);
        }
        return ret;
    }

    @Description("@i18n:biz.batchModify|批量增删改")
    @BizMutation
    public void batchModify(@Name("data") List<Map<String, Object>> data,
                            @Optional @Name("common") Map<String, Object> common,
                            @Optional @Name("delIds") @Description("@i18n:biz.delIds|待删除的实体主键列表") Set<String> delIds,
                            IServiceContext context) {
        if (data != null) {
            List<Object> idList = new ArrayList<>();
            for (Map<String, Object> item : data) {
                if (common != null) {
                    item.putAll(common);
                }
                Object id = item.get(OrmConstants.PROP_ID);
                if (!StringHelper.isEmptyObject(id)) {
                    idList.add(id);
                }
            }
            // 预加载数据
            dao().batchGetEntitiesByIds(idList);

            for (Map<String, Object> item : data) {
                Object id = item.get(OrmConstants.PROP_ID);
                String chgType = DaoHelper.getChangeType(item);
                if (StringHelper.isEmptyObject(id) || DaoConstants.CHANGE_TYPE_ADD.equals(chgType)) {
                    save(item, context);
                } else if (DaoConstants.CHANGE_TYPE_DELETE.equals(chgType)) {
                    delete(StringHelper.toString(id, null), context);
                } else {
                    // 具有id属性，且没有标记为A/U，则是update
                    update(item, context);
                }
            }
        }
        batchDelete(delIds, context);
    }

    @Description("@i18n:biz.saveOrUpdate|如果没有id就修改记录，否则就新增记录")
    @BizMutation
    public T saveOrUpdate(@Name("data") Map<String, Object> data, IServiceContext context) {
        if (CollectionHelper.isEmptyMap(data))
            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_UPDATE).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        T result;
        Object id = data.get(OrmConstants.PROP_ID);
        if (StringHelper.isEmptyObject(id) || DaoConstants.CHANGE_TYPE_ADD.equals(DaoHelper.getChangeType(data))) {
            result = save(data, context);
        } else {
            // 具有id属性，且没有标记为_forAdd，则是update
            result = update(data, context);
        }
        return result;
    }

    @Description("@i18n:biz.saveOrUpdate|如果没有id就修改记录，否则就新增记录。已经被saveOrUpdate取代")
    @BizMutation
    @Deprecated
    public T save_update(@Name("data") Map<String, Object> data, IServiceContext context) {
        return saveOrUpdate(data, context);
    }

    @Description("@i18n:biz.deleted_findPage|分页查询已删除记录")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public PageBean<T> deleted_findPage(@Optional @Name("query") @Description("@i18n:biz.query|查询条件") QueryBean query,
                                        FieldSelectionBean selection, IServiceContext context) {
        if (!isAllowGetDeleted())
            throw new NopException(ERR_BIZ_NOT_ALLOW_GET_DELETED).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        if (query == null) {
            query = new QueryBean();
        }
        query.setDisableLogicalDelete(true);
        String deleteFlagProp = dao().getDeleteFlagProp();
        if (StringHelper.isEmpty(deleteFlagProp))
            throw new NopException(ERR_BIZ_ENTITY_NOT_SUPPORT_LOGICAL_DELETE).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        query.addFilter(FilterBeans.gt(deleteFlagProp, 0));

        return doFindPage(query, this::invokeDefaultPrepareQuery, selection, context);
    }

    @Description("@i18n:biz.recoverDeleted|恢复已删除记录")
    @BizMutation
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T recoverDeleted(@Name("id") String id, IServiceContext context) {
        if (!isAllowGetDeleted())
            throw new NopException(ERR_BIZ_NOT_ALLOW_GET_DELETED).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        IEntityDao<T> dao = dao();
        String deleteFlagProp = dao.getDeleteFlagProp();
        if (StringHelper.isEmpty(deleteFlagProp))
            throw new NopException(ERR_BIZ_ENTITY_NOT_SUPPORT_LOGICAL_DELETE).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        T entity = dao().requireEntityById(id);
        checkMetaFilter(entity, getThisObj().getObjMeta(), context);

        checkDataAuth(BizConstants.METHOD_UPDATE, entity, context);

        entity.orm_propValueByName(deleteFlagProp, 0);
        if (dao.getDeleteVersionProp() != null)
            entity.orm_propValueByName(dao.getDeleteVersionProp(), 0);

        dao().updateEntity(entity);
        return entity;
    }

    @Description("根据查询条件获取一批实体数据，然后对每个实体更新指定属性。返回查询得到的实体个数")
    @BizMutation
    public int updateByQuery(@Name("query") QueryBean query, @Name("data") Map<String, Object> data, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);
        return doUpdateByQuery(query, getAuthObjName(METHOD_FIND_LIST), data, null, this::invokeDefaultPrepareUpdate, context);
    }

    @BizAction
    public int doUpdateByQuery(@Name("query") QueryBean query,
                               @Name("authObjName") String authObjName,
                               @Name("data") Map<String, Object> data,
                               @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                               @Name("prepareUpdate") BiConsumer<EntityData<T>, IServiceContext> prepareUpdate,
                               IServiceContext context) {
        if (data == null || data.isEmpty())
            return 0;

        List<T> list = doFindList0(query, authObjName, prepareQuery, null, context);
        if (list.isEmpty())
            return 0;

        // 受maxPageSize封顶，取满limit时可能存在未被处理的剩余行，此时返回值不代表全部命中行数
        if (query != null && list.size() >= query.getLimit() && query.getLimit() > 0)
            LOG.warn("nop.biz.update-by-query-result-truncated:bizObjName={},limit={},returned={}",
                    getBizObjName(), query.getLimit(), list.size());

        doUpdateMulti(list, data, prepareUpdate, context);
        return list.size();
    }

    @BizAction
    public void doUpdateMulti(@Name("entityList") List<T> entityList,
                              @Name("data") Map<String, Object> data,
                              @Name("prepareUpdate") BiConsumer<EntityData<T>, IServiceContext> prepareUpdate,
                              IServiceContext context) {
        for (T entity : entityList) {
            Map<String, Object> modified = new LinkedHashMap<>(data);
            modified.put(OrmConstants.PROP_ID, entity.orm_idString());
            doUpdate(modified, null, prepareUpdate, context);
        }
    }


    @Description("根据查询条件获取一批实体数据，然后删除这些实体")
    @BizMutation
    public int deleteByQuery(@Name("query") QueryBean query, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);

        return doDeleteByQuery(query, getAuthObjName(METHOD_FIND_LIST), getDefaultRefNamesToCheckExists(),
                null, this::invokeDefaultPrepareDelete, context);
    }

    @BizAction
    public int doDeleteByQuery(@Name("query") QueryBean query,
                               @Name("authObjName") String authObjName,
                               @Name("refNamesToCheck") Set<String> refNamesToCheck,
                               @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                               @Name("prepareDelete") BiConsumer<T, IServiceContext> prepareDelete,
                               IServiceContext context) {
        List<T> list = doFindList0(query, authObjName, prepareQuery, null, context);
        if (list.isEmpty())
            return 0;

        // 受maxPageSize封顶，取满limit时可能存在未被处理的剩余行，此时返回值不代表全部命中行数
        if (query != null && list.size() >= query.getLimit() && query.getLimit() > 0)
            LOG.warn("nop.biz.delete-by-query-result-truncated:bizObjName={},limit={},returned={}",
                    getBizObjName(), query.getLimit(), list.size());

        doDeleteMulti(list, refNamesToCheck, prepareDelete, context);
        return list.size();
    }

    @BizAction
    public void doDeleteMulti(@Name("entityList") List<T> entityList,
                              @Name("refNamesToCheck") Set<String> refNamesToCheck,
                              @Name("prepareDelete") BiConsumer<T, IServiceContext> prepareDelete,
                              IServiceContext context) {
        for (T entity : entityList) {
            doDelete(entity.orm_idString(), refNamesToCheck, prepareDelete, context);
        }
    }

    @Description("@i18n:biz.asDict|将实体记录作为字典项返回")
    @BizQuery
    public DictBean asDict(IServiceContext context) {
        IObjMeta objMeta = getThisObj().requireObjMeta();
        if (!objMeta.containsTag(TAG_DICT))
            throw new NopException(ERR_BIZ_OBJ_NO_DICT_TAG).param(ARG_BIZ_OBJ_NAME, getBizObjName());

        DictBean dict = new DictBean();
        dict.setNormalized(true);
        QueryBean query = new QueryBean();
        query.setLimit(getMaxPageSize());
        PageBean<T> pageBean = findPage(query, FieldSelectionBean.fromProp(GraphQLConstants.FIELD_ITEMS), context);
        List<DictOptionBean> options = new ArrayList<>(pageBean.getItems().size());

        String labelProp = objMeta.getDisplayProp();
        if (labelProp == null) {
            labelProp = GraphQLConstants.PROP_ID;
        }
        IObjPropMeta propMeta = objMeta.requireProp(labelProp);

        for (T entity : pageBean.getItems()) {
            DictOptionBean option = new DictOptionBean();
            option.setValue(entity.orm_idString());
            Object value = BizObjHelper.getProp(entity, propMeta, context);
            option.setLabel(StringHelper.toString(value, ""));
            options.add(option);
        }
        // 字典选项数量达到分页上限时可能被截断，此时前端选项不完整
        if (options.size() >= query.getLimit() && query.getLimit() > 0)
            LOG.warn("nop.biz.as-dict-options-truncated:bizObjName={},limit={},options={}",
                    getBizObjName(), query.getLimit(), options.size());
        dict.setOptions(options);
        return dict;
    }

    @Description("@i18n:biz.findList|根据查询条件返回列表数据。与findPage的不同在于,findPage返回PageBean类型，支持分页，而这个函数返回List类型，而且缺省不分页")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public List<T> findList(@Optional @Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        if (query != null)
            query.setDisableLogicalDelete(false);
        return doFindList(query, this::invokeDefaultPrepareQuery, selection, context);
    }

    @BizAction
    public List<T> doFindList(@Name("query") QueryBean query,
                              @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                              FieldSelectionBean selection,
                              IServiceContext context) {
        return doFindList0(query, getAuthObjName(METHOD_FIND_LIST), prepareQuery, selection, context);
    }

    @BizAction
    @Override
    public List<T> doFindList0(@Name("query") QueryBean query,
                               @Name("authObjName") String authObjName,
                               @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                               FieldSelectionBean selection,
                               IServiceContext context) {
        if (query == null)
            query = new QueryBean();

        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_LIST, prepareQuery, context);
        return doFindListByQueryDirectly(query, context);
    }

    @Description("@i18n:biz.findRoots|根据查询条件返回树形结构的根节点列表")
    @BizQuery
    @BizArgsNormalizer(BizConstants.BEAN_nopQueryBeanArgsNormalizer)
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public List<T> findRoots(@Optional @Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        if (query == null) {
            query = new QueryBean();
        }
        IObjMeta objMeta = getThisObj().getObjMeta();
        ObjTreeModel treeModel = objMeta.getTree();
        Guard.notNull(treeModel, "treeModel");

        if (treeModel.getLevelProp() != null && treeModel.getRootLevelValue() != null) {
            query.addFilter(FilterBeans.eq(treeModel.getLevelProp(), treeModel.getRootLevelValue()));
        } else if (treeModel.getParentProp() != null) {
            String rootParentValue = StringHelper.emptyAsNull(treeModel.getRootParentValue());
            query.addFilter(FilterBeans.eq(treeModel.getParentProp(), rootParentValue));
        }
        query.setDisableLogicalDelete(false);
        return doFindList(query, this::invokeDefaultPrepareQuery, selection, context);
    }


    @Description("@i18n:biz.addManyToMany|新增多对多关联")
    @BizArgsNormalizer(BizConstants.BEAN_nopFilterArgsNormalizer)
    @BizMutation
    public void addManyToManyRelations(@Name("id") String id, @Name("propName") String propName,
                                       @Name("relValues") Collection<String> relValues,
                                       @Optional @Name("filter") TreeBean filter,
                                       IServiceContext context) {
        T entity = get(id, false, context);
        // 增删中间表记录属于变更操作，需要校验update行级数据权限，避免仅有读权限的用户篡改关联
        checkDataAuth(BizConstants.METHOD_UPDATE, entity, context);

        ManyToManyPropMeta propMeta = requireManyToManyPropMeta(propName);
        ManyToManyTool<?> tool = this.manyToMany(propMeta.getRelatedEntityName(), propMeta.getJoinRightProp(), propMeta.getManyToManyRefProp());
        Object leftValue = entity.orm_propValueByName(propMeta.getJoinLeftProp());
        tool.addRelations(leftValue, relValues, filter);
    }

    @Description("@i18n:biz.removeManyToMany|删除多对多关联")
    @BizArgsNormalizer(BizConstants.BEAN_nopFilterArgsNormalizer)
    @BizMutation
    public void removeManyToManyRelations(@Name("id") String id, @Name("propName") String propName,
                                          @Name("relValues") Collection<String> relValues,
                                          @Optional @Name("filter") TreeBean filter,
                                          IServiceContext context) {
        T entity = get(id, false, context);
        checkDataAuth(BizConstants.METHOD_UPDATE, entity, context);
        ManyToManyPropMeta propMeta = requireManyToManyPropMeta(propName);
        ManyToManyTool<?> tool = this.manyToMany(propMeta.getRelatedEntityName(), propMeta.getJoinRightProp(), propMeta.getManyToManyRefProp());
        Object leftValue = entity.orm_propValueByName(propMeta.getJoinLeftProp());
        tool.removeRelations(leftValue, relValues, filter);
    }

    @Description("@i18n:biz.updateManyToMany|更新多对多关联")
    @BizArgsNormalizer(BizConstants.BEAN_nopFilterArgsNormalizer)
    @BizMutation
    public void updateManyToManyRelations(@Name("id") String id, @Name("propName") String propName,
                                          @Name("relValues") Collection<String> relValues,
                                          @Optional @Name("filter") TreeBean filter, IServiceContext context) {
        T entity = get(id, false, context);
        checkDataAuth(BizConstants.METHOD_UPDATE, entity, context);
        ManyToManyPropMeta propMeta = requireManyToManyPropMeta(propName);
        ManyToManyTool<?> tool = this.manyToMany(propMeta.getRelatedEntityName(), propMeta.getJoinRightProp(), propMeta.getManyToManyRefProp());
        Object leftValue = entity.orm_propValueByName(propMeta.getJoinLeftProp());
        tool.updateRelations(leftValue, relValues, filter);
    }

    protected ManyToManyPropMeta requireManyToManyPropMeta(String propName) {
        IObjPropMeta propMeta = requirePropMeta(propName);
        if (!BizConstants.PROP_KIND_TO_MANY.equals(propMeta.prop_get(BizConstants.EXT_KIND)))
            throw new NopException(ERR_BIZ_PROP_NOT_MANY_TO_MANY_REF)
                    .param(ARG_BIZ_OBJ_NAME, getBizObjName())
                    .param(ARG_PROP_NAME, propName);

        ManyToManyPropMeta manyToManyPropMeta = new ManyToManyPropMeta(propMeta);
        String joinLeftProp = manyToManyPropMeta.getJoinLeftProp();
        String joinRightProp = manyToManyPropMeta.getJoinRightProp();
        String joinRefProp = manyToManyPropMeta.getManyToManyRefProp();

        String relatedEntityName = null;
        ISchema itemSchema = propMeta.getItemSchema();
        if (itemSchema != null) {
            relatedEntityName = itemSchema.getBizObjName();
        }

        if (StringHelper.isEmpty(joinLeftProp) || StringHelper.isEmpty(joinRightProp)
                || StringHelper.isEmpty(joinRefProp) || StringHelper.isEmpty(relatedEntityName))
            throw new NopException(ERR_BIZ_PROP_NOT_MANY_TO_MANY_REF)
                    .param(ARG_BIZ_OBJ_NAME, getBizObjName())
                    .param(ARG_PROP_NAME, propName);

        return manyToManyPropMeta;
    }

    protected IObjPropMeta requirePropMeta(String propName) {
        return getThisObj().requireObjMeta().requireProp(propName);
    }

    @Description("@i18n:biz.copyForNew|复制新建")
    @BizMutation
    @GraphQLReturn(bizObjName = BIZ_OBJ_NAME_THIS_OBJ)
    public T copyForNew(@Name("data") Map<String, Object> data, IServiceContext context) {
        if (CollectionHelper.isEmptyMap(data))
            throw new NopException(ERR_BIZ_EMPTY_DATA_FOR_SAVE).param(ARG_BIZ_OBJ_NAME, getBizObjName());
        return doCopyForNew(data, BizConstants.SELECTION_COPY_FOR_NEW, this::invokeDefaultPrepareCopyForNew, context);
    }

    @BizAction
    protected T doCopyForNew(@Name("data") Map<String, Object> data, @Name("copySelection") String copySelection,
                             @Name("prepareSave") BiConsumer<EntityData<T>, IServiceContext> prepareSave,
                             IServiceContext context) {
        Object id = data.get(OrmConstants.PROP_ID);

        IEntityDao<T> dao = dao();
        T entity = dao.requireEntityById(id);
        IObjMeta objMeta = getThisObj().requireObjMeta();
        checkMetaFilter(entity, objMeta, context);

        FieldSelectionBean inputSelection = objMeta.getFieldSelection(copySelection);
        // copyForNew总是新建记录，data中的id指向存活的源记录，不应触发按id恢复逻辑删除记录的逻辑
        EntityData<T> entityData = buildEntityDataForSave(data, inputSelection, context, false);
        entityData.getValidatedData().remove(OrmConstants.PROP_ID);

        checkUniqueForSave(entityData);

        T newEntity;
        if (inputSelection != null) {
            newEntity = dao.newEntity();
            crudToolProvider.newOrmEntityCopier(objMeta, context, entityData.getDelayedActions()).copyToEntity(entity,
                    newEntity, inputSelection, entityData.getObjMeta(), getBizObjName(),
                    BizConstants.SELECTION_COPY_FOR_NEW, context.getEvalScope());
        } else {
            newEntity = (T) entity.cloneInstance();
            // copyForNew总是新建记录，克隆体不能保留源记录主键。对所有主键列统一清空：
            // seq/seq-default主键由ORM生成器重新生成；非序列主键（业务分配主键）清空后若无法生成，
            // 由OrmEntityIdGenerator抛ERR_ORM_ENTITY_ID_NOT_SET，而不是沿用源主键在保存时触发主键重复
            for (IColumnModel col : entity.orm_entityModel().getPkColumns()) {
                newEntity.orm_propValue(col.getPropId(), null);
            }
        }

        entityData.setEntity(newEntity);

        crudToolProvider.newOrmEntityCopier(objMeta, context, entityData.getDelayedActions()).copyToEntity(entityData.getValidatedData(),
                newEntity, inputSelection, entityData.getObjMeta(), getBizObjName(),
                BizConstants.SELECTION_COPY_FOR_NEW, context.getEvalScope());

        if (prepareSave != null)
            prepareSave.accept(entityData, context);

        checkDataAuth(BizConstants.SELECTION_COPY_FOR_NEW, entityData.getEntity(), context);

        // 与doSave保持一致：writeMode=biz的关联通过延迟动作执行，否则会被静默丢弃
        executeDelayedRelationActions(entityData, context);

        this.doSaveEntity(entityData, context);
        return newEntity;
    }

    public <R extends IOrmEntity> ManyToManyTool<R> manyToMany(String relationEntityName, String leftProp, String rightProp) {
        return new ManyToManyTool<R>(daoProvider(), relationEntityName, leftProp, rightProp);
    }

    @BizAction
    public <R extends IOrmEntity> void removeRelation(@Name("relationEntityName") String relationEntityName,
                                                      @Name("leftProp") String leftProp,
                                                      @Name("rightProp") String rightProp,
                                                      @Name("leftValue") Object leftValue,
                                                      @Name("rightValue") Object rightValue) {
        manyToMany(relationEntityName, leftProp, rightProp).removeRelation(leftValue, rightValue);
    }

    @BizAction
    public <R extends IOrmEntity> void removeRelations(@Name("relationEntityName") String relationEntityName,
                                                       @Name("leftProp") String leftProp,
                                                       @Name("rightProp") String rightProp,
                                                       @Name("leftValue") Object leftValue,
                                                       @Name("rightValues") Collection<?> rightValues,
                                                       @Name("filter") TreeBean filter) {
        manyToMany(relationEntityName, leftProp, rightProp).removeRelations(leftValue, rightValues, filter);
    }

    @BizAction
    public <R extends IOrmEntity> void addRelations(@Name("relationEntityName") String relationEntityName,
                                                    @Name("leftProp") String leftProp,
                                                    @Name("rightProp") String rightProp,
                                                    @Name("leftValue") Object leftValue,
                                                    @Name("rightValues") Collection<?> rightValues,
                                                    @Name("filter") TreeBean filter) {
        manyToMany(relationEntityName, leftProp, rightProp).addRelations(leftValue, rightValues, filter);
    }

    @BizAction
    public <R extends IOrmEntity> void updateRelations(@Name("relationEntityName") String relationEntityName,
                                                       @Name("leftProp") String leftProp,
                                                       @Name("rightProp") String rightProp,
                                                       @Name("leftValue") Object leftValue,
                                                       @Name("rightValues") Collection<?> rightValues,
                                                       @Name("filter") TreeBean filter) {
        manyToMany(relationEntityName, leftProp, rightProp).updateRelations(leftValue, rightValues, filter);
    }

    @BizAction
    public <R extends IOrmEntity> void updateRelationsEx(@Name("relationEntityName") String relationEntityName,
                                                         @Name("leftProp") String leftProp,
                                                         @Name("fixedProps") Map<String, Object> fixedProps,
                                                         @Name("filter") TreeBean filter,
                                                         @Name("deleteUnknown") boolean deleteUnknown,
                                                         @Name("rightProp") String rightProp,
                                                         @Name("rightValues") Collection<?> relValues) {
        ManyToManyTool<R> tool = manyToMany(relationEntityName, leftProp, rightProp);
        tool.updateRelations(fixedProps, filter, deleteUnknown, rightProp, relValues);
    }

    @BizQuery
    @Description("分页查询树状结构")
    public PageBean<StdTreeEntity> findTreeEntityPage(@Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        return doFindTreeEntityPage(query, getAuthObjName(METHOD_FIND_TREE_PAGE), null, selection, context);
    }

    @BizAction
    public PageBean<StdTreeEntity> doFindTreeEntityPage(@Name("query") QueryBean query,
                                                        @Name("authObjName") String authObjName,
                                                        @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                                        FieldSelectionBean selection,
                                                        IServiceContext context
    ) {
        if (query == null)
            query = new QueryBean();

        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_TREE_PAGE, prepareQuery, context);

        PageBean<StdTreeEntity> pageBean = new PageBean<>();
        pageBean.setLimit(query.getLimit());
        pageBean.setOffset(query.getOffset());
        pageBean.setTotal(-1L);

        if (selection != null && selection.hasSourceField(GraphQLConstants.FIELD_TOTAL)) {
            long total = countTreeEntity(query);
            pageBean.setTotal(total);
        }

        if (selection == null || selection.hasSourceField(GraphQLConstants.FIELD_ITEMS)) {
            List<StdTreeEntity> ret = getTreeEntityList(query);
            pageBean.setItems(ret);
        }
        return pageBean;
    }

    protected long countTreeEntity(QueryBean query) {
        IObjMeta objMeta = getThisObj().requireObjMeta();
        SQL sql = TreeEntityHelper.buildTreeEntityCountSql(objMeta, getTreeEntityModel(objMeta), query.getFilter()).end();
        return orm().findLong(sql, 0L);
    }

    protected List<StdTreeEntity> getTreeEntityList(QueryBean query) {
        IObjMeta objMeta = getThisObj().requireObjMeta();
        SQL sql = TreeEntityHelper.buildTreeEntitySql(objMeta, getTreeEntityModel(objMeta), query.getFilter()).end();
        return orm().findPage(sql, query.getOffset(), query.getLimit(), BeanRowMapper.of(StdTreeEntity.class));
    }

    /**
     * 树查询按实体模型的逻辑删除配置过滤deleteFlag，实体模型未注册时返回null（保持不过滤的原有行为）
     */
    protected IEntityModel getTreeEntityModel(IObjMeta objMeta) {
        String entityName = objMeta.getEntityName();
        if (entityName == null)
            entityName = objMeta.getName();
        return orm().getOrmModel().getEntityModel(entityName);
    }

    @BizQuery
    @Description("查询树状结构")
    public List<StdTreeEntity> findTreeEntityList(@Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        return doFindTreeEntityList(query, getAuthObjName(METHOD_FIND_TREE_LIST), null, selection, context);
    }

    @BizAction
    public List<StdTreeEntity> doFindTreeEntityList(@Name("query") QueryBean query,
                                                    @Name("authObjName") String authObjName,
                                                    @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                                    FieldSelectionBean selection,
                                                    IServiceContext context
    ) {
        if (query == null)
            query = new QueryBean();

        // 列表入口按findTreeList应用数据权限规则，与入口方法声明的action保持一致
        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_TREE_LIST, prepareQuery, context);

        return getTreeEntityList(query);
    }

    @BizQuery
    @Description("查询树状结构")
    public List<T> findListForTree(@Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        return doFindListForTree(query, getAuthObjName(METHOD_FIND_TREE_LIST), null, selection, context);
    }

    @BizAction
    public List<T> doFindListForTree(@Name("query") QueryBean query,
                                     @Name("authObjName") String authObjName,
                                     @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                     FieldSelectionBean selection,
                                     IServiceContext context) {
        List<StdTreeEntity> list = doFindTreeEntityList(query, authObjName, prepareQuery, selection, context);
        return getEntityListByTreeEntity(list, context);
    }

    protected List<T> getEntityListByTreeEntity(List<StdTreeEntity> list, IServiceContext context) {
        List<String> idList = list.stream().map(StdTreeEntity::getId).collect(Collectors.toList());
        return batchGet(idList, false, context);
    }

    @BizQuery
    @Description("分页查询树状结构")
    public PageBean<T> findPageForTree(@Name("query") QueryBean query, FieldSelectionBean selection, IServiceContext context) {
        return doFindPageForTree(query, getAuthObjName(METHOD_FIND_TREE_PAGE), null, selection, context);
    }

    @BizAction
    public PageBean<T> doFindPageForTree(@Name("query") QueryBean query,
                                         @Name("authObjName") String authObjName,
                                         @Name("prepareQuery") BiConsumer<QueryBean, IServiceContext> prepareQuery,
                                         FieldSelectionBean selection,
                                         IServiceContext context
    ) {
        if (query == null)
            query = new QueryBean();

        query = prepareFindPageQuery(query, authObjName, METHOD_FIND_TREE_PAGE, prepareQuery, context);

        PageBean<T> pageBean = new PageBean<>();
        pageBean.setLimit(query.getLimit());
        pageBean.setOffset(query.getOffset());
        pageBean.setTotal(-1L);

        if (selection != null && selection.hasSourceField(GraphQLConstants.FIELD_TOTAL)) {
            long total = countTreeEntity(query);
            pageBean.setTotal(total);
        }

        if (selection == null || selection.hasSourceField(GraphQLConstants.FIELD_ITEMS)) {
            List<StdTreeEntity> ret = getTreeEntityList(query);
            pageBean.setItems(getEntityListByTreeEntity(ret, context));
        }
        return pageBean;
    }
//
//    @BizQuery
//    @Description("所有可导出的字段")
//    public List<DictOptionBean> exportableFields(IServiceContext context) {
//        return BizExportHelper.getExportableFields(getBizObjName(), getThisObj().getObjMeta(), context);
//    }


    protected void invokeDefaultPrepareQuery(@Name("query") QueryBean query, IServiceContext context) {
        // 通过这种方式调用，允许在xbiz文件中覆盖Java中的方法
        getThisObj().invoke("defaultPrepareQuery", Map.of("query", query), null, context);
    }

    protected void invokeDefaultPrepareSave(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        // 通过这种方式调用，允许在xbiz文件中覆盖Java中的方法
        getThisObj().invoke("defaultPrepareSave", Map.of("entityData", entityData), null, context);
    }

    protected void invokeDefaultPrepareCopyForNew(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        // 通过这种方式调用，允许在xbiz文件中覆盖Java中的方法
        getThisObj().invoke("defaultPrepareCopyForNew", Map.of("entityData", entityData), null, context);
    }


    protected void invokeDefaultPrepareUpdate(@Name("entityData") EntityData<T> entityData, IServiceContext context) {
        // 通过这种方式调用，允许在xbiz文件中覆盖Java中的方法
        getThisObj().invoke("defaultPrepareUpdate", Map.of("entityData", entityData), null, context);
    }


    protected void invokeDefaultPrepareDelete(@Name("entity") T entity, IServiceContext context) {
        // 通过这种方式调用，允许在xbiz文件中覆盖Java中的方法
        getThisObj().invoke("defaultPrepareDelete", Map.of("entity", entity), null, context);
    }

    // ==================== ICrudBiz接口实现 - 直接针对实体对象的操作方法 ====================

    /**
     * 保存实体对象
     * 包含数据权限检查、唯一性检查、状态机初始化等逻辑
     */
    @BizAction
    public void saveEntity(@Name("entity") T entity, @Optional @Name("action") String action,
                           IServiceContext context) {
        Guard.notNull(entity, "entity");
        if (action == null)
            action = BizConstants.METHOD_SAVE;

        IObjMeta objMeta = getThisObj().requireObjMeta();

        // 检查唯一性约束
        checkUniqueForSaveEntity(entity, objMeta);

        // 检查数据权限
        checkDataAuth(action, entity, context);

        // 初始化状态机
        IStateMachine stm = getThisObj().getStateMachine();
        if (stm != null) {
            stm.initState(entity);
        }

        // 保存实体。考虑到逻辑删除后再保存，这里有可能是update
        daoSaveEntity(entity, context);

        // 触发实体变更后处理
        afterEntityChange(entity, action, context);
    }

    /**
     * 更新实体对象
     * 包含数据权限检查、唯一性检查等逻辑
     */
    @BizAction
    public void updateEntity(@Name("entity") T entity, @Optional @Name("action") String action,
                             IServiceContext context) {
        Guard.notNull(entity, "entity");
        if (action == null)
            action = BizConstants.METHOD_UPDATE;

        IObjMeta objMeta = getThisObj().requireObjMeta();

        // 检查元数据过滤器
        checkMetaFilter(entity, objMeta, context);

        // 检查唯一性约束（仅针对脏属性）
        checkUniqueForUpdate(entity, context);

        checkDataAuth(action, entity, context);

        // 更新实体
        daoUpdateEntity(entity, context);

        // 触发实体变更后处理
        afterEntityChange(entity, action, context);
    }

    /**
     * 删除实体对象
     * 包含数据权限检查、关联引用检查、级联删除等逻辑
     */
    @BizAction
    public void deleteEntity(@Name("entity") T entity, @Optional @Name("action") String action,
                             IServiceContext context) {
        Guard.notNull(entity, "entity");
        if (action == null)
            action = BizConstants.METHOD_DELETE;

        IObjMeta objMeta = getThisObj().requireObjMeta();

        // 检查元数据过滤器
        checkMetaFilter(entity, objMeta, context);

        // 检查关联引用是否存在
        Set<String> refNamesToCheck = getRefNamesToCheckExists(action);
        if (refNamesToCheck != null) {
            checkEntityRefsNotExists(entity, refNamesToCheck, context);
        }

        // 删除实体
        daoDeleteEntity(entity, context);

        // 删除关联对象
        deleteReferences(entity, action, context);

        // 触发实体变更后处理
        afterEntityChange(entity, action, context);
    }

    protected Set<String> getRefNamesToCheckExists(String action) {
        return getDefaultRefNamesToCheckExists();
    }

    protected void daoSaveEntity(T entity, IServiceContext context) {
        dao().saveEntity(entity);
    }

    protected void daoUpdateEntity(T entity, IServiceContext context) {
        dao().updateEntity(entity);
    }

    protected void daoDeleteEntity(T entity, IServiceContext context) {
        dao().deleteEntity(entity);
    }

    /**
     * 给实体对象赋值
     * 支持复杂主子表数据的赋值
     */
    @BizAction
    public void assignToEntity(@Name("entity") T entity,
                               @Name("data") Map<String, Object> data,
                               @Name("action") String action, IServiceContext context) {
        Guard.notNull(entity, "entity");
        Guard.notNull(data, "data");

        if (action == null)
            action = BizConstants.METHOD_UPDATE;

        EntityData<T> entityData = buildEntityDataForUpdate(data, null, context);
        if (BizConstants.METHOD_UPDATE.equals(action)) {
            this.invokeDefaultPrepareUpdate(entityData, context);
        }

        copyToEntity(entityData.getValidatedData(), entity, action, context);
    }

    /**
     * 根据传入的数据构建保存用的实体对象
     * 支持复杂主子表数据，包含数据验证、逻辑删除恢复等逻辑
     */
    @BizAction
    public T buildEntityForSave(@Name("data") Map<String, Object> data,
                                @Name("action") String action, IServiceContext context) {
        Guard.notNull(data, "data");
        if (action == null)
            action = BizConstants.METHOD_SAVE;

        EntityData<T> entityData = buildEntityDataForSave(data, null, context);

        // 执行默认的准备工作（状态机初始化等）
        if (BizConstants.METHOD_SAVE.equals(action)) {
            invokeDefaultPrepareSave(entityData, context);
        }

        return entityData.getEntity();
    }

    /**
     * 检查是否允许访问指定实体
     * 包含数据权限检查
     */
    @BizAction
    public void checkAllowAccess(@Name("entity") T entity,
                                 @Name("action") String action, IServiceContext context) {
        Guard.notNull(entity, "entity");
        Guard.notEmpty(action, "action");

        checkMetaFilter(entity, getObjMeta(), context);
        checkDataAuth(action, entity, context);
    }

    @Override
    public void batchLoadSelection(@Name("entityList") Collection<T> entityList,
                                   @Name("selection") FieldSelectionBean selection, IServiceContext context) {
        dao().batchLoadSelection(entityList, selection);
    }

    @BizAction
    @Override
    public Map<String, Object> fetchSelection(@Name("entity") T entity, @Name("selection") FieldSelectionBean selection,
                                              IServiceContext context) {
        Guard.notNull(entity, "entity");
        Guard.notNull(selection, "selection");

        return (Map<String, Object>) FutureHelper.syncGet(
                graphQLEngine.fetchResultWithSelection(entity, getBizObjName(), selection, context));
    }

    @BizAction
    @Override
    public List<Map<String, Object>> fetchSelectionForList(@Name("entityList") Collection<T> entityList,
                                                           @Name("selection") FieldSelectionBean selection,
                                                           IServiceContext context) {
        Guard.notNull(entityList, "entityList");
        Guard.notNull(selection, "selection");
        
        if (entityList.isEmpty())
            return Collections.emptyList();

        return (List<Map<String, Object>>) FutureHelper.syncGet(
                graphQLEngine.fetchResultWithSelection(entityList, getBizObjName(), selection, context));
    }
}
