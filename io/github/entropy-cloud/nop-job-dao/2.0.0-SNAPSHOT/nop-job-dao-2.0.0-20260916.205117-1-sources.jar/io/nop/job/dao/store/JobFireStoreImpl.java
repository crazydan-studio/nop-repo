package io.nop.job.dao.store;

import io.nop.job.core.JobCoreErrors;
import io.nop.api.core.annotations.txn.TransactionPropagation;
import io.nop.api.core.annotations.txn.Transactional;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.IntRangeSet;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.commons.util.DateHelper;
import io.nop.dao.api.IDaoProvider;
import io.nop.job.api.spec.TriggerSpec;
import io.nop.job.core.ITriggerEvalContext;
import io.nop.job.core._NopJobCoreConstants;
import io.nop.job.core.trigger.JobTriggerCalculator;
import io.nop.job.dao.entity.NopJobFire;
import io.nop.job.dao.entity.NopJobSchedule;
import io.nop.job.dao.entity.NopJobTask;
import io.nop.job.dao.entity._gen._NopJobTask;
import io.nop.job.dao.helper.JobFireStateMachine;
import io.nop.job.dao.helper.JobQueryHelper;
import io.nop.job.dao.helper.JobTaskStateMachine;
import io.nop.job.dao.helper.TriggerSpecHelper;
import io.nop.orm.dao.IOrmEntityDao;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static io.nop.job.core.JobCoreErrors.ERR_JOB_CANCELED;
import static io.nop.job.core.JobCoreErrors.ERR_JOB_FIRE_STATUS_CONFLICT;
import static io.nop.job.dao.entity._gen._NopJobFire.PROP_NAME_fireStatus;
import static io.nop.job.dao.entity._gen._NopJobFire.PROP_NAME_jobFireId;
import static io.nop.job.dao.entity._gen._NopJobFire.PROP_NAME_partitionIndex;
import static io.nop.job.dao.entity._gen._NopJobFire.PROP_NAME_scheduledFireTime;
import static io.nop.job.dao.entity._gen._NopJobFire.PROP_NAME_startTime;

public class JobFireStoreImpl implements IJobFireStore {
    static final Logger LOG = LoggerFactory.getLogger(JobFireStoreImpl.class);

    private IDaoProvider daoProvider;

    @Inject
    public void setDaoProvider(IDaoProvider daoProvider) {
        this.daoProvider = daoProvider;
    }

    @Override
    public List<NopJobFire> fetchWaitingFires(int limit, IntRangeSet partitions) {
        QueryBean query = new QueryBean();
        query.setLimit(limit);
        query.addFilter(FilterBeans.eq(PROP_NAME_fireStatus, _NopJobCoreConstants.FIRE_STATUS_WAITING));
        // Backoff filter (AR-86): skip WAITING fires whose startTime (reused as backoff-until after a
        // no-fitting-worker revert) is still in the future. Never-dispatched fires have startTime=null
        // and must always be eligible.
        long now = fireDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
        query.addFilter(FilterBeans.or(
                FilterBeans.isNull(PROP_NAME_startTime),
                FilterBeans.le(PROP_NAME_startTime, new Timestamp(now))
        ));
        JobQueryHelper.addPartitionFilter(query, partitions, PROP_NAME_partitionIndex);
        query.addOrderField(PROP_NAME_scheduledFireTime, false);
        query.addOrderField(PROP_NAME_jobFireId, false);
        return fireDao().findPageByQuery(query);
    }

    @Override
    public List<NopJobFire> fetchRunningFires(int limit, IntRangeSet partitions) {
        QueryBean query = new QueryBean();
        query.setLimit(limit);
        query.addFilter(FilterBeans.eq(PROP_NAME_fireStatus, _NopJobCoreConstants.FIRE_STATUS_RUNNING));
        JobQueryHelper.addPartitionFilter(query, partitions, PROP_NAME_partitionIndex);
        query.addOrderField(PROP_NAME_scheduledFireTime, false);
        query.addOrderField(PROP_NAME_jobFireId, false);
        return fireDao().findPageByQuery(query);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public List<NopJobFire> tryLockFiresForDispatch(List<NopJobFire> fires, String dispatchInstanceId,
                                                    long lockTimeoutMs) {
        if (fires == null || fires.isEmpty()) {
            return Collections.emptyList();
        }

        long now = fireDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
        Timestamp startTime = new Timestamp(now);
        for (NopJobFire fire : fires) {
            fire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_DISPATCHING);
            fire.setDispatchInstanceId(dispatchInstanceId);
            fire.setStartTime(startTime);
        }
        return fireDao().tryUpdateManyWithVersionCheck(fires);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public boolean insertTasksAndMarkFireDispatching(NopJobFire fire, List<NopJobTask> tasks) {
        NopJobFire currentFire = fireDao().requireEntityById(fire.getJobFireId());
        if (!JobFireStateMachine.isDispatching(currentFire.getFireStatus())) {
            // check2 [P3-11]: 静默跳过时返回 false，调用方不再虚增 dispatchedCount/metrics
            return false;
        }

        currentFire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_RUNNING);
        if (!fireDao().tryUpdateWithVersionCheck(currentFire)) {
            throw new NopException(ERR_JOB_FIRE_STATUS_CONFLICT)
                    .param("jobFireId", fire.getJobFireId())
                    .param("expectedStatus", _NopJobCoreConstants.FIRE_STATUS_DISPATCHING);
        }

        for (NopJobTask task : tasks) {
            taskDao().saveEntity(task);
        }
        return true;
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public FireScheduleOutcome completeFireAndUpdateSchedule(NopJobFire fire, NopJobSchedule schedule) {
        // Bug A fix: removed requireEntityById + isTerminalFire short-circuit
        // (it returned the @SingleSession-cached entity already modified by caller)

        if (!fireDao().tryUpdateWithVersionCheck(fire)) {
            return FireScheduleOutcome.bothFailed();
        }

        // Under @SingleSession, requireEntityById returns the same cached entity as the
        // schedule parameter. The entity is already dirty with the caller's counter
        // modifications, so tryUpdateWithVersionCheck will flush them in the new transaction.
        // No retry loop: with @SingleSession, requireEntityById cannot load fresh data
        // (cache always returns the same object), making retries pointless.
        if (!scheduleDao().tryUpdateWithVersionCheck(schedule)) {
            LOG.warn("nop.job.complete.schedule-update-conflict:fireId={}", fire.getJobFireId());
            return FireScheduleOutcome.fireOnly();
        }
        return FireScheduleOutcome.bothUpdated();
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public FireScheduleOutcome cancelFire(String jobFireId) {
        NopJobFire fire = fireDao().requireEntityById(jobFireId);
        List<NopJobTask> tasks = findTasksByFireId(jobFireId);
        if (!isCancelableFire(fire, tasks)) {
            return FireScheduleOutcome.bothFailed();
        }

        NopJobSchedule schedule = scheduleDao().requireEntityById(fire.getJobScheduleId());
        Timestamp cancelTime = new Timestamp(fireDao().getDbEstimatedClock().getMaxCurrentTimeMillis());

        fire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_CANCELED);
        fire.setEndTime(cancelTime);
        fire.setDurationMs(DateHelper.durationMs(fire.getStartTime(), cancelTime));
        fire.setErrorCode(ERR_JOB_CANCELED.getErrorCode());
        fire.setErrorMessage(ERR_JOB_CANCELED.getDescription());
        if (!fireDao().tryUpdateWithVersionCheck(fire)) {
            return FireScheduleOutcome.bothFailed();
        }

        for (NopJobTask task : tasks) {
            if (JobTaskStateMachine.isFinished(task.getTaskStatus())) {
                continue;
            }

            task.setTaskStatus(_NopJobCoreConstants.TASK_STATUS_CANCELED);
            task.setEndTime(cancelTime);
            task.setDurationMs(DateHelper.durationMs(task.getStartTime(), cancelTime));
            task.setErrorCode(ERR_JOB_CANCELED.getErrorCode());
            task.setErrorMessage(ERR_JOB_CANCELED.getDescription());

            if (!taskDao().tryUpdateWithVersionCheck(task)) {
                NopJobTask freshTask = taskDao().requireEntityById(task.getJobTaskId());
                if (JobTaskStateMachine.isFinished(freshTask.getTaskStatus())) {
                    LOG.debug("nop.job.cancel.task-already-terminal:taskId={},status={}",
                            task.getJobTaskId(), freshTask.getTaskStatus());
                    continue;
                }
                task.setVersion(freshTask.getVersion());
                if (!taskDao().tryUpdateWithVersionCheck(task)) {
                    LOG.warn("nop.job.cancel.task-update-failed-after-retry:taskId={}", task.getJobTaskId());
                }
            }
        }

        // Under @SingleSession, schedule is the same cached entity. It's already
        // dirty with the caller's counter modifications (set at lines below).
        // Single try (same reasoning as completeFireAndUpdateSchedule — with
        // @SingleSession, requireEntityById returns the same cached entity, making
        // retries pointless).
        schedule.setActiveFireCount(Math.max(0, defaultInt(schedule.getActiveFireCount()) - 1));
        schedule.setTotalFireCount(Math.max(0, defaultLong(schedule.getTotalFireCount()) + 1));
        schedule.setFailFireCount(Math.max(0, defaultLong(schedule.getFailFireCount()) + 1));
        schedule.setLastEndTime(cancelTime);
        schedule.setLastFireStatus(_NopJobCoreConstants.FIRE_STATUS_CANCELED);
        if (shouldAdvanceFixedDelaySchedule(schedule, fire)) {
            schedule.setNextFireTime(calculateFixedDelayNextFireTime(schedule, cancelTime));
        }
        if (!scheduleDao().tryUpdateWithVersionCheck(schedule)) {
            LOG.warn("nop.job.cancel.schedule-update-conflict:fireId={}", fire.getJobFireId());
            return FireScheduleOutcome.fireOnly();
        }
        return FireScheduleOutcome.bothUpdated();
    }

    @Override
    public NopJobFire loadFire(String jobFireId) {
        return fireDao().requireEntityById(jobFireId);
    }

    @Override
    public NopJobFire getFireById(String jobFireId) {
        return fireDao().getEntityById(jobFireId);
    }

    @Override
    public Map<String, NopJobFire> batchLoadFires(Set<String> fireIds) {
        if (fireIds == null || fireIds.isEmpty()) {
            return Collections.emptyMap();
        }
        // batchGetEntityMapByIds 的单 id 分支返回未加载的 proxy 实体（见 OrmEntityDao.batchGetEntitiesByIds），
        // session 关闭后访问属性会抛 session-closed，因此单 id 场景改用 getEntityById 全量加载。
        if (fireIds.size() == 1) {
            String id = fireIds.iterator().next();
            NopJobFire fire = fireDao().getEntityById(id);
            if (fire == null) {
                return Collections.emptyMap();
            }
            return Collections.singletonMap(id, fire);
        }
        return (Map) fireDao().batchGetEntityMapByIds(fireIds);
    }

    @Override
    public List<NopJobFire> fetchDispatchingFires(int limit, IntRangeSet partitions,
                                                  Timestamp cursorTime, String cursorId) {
        if (cursorTime == null && cursorId != null) {
            throw new NopException(JobCoreErrors.ERR_JOB_CURSOR_REQUIRES_CURSOR_TIME).param(JobCoreErrors.ARG_CURSOR_ID, cursorId);
        }
        QueryBean query = new QueryBean();
        query.setLimit(limit);
        query.addFilter(FilterBeans.eq(PROP_NAME_fireStatus, _NopJobCoreConstants.FIRE_STATUS_DISPATCHING));
        JobQueryHelper.addPartitionFilter(query, partitions, PROP_NAME_partitionIndex);
        if (cursorTime != null) {
            query.addFilter(FilterBeans.or(
                    FilterBeans.lt(PROP_NAME_startTime, cursorTime),
                    FilterBeans.and(
                            FilterBeans.eq(PROP_NAME_startTime, cursorTime),
                            FilterBeans.lt(PROP_NAME_jobFireId, cursorId)
                    )
            ));
        }
        query.addOrderField(PROP_NAME_startTime, true);
        query.addOrderField(PROP_NAME_jobFireId, true);
        return fireDao().findPageByQuery(query);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public boolean revertDispatchingFireToWaiting(NopJobFire fire, long backoffUntilMs) {
        NopJobFire currentFire = fireDao().requireEntityById(fire.getJobFireId());
        if (!JobFireStateMachine.isDispatching(currentFire.getFireStatus())) {
            return false;
        }
        currentFire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_WAITING);
        currentFire.setDispatchInstanceId(null);
        // Reuse startTime as the "earliest re-dispatch" marker while WAITING (no-fitting-worker backoff).
        currentFire.setStartTime(new Timestamp(backoffUntilMs));
        return fireDao().tryUpdateWithVersionCheck(currentFire);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public boolean failFireWithoutSchedule(String jobFireId, String errorCode, String errorMessage) {
        NopJobFire fire = fireDao().requireEntityById(jobFireId);
        // 前置校验：已处终态的fire不再改写（对齐insertTasksAndMarkFireDispatching/revert的防护惯例）
        if (JobFireStateMachine.isTerminal(fire.getFireStatus())) {
            return false;
        }
        fire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_FAILED);
        fire.setEndTime(new Timestamp(fireDao().getDbEstimatedClock().getMaxCurrentTimeMillis()));
        fire.setDurationMs(DateHelper.durationMs(fire.getStartTime(), fire.getEndTime()));
        fire.setErrorCode(errorCode);
        fire.setErrorMessage(errorMessage);
        // plan 340 §2.4 (P2-3): observe version-conflict outcome instead of discarding it.
        // A false return means the fire was already terminalized concurrently; the timeout
        // checker would otherwise re-enter this path every cycle silently.
        if (!fireDao().tryUpdateWithVersionCheck(fire)) {
            LOG.warn("nop.job.fire-finalize-conflict:fireId={},errorCode={}", jobFireId, errorCode);
            return false;
        }
        return true;
    }

    private IOrmEntityDao<NopJobFire> fireDao() {
        return (IOrmEntityDao<NopJobFire>) daoProvider.daoFor(NopJobFire.class);
    }

    private IOrmEntityDao<NopJobTask> taskDao() {
        return (IOrmEntityDao<NopJobTask>) daoProvider.daoFor(NopJobTask.class);
    }

    private IOrmEntityDao<NopJobSchedule> scheduleDao() {
        return (IOrmEntityDao<NopJobSchedule>) daoProvider.daoFor(NopJobSchedule.class);
    }

    private List<NopJobTask> findTasksByFireId(String jobFireId) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobTask.PROP_NAME_jobFireId, jobFireId));
        query.addOrderField(_NopJobTask.PROP_NAME_taskNo, false);
        query.addOrderField(_NopJobTask.PROP_NAME_jobTaskId, false);
        // No LIMIT: completion/cancel need ALL tasks of a fire (capping would yield incomplete
        // status aggregation / partial cancel). Task count per fire is bounded at dispatch time
        // (broadcast = healthy instances, partition = partition count, single = 1).
        return taskDao().findAllByQuery(query);
    }

    private boolean isCancelableFire(NopJobFire fire, List<NopJobTask> tasks) {
        boolean hasUnfinishedTask = tasks.isEmpty()
                || tasks.stream().anyMatch(t -> !JobTaskStateMachine.isFinished(t.getTaskStatus()));
        return JobFireStateMachine.canCancel(fire.getFireStatus(), hasUnfinishedTask);
    }

    private boolean shouldAdvanceFixedDelaySchedule(NopJobSchedule schedule, NopJobFire fire) {
        return fire.getTriggerSource() != null
                && fire.getTriggerSource() == _NopJobCoreConstants.TRIGGER_SOURCE_SCHEDULE
                && schedule.getTriggerType() != null
                && schedule.getTriggerType() == _NopJobCoreConstants.TRIGGER_TYPE_FIXED_DELAY;
    }

    private Timestamp calculateFixedDelayNextFireTime(NopJobSchedule schedule, Timestamp fireEndTime) {
        NopJobSchedule evalSchedule = schedule.cloneInstance();
        evalSchedule.setLastEndTime(fireEndTime);

        long next = JobTriggerCalculator.calculateNextFireTime(
                toTriggerSpec(evalSchedule),
                toEvalContext(evalSchedule),
                fireEndTime.getTime()
        );
        return next <= 0 ? null : new Timestamp(next);
    }

    private TriggerSpec toTriggerSpec(NopJobSchedule schedule) {
        return TriggerSpecHelper.toTriggerSpec(schedule);
    }

    private ITriggerEvalContext toEvalContext(NopJobSchedule schedule) {
        return TriggerSpecHelper.toEvalContext(schedule);
    }


    private long defaultLong(Long value) {
        return value == null ? 0L : value;
    }

    private int defaultInt(Integer value) {
        return value == null ? 0 : value;
    }
}
