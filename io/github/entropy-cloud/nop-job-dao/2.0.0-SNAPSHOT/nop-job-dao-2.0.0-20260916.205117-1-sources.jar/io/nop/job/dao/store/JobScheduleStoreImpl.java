package io.nop.job.dao.store;

import io.nop.api.core.annotations.txn.TransactionPropagation;
import io.nop.api.core.annotations.txn.Transactional;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.IntRangeSet;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.commons.util.DateHelper;
import io.nop.dao.api.IDaoProvider;
import io.nop.job.core._NopJobCoreConstants;
import io.nop.job.dao.entity.NopJobFire;
import io.nop.job.dao.entity.NopJobSchedule;
import io.nop.job.dao.entity.NopJobTask;
import io.nop.job.dao.entity._gen._NopJobFire;
import io.nop.job.dao.entity._gen._NopJobTask;
import io.nop.job.dao.helper.JobFireStateMachine;
import io.nop.job.dao.helper.JobQueryHelper;
import io.nop.job.dao.helper.JobTaskStateMachine;
import io.nop.orm.dao.IOrmEntityDao;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static io.nop.job.core.JobCoreErrors.ERR_JOB_FIRE_STATUS_CONFLICT;
import static io.nop.job.core.JobCoreErrors.ERR_JOB_OVERLAID;
import static io.nop.job.dao.entity._gen._NopJobSchedule.PROP_NAME_jobScheduleId;
import static io.nop.job.dao.entity._gen._NopJobSchedule.PROP_NAME_nextFireTime;
import static io.nop.job.dao.entity._gen._NopJobSchedule.PROP_NAME_partitionIndex;
import static io.nop.job.dao.entity._gen._NopJobSchedule.PROP_NAME_scheduleStatus;

public class JobScheduleStoreImpl implements IJobScheduleStore {
    static final Logger LOG = LoggerFactory.getLogger(JobScheduleStoreImpl.class);

    // plan 340 §2.9 (P2-8): defensive cap on active-fire queries (overlay/manual storm drain).
    private static final int ACTIVE_FIRES_QUERY_LIMIT = 500;

    private IDaoProvider daoProvider;

    @Inject
    public void setDaoProvider(IDaoProvider daoProvider) {
        this.daoProvider = daoProvider;
    }

    @Override
    public List<NopJobSchedule> fetchDueSchedules(int limit, IntRangeSet partitions) {
        IOrmEntityDao<NopJobSchedule> dao = scheduleDao();
        long now = dao.getDbEstimatedClock().getMinCurrentTimeMillis();

        QueryBean query = new QueryBean();
        query.setLimit(limit);
        query.addFilter(FilterBeans.eq(PROP_NAME_scheduleStatus, _NopJobCoreConstants.SCHEDULE_STATUS_ENABLED));
        query.addFilter(FilterBeans.le(PROP_NAME_nextFireTime, now));
        JobQueryHelper.addPartitionFilter(query, partitions, PROP_NAME_partitionIndex);
        query.addOrderField(PROP_NAME_nextFireTime, false);
        query.addOrderField(PROP_NAME_jobScheduleId, false);
        return dao.findPageByQuery(query);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public List<NopJobSchedule> tryLockSchedulesForPlan(List<NopJobSchedule> schedules, String plannerInstanceId,
                                                        long lockTimeoutMs) {
        if (schedules == null || schedules.isEmpty()) {
            return Collections.emptyList();
        }

        IOrmEntityDao<NopJobSchedule> dao = scheduleDao();
        long now = dao.getDbEstimatedClock().getMaxCurrentTimeMillis();
        Timestamp lockTime = new Timestamp(now + Math.max(lockTimeoutMs, 1));

        for (NopJobSchedule schedule : schedules) {
            schedule.setNextFireTime(lockTime);
        }
        return dao.tryUpdateManyWithVersionCheck(schedules);
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public void advanceScheduleAfterSkip(NopJobSchedule schedule, Timestamp nextFireTime) {
        updateScheduleWithRetry(schedule, () -> schedule.setNextFireTime(nextFireTime), "skip");
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public void insertFireAndAdvanceSchedule(NopJobSchedule schedule, NopJobFire fire, Timestamp nextFireTime,
                                             Integer lastFireStatus) {
        if (hasWaitingFire(schedule.getJobScheduleId(), fire.getScheduledFireTime(), fire.getTriggerSource())) {
            LOG.info("nop.job.schedule.skip-duplicate-fire:scheduleId={},scheduledFireTime={}",
                    schedule.getJobScheduleId(), fire.getScheduledFireTime());
            updateScheduleWithRetry(schedule, () -> schedule.setNextFireTime(nextFireTime), "skip-duplicate-fire");
            return;
        }

        fireDao().saveEntityDirectly(fire);

        updateScheduleWithRetry(schedule,
                () -> {
                    schedule.setFireCount(defaultLong(schedule.getFireCount()) + 1);
                    schedule.setActiveFireCount(defaultInt(schedule.getActiveFireCount()) + 1);
                    schedule.setLastFireTime(fire.getScheduledFireTime());
                    schedule.setNextFireTime(nextFireTime);
                    if (lastFireStatus != null) {
                        schedule.setLastFireStatus(lastFireStatus);
                    }
                },
                "insertFire");
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public void overlayFireAndAdvanceSchedule(NopJobSchedule schedule, NopJobFire fire, Timestamp nextFireTime,
                                              Integer lastFireStatus) {
        long now = scheduleDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
        Timestamp cancelTime = new Timestamp(now);
        List<NopJobFire> activeFires = findActiveFires(schedule.getJobScheduleId());

        int actualCancelledCount = 0;
        for (NopJobFire activeFire : activeFires) {
            try {
                boolean cancelled = markFireCanceledOnly(activeFire, cancelTime);
                if (cancelled) {
                    actualCancelledCount++;
                }
                cancelTasks(activeFire.getJobFireId(), cancelTime);
            } catch (Exception e) {
                LOG.warn("nop.job.schedule.cancel-fire-failed:fireId={}", activeFire.getJobFireId(), e);
            }
        }

        fireDao().saveEntityDirectly(fire);

        final int cancelledCount = actualCancelledCount;
        updateScheduleWithRetry(schedule,
                () -> {
                    schedule.setTotalFireCount(defaultLong(schedule.getTotalFireCount()) + cancelledCount);
                    schedule.setFailFireCount(defaultLong(schedule.getFailFireCount()) + cancelledCount);
                    schedule.setFireCount(defaultLong(schedule.getFireCount()) + 1);
                    // check2 [P3-1]: 与 cancelFire/completeSingleFire/tryMarkDispatchTimeout 对齐补
                    // Math.max 下限——计数已向下漂移（偏小/为0）时，overlay/manual 减法不得产生负值
                    //（负值使 shouldDiscard/shouldOverlay/shouldRecovery 的 activeFireCount>0 判定永久失效）
                    schedule.setActiveFireCount(Math.max(0,
                            defaultInt(schedule.getActiveFireCount()) - cancelledCount) + 1);
                    schedule.setLastFireTime(fire.getScheduledFireTime());
                    if (!activeFires.isEmpty()) {
                        schedule.setLastEndTime(cancelTime);
                    }
                    schedule.setNextFireTime(nextFireTime);
                    if (lastFireStatus != null) {
                        schedule.setLastFireStatus(lastFireStatus);
                    }
                },
                "overlayFire");
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public void recoveryFireAndAdvanceSchedule(NopJobSchedule schedule, Timestamp nextFireTime) {
        List<NopJobFire> failedFires = findFailedFires(schedule.getJobScheduleId());

        if (failedFires.isEmpty()) {
            long now = scheduleDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
            Timestamp fireTime = new Timestamp(now);

            NopJobFire newFire = fireDao().newEntity();
            newFire.setJobScheduleId(schedule.getJobScheduleId());
            newFire.setNamespaceId(schedule.getNamespaceId());
            newFire.setGroupId(schedule.getGroupId());
            newFire.setJobName(schedule.getJobName());
            newFire.setScheduledFireTime(fireTime);
            newFire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_WAITING);
            newFire.setTriggerSource(_NopJobCoreConstants.TRIGGER_SOURCE_RECOVERY);
            newFire.setRetryPolicyId(schedule.getRetryPolicyId());
            newFire.setJobParamsSnapshot(schedule.getJobParams());
            newFire.setPartitionIndex(schedule.getPartitionIndex());
            newFire.setExecutorKind(schedule.getExecutorKind());
            newFire.setDispatchMode(schedule.getDispatchMode());

            fireDao().saveEntityDirectly(newFire);

            updateScheduleWithRetry(schedule,
                    () -> {
                        schedule.setFireCount(defaultLong(schedule.getFireCount()) + 1);
                        schedule.setActiveFireCount(defaultInt(schedule.getActiveFireCount()) + 1);
                        schedule.setLastFireTime(fireTime);
                        schedule.setNextFireTime(nextFireTime);
                    },
                    "recovery-new-fire");
            return;
        }

        long now = scheduleDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
        Timestamp recoveryTime = new Timestamp(now);

        NopJobFire failedFire = failedFires.get(0);

        // plan 340 §2.8 (P2-7): the failedFire field mutations below were dead code — only the
        // reloaded freshFire is persisted. Reload is required for version-check correctness
        // (the entity must reflect the latest row state before tryUpdateWithVersionCheck).
        NopJobFire freshFire = fireDao().requireEntityById(failedFire.getJobFireId());
        Integer currentFireStatus = freshFire.getFireStatus();
        if (!JobFireStateMachine.isRecoverable(currentFireStatus)) {
            LOG.info("nop.job.schedule.recovery-skip-fire-no-longer-failed:fireId={},status={}",
                    failedFire.getJobFireId(), currentFireStatus);
            // plan 340 §2.3 (P2-2): still advance nextFireTime so the planner does not re-fetch
            // this schedule every 5s cycle in a tight retry loop.
            updateScheduleWithRetry(schedule,
                    () -> schedule.setNextFireTime(nextFireTime),
                    "recovery-skip");
            return;
        }

        freshFire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_WAITING);
        freshFire.setErrorCode(null);
        freshFire.setErrorMessage(null);
        freshFire.setEndTime(null);
        freshFire.setDurationMs(null);
        freshFire.setJobParamsSnapshot(schedule.getJobParams());
        freshFire.setRetryPolicyId(schedule.getRetryPolicyId());

        if (!fireDao().tryUpdateWithVersionCheck(freshFire)) {
            LOG.warn("nop.job.schedule.recovery-fire-version-conflict:fireId={}", failedFire.getJobFireId());
            return;
        }

        resetFailedTasks(failedFire.getJobFireId(), recoveryTime);

        updateScheduleWithRetry(schedule,
                () -> {
                    schedule.setActiveFireCount(defaultInt(schedule.getActiveFireCount()) + 1);
                    schedule.setNextFireTime(nextFireTime);
                },
                "recovery-reuse-failed");
    }

    @Transactional(propagation = TransactionPropagation.REQUIRES_NEW)
    @Override
    public boolean insertManualFire(NopJobSchedule schedule, NopJobFire fire) {
        long now = scheduleDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
        Timestamp updateTime = new Timestamp(now);

        if (hasWaitingFire(schedule.getJobScheduleId(), fire.getScheduledFireTime(), fire.getTriggerSource())) {
            LOG.info("nop.job.schedule.insert-manual-fire-duplicate:scheduleId={},fireTime={}",
                    schedule.getJobScheduleId(), fire.getScheduledFireTime());
            return false;
        }

        List<NopJobFire> activeFires = findActiveFires(schedule.getJobScheduleId());

        if (isDiscard(schedule) && !activeFires.isEmpty()) {
            return false;
        }

        if (isOverlay(schedule)) {
            for (NopJobFire activeFire : activeFires) {
                try {
                    markFireCanceledOnly(activeFire, updateTime);
                    cancelTasks(activeFire.getJobFireId(), updateTime);
                } catch (Exception e) {
                    LOG.warn("nop.job.schedule.cancel-fire-failed:fireId={}", activeFire.getJobFireId(), e);
                }
            }
        }

        fireDao().saveEntityDirectly(fire);

        int cancelledCount = 0;
        if (isOverlay(schedule)) {
            for (NopJobFire af : activeFires) {
                NopJobFire fresh = fireDao().requireEntityById(af.getJobFireId());
                if (JobFireStateMachine.isCanceled(fresh.getFireStatus())) {
                    cancelledCount++;
                }
            }
        }

        final int finalCancelledCount = cancelledCount;
        updateScheduleWithRetry(schedule,
                () -> {
                    if (finalCancelledCount > 0) {
                        schedule.setTotalFireCount(defaultLong(schedule.getTotalFireCount()) + finalCancelledCount);
                        schedule.setFailFireCount(defaultLong(schedule.getFailFireCount()) + finalCancelledCount);
                    }

                    schedule.setFireCount(defaultLong(schedule.getFireCount()) + 1);
                    // check2 [P3-1]: 同 overlayFireAndAdvanceSchedule——减法补 Math.max 下限
                    schedule.setActiveFireCount(Math.max(0,
                            defaultInt(schedule.getActiveFireCount())
                                    - (isOverlay(schedule) ? finalCancelledCount : 0)) + 1);
                    if (isOverlay(schedule) && !activeFires.isEmpty()) {
                        schedule.setLastEndTime(updateTime);
                        schedule.setLastFireStatus(_NopJobCoreConstants.FIRE_STATUS_CANCELED);
                    }
                },
                "insertManualFire");
        return true;
    }

    @Override
    public NopJobSchedule loadSchedule(String jobScheduleId) {
        return scheduleDao().requireEntityById(jobScheduleId);
    }

    @Override
    public NopJobSchedule tryLoadSchedule(String jobScheduleId) {
        return scheduleDao().getEntityById(jobScheduleId);
    }

    @Override
    public Map<String, NopJobSchedule> batchLoadSchedules(Set<String> scheduleIds) {
        if (scheduleIds == null || scheduleIds.isEmpty()) {
            return Collections.emptyMap();
        }
        // batchGetEntityMapByIds 的单 id 分支返回未加载的 proxy 实体（见 OrmEntityDao.batchGetEntitiesByIds），
        // session 关闭后访问属性会抛 session-closed，因此单 id 场景改用 getEntityById 全量加载。
        if (scheduleIds.size() == 1) {
            String id = scheduleIds.iterator().next();
            NopJobSchedule schedule = scheduleDao().getEntityById(id);
            if (schedule == null) {
                return Collections.emptyMap();
            }
            return Collections.singletonMap(id, schedule);
        }
        return (Map) scheduleDao().batchGetEntityMapByIds(scheduleIds);
    }

    @Override
    public long getCurrentTime() {
        return scheduleDao().getDbEstimatedClock().getMaxCurrentTimeMillis();
    }

    private void updateScheduleWithRetry(NopJobSchedule schedule, Runnable fieldSetter, String retryContext) {
        if (scheduleDao().updateWithRetry(schedule, 5, fieldSetter)) {
            return;
        }

        throw new NopException(ERR_JOB_FIRE_STATUS_CONFLICT)
                .param("scheduleId", schedule.getJobScheduleId())
                .param("reason", "Failed to update schedule after " + retryContext + ", 5 retries exhausted");
    }

    private IOrmEntityDao<NopJobSchedule> scheduleDao() {
        return (IOrmEntityDao<NopJobSchedule>) daoProvider.daoFor(NopJobSchedule.class);
    }

    private IOrmEntityDao<NopJobFire> fireDao() {
        return (IOrmEntityDao<NopJobFire>) daoProvider.daoFor(NopJobFire.class);
    }

    private IOrmEntityDao<NopJobTask> taskDao() {
        return (IOrmEntityDao<NopJobTask>) daoProvider.daoFor(NopJobTask.class);
    }

    private boolean hasWaitingFire(String scheduleId, Timestamp scheduledFireTime, Integer triggerSource) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_jobScheduleId, scheduleId));
        query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_fireStatus, _NopJobCoreConstants.FIRE_STATUS_WAITING));
        query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_scheduledFireTime, scheduledFireTime));
        if (triggerSource != null) {
            query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_triggerSource, triggerSource));
        }
        query.setLimit(1);
        return !fireDao().findPageByQuery(query).isEmpty();
    }

    private List<NopJobFire> findActiveFires(String jobScheduleId) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_jobScheduleId, jobScheduleId));
        query.addFilter(FilterBeans.in(_NopJobFire.PROP_NAME_fireStatus, JobFireStateMachine.ACTIVE_STATUSES));
        query.addOrderField(_NopJobFire.PROP_NAME_scheduledFireTime, false);
        query.addOrderField(_NopJobFire.PROP_NAME_jobFireId, false);
        // plan 340 §2.9 (P2-8): defensive cap; remaining active fires are handled on subsequent cycles.
        query.setLimit(ACTIVE_FIRES_QUERY_LIMIT);
        List<NopJobFire> result = fireDao().findPageByQuery(query);
        if (result.size() >= ACTIVE_FIRES_QUERY_LIMIT) {
            LOG.warn("nop.job.query-limit-hit:method=findActiveFires,scheduleId={},limit={}",
                    jobScheduleId, ACTIVE_FIRES_QUERY_LIMIT);
        }
        return result;
    }

    private boolean isDiscard(NopJobSchedule schedule) {
        return schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_DISCARD;
    }

    private boolean isOverlay(NopJobSchedule schedule) {
        return schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_OVERLAY;
    }

    private List<NopJobFire> findFailedFires(String jobScheduleId) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobFire.PROP_NAME_jobScheduleId, jobScheduleId));
        query.addFilter(FilterBeans.in(_NopJobFire.PROP_NAME_fireStatus, JobFireStateMachine.RECOVERABLE_STATUSES));
        query.addOrderField(_NopJobFire.PROP_NAME_scheduledFireTime, false);
        query.addOrderField(_NopJobFire.PROP_NAME_jobFireId, false);
        query.setLimit(1);
        return fireDao().findPageByQuery(query);
    }

    private void resetFailedTasks(String jobFireId, Timestamp recoveryTime) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobTask.PROP_NAME_jobFireId, jobFireId));
        List<NopJobTask> tasks = taskDao().findAllByQuery(query);
        for (NopJobTask task : tasks) {
            if (!isTaskFailed(task.getTaskStatus())) {
                continue;
            }
            task.setTaskStatus(_NopJobCoreConstants.TASK_STATUS_WAITING);
            task.setStartTime(null);
            task.setEndTime(null);
            task.setDurationMs(null);
            task.setErrorCode(null);
            task.setErrorMessage(null);
            if (!taskDao().tryUpdateWithVersionCheck(task)) {
                LOG.warn("nop.job.schedule.reset-task-version-conflict:taskId={}", task.getJobTaskId());
            }
        }
    }

    private boolean isTaskFailed(Integer taskStatus) {
        return JobTaskStateMachine.isRecoverable(taskStatus);
    }

    // plan 340 §2.6 (P2-5): renamed from cancelFire to eliminate the name collision with
    // IJobFireStore.cancelFire(jobFireId). This private helper marks ONLY the fire row as
    // CANCELED (ERR_JOB_OVERLAID); it does NOT cancel tasks nor update schedule counters —
    // the overlay/manual callers compose markFireCanceledOnly + cancelTasks + aggregated
    // counter math in their own transaction (more efficient than per-fire REQUIRES_NEW).
    private boolean markFireCanceledOnly(NopJobFire fire, Timestamp cancelTime) {
        NopJobFire fresh = fireDao().requireEntityById(fire.getJobFireId());
        Integer currentStatus = fresh.getFireStatus();
        if (JobFireStateMachine.isTerminal(currentStatus)) {
            return false;
        }

        fresh.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_CANCELED);
        fresh.setEndTime(cancelTime);
        fresh.setDurationMs(DateHelper.durationMs(fresh.getStartTime(), cancelTime));
        fresh.setErrorCode(ERR_JOB_OVERLAID.getErrorCode());
        fresh.setErrorMessage(ERR_JOB_OVERLAID.getDescription());
        if (!fireDao().tryUpdateWithVersionCheck(fresh)) {
            LOG.warn("nop.job.schedule.cancel-fire-version-conflict:fireId={}", fire.getJobFireId());
            return false;
        }
        return true;
    }

    private void cancelTasks(String jobFireId, Timestamp cancelTime) {
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(_NopJobTask.PROP_NAME_jobFireId, jobFireId));
        List<NopJobTask> tasks = taskDao().findAllByQuery(query);
        for (NopJobTask task : tasks) {
            if (JobTaskStateMachine.isFinished(task.getTaskStatus())) {
                continue;
            }

            task.setTaskStatus(_NopJobCoreConstants.TASK_STATUS_CANCELED);
            task.setEndTime(cancelTime);
            task.setDurationMs(DateHelper.durationMs(task.getStartTime(), cancelTime));
            task.setErrorCode(ERR_JOB_OVERLAID.getErrorCode());
            task.setErrorMessage(ERR_JOB_OVERLAID.getDescription());
            if (!taskDao().tryUpdateWithVersionCheck(task)) {
                LOG.warn("nop.job.schedule.cancel-task-version-conflict:taskId={}", task.getJobTaskId());
            }
        }
    }

    private long defaultLong(Long value) {
        return value == null ? 0L : value;
    }

    private int defaultInt(Integer value) {
        return value == null ? 0 : value;
    }
}
