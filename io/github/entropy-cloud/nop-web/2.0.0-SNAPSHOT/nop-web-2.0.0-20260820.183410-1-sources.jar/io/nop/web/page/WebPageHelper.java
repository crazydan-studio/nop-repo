/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.web.page;

import io.nop.api.core.config.AppConfig;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.CloneHelper;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.util.StringHelper;
import io.nop.web.WebConfigs;
import io.nop.core.CoreConstants;
import io.nop.core.CoreErrors;
import io.nop.core.i18n.I18nMessageManager;
import io.nop.core.lang.json.DeltaJsonOptions;
import io.nop.core.lang.json.JObject;
import io.nop.core.lang.json.JsonTool;
import io.nop.core.lang.json.delta.JsonCleaner;
import io.nop.core.lang.json.delta.JsonMerger;
import io.nop.core.lang.json.utils.JsonTransformHelper;
import io.nop.core.lang.json.utils.SourceLocationHelper;
import io.nop.core.resource.IResource;
import io.nop.core.resource.VirtualFileSystem;
import io.nop.web.WebConstants;
import io.nop.xlang.xdsl.json.XJsonLoader;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static io.nop.web.WebErrors.ARG_ALLOWED_FILE_TYPES;
import static io.nop.web.WebErrors.ARG_PATH;
import static io.nop.web.WebErrors.ERR_WEB_INVALID_PAGE_FILE_TYPE;
import static io.nop.web.WebErrors.ERR_WEB_UNSUPPORTED_FILE_TYPE;

public class WebPageHelper {
    /**
     * 将 {@code *.page.yaml} 路径转换为同目录同名的 {@code *.flux.yaml} 路径（仅替换复合扩展名 {@code page.yaml} 为 {@code flux.yaml}）。
     * 用于 Flux 渲染模式下的页面回退：开启 {@code nop.web.render-mode=flux} 时，优先加载同名的 flux.yaml。
     * 输入不是 {@code page.yaml} 时返回 {@code null}。
     */
    public static String toFluxPagePath(String pagePath) {
        if (pagePath == null)
            return null;
        if (!WebConstants.FILE_TYPE_PAGE_YAML.equals(StringHelper.fileType(pagePath)))
            return null;
        return pagePath.substring(0, pagePath.length() - WebConstants.FILE_TYPE_PAGE_YAML.length())
                + WebConstants.FILE_TYPE_FLUX_YAML;
    }

    public static Map<String, Object> internalLoadPage(String pagePath) {
        IResource resource = VirtualFileSystem.instance().getResource(pagePath);
        DeltaJsonOptions options = XJsonLoader.newOptions(null);
        options.setCleanDelta(false);

        Map<String, Object> map = JsonTool.instance().loadDeltaBean(resource, JObject.class, options);
        return map;
    }

    /**
     * 将 view/embed 配置中声明的 override 内容以 delta 合并语义（Io.nop.core.lang.json.delta.JsonMerger）
     * 应用到已加载的页面 JSON 上：map 按 key 合并（! 前缀强制覆盖）、list 按唯一键(id/name)合并、无唯一键整段替换。
     * override 为 null 或空 map 时原样返回 base，保证既有渲染输出不变。
     * override 来自已冻结的组件模型（view/disp），可能为只读 JObject，而 JsonMerger.mergeMap 会就地
     * remove x:virtual/x:inherit 标记键，故先经 CloneHelper.deepClone 转为可写副本，避免 map-is-readonly。
     */
    public static Map<String, Object> applyViewOverride(Map<String, Object> base, Object override) {
        if (override == null || isEmptyMapOrList(override))
            return base;
        Object mutableOverride = CloneHelper.deepClone(override);
        Object merged = JsonMerger.instance().merge(base, mutableOverride);
        return merged instanceof Map ? (Map<String, Object>) merged : base;
    }

    private static boolean isEmptyMapOrList(Object value) {
        if (value instanceof Map)
            return ((Map<?, ?>) value).isEmpty();
        if (value instanceof Collection)
            return ((Collection<?>) value).isEmpty();
        return false;
    }

    public static void checkPageFile(String path) {
        String fileType = StringHelper.fileType(path);
        if (!WebConstants.PAGE_FILE_TYPES.contains(fileType))
            throw new NopException(ERR_WEB_INVALID_PAGE_FILE_TYPE).param(ARG_PATH, path).param(ARG_ALLOWED_FILE_TYPES,
                    WebConstants.PAGE_FILE_TYPES);
    }

    public static void checkJsFile(String path) {
        String fileType = StringHelper.fileExt(path);
        if (!WebConstants.JS_FILE_TYPES.contains(fileType))
            throw new NopException(ERR_WEB_UNSUPPORTED_FILE_TYPE).param(ARG_PATH, path).param(ARG_ALLOWED_FILE_TYPES,
                    WebConstants.JS_FILE_TYPES);
    }

    public static void checkXjsFile(String path) {
        String fileType = StringHelper.fileExt(path);
        if (!WebConstants.XJS_FILE_TYPES.contains(fileType))
            throw new NopException(ERR_WEB_UNSUPPORTED_FILE_TYPE).param(ARG_PATH, path).param(ARG_ALLOWED_FILE_TYPES,
                    WebConstants.XJS_FILE_TYPES);
    }

    // 删除null值和空集合，简化最终的Page结构
    public static void removeNullEntry(Object map) {
        JsonCleaner.instance().clean(map, (name, value) -> {
            // amis区分value的null和undefined
            if (value == null && !"value".equals(name))
                return true;
            if (value instanceof Map<?, ?>) {
                if (((Map<?, ?>) value).isEmpty()) {
                    if (name.equals("validations") || name.equals("transform"))
                        return true;
                }
            } else if (value instanceof Collection) {
                if(((Collection<?>) value).isEmpty()) {
                    if (name.equals("rules"))
                        return true;
                }
            }
            return false;
        });
    }

    public static boolean isFluxMode() {
        return "flux".equals(WebConfigs.CFG_WEB_RENDER_MODE.get());
    }

    /**
     * 修正页面结构。Flux 模式下跳过 AMIS 特有处理（className 注入、group.body 归一化），
     * 但 GraphQL URL 转义和国际化解析对所有模式均生效。
     */
    public static void fixPage(Object map, String locale, boolean resolveI18n) {
        boolean isFlux = isFluxMode();
        JsonTransformHelper.transformInPlace(map, value -> {
            if (value instanceof String) {
                String str = value.toString();
                // url中包含回车或者空格会导致前台amis框架死循环
                if (str.startsWith("@")) {
                    if (str.startsWith("@query:") || str.startsWith("@mutation:") || str.startsWith("@subscription:")) {
                        str = escapeGraphQL(str);
                    }
                } else if (resolveI18n && locale != null && str.contains(CoreConstants.I18N_VAR_START)) {
                    return I18nMessageManager.instance().resolveI18nVar(locale, str);
                }
                return str;
            } else if (value instanceof Map) {
                if (isFlux)
                    return value;
                // 确保所有amis的组件都具有amis这个scope，前端会利用它限制css的作用范围
                Map<String, Object> data = (Map<String, Object>) value;
                Object dialog = data.get("dialog");
                if (dialog instanceof Map) {
                    addClassName((Map<String, Object>) dialog, "bodyClassName", "amis");
                }
                Object drawer = data.get("drawer");
                if (drawer instanceof Map) {
                    addClassName((Map<String, Object>) drawer, "className", "amis");
                }

                if ("group".equals(data.get("type"))) {
                    // group的body必须是Array类型。如果是Map，则不显示
                    Object body = data.get("body");
                    if (body != null && !(body instanceof Collection)) {
                        List<Object> list = Collections.singletonList(body);
                        data.put("body", list);
                    }
                }
            }
            return value;
        });
    }

    static String escapeGraphQL(String url) {
        url = url.trim();
        StringBuilder sb = new StringBuilder();
        boolean prevSep = false;
        for (int i = 0, n = url.length(); i < n; i++) {
            char c = url.charAt(i);
            if (c == ' ' || c == '\r' || c == '\t') {
                if (!prevSep) {
                    prevSep = true;
                    sb.append("%20");
                }
            } else if (c == '\n') {
                prevSep = false;
                sb.append("%0A");
            } else {
                prevSep = false;
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static void unfixPage(Map<String, Object> map) {
        JsonTransformHelper.transformInPlace(map, value -> {
            if (value instanceof String) {
                String str = value.toString();
                // url中包含回车或者空格会导致前台amis框架死循环
                if (str.startsWith("@")) {
                    if (str.startsWith("@query:") || str.startsWith("@mutation:") || str.startsWith("@subscription:")) {
                        str = escapeGraphQL(str);
                    }
                }
                return str;
            } else if (value instanceof Map) {
                // 确保所有amis的组件都具有amis这个scope，前端会利用它限制css的作用范围
                Map<String, Object> data = (Map<String, Object>) value;
                Object dialog = data.get("dialog");
                if (dialog instanceof Map) {
                    addClassName((Map<String, Object>) dialog, "bodyClassName", "amis");
                }
                Object drawer = data.get("drawer");
                if (drawer instanceof Map) {
                    addClassName((Map<String, Object>) drawer, "className", "amis");
                }
                //
                // if ("group".equals(data.get("type"))) {
                // // group的body必须是Array类型。如果是Map，则不显示
                // Object body = data.get("body");
                // if (body != null && (body instanceof List)) {
                // List<Object> list = (List<Object>) body;
                // boolean fixList = Boolean.TRUE.equals(data.remove("xui:fix-list"));
                // if (list.size() == 1 && fixList) {
                // data.put("body", list.get(0));
                // }
                // }
                // }
            }
            return value;
        });
    }

    static void addClassName(Map<String, Object> map, String classNameKey, String className) {
        String value = (String) map.get(classNameKey);
        if (value == null) {
            value = className;
        } else if (!StringHelper.hasCssClass(value, className)) {
            value = className + " " + value;
        }
        map.put(classNameKey, value);
    }

    /**
     * 如果已经包含v:id，则删除前台提交的代码中由编辑器自动生成的随机id,否则无法正确合并
     */
    public static void removeGeneratedId(Object value) {
        if (value instanceof Map<?, ?>) {
            Map<String, Object> map = (Map<String, Object>) value;
            String id = (String) map.get("id");
            if (id != null) {
                if (id.startsWith("u:")) {
                    if (map.containsKey("name") || map.containsKey(CoreConstants.ATTR_V_ID)
                            || map.containsKey(CoreConstants.ATTR_X_ID)) {
                        map.remove("id");
                    }
                }
            }

            for (Object entryValue : map.values()) {
                removeGeneratedId(entryValue);
            }
        } else if (value instanceof List) {
            List<Object> list = (List<Object>) value;
            for (Object item : list) {
                removeGeneratedId(item);
            }
        }
    }

    public static void normalizeXuiImport(Map<String, Object> page) {
        JsonTransformHelper.transformMapEntryInPlace(page, (name, v) -> {
            return name.equals(WebConstants.ATTR_XUI_IMPORT);
        }, WebPageHelper::normalizeXuiImportUrls);
    }

    private static Object normalizeXuiImportUrls(SourceLocation loc, String name, Object value) {
        if (value instanceof String) {
            List<String> paths = StringHelper.split(value.toString(), ',');
            return paths.stream().map(path -> normalizeFileUrl(loc, path)).collect(Collectors.joining(","));
        } else if (value instanceof Collection) {
            Collection<String> paths = (Collection<String>) value;
            return paths.stream().map(path -> normalizeFileUrl(loc, name)).collect(Collectors.joining(","));
        } else if (value instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) value;
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                SourceLocation loc2 = SourceLocationHelper.getLocation(map, entry.getKey());
                if (loc2 == null)
                    loc2 = loc;
                entry.setValue(normalizeFileUrl(loc2, (String) entry.getValue()));
            }
            return map;
        } else {
            return value;
        }
    }

    private static String normalizeFileUrl(SourceLocation loc, String path) {
        String absPath = SourceLocationHelper.toAbsolutePath(loc, path);
        IResource resource = VirtualFileSystem.instance().getResource(absPath);
        if (!resource.exists())
            throw new NopException(CoreErrors.ERR_RESOURCE_NOT_EXISTS).param(ARG_PATH, absPath).loc(loc);
        long ts = AppConfig.webFileTimestamp();
        if (ts > 0)
            return absPath + "?_t=" + ts;
        return absPath;
    }
}
