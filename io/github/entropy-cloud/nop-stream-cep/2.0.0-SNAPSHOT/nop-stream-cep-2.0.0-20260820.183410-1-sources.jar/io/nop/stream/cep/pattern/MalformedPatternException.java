/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.cep.pattern;

import io.nop.api.core.exceptions.ErrorCode;
import io.nop.stream.core.exceptions.StreamRuntimeException;

/**
 * An exception used to indicate that a {@link Pattern} was not
 * specified correctly.
 */
public class MalformedPatternException extends StreamRuntimeException {

    private static final long serialVersionUID = 7751134834983361543L;

    public MalformedPatternException(String message) {
        super(message);
    }

    public MalformedPatternException(ErrorCode errorCode) {
        super(errorCode);
    }

    public MalformedPatternException(ErrorCode errorCode, Throwable cause) {
        super(errorCode, cause);
    }
}
