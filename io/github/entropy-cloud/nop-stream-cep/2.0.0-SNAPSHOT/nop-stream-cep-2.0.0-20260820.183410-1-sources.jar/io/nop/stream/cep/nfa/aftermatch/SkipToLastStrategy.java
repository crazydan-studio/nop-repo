/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.cep.nfa.aftermatch;

import java.util.Optional;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_NAME;

/**
 * Discards every partial match that started before the last event of emitted match mapped to
 * *PatternName*.
 */
public final class SkipToLastStrategy extends SkipToElementStrategy {
    private static final long serialVersionUID = 7585116990619594531L;

    SkipToLastStrategy(String patternName, boolean shouldThrowException) {
        super(patternName, shouldThrowException);
    }

    @Override
    public SkipToElementStrategy throwExceptionOnMiss() {
        Optional<String> name = getPatternName();
        if(name.isEmpty())
            throw new StreamException(ERR_STREAM_NULL_NAME);
        return new SkipToLastStrategy(name.get(), true);
    }

    @Override
    int getIndex(int size) {
        return size - 1;
    }

    @Override
    public String toString() {
        String name = getPatternName().orElse("");
        return "SkipToLastStrategy{" + "patternName='" + name + '\'' + '}';
    }
}
