/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.cep.nfa;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.PriorityQueue;
import java.io.Serializable;
import java.util.Queue;

/** State kept for a {@link NFA}. */
public class NFAState implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Current set of {@link ComputationState computation states} within the state machine. These
     * are the "active" intermediate states that are waiting for new matching events to transition
     * to new valid states.
     */
    private Queue<ComputationState> partialMatches;

    private Queue<ComputationState> completedMatches;

    /** Flag indicating whether the matching status of the state machine has changed. */
    private boolean stateChanged;

    /** Flag indicating whether the current matching status is new partial matched. */
    private boolean isNewStartPartialMatch;

    /**
     * Serializable comparator: NFAState queues are Java-serialized into the
     * checkpoint (JavaStreamSerializer), and PriorityQueue serializes its
     * comparator — a lambda/method-reference comparator is not serializable
     * and would make every checkpoint persist fail.
     */
    private static final class SerializableStateComparator
            implements Comparator<ComputationState>, Serializable {
        private static final long serialVersionUID = 1L;

        @Override
        public int compare(ComputationState c1, ComputationState c2) {
            long t1 = c1.getStartEventID() != null ? c1.getStartEventID().getTimestamp() : Long.MAX_VALUE;
            long t2 = c2.getStartEventID() != null ? c2.getStartEventID().getTimestamp() : Long.MAX_VALUE;
            int cmp = Long.compare(t1, t2);
            if (cmp != 0) {
                return cmp;
            }
            int i1 = c1.getStartEventID() != null ? c1.getStartEventID().getId() : Integer.MAX_VALUE;
            int i2 = c2.getStartEventID() != null ? c2.getStartEventID().getId() : Integer.MAX_VALUE;
            return Integer.compare(i1, i2);
        }
    }

    public static final Comparator<ComputationState> COMPUTATION_STATE_COMPARATOR =
            new SerializableStateComparator();

    public NFAState(Iterable<ComputationState> states) {
        this.partialMatches = new PriorityQueue<>(COMPUTATION_STATE_COMPARATOR);
        for (ComputationState startingState : states) {
            partialMatches.add(startingState);
        }

        this.completedMatches = new PriorityQueue<>(COMPUTATION_STATE_COMPARATOR);
    }

    public NFAState(
            Queue<ComputationState> partialMatches, Queue<ComputationState> completedMatches) {
        this.partialMatches = partialMatches;
        this.completedMatches = completedMatches;
    }

    /**
     * Check if the matching status of the NFA has changed so far.
     *
     * @return {@code true} if matching status has changed, {@code false} otherwise
     */
    public boolean isStateChanged() {
        return stateChanged;
    }

    /** Reset the changed bit checked via {@link #isStateChanged()} to {@code false}. */
    public void resetStateChanged() {
        this.stateChanged = false;
    }

    /** Set the changed bit checked via {@link #isStateChanged()} to {@code true}. */
    public void setStateChanged() {
        this.stateChanged = true;
    }

    public Queue<ComputationState> getPartialMatches() {
        return partialMatches;
    }

    public Queue<ComputationState> getCompletedMatches() {
        return completedMatches;
    }

    public void setNewPartialMatches(PriorityQueue<ComputationState> newPartialMatches) {
        this.partialMatches = newPartialMatches;
    }

    public boolean isNewStartPartialMatch() {
        return isNewStartPartialMatch;
    }

    public void resetNewStartPartialMatch() {
        this.isNewStartPartialMatch = false;
    }

    public void setNewStartPartialMatch() {
        this.isNewStartPartialMatch = true;
    }

    private static final Comparator<ComputationState> STATE_COMPARATOR =
            Comparator.<ComputationState, String>comparing(ComputationState::getCurrentStateName)
                    .thenComparing((c1, c2) -> {
                        DeweyNumber v1 = c1.getVersion();
                        DeweyNumber v2 = c2.getVersion();
                        if (v1 == null && v2 == null) return 0;
                        if (v1 == null) return -1;
                        if (v2 == null) return 1;
                        return compareDeweyNumber(v1, v2);
                    })
                    .thenComparingLong(ComputationState::getStartTimestamp)
                    .thenComparingLong(ComputationState::getPreviousTimestamp);

    private static int compareDeweyNumber(DeweyNumber a, DeweyNumber b) {
        int minLen = Math.min(a.length(), b.length());
        String[] da = a.toString().split("\\.");
        String[] db = b.toString().split("\\.");
        for (int i = 0; i < minLen; i++) {
            int cmp = Integer.compare(Integer.parseInt(da[i]), Integer.parseInt(db[i]));
            if (cmp != 0) return cmp;
        }
        return Integer.compare(a.length(), b.length());
    }

    private ComputationState[] sortedCopy(Queue<ComputationState> queue) {
        ComputationState[] arr = queue.toArray(new ComputationState[0]);
        Arrays.sort(arr, STATE_COMPARATOR);
        return arr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        NFAState nfaState = (NFAState) o;
        return Arrays.equals(sortedCopy(partialMatches), sortedCopy(nfaState.partialMatches))
                && Arrays.equals(sortedCopy(completedMatches), sortedCopy(nfaState.completedMatches));
    }

    @Override
    public int hashCode() {
        return Objects.hash(Arrays.hashCode(sortedCopy(partialMatches)), Arrays.hashCode(sortedCopy(completedMatches)));
    }

    @Override
    public String toString() {
        return "NFAState{"
                + "partialMatches="
                + partialMatches
                + ", completedMatches="
                + completedMatches
                + ", stateChanged="
                + stateChanged
                + '}';
    }
}
