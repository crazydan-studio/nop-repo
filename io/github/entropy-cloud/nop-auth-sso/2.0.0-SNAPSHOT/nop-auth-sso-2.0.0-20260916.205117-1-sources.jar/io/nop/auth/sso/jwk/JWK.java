/*
 * Copyright 2016 Red Hat, Inc. and/or its affiliates
 * and other contributors as indicated by the @author tags.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.auth.sso.jwk;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.nop.api.core.exceptions.NopException;
import io.nop.commons.util.StringHelper;

import java.math.BigInteger;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import java.util.Map;

import static io.nop.auth.sso.SsoErrors.ARG_ERROR;
import static io.nop.auth.sso.SsoErrors.ERR_AUTH_SSO_ACCESS_FAIL;

/**
 * @author <a href="mailto:sthorger@redhat.com">Stian Thorgersen</a>
 */
public class JWK {

    public static final String KEY_ID = "kid";

    public static final String KEY_TYPE = "kty";

    public static final String ALGORITHM = "alg";

    public static final String PUBLIC_KEY_USE = "use";

    public enum Use {
        SIG("sig"),
        ENCRYPTION("enc");

        private String str;

        Use(String str) {
            this.str = str;
        }

        public String asString() {
            return str;
        }
    }

    private String keyId;

    private String keyType;

    private String algorithm;

    private String publicKeyUse;

    protected Map<String, Object> otherClaims = new HashMap<String, Object>();

    @JsonProperty(KEY_ID)
    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    @JsonProperty(KEY_TYPE)
    public String getKeyType() {
        return keyType;
    }

    public void setKeyType(String keyType) {
        this.keyType = keyType;
    }

    @JsonProperty(ALGORITHM)
    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    @JsonProperty(PUBLIC_KEY_USE)
    public String getPublicKeyUse() {
        return publicKeyUse;
    }

    public void setPublicKeyUse(String publicKeyUse) {
        this.publicKeyUse = publicKeyUse;
    }

    @JsonAnyGetter
    public Map<String, Object> getOtherClaims() {
        return otherClaims;
    }

    @JsonAnySetter
    public void setOtherClaims(String name, Object value) {
        otherClaims.put(name, value);
    }


    public PublicKey toPublicKey() {
        String keyType = getKeyType();
        // JWKS端点畸形数据（kty缺失）显式拒绝而非NPE
        if (StringHelper.isEmpty(keyType))
            throw new NopException(ERR_AUTH_SSO_ACCESS_FAIL).param(ARG_ERROR, "JWK kty is missing");
        if (KeyType.RSA.equals(keyType)) {
            return createRSAPublicKey();
        } else if (KeyType.EC.equals(keyType)) {
            return createECPublicKey();
        } else {
            throw new NopException(ERR_AUTH_SSO_ACCESS_FAIL)
                    .param(ARG_ERROR, "unsupported JWK keyType: " + keyType);
        }
    }

    private PublicKey createECPublicKey() {
        String crv = (String) getOtherClaims().get(ECPublicJWK.CRV);
        BigInteger x = new BigInteger(1, StringHelper.decodeBase64((String) getOtherClaims().get(ECPublicJWK.X)));
        BigInteger y = new BigInteger(1, StringHelper.decodeBase64((String) getOtherClaims().get(ECPublicJWK.Y)));

        String name;
        switch (crv) {
            case "P-256":
                name = "secp256r1";
                break;
            case "P-384":
                name = "secp384r1";
                break;
            case "P-521":
                name = "secp521r1";
                break;
            default:
                throw new NopException(ERR_AUTH_SSO_ACCESS_FAIL)
                        .param(ARG_ERROR, "unsupported EC curve: " + crv);
        }

        try {
            AlgorithmParameters params = AlgorithmParameters.getInstance("EC");
            params.init(new ECGenParameterSpec(name));
            ECParameterSpec ecSpec = params.getParameterSpec(ECParameterSpec.class);

            ECPoint point = new ECPoint(x, y);
            ECPublicKeySpec pubKeySpec = new ECPublicKeySpec(point, ecSpec);

            KeyFactory kf = KeyFactory.getInstance("EC");
            return kf.generatePublic(pubKeySpec);
        } catch (Exception e) {
            throw new NopException(ERR_AUTH_SSO_ACCESS_FAIL, e).param(ARG_ERROR, "EC public key construction failed");
        }
    }

    private PublicKey createRSAPublicKey() {
        BigInteger modulus = new BigInteger(1, StringHelper.decodeBase64Url((String) getOtherClaims().get(RSAPublicJWK.MODULUS)));
        BigInteger publicExponent = new BigInteger(1, StringHelper.decodeBase64Url((String) getOtherClaims().get(RSAPublicJWK.PUBLIC_EXPONENT)));

        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePublic(new RSAPublicKeySpec(modulus, publicExponent));
        } catch (Exception e) {
            throw new NopException(ERR_AUTH_SSO_ACCESS_FAIL, e).param(ARG_ERROR, "RSA public key construction failed");
        }
    }

    public boolean isKeyTypeSupported(String keyType) {
        return (RSAPublicJWK.RSA.equals(keyType) || ECPublicJWK.EC.equals(keyType));
    }
}
