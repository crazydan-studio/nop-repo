/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.orm.eql.compile;

import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.type.StdSqlType;
import io.nop.commons.util.StringHelper;
import io.nop.commons.util.objects.PropPath;
import io.nop.core.CoreConfigs;
import io.nop.dao.DaoConstants;
import io.nop.dao.dialect.IDialect;
import io.nop.dao.dialect.function.ISQLFunction;
import io.nop.orm.eql.OrmEqlConstants;
import io.nop.orm.eql.ast.EqlASTKind;
import io.nop.orm.eql.ast.EqlASTNode;
import io.nop.orm.eql.ast.EqlASTVisitor;
import io.nop.orm.eql.ast.SqlAlias;
import io.nop.orm.eql.ast.SqlAllProjection;
import io.nop.orm.eql.ast.SqlAndExpr;
import io.nop.orm.eql.ast.SqlBinaryExpr;
import io.nop.orm.eql.ast.SqlColumnName;
import io.nop.orm.eql.ast.SqlCteStatement;
import io.nop.orm.eql.ast.SqlDecorator;
import io.nop.orm.eql.ast.SqlDelete;
import io.nop.orm.eql.ast.SqlWindowDecl;
import io.nop.orm.eql.ast.SqlWindowExpr;
import io.nop.orm.eql.ast.SqlWindowFrame;
import io.nop.orm.eql.ast.SqlExpr;
import io.nop.orm.eql.ast.SqlExprProjection;
import io.nop.orm.eql.ast.SqlFrom;
import io.nop.orm.eql.ast.SqlGroupBy;
import io.nop.orm.eql.ast.SqlInValuesExpr;
import io.nop.orm.eql.ast.SqlInsert;
import io.nop.orm.eql.ast.SqlJoinTableSource;
import io.nop.orm.eql.ast.SqlValuesTableSource;
import io.nop.orm.eql.ast.SqlLiteral;
import io.nop.orm.eql.ast.SqlNumberLiteral;
import io.nop.orm.eql.ast.SqlMultiValueExpr;
import io.nop.orm.eql.ast.SqlOrderBy;
import io.nop.orm.eql.ast.SqlParameterMarker;
import io.nop.orm.eql.ast.SqlProgram;
import io.nop.orm.eql.ast.SqlProjection;
import io.nop.orm.eql.ast.SqlQualifiedName;
import io.nop.orm.eql.ast.SqlQuerySelect;
import io.nop.orm.eql.ast.SqlRegularFunction;
import io.nop.orm.eql.ast.SqlSelect;
import io.nop.orm.eql.ast.SqlSelectWithCte;
import io.nop.orm.eql.ast.SqlSingleTableSource;
import io.nop.orm.eql.ast.SqlStringLiteral;
import io.nop.orm.eql.ast.SqlSubqueryTableSource;
import io.nop.orm.eql.ast.SqlTableName;
import io.nop.orm.eql.ast.SqlTableSource;
import io.nop.orm.eql.ast.SqlTumbleTableSource;
import io.nop.orm.eql.ast.SqlUnionSelect;
import io.nop.orm.eql.ast.SqlUpdate;
import io.nop.orm.eql.ast.SqlWhere;
import io.nop.orm.eql.enums.SqlJoinType;
import io.nop.orm.eql.enums.SqlOperator;
import io.nop.orm.eql.compile.CollectionOperatorTransformer;
import io.nop.orm.eql.meta.ISqlExprMeta;
import io.nop.orm.eql.meta.ISqlSelectionMeta;
import io.nop.orm.eql.meta.ISqlTableMeta;
import io.nop.orm.eql.meta.RenamedSqlExprMeta;
import io.nop.orm.eql.meta.SelectResultTableMeta;
import io.nop.orm.eql.meta.SingleColumnExprMeta;
import io.nop.orm.eql.param.ISqlParamBuilder;
import io.nop.orm.eql.param.TenantParamBuilder;
import io.nop.orm.eql.sql.IAliasGenerator;
import io.nop.orm.eql.utils.EqlASTBuilder;
import io.nop.orm.eql.utils.EqlHelper;
import io.nop.orm.model.IColumnModel;
import io.nop.orm.model.IEntityJoinConditionModel;
import io.nop.orm.model.IEntityModel;
import io.nop.orm.model.IEntityPropModel;
import io.nop.orm.model.IEntityRelationModel;
import io.nop.orm.model.IOrmDataType;
import io.nop.orm.model.OrmEntityFilterModel;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_RETURNING_FOR_UPDATE;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_FULL_JOIN;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_RIGHT_JOIN;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_ROW_VALUE_CONSTRUCTOR;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_WINDOW_FRAME_GROUPS;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_WINDOW_FRAME_RANGE;
import static io.nop.orm.eql.OrmEqlConstants.FEATURE_SUPPORT_WINDOW_FRAME_ROWS;
import static io.nop.orm.eql.OrmEqlErrors.ARG_ALIAS;
import static io.nop.orm.eql.OrmEqlErrors.ARG_ARG_COUNT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_ARG_INDEX;
import static io.nop.orm.eql.OrmEqlErrors.ARG_COL_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_DECORATOR;
import static io.nop.orm.eql.OrmEqlErrors.ARG_DIALECT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_ENTITY_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_EXPECTED;
import static io.nop.orm.eql.OrmEqlErrors.ARG_EXPECTED_COUNT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_FEATURE;
import static io.nop.orm.eql.OrmEqlErrors.ARG_WINDOW_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_FIELD_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_FUNC_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_LEFT_SOURCE;
import static io.nop.orm.eql.OrmEqlErrors.ARG_MAX_ARG_COUNT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_MIN_ARG_COUNT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_PROP_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ARG_PROP_PATH;
import static io.nop.orm.eql.OrmEqlErrors.ARG_QUERY_SPACE;
import static io.nop.orm.eql.OrmEqlErrors.ARG_QUERY_SPACE_MAP;
import static io.nop.orm.eql.OrmEqlErrors.ARG_TABLE;
import static io.nop.orm.eql.OrmEqlErrors.ARG_TABLE_SOURCE;
import static io.nop.orm.eql.OrmEqlErrors.ARG_ITEM_COUNT;
import static io.nop.orm.eql.OrmEqlErrors.ARG_MAX_ITEMS;
import static io.nop.orm.eql.OrmEqlErrors.ARG_STMT_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_DECORATOR_ARG_COUNT_IS_NOT_EXPECTED;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_DECORATOR_ARG_TYPE_IS_NOT_EXPECTED;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_IN_LIST_TOO_LARGE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_WINDOW_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_FIELD_NOT_IN_SUBQUERY;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_FUNC_ONLY_ALLOW_IN_WINDOW_EXPR;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_FUNC_TOO_FEW_ARGS;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_FUNC_TOO_MANY_ARGS;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_JOIN_NO_CONDITION;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_JOIN_PROP_PATH_IS_DUPLICATED;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_NOT_ALLOW_MULTIPLE_QUERY_SPACE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_NOT_SUPPORT_MULTI_JOIN_ON_ALIAS;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_ONLY_SUPPORT_SINGLE_TABLE_SOURCE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_OWNER_NOT_REF_TO_ENTITY;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_PROP_PATH_JOIN_NOT_ALLOW_CONDITION;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_TABLE_SOURCE_NOT_RESOLVED;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_PROP_PATH_NOT_VALID_TO_ONE_REFERENCE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_QUERY_NO_FROM_CLAUSE;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_SELECT_NO_PROJECTIONS;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_TABLE_SOURCE_NOT_RESOLVED;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_ALIAS;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_COLUMN_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_ENTITY_NAME;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_FUNCTION;
import static io.nop.orm.eql.OrmEqlErrors.ERR_EQL_UNKNOWN_QUERY_SPACE;

public class EqlTransformVisitor extends EqlASTVisitor {

    private final ISqlCompileContext context;
    // WI2: 当前查询链上已声明的命名窗口名（每个 SqlQuerySelect 入栈一层）
    private final Deque<Set<String>> windowNameScopes = new ArrayDeque<>();

    private IDialect dialect;

    // WI10b: 语句名（IN 列表超长错误定位用），由 EqlCompiler 传入；可为 null
    private final String stmtName;

    // 预先收集所有明确指定的alias，自动生成的alias需要避免和它们冲突
    private final Set<String> assignedAliases = new HashSet<>();

    private final IAliasGenerator aliasGenerator;

    /**
     * 一条eql语句仅允许在一个querySpace中执行，如果分析发现存在多个querySpace，则抛出异常
     */
    private final Map<String, String> querySpaceToEntityNames = new HashMap<>();
    private String querySpace;

    private SqlTableScope currentScope;

    private List<ISqlParamBuilder> params;

    private final Set<String> readEntityModels = new LinkedHashSet<>();
    private String writeEntityModel;
    private boolean useTenantModel;

    /**
     * 判断是否正在处理order by子句。如果仅在order by语句中通过a.b.c这种属性表达式引用关联表上的字段，且关联字段允许为空， 则使用left join来实现隐式关联。
     */
    private boolean inOrderBy;
    private boolean inGroupBy;
    private CollectionOperatorTransformer collectionOperatorTransformer;

    public EqlTransformVisitor(ISqlCompileContext context) {
        this(context, null);
    }

    /**
     * WI10b：stmtName 仅用于 IN 列表超长错误的定位 param（`EqlCompiler#compile` 传入语句名）。
     */
    public EqlTransformVisitor(ISqlCompileContext context, String stmtName) {
        this.context = context;
        this.stmtName = stmtName;
        this.aliasGenerator = context.getAliasGenerator();
        this.collectionOperatorTransformer = new CollectionOperatorTransformer(aliasGenerator);
    }

    public List<String> getReadEntityModels() {
        return new ArrayList<>(readEntityModels);
    }

    public String getWriteEntityModel() {
        return writeEntityModel;
    }

    public IDialect getDialect() {
        return dialect;
    }

    public boolean isUseTenantModel() {
        return useTenantModel;
    }

    public void transform(SqlProgram program) {
        collectNames(program);
        visitSqlProgram(program);

        SqlParamTypeResolver resolver = new SqlParamTypeResolver(dialect);
        resolver.visit(program);
        this.params = resolver.getParams();
    }

    public List<ISqlParamBuilder> getParams() {
        return params;
    }

    public String getQuerySpace() {
        return querySpace;
    }

    private void collectNames(SqlProgram program) {
        new EqlASTVisitor() {
            int paramIndex = 0;

            @Override
            public void visitSqlAlias(SqlAlias alias) {
                assignedAliases.add(alias.getAlias());
            }

            @Override
            public void visitSqlParameterMarker(SqlParameterMarker param) {
                // 对参数进行编号
                param.setParamIndex(paramIndex++);
            }

        }.visit(program);
    }

    @Override
    public void visitSqlSelectWithCte(SqlSelectWithCte node) {
        if (node.getWithCtes() == null || node.getWithCtes().isEmpty()) {
            visit(node.getSelect());
        } else {
            SqlTableScope scope = new SqlTableScope(node, currentScope);
            currentScope = scope;
            for (SqlCteStatement cteStm : node.getWithCtes()) {
                visit(cteStm.getStatement());
            }
            visit(node.getSelect());
            currentScope = scope.getParent();
        }
    }

    @Override
    public void visitSqlQuerySelect(SqlQuerySelect node) {

        // 先分析from子句，确保所有的表都有alias
        SqlFrom from = node.getFrom();
        if (from != null) {
            visitSqlFrom(from);

            addTableFilter(node);
        } else {
            if (node.getWhere() != null || node.getHaving() != null || node.getOrderBy() != null
                    || node.getGroupBy() != null || node.getLimit() != null
                    || node.getWindowClause() != null)
                throw new NopException(ERR_EQL_QUERY_NO_FROM_CLAUSE).source(node);

            // 如果没有指定from，则需要根据decorator来确定querySpace
            String querySpace = findQuerySpaceWhenNoFrom(node);
            if (this.querySpace == null) {
                // 仅在首次确定querySpace时赋值。嵌套的无from子查询（如投影中的select 1）不重置外层状态，
                // 否则外层实体的querySpace会被覆盖，导致SQL被路由到错误的数据源
                this.querySpace = querySpace;
                this.dialect = context.getDialectForQuerySpace(querySpace);
            } else if (!querySpace.equals(this.querySpace)
                    && node.getDecorator(OrmEqlConstants.DECORATOR_QUERY_SPACE) != null) {
                // 嵌套子查询通过decorator显式指定了不同的querySpace，与外层语句冲突
                throw new NopException(ERR_EQL_NOT_ALLOW_MULTIPLE_QUERY_SPACE).source(node)
                        .param(ARG_QUERY_SPACE, querySpace).param(ARG_QUERY_SPACE_MAP, querySpaceToEntityNames);
            }
        }

        SqlTableScope scope = new SqlTableScope(node, currentScope);
        node.setTableScope(scope);
        if (from != null) {
            addAliasToScope(scope, from);
        }
        currentScope = scope;

        // WI2: 收集本查询声明的命名窗口名，供 over <name> 引用校验
        Set<String> windowNames = Collections.emptySet();
        if (node.getWindowClause() != null && node.getWindowClause().getItems() != null) {
            windowNames = new HashSet<>();
            for (SqlWindowDecl decl : node.getWindowClause().getItems()) {
                windowNames.add(decl.getName());
            }
        }
        windowNameScopes.push(windowNames);

        // 分析所有的projection，并且确保每一列都有一个别名
        if (node.getProjections().isEmpty()) {
            // select *
            if (!node.getSelectAll())
                throw new NopException(ERR_EQL_SELECT_NO_PROJECTIONS).source(node);

            List<SqlProjection> items = getAllProjections(node);
            node.setProjections(items);
        } else {
            visitChildren(node.getProjections());
        }

        resolveSelectFields(node);

        if (node.getWhere() != null) {
            collectionOperatorTransformer.transform(node.getWhere());
        }
        
        if (node.getWhere() != null)
            visitSqlWhere(node.getWhere());


        if (node.getGroupBy() != null) {
            visitSqlGroupBy(node.getGroupBy());
        }

        if (node.getHaving() != null) {
            visitSqlHaving(node.getHaving());
        }

        // WI2: 命名窗口声明位于 having 之后 order by 之前；逐 decl 解析列并校验 frame 能力位
        if (node.getWindowClause() != null) {
            for (SqlWindowDecl decl : node.getWindowClause().getItems()) {
                if (decl.getFrame() != null) {
                    checkWindowFrameFeature(decl.getFrame());
                }
                visitChild(decl.getPartitionBy());
                visitChild(decl.getOrderBy());
                visitChild(decl.getFrame());
            }
        }

        if (node.getOrderBy() != null) {
            visitSqlOrderBy(node.getOrderBy());
        }

        if (node.getLimit() != null) {
            visitSqlLimit(node.getLimit());
        }

        windowNameScopes.pop();
        currentScope = scope.getParent();
    }

    private void checkWindowFrameFeature(SqlWindowFrame frame) {
        switch (frame.getUnit()) {
            case ROWS:
                if (!dialect.isSupportWindowFrameRows())
                    throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(frame)
                            .param(ARG_DIALECT, dialect.getName())
                            .param(ARG_FEATURE, FEATURE_SUPPORT_WINDOW_FRAME_ROWS);
                break;
            case RANGE:
                if (!dialect.isSupportWindowFrameRange())
                    throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(frame)
                            .param(ARG_DIALECT, dialect.getName())
                            .param(ARG_FEATURE, FEATURE_SUPPORT_WINDOW_FRAME_RANGE);
                break;
            case GROUPS:
                if (!dialect.isSupportWindowFrameGroups())
                    throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(frame)
                            .param(ARG_DIALECT, dialect.getName())
                            .param(ARG_FEATURE, FEATURE_SUPPORT_WINDOW_FRAME_GROUPS);
                break;
        }
    }

    // WI7b（plan 37，roadmap EC ①；ⓒ-A 裁定文档 §3.2）：GROUP BY 位置 grouping 操作符
    // ROLLUP/CUBE 的方言能力门。supportRollup/supportCube 分立两标志——mysql 函数式 ROLLUP
    //（8.4.3+，超 G-1 基线）与 CUBE（永无）successor 触发条件不同。先门后遍历（先例同上）；
    // 错误码复用族不新起。非 GROUP BY 位置的 rollup(x)/cube(x) 解析为 SqlRegularFunction，
    // 函数表永不注册 → ERR_EQL_UNKNOWN_FUNCTION（放置排他 = "GROUP BY 之外无注册"）。
    @Override
    public void visitSqlGroupingOp(io.nop.orm.eql.ast.SqlGroupingOp node) {
        boolean rollup = node.getType() == io.nop.orm.eql.enums.SqlGroupingOpType.ROLLUP;
        boolean support = rollup ? dialect.isSupportRollup() : dialect.isSupportCube();
        if (!support)
            throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(node)
                    .param(ARG_DIALECT, dialect.getName())
                    .param(ARG_FEATURE, rollup ? "rollup" : "cube");
        visitChildren(node.getArgs());
    }

    // WI2: over <name> 引用必须命中当前查询声明的窗口名；inline frame 按单位过能力门。
    // 先门后遍历：能力门/引用校验先于子节点解析（错误优先级高于子表达式的 unknown-function 等）
    @Override
    public void visitSqlWindowExpr(SqlWindowExpr node) {
        if (node.getWindowName() != null) {
            Set<String> names = windowNameScopes.isEmpty() ? Collections.emptySet() : windowNameScopes.peek();
            if (!names.contains(node.getWindowName()))
                throw new NopException(ERR_EQL_UNKNOWN_WINDOW_NAME).source(node)
                        .param(ARG_WINDOW_NAME, node.getWindowName());
        } else if (node.getFrame() != null) {
            checkWindowFrameFeature(node.getFrame());
        }
        super.visitSqlWindowExpr(node);
    }

    void addTableFilter(SqlQuerySelect node) {
        addEntityFilter(node);
    }

    void collectDefaultEntityFilter(SqlSingleTableSource table, Consumer<SqlExpr> consumer) {
        ISqlTableMeta tableMeta = (ISqlTableMeta) table.getResolvedTableMeta();

        if (tableMeta.isUseLogicalDelete() && !context.isDisableLogicalDelete()) {
            consumer.accept(buildLogicalDeleteFilter(table, tableMeta));
        }

        IEntityModel entityModel = tableMeta.getEntityModel();
        if (entityModel.isUseTenant()) {
            SqlBinaryExpr expr = newTenantExpr(table, tableMeta);
            consumer.accept(expr);
        }

        if (tableMeta.hasFilter()) {
            for (OrmEntityFilterModel filter : tableMeta.getFilters()) {
                SqlBinaryExpr expr = newBinaryExpr(table, tableMeta, filter.getName(), filter.getValue());
                consumer.accept(expr);
            }
        }
    }

    /**
     * 为 update/delete 语句的 where 子句补齐缺省租户过滤条件。
     *
     * select 语句的缺省过滤由 {@link #addTableFilter} 注入，但 update/delete 走
     * {@link #visitSqlUpdate} 与 {@link #visitSqlDelete}，此前只设置 useTenantModel
     * 这个「查询计划缓存标记」，并不生成 SQL 条件，导致
     * `delete from X where id = ?` / `update X set ... where ...` 完全绕过租户隔离
     * （GenSqlHelper 只覆盖按主键与 example 的入口，EQL 写语句不经由它）。
     *
     * 注入时机与 select 对齐：都在访问 where 之前追加，使新条件与用户书写的条件
     * 一起经过后续的 SqlParamTypeResolver 参数解析。
     *
     * 只补租户条件，不补逻辑删除条件。给 update/delete 注入逻辑删除条件会改变
     * 「硬删除一条已逻辑删除的行」的既有语义，属独立决策，不在本次修复范围内。
     *
     * @param where        语句当前的 where，可能为 null
     * @param source       目标实体的表源，用于生成带别名的列名
     * @param tableMeta    目标实体的元数据
     * @param whereSetter  where 为 null 时用于回填新建的 SqlWhere
     */
    void addWriteTenantFilter(SqlWhere where, SqlSingleTableSource source, ISqlTableMeta tableMeta,
            Consumer<SqlWhere> whereSetter) {
        if (!tableMeta.getEntityModel().isUseTenant())
            return;

        SqlWhere target = where;
        if (target == null) {
            target = new SqlWhere();
            whereSetter.accept(target);
        }
        target.appendFilter(newTenantExpr(source, tableMeta));
    }

    SqlBinaryExpr newTenantExpr(SqlSingleTableSource table, ISqlTableMeta tableMeta) {
        IEntityModel entityModel = tableMeta.getEntityModel();
        SqlBinaryExpr expr = new SqlBinaryExpr();
        SqlColumnName colName = newColName(table, tableMeta, entityModel.getTenantColumn().getName());

        expr.setLeft(colName);
        expr.setOperator(SqlOperator.EQ);
        SqlParameterMarker param = new SqlParameterMarker();
        param.setSqlParamBuilder(TenantParamBuilder.INSTANCE);
        expr.setRight(param);
        return expr;
    }

    SqlBinaryExpr newBinaryExpr(SqlSingleTableSource table, ISqlTableMeta tableMeta, String propName, Object value) {
        SqlBinaryExpr expr = new SqlBinaryExpr();
        SqlColumnName colName = newColName(table, tableMeta, propName);
        expr.setLeft(colName);
        expr.setOperator(SqlOperator.EQ);

        expr.setRight(EqlASTBuilder.literal(value));
        return expr;
    }

    SqlColumnName newColName(SqlSingleTableSource table, ISqlTableMeta tableMeta, String propName) {
        SqlColumnName col = EqlASTBuilder.colName(table.getAliasName(), propName);
        col.setTableSource(table);

        col.setResolvedExprMeta(tableMeta.getFieldExprMeta(propName, context.isAllowUnderscoreName()));
        return col;
    }

    SqlBinaryExpr buildLogicalDeleteFilter(SqlSingleTableSource table, ISqlTableMeta tableMeta) {
        Object value = tableMeta.getDeleteFlagValue(false, dialect);
        return newBinaryExpr(table, tableMeta, tableMeta.getDeleteFlagPropName(), value);
    }

    void addEntityFilter(SqlQuerySelect node) {
        SqlFrom from = node.getFrom();

        for (SqlSingleTableSource table : from.getEntitySources()) {
            if (!table.isFilterAlreadyAdded()) {
                table.setFilterAlreadyAdded(true);
                collectDefaultEntityFilter(table, filter -> node.makeWhere().appendFilter(filter));
            } else if (table.isMainSource()) {
                // 对于left join和right join，主表的缺省过滤条件需要写在where段
                collectDefaultEntityFilter(table, filter -> node.makeWhere().appendFilter(filter));
            }
        }
    }

    String findQuerySpaceWhenNoFrom(SqlQuerySelect node) {
        SqlDecorator decorator = node.getDecorator(OrmEqlConstants.DECORATOR_QUERY_SPACE);
        if (decorator == null)
            return DaoConstants.DEFAULT_QUERY_SPACE;
        if (decorator.getArgs() == null || decorator.getArgs().size() != 1)
            throw new NopException(ERR_EQL_DECORATOR_ARG_COUNT_IS_NOT_EXPECTED).source(decorator)
                    .param(ARG_DECORATOR, decorator.getName()).param(ARG_EXPECTED_COUNT, 1);
        SqlLiteral literal = decorator.getArgs().get(0);
        if (!(literal instanceof SqlStringLiteral))
            throw new NopException(ERR_EQL_DECORATOR_ARG_TYPE_IS_NOT_EXPECTED).source(decorator)
                    .param(ARG_DECORATOR, decorator.getName()).param(ARG_ARG_INDEX, 0).param(ARG_EXPECTED, "String");
        return ((SqlStringLiteral) literal).getValue();
    }

    /**
     * 向scope中注册数据库表的别名
     */
    void addAliasToScope(SqlTableScope scope, SqlFrom node) {
        for (SqlTableSource table : node.getTableSources()) {
            addAliasToScope(scope, table);
        }
    }

    void addAliasToScope(SqlTableScope scope, SqlTableSource table) {
        if (table instanceof SqlSingleTableSource) {
            SqlSingleTableSource source = (SqlSingleTableSource) table;
            scope.addTable(source.getScopeName(), source);
        } else if (table instanceof SqlSubqueryTableSource) {
            // lateral 表示可以看到同级的表
            SqlSubqueryTableSource source = (SqlSubqueryTableSource) table;
            scope.addTable(source.getAlias().getAlias(), source);
        } else if (table instanceof SqlTumbleTableSource) {
            // WI17: TUMBLE 伪表函数是 stream-only 表源（D4/T1 裁定），ORM 编译通道
            // 不支持——显式 fail-fast 而非静默跳过作用域注册
            throw new NopException(ERR_EQL_TABLE_SOURCE_NOT_RESOLVED).loc(table.getLocation());
        } else if (table instanceof SqlValuesTableSource) {
            // WI12 交付⑤：VALUES 表源按别名注册作用域（SqlSubqueryTableSource 分支同形；
            // 文法层 alias 必填 = 注册锚点，裁定 §4）
            SqlValuesTableSource source = (SqlValuesTableSource) table;
            scope.addTable(source.getAlias().getAlias(), source);
        } else if (table instanceof SqlJoinTableSource) {
            SqlJoinTableSource source = (SqlJoinTableSource) table;
            addAliasToScope(scope, source.getLeft());
            addAliasToScope(scope, source.getRight());
        }
    }

    @Override
    public void visitSqlFrom(SqlFrom node) {
        SqlTableScope tableScope = new SqlTableScope(node, currentScope);
        node.setTableScope(tableScope);

        for (SqlTableSource table : node.getTableSources()) {
            markMainSource(table);
        }

        for (SqlTableSource table : node.getTableSources()) {
            visitTableSource(tableScope, table);
        }
    }

    void markMainSource(SqlTableSource table) {
        if (table instanceof SqlSingleTableSource) {
            ((SqlSingleTableSource) table).setMainSource(true);
        } else if (table instanceof SqlJoinTableSource) {
            SqlJoinTableSource join = (SqlJoinTableSource) table;
            if (join.getJoinType() == SqlJoinType.LEFT_JOIN) {
                markMainSource(join.getLeft());
            } else if (join.getJoinType() == SqlJoinType.RIGHT_JOIN) {
                markMainSource(join.getRight());
            } else if (join.getJoinType() == SqlJoinType.FULL_JOIN) {
                //
                markMainSource(join.getLeft());
                markMainSource(join.getRight());
            }
        }
    }

    void visitTableSource(SqlTableScope tableScope, SqlTableSource table) {
        if (table instanceof SqlSingleTableSource) {
            SqlSingleTableSource source = (SqlSingleTableSource) table;
            SqlQuerySelect select = getQuerySelect(source);

            // Try to treat collection-valued property paths (e.g., from o.simsClasses c)
            // as real entity table sources in correlated subqueries.
            SqlSingleTableSource transformed = null;
            if (select != null) {
                // 使用当前 scope 作为 ownerScope，确保能解析到本层的别名（例如 o）
                SqlTableScope ownerScope = tableScope;
                transformed = CollectionTableSourceHelper.transformCollectionTableSource(this, ownerScope, select,
                        source);
            }

            if (transformed != null) {
                // The helper already resolved the underlying entity and join condition;
                // do NOT call resolveEntity again to avoid regenerating aliases.
                tableScope.addTable(transformed.getScopeName(), transformed);
            } else {
                resolveEntity(source);
                tableScope.addTable(source.getScopeName(), source);
            }
        } else if (table instanceof SqlSubqueryTableSource) {
            // lateral 表示可以看到同级的表
            SqlSubqueryTableSource source = (SqlSubqueryTableSource) table;
            source.setAlias(makeTableAlias(source.getAlias()));

            if (source.getLateral()) {
                SqlTableScope oldScope = currentScope;
                currentScope = tableScope;
                visitSqlSubqueryTableSource(source);
                currentScope = oldScope;
            } else {
                visitSqlSubqueryTableSource(source);
            }
            tableScope.addTable(source.getAliasName(), source);
        } else if (table instanceof SqlValuesTableSource) {
            // WI12 交付⑤（plan 38，裁定 §4.1）：VALUES 表源的 querySpace 实体无关回落——
            // 实体现解析路径（resolveEntity → addResolvedEntity）对 VALUES 源不触发，
            // FROM 只有 VALUES 源时 querySpace/dialect 会保持 null（下游 NPE 面）。
            // 首个 VALUES 源遍历点回落（decorator 显式指定优先，否则 default query space，
            // findQuerySpaceWhenNoFrom 同口径）；实体源解析会无条件覆盖（addResolvedEntity），
            // 混合源（实体+VALUES）行为 = 实体 querySpace 胜出，与既有单 querySpace 约束一致。
            if (this.querySpace == null) {
                String qs = findQuerySpaceWhenNoFrom(getQuerySelect(table));
                this.querySpace = qs;
                this.dialect = context.getDialectForQuerySpace(qs);
            }
            SqlValuesTableSource source = (SqlValuesTableSource) table;
            visitChildren(source.getRows());
            source.setResolvedTableMeta(buildValuesTableMeta(source));
            tableScope.addTable(source.getAliasName(), source);
        } else if (table instanceof SqlJoinTableSource) {
            SqlJoinTableSource source = (SqlJoinTableSource) table;
            boolean hasCondition = source.getCondition() != null;
            visitJoinLeft(tableScope, source);
            // WI2 BUG-6: 门在左源解析后、右源遍历前触发。方言实例要到首个实体解析
            // （addResolvedEntity → context.getDialectForQuerySpace）才确定，头部触发
            // 时 dialect 尚为 null；左源（实体/嵌套 join/子查询）遍历完成后方言必然
            // 就绪且与后续生成用同一实例。仍先于 visitJoinRight 的条件校验
            // （ERR_EQL_JOIN_NO_CONDITION）与右侧任何解析错误；每个 join 节点恰过门一次
            // （嵌套 join 经 visitJoinLeft 递归回本分支）。
            checkJoinTypeFeature(source);
            visitJoinRight(tableScope, source);

            if (hasCondition) {
                SqlTableScope oldScope = currentScope;
                currentScope = tableScope;
                visitJoinCondition(source);
                currentScope = oldScope;
            }
            addTableFilterForJoin(source);
        }
    }

    /**
     * WI2 BUG-6: `full [outer] join` 编译期能力门（裁定=独立私有方法，挂
     * {@code visitTableSource} 的 SqlJoinTableSource 转换遍历点，仿
     * {@link #checkWindowFrameFeature(SqlWindowFrame)} 的调用形态）。
     * 不支持时响亮报错，绝不静默改写或丢弃 join 类型。
     */
    private void checkJoinTypeFeature(SqlJoinTableSource source) {
        if (source.getJoinType() == SqlJoinType.FULL_JOIN && !dialect.isSupportFullJoin())
            throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(source)
                    .param(ARG_DIALECT, dialect.getName())
                    .param(ARG_FEATURE, FEATURE_SUPPORT_FULL_JOIN);
        // WI10b（Phase 0 §2.5 终裁）：right join 与 full join 同门同层，不支持时响亮报错
        if (source.getJoinType() == SqlJoinType.RIGHT_JOIN && !dialect.isSupportRightJoin())
            throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(source)
                    .param(ARG_DIALECT, dialect.getName())
                    .param(ARG_FEATURE, FEATURE_SUPPORT_RIGHT_JOIN);
    }

    /**
     * WI10b（Phase 0 §2.6 终裁）：行值构造器 `(a,b)` 能力门。SqlMultiValueExpr 三形态
     * 文法可达且无条件打印——`(a,b)` 独立值表达式、`(a,b) = (1,2)` 真行值比较、
     * `(a,b) IN ((1,2))`（IN 列表元素本身是行组）——门在 transform 遍历点统一拦截，
     * 覆盖三形态全集；不在打印器设门（回显忠实转储零变化）。
     *
     * <p>与 IN 列表长度门正交：SqlMultiValueExpr 不是 SqlInValuesExpr，本门不计数、
     * IN 门不管行组语义。全部既有方言 XML 继承 default 的 true ⇒ 真实方言零 BC；
     * 负向载体 = 合成方言 false（无任何真实方言应配 false 的一手证据）。
     */
    @Override
    public void visitSqlMultiValueExpr(SqlMultiValueExpr node) {
        if (dialect != null && !dialect.isSupportRowValueConstructor())
            throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE).source(node)
                    .param(ARG_DIALECT, dialect.getName())
                    .param(ARG_FEATURE, FEATURE_SUPPORT_ROW_VALUE_CONSTRUCTOR);
        super.visitSqlMultiValueExpr(node);
    }

    /**
     * WI10b（WI10a 设计定稿 2026-10-03）：IN 列表长度门禁。统一阈值 1000（唯一硬依据
     * Oracle ORA-01795），经 {@link CoreConfigs#CFG_CORE_SQL_IN_LIST_MAX_SIZE} 可调高、
     * 无关闭取值；门禁方言无关、超限显式报错（{@link OrmEqlErrors#ERR_EQL_IN_LIST_TOO_LARGE}）、
     * 不做任何改写。`NOT IN` 与 `IN` 同为 SqlInValuesExpr 节点，本门天然覆盖两者。
     *
     * <p>挂载点裁定（`ai-dev/design/eql-cross-db-compat/2026-10-04-wi10b-phase0-adjudications.md`
     * §4.1）：检查在编译管线（transform 遍历点，与 {@link #checkJoinTypeFeature(SqlJoinTableSource)}
     * / returning 门同层），不在打印器——回显路径 `EqlASTNode#toSqlString()` 保持忠实转储零变化。
     * 缓存路径（useCache=true）下检查随首次编译执行一次，非缓存路径逐次确定性重查。
     * 字面量与 marker 统一计数（对 values.size() 计数，不逐元素分型）。
     */
    @Override
    public void visitSqlInValuesExpr(SqlInValuesExpr node) {
        int max = CoreConfigs.CFG_CORE_SQL_IN_LIST_MAX_SIZE.get();
        int count = node.getValues() == null ? 0 : node.getValues().size();
        if (count > max) {
            throw new NopException(ERR_EQL_IN_LIST_TOO_LARGE).source(node)
                    .param(ARG_ITEM_COUNT, count)
                    .param(ARG_MAX_ITEMS, max)
                    .param(ARG_STMT_NAME, stmtName)
                    .param(ARG_DIALECT, dialect == null ? null : dialect.getName());
        }
        super.visitSqlInValuesExpr(node);
    }

    void addTableFilterForJoin(SqlJoinTableSource source) {
        if (source.getLeft().isEntityTableSource()) {
            addTableFilterForJoinTable((SqlSingleTableSource) source.getLeft(), source);
        }

        if (source.getRight().isEntityTableSource()) {
            addTableFilterForJoinTable((SqlSingleTableSource) source.getRight(), source);
        }
    }

    void addTableFilterForJoinTable(SqlSingleTableSource table, SqlJoinTableSource join) {
        if (table.isFilterAlreadyAdded())
            return;

        // Plan 2307 V2b: CROSS JOIN 不接受 ON 子句，把缺省过滤条件（逻辑删除/租户/固定过滤器）
        // 塞进 join.condition 会产出 `cross join T on (...)` 这种非法 SQL。
        //
        // 此处必须**在置 filterAlreadyAdded 之前**返回：若照常置位，SELECT 级的
        // addEntityFilter(:486) 会认为该表源的缺省过滤「已处理」而整体跳过，
        // 结果是 WHERE 子句里只剩 `1=1` 与空标记、租户条件彻底丢失（多租户数据泄漏）。
        // 保持未置位即可让 addEntityFilter 把两侧条件收进 WHERE——语义等价
        // （(A×B) 再过滤 == 过滤后的 A×B），且租户隔离不泄漏。
        if (join.getJoinType() == SqlJoinType.CROSS_JOIN)
            return;

        table.setFilterAlreadyAdded(true);

        collectDefaultEntityFilter(table, join::addConditionFilter);
    }

    void visitJoinLeft(SqlTableScope tableScope, SqlJoinTableSource source) {
        SqlTableSource left = source.getLeft();
        if (left instanceof SqlSingleTableSource) {
            SqlSingleTableSource table = (SqlSingleTableSource) left;
            table.setAlias(makeTableAlias(table.getAlias()));

            tableScope.addTable(table.getAliasName(), table);

            SqlTableName tableName = table.getTableName();
            String fullName = tableName.getFullName();
            ISqlTableMeta entityMeta = context.resolveEntityTableMeta(fullName);
            if (entityMeta != null) {
                addResolvedEntity(source.getLocation(), entityMeta);
                // 对应全类名或者简单类名
                tableName.setResolvedTableMeta(entityMeta);
            } else {
                // 如果不是实体，检查是否是with xx as()语句所定义的内嵌视图
                SqlQualifiedName owner = tableName.getOwner();
                if (owner == null) {
                    SqlSelect cte = getCte(source, tableName.getName());
                    if (cte != null) {
                        resolveSelectFields(cte);
                        tableName.setResolvedTableMeta(cte.getResolvedTableMeta());
                        tableName.setResolvedCte(cte);

                        SqlSubqueryTableSource querySource = newCteSource(table, cte);
                        if (!dialect.isSupportWithAsClause()) {
                            source.setLeft(querySource);
                        } else {
                            addAliasToScope(currentScope, querySource);
                        }
                        return;
                    }
                }
                throw new NopException(ERR_EQL_UNKNOWN_ENTITY_NAME).source(source).param(ARG_ENTITY_NAME, fullName);
            }
        } else {
            visitTableSource(tableScope, left);
        }
    }

    SqlSubqueryTableSource newCteSource(SqlSingleTableSource table, SqlSelect cte) {
        SqlSubqueryTableSource querySource = new SqlSubqueryTableSource();
        querySource.setLocation(table.getLocation());
        querySource.setWithClauseSelect(cte);
        querySource.setQuery(cte.deepClone());
        SqlAlias name = new SqlAlias();
        name.setAlias(table.getTableName().getName());
        querySource.setAlias(name);
        return querySource;
    }

    void resolveSelectFields(SqlSelect select) {
        if (select.getResolvedTableMeta() != null)
            return;

        ExprTypeResolver typeResolver = new ExprTypeResolver(dialect);
        Map<String, ISqlExprMeta> fields = new HashMap<>();
        for (SqlProjection projection : select.getProjections()) {
            SqlExprProjection proj = (SqlExprProjection) projection;
            String fieldName = EqlHelper.getFieldName(proj);
            typeResolver.resolveExprMeta(proj.getExpr());
            fields.put(fieldName, proj.getExpr().getResolvedExprMeta());
        }
        select.setResolvedTableMeta(new SelectResultTableMeta(fields));
    }

    /**
     * WI12 交付⑤（plan 38，裁定 §4.3）：VALUES 表源列元数据——列名 = 显式别名列清单
     * 优先，缺省 C1..Cn（H2 惯例）；类型 = 首行表达式经 ExprTypeResolver best-effort
     * 解析（字面量/列引用得精确类型；无法确定时由 resolver 兜底）。ragged rows 已在
     * 构建期响亮（ERR_EQL_VALUES_ROW_ARITY_MISMATCH），此处行元数恒一致。
     */
    ISqlSelectionMeta buildValuesTableMeta(SqlValuesTableSource source) {
        ExprTypeResolver typeResolver = new ExprTypeResolver(dialect);
        List<SqlMultiValueExpr> rows = source.getRows();
        int arity = rows.get(0).getValues().size();
        List<String> names = source.getColumns();
        Map<String, ISqlExprMeta> fields = new LinkedHashMap<>();
        for (int i = 0; i < arity; i++) {
            String name = (names != null && i < names.size()) ? names.get(i) : ("C" + (i + 1));
            SqlExpr expr = rows.get(0).getValues().get(i);
            typeResolver.resolveExprMeta(expr);
            fields.put(name, expr.getResolvedExprMeta());
        }
        return new SelectResultTableMeta(fields);
    }

    // 将 UserInfo o left join o.dept 这种形式变换为 UserInfo o left join Department d on o.xx=d.xx
    void visitJoinRight(SqlTableScope tableScope, SqlJoinTableSource source) {
        SqlTableSource right = source.getRight();
        if (right instanceof SqlSingleTableSource) {
            SqlSingleTableSource table = (SqlSingleTableSource) right;
            table.setAlias(makeTableAlias(table.getAlias()));

            tableScope.addTable(table.getAliasName(), table);

            SqlTableName tableName = table.getTableName();
            String fullName = tableName.getFullName();
            ISqlTableMeta entityMeta = context.resolveEntityTableMeta(fullName);
            if (entityMeta != null) {
                // 对应全类名或者简单类名
                tableName.setResolvedTableMeta(entityMeta);
                // Plan 2307 V2b: CROSS JOIN 按定义就是笛卡尔积，不带连接条件。
                // 该检查原本拦截「实体 join 漏写 on」，对 CROSS JOIN 是误报——
                // 若不放行，用户显式写的 CROSS JOIN 会在此被 ERR_EQL_JOIN_NO_CONDITION 拒绝，
                // 使 V2 的修复无法端到端生效（能解析、不能编译）。
                if (source.getCondition() == null && source.getJoinType() != SqlJoinType.CROSS_JOIN) {
                    throw new NopException(ERR_EQL_JOIN_NO_CONDITION).source(source).param(ARG_ENTITY_NAME, fullName);
                }
            } else {
                // 不是实体对象，需要检查是否是属性表达式
                SqlQualifiedName owner = tableName.getOwner();
                if (owner == null) {
                    // 如果没有owner，则检查是否是with xx as 语句引入的内嵌视图
                    SqlSelect cte = getCte(source, tableName.getName());
                    if (cte != null) {
                        tableName.setResolvedCte(cte);
                        tableName.setResolvedTableMeta(cte.getResolvedTableMeta());
                        if (tableName.getResolvedTableMeta() == null) {
                            if (cte instanceof SqlUnionSelect) {
                                tableName.setResolvedTableMeta(((SqlUnionSelect) cte).getLeft().getResolvedTableMeta());
                            }
                        }

                        SqlSubqueryTableSource querySource = newCteSource(table, cte);
                        if (!dialect.isSupportWithAsClause()) {
                            source.setRight(querySource);
                        } else {
                            addAliasToScope(currentScope, querySource);
                        }
                        return;
                    }
                    throw new NopException(ERR_EQL_UNKNOWN_ENTITY_NAME).source(source).param(ARG_ENTITY_NAME, fullName);
                }

                if (source.getCondition() != null) {
                    throw new NopException(ERR_EQL_PROP_PATH_JOIN_NOT_ALLOW_CONDITION).source(source)
                            .param(ARG_PROP_PATH, fullName).param(ARG_ENTITY_NAME, fullName);
                }

                PropPath propPath = table.getTableName().toPropPath();

                // 将属性关联表达式转换为表关联
                // 例如将left join o.dept d 替换为 left join Department d on o.deptId = d.id
                SqlPropJoin join = resolvePropPath(tableScope, right.getLocation(), propPath);
                if (join.getRight().getASTParent() != null) {
                    throw new NopException(ERR_EQL_JOIN_PROP_PATH_IS_DUPLICATED).source(source).param(ARG_PROP_PATH,
                            propPath.toString());
                }
                join.setExplicit(true);
                source.setRight(join.getRight());
                source.setCondition(join.getCondition());
            }
        } else {
            visitTableSource(tableScope, source.getRight());
        }
    }

    void addResolvedEntity(SourceLocation loc, ISqlTableMeta tableMeta) {
        readEntityModels.add(tableMeta.getEntityName());

        if (tableMeta.getEntityModel().isTenantModel())
            this.useTenantModel = true;

        String querySpace = tableMeta.getQuerySpace();
        querySpaceToEntityNames.put(querySpace, tableMeta.getEntityName());
        if (querySpaceToEntityNames.size() > 1)
            throw new NopException(ERR_EQL_NOT_ALLOW_MULTIPLE_QUERY_SPACE).loc(loc)
                    .param(ARG_ENTITY_NAME, tableMeta.getEntityName()).param(ARG_QUERY_SPACE_MAP, querySpaceToEntityNames);

        this.querySpace = querySpace;

        if (dialect == null) {
            dialect = context.getDialectForQuerySpace(querySpace);

            if (dialect == null)
                throw new NopException(ERR_EQL_UNKNOWN_QUERY_SPACE).loc(loc).param(ARG_QUERY_SPACE, querySpace)
                        .param(ARG_ENTITY_NAME, tableMeta.getEntityName());
        }
    }

    SqlPropJoin resolvePropPath(SqlTableScope scope, SourceLocation loc, PropPath propPath) {
        // 例如 left join o.dept 未找到o对应的数据源定义
        SqlTableSource left = scope.getTableByAlias(propPath.getName());
        if (left == null) {
            throw new NopException(ERR_EQL_UNKNOWN_ALIAS).loc(loc).param(ARG_ALIAS, propPath.getName())
                    .param(ARG_PROP_PATH, propPath.toString());
        }

        if (!(left instanceof SqlSingleTableSource))
            throw new NopException(ERR_EQL_OWNER_NOT_REF_TO_ENTITY).loc(loc).param(ARG_LEFT_SOURCE, left)
                    .param(ARG_ALIAS, propPath.getName()).param(ARG_PROP_PATH, propPath.toString());

        return resolvePropPath((SqlSingleTableSource) left, propPath.getNext());
    }

    SqlPropJoin resolvePropPath(SqlSingleTableSource source, PropPath propPath) {
        SqlPropJoin join = source.getPropJoin(propPath.getName());
        if (join != null) {
            join.incRef();
        } else {
            ISqlSelectionMeta table = source.getTableName().getResolvedTableMeta();
            if (!(table instanceof ISqlTableMeta)) {
                throw new NopException(ERR_EQL_OWNER_NOT_REF_TO_ENTITY).source(source).param(ARG_TABLE,
                        source.getTableName().getFullName());
            }

            ISqlTableMeta tableMeta = (ISqlTableMeta) table;

            ISqlExprMeta fieldExpr = table.getFieldExprMeta(propPath.getName(), context.isAllowUnderscoreName());
            if (fieldExpr != null) {
                IOrmDataType dataType = fieldExpr.getOrmDataType();
                if (!dataType.getKind().isRelation())
                    throw new NopException(ERR_EQL_PROP_PATH_NOT_VALID_TO_ONE_REFERENCE).source(source)
                            .param(ARG_PROP_PATH, propPath)
                            .param(ARG_PROP_NAME, propPath.getName()).param(ARG_ENTITY_NAME, tableMeta.getEntityName());

                IEntityRelationModel ref = (IEntityRelationModel) dataType;
                if (ref.isToOneRelation()) {
                    join = addToOneRelationJoin(source, ref);
                } else {
                    if (ref.getKeyProp() == null)
                        throw new NopException(ERR_EQL_PROP_PATH_NOT_VALID_TO_ONE_REFERENCE).source(source)
                                .param(ARG_PROP_PATH, propPath)
                                .param(ARG_PROP_NAME, propPath.getName()).param(ARG_ENTITY_NAME, tableMeta.getEntityName());

                    if (propPath.getNext() == null)
                        throw new NopException(ERR_EQL_PROP_PATH_NOT_VALID_TO_ONE_REFERENCE).source(source)
                                .param(ARG_PROP_PATH, propPath)
                                .param(ARG_PROP_NAME, propPath.getName()).param(ARG_ENTITY_NAME, tableMeta.getEntityName());

                    String propJoinName = propPath.getName() + '.' + propPath.getNext().getName();
                    join = source.getPropJoin(propJoinName);
                    propPath = propPath.getNext();
                    if (join != null) {
                        join.incRef();
                    } else {
                        // to-many关联，且具有keyProp属性
                        join = addToManyRelationJoin(source, ref, propJoinName, propPath.getName());
                    }
                }
            } else {
                // 如果不是实体的直接属性，检查是否是复合属性的别名
                join = requireAliasPropPathForRef(source, tableMeta, propPath.getName());
            }
        }

        if (propPath.getNext() == null)
            return join;

        return resolvePropPath(join.getRight(), propPath.getNext());
    }

    SqlPropJoin requireAliasPropPathForRef(SqlSingleTableSource source, ISqlTableMeta tableMeta, String aliasName) {
        PropPath aliasPath = tableMeta.getAliasPropPath(aliasName);
        if (aliasPath != null) {
            return resolvePropPath(source, aliasPath);
        } else {
            throw new NopException(ERR_EQL_PROP_PATH_NOT_VALID_TO_ONE_REFERENCE).source(source)
                    .param(ARG_PROP_NAME, aliasName)
                    .param(ARG_PROP_PATH, aliasName).param(ARG_ENTITY_NAME, tableMeta.getEntityName());
        }
    }

    SqlPropJoin addToOneRelationJoin(SqlSingleTableSource source, IEntityRelationModel ref) {
        return addToOneRelationJoin(source, ref, null);
    }

    SqlPropJoin addToOneRelationJoin(SqlSingleTableSource source, IEntityRelationModel ref, SqlAlias userAlias) {
        if (ref.isDynamicJoin())
            return addToOneDynamicRelationJoin(source, ref);

        SqlSingleTableSource refTable = makeTableSource(source.getLocation(), ref.getRefEntityModel(), userAlias);
        SqlExpr condition = makeCondition(ref.getJoin(), source, refTable);

        refTable.setForPropJoin(true);
        SqlPropJoin join = new SqlPropJoin();
        join.setLeft(source);
        join.setRight(refTable);
        join.setJoinType(SqlJoinType.JOIN); // 暂时设置为inner join

        // 如果仅在order by中使用，且属性可空，则使用left join
        if (inOrderBy && !ref.isMandatory()) {
            join.setJoinType(SqlJoinType.LEFT_JOIN);
        }

        join.setExplicit(false);
        join.setCondition(condition);

        addTableFilterForPropJoin(join);

        source.addPropJoin(ref.getName(), join);
        return join;
    }

    void addTableFilterForPropJoin(SqlPropJoin join) {
        if (join.getLeft().isEntityTableSource()) {
            addTableFilterForPropJoinTable(join.getLeft(), join);
        }

        if (join.getRight().isEntityTableSource()) {
            addTableFilterForPropJoinTable(join.getRight(), join);
        }
    }

    void addTableFilterForPropJoinTable(SqlSingleTableSource table, SqlPropJoin join) {
        if (table.isFilterAlreadyAdded())
            return;

        table.setFilterAlreadyAdded(true);
        // 与实体名join的缺省过滤(collectDefaultEntityFilter)对齐：
        // prop join的ON条件同样包含逻辑删除/租户条件/实体固定过滤器，避免多租户数据经关联泄漏。
        // 其中租户条件带参数标记，由SqlParamTypeResolver按prop join渲染顺序收集(EQL-01)
        collectDefaultEntityFilter(table, join::addConditionFilter);
    }

    SqlPropJoin addToOneDynamicRelationJoin(SqlSingleTableSource source, IEntityRelationModel ref) {
        SqlSingleTableSource refTable = makeTableSource(source.getLocation(), ref.getRefEntityModel(), null);

        SqlSingleTableSource leftSource = source, rightSource = refTable;

        SqlExpr condition = null;
        if (ref.getJoin().size() != 1) {
            throw new NopException(ERR_EQL_NOT_SUPPORT_MULTI_JOIN_ON_ALIAS)
                    .param(ARG_ENTITY_NAME, ref.getOwnerEntityModel().getName())
                    .param(ARG_PROP_NAME, ref.getName());
        }

        IEntityJoinConditionModel on = ref.getJoin().get(0);

        IEntityPropModel leftProp = on.getLeftPropModel();
        IEntityPropModel rightProp = on.getRightPropModel();

        if (leftProp != null) {
            if (leftProp.isAliasModel()) {
                PropPath propPath = PropPath.parse(leftProp.getAliasPropPath());
                if (propPath.getNext() == null) {
                    leftProp = on.getLeftPropModel().getOwnerEntityModel().getColumn(propPath.getName(), false);
                } else {
                    SqlPropJoin join = resolvePropPath(source, propPath.getOwner());
                    leftSource = join.getRight();
                    leftProp = leftSource.getResolvedTableMeta().requirePropMeta(propPath.getLast(), context.isAllowUnderscoreName());
                }
            }
        }
        if (rightProp != null) {
            if (rightProp.isAliasModel()) {
                PropPath propPath = PropPath.parse(rightProp.getAliasPropPath());
                if (propPath.getNext() == null) {
                    rightProp = on.getRightPropModel().getOwnerEntityModel().getColumn(propPath.getName(), false);
                } else {
                    SqlPropJoin join = resolvePropPath(refTable, propPath.getOwner());
                    rightSource = join.getRight();
                    rightProp = rightSource.getResolvedTableMeta().requirePropMeta(propPath.getLast(), context.isAllowUnderscoreName());
                }
            }

            SqlBinaryExpr eq = new SqlBinaryExpr();
            eq.setOperator(SqlOperator.EQ);
            eq.setLeft(makePropExpr(leftSource, leftProp, null));
            eq.setRight(makePropExpr(rightSource, rightProp, null));
            condition = eq;
        }

        rightSource.setForPropJoin(true);
        SqlPropJoin join = new SqlPropJoin();
        join.setLeft(leftSource);
        join.setRight(rightSource);
        join.setJoinType(SqlJoinType.JOIN); // 暂时设置为inner join

        // 如果仅在order by中使用，且属性可空，则使用left join
        if (inOrderBy && !ref.isMandatory()) {
            join.setJoinType(SqlJoinType.LEFT_JOIN);
        }

        join.setExplicit(false);
        join.setCondition(condition);

        addTableFilterForPropJoin(join);

        leftSource.addPropJoin(ref.getName(), join);
        return join;
    }

    SqlPropJoin addToManyRelationJoin(SqlSingleTableSource source, IEntityRelationModel ref, String propJoinName,
                                      String keyValue) {
        IColumnModel keyCol = ref.getRefEntityModel().getColumn(ref.getKeyProp(), false);
        SqlSingleTableSource refTable = makeTableSource(source.getLocation(), ref.getRefEntityModel(), null);
        SqlExpr joinCondition = makeCondition(ref.getJoin(), source, refTable);
        SqlAndExpr condition = new SqlAndExpr();
        condition.setLeft(joinCondition);
        condition.setRight(makeEqExpr(refTable, keyCol, keyValue));

        refTable.setForPropJoin(true);
        SqlPropJoin join = new SqlPropJoin();
        join.setLeft(source);
        join.setRight(refTable);
        // 扩展字段有可能没有被初始化，因此这里总是使用left join
        join.setJoinType(SqlJoinType.LEFT_JOIN);

        join.setExplicit(false);
        join.setCondition(condition);

        addTableFilterForPropJoin(join);

        source.addPropJoin(propJoinName, join);
        return join;
    }

    /**
     * 用于集合属性作为表来源的场景：只基于关系元数据生成关联，不使用 keyProp 额外过滤。
     * 例如 from o.simsClasses c 这种写法，仅需要 College 与 Class 的 join 条件即可。
     */
    SqlPropJoin addToManyCollectionJoin(SqlSingleTableSource source, IEntityRelationModel ref, String propJoinName) {
        return addToManyCollectionJoin(source, ref, propJoinName, null);
    }

    SqlPropJoin addToManyCollectionJoin(SqlSingleTableSource source, IEntityRelationModel ref, String propJoinName, SqlAlias userAlias) {
        SqlSingleTableSource refTable = makeTableSource(source.getLocation(), ref.getRefEntityModel(), userAlias);
        SqlExpr joinCondition = makeCondition(ref.getJoin(), source, refTable);

        refTable.setForPropJoin(true);
        SqlPropJoin join = new SqlPropJoin();
        join.setLeft(source);
        join.setRight(refTable);
        // 集合表源语义上等价于左表拥有一组子记录，这里使用 left join 更安全
        join.setJoinType(SqlJoinType.LEFT_JOIN);

        join.setExplicit(false);
        join.setCondition(joinCondition);

        addTableFilterForPropJoin(join);

        source.addPropJoin(propJoinName, join);
        return join;
    }

    SqlExpr makeEqExpr(SqlTableSource source, IColumnModel keyCol, String keyValue) {
        SqlBinaryExpr expr = new SqlBinaryExpr();
        expr.setOperator(SqlOperator.EQ);
        SqlColumnName col = new SqlColumnName();
        SqlQualifiedName owner = new SqlQualifiedName();
        owner.setName(source.getAliasName());
        col.setOwner(owner);
        col.setTableSource(source);
        col.setResolvedExprMeta(source.getResolvedTableMeta().getFieldExprMeta(keyCol.getName(), context.isAllowUnderscoreName()));
        expr.setLeft(col);
        SqlStringLiteral value = new SqlStringLiteral();
        value.setValue(keyValue);
        expr.setRight(value);
        return expr;
    }

    SqlSingleTableSource makeTableSource(SourceLocation loc, IEntityModel entityModel, SqlAlias alias) {
        readEntityModels.add(entityModel.getName());
        if (entityModel.isTenantModel())
            this.useTenantModel = entityModel.isTenantModel();

        SqlSingleTableSource table = new SqlSingleTableSource();
        table.setLocation(loc);
        SqlTableName tableName = new SqlTableName();
        ISqlSelectionMeta tableMeta = context.resolveEntityTableMeta(entityModel.getName());
        if (tableMeta == null)
            throw new NopException(ERR_EQL_UNKNOWN_ENTITY_NAME).param(ARG_ENTITY_NAME, entityModel.getName());
        tableName.setResolvedTableMeta(tableMeta);

        tableName.setName(entityModel.getName());
        table.setTableName(tableName);

        alias = makeTableAlias(alias);
        alias.setASTParent(null);
        table.setAlias(alias);
        return table;
    }

    SqlExpr makeCondition(List<? extends IEntityJoinConditionModel> condition, SqlTableSource leftSource,
                          SqlTableSource rightSource) {
        if (condition.size() == 1) {
            return makeConditionExpr(condition.get(0), leftSource, rightSource);
        } else {
            SqlAndExpr and = new SqlAndExpr();
            and.setLeft(makeConditionExpr(condition.get(0), leftSource, rightSource));
            and.setRight(makeCondition(condition.subList(1, condition.size()), leftSource, rightSource));
            return and;
        }
    }

    SqlExpr makeConditionExpr(IEntityJoinConditionModel condition, SqlTableSource leftSource,
                              SqlTableSource rightSource) {
        SqlBinaryExpr eq = new SqlBinaryExpr();
        eq.setOperator(SqlOperator.EQ);
        eq.setLeft(makePropExpr(leftSource, condition.getLeftPropModel(), condition.getLeftValue()));
        eq.setRight(makePropExpr(rightSource, condition.getRightPropModel(), condition.getRightValue()));
        return eq;
    }

    SqlExpr makePropExpr(SqlTableSource source, IEntityPropModel propModel, Object value) {
        if (propModel != null) {
            SqlColumnName col = new SqlColumnName();
            col.setPropModel(propModel);
            col.setName(propModel.getName());
            col.setTableSource(source);
            col.setResolvedExprMeta(source.getResolvedTableMeta().requireFieldExprMeta(propModel.getName(), context.isAllowUnderscoreName()));
            SqlQualifiedName name = new SqlQualifiedName();
            name.setName(source.getAliasName());
            col.setOwner(name);
            return col;
        } else {
            if (value instanceof Number) {
                SqlNumberLiteral literal = new SqlNumberLiteral();
                literal.setResolvedExprMeta(SingleColumnExprMeta.valueExprMeta(StdSqlType.DECIMAL));
                literal.setValue(StringHelper.toString(value, null));
                return literal;
            } else {
                SqlStringLiteral literal = new SqlStringLiteral();
                literal.setResolvedExprMeta(SingleColumnExprMeta.valueExprMeta(StdSqlType.VARCHAR));
                literal.setValue(StringHelper.toString(value, null));
                return literal;
            }
        }
    }

    // void visitLateral(SqlTableScope joinScope, SqlTableScope lateralScope, SqlTableSource table) {
    // if (table instanceof SqlSubqueryTableSource) {
    // // lateral 表示可以看到同级的表
    // SqlSubqueryTableSource source = (SqlSubqueryTableSource) table;
    //
    // if (source.getLateral()) {
    // currentScope = lateralScope;
    // visitSqlSubqueryTableSource(source);
    // currentScope = lateralScope.getParent();
    // lateralScope.addTable(source.getAlias().getAlias(), source);
    // } else {
    // joinScope.addTable(source.getAlias().getAlias(), source);
    // }
    // } else if (table instanceof SqlJoinTableSource) {
    // SqlJoinTableSource source = (SqlJoinTableSource) table;
    // visitLateral(joinScope, lateralScope, source.getLeft());
    // visitLateral(joinScope, lateralScope, source.getRight());
    //
    // currentScope = joinScope;
    // visitJoinCondition(source);
    // currentScope = joinScope.getParent();
    // }
    // }

    void resolveEntity(SqlSingleTableSource table) {
        SqlTableName tableName = table.getTableName();
        String fullName = tableName.getFullName();
        ISqlTableMeta tableMeta = context.resolveEntityTableMeta(fullName);
        if (tableMeta != null) {
            table.setAlias(makeTableAlias(table.getAlias()));
            addResolvedEntity(tableName.getLocation(), tableMeta);
            // 对应全类名或者简单类名
            tableName.setResolvedTableMeta(tableMeta);
        } else {
            // 不是实体对象，需要检查是否是属性表达式或 CTE
            SqlQualifiedName owner = tableName.getOwner();
            if (owner == null) {
                SqlSelect cte = getCte(table, tableName.getName());
                if (table.getAlias() == null) {
                    SqlAlias alias = new SqlAlias();
                    alias.setAlias(tableName.getName());
                    table.setAlias(alias);
                }
                if (cte != null) {
                    resolveSelectFields(cte);
                    tableName.setResolvedCte(cte);
                    tableName.setResolvedTableMeta(cte.getResolvedTableMeta());

                    SqlSubqueryTableSource querySource = newCteSource(table, cte);
                    if (!dialect.isSupportWithAsClause()) {
                        table.getASTParent().replaceChild(table, querySource);
                    } else {
                        addAliasToScope(currentScope, querySource);
                    }
                    return;
                }
            }
            throw new NopException(ERR_EQL_UNKNOWN_ENTITY_NAME).source(table).param(ARG_ENTITY_NAME, fullName);
        }
    }

    void visitJoinCondition(SqlJoinTableSource source) {
        if (source.getCondition() != null) {
            visit(source.getCondition());
        }
    }

    SqlAlias makeTableAlias(SqlAlias alias) {
        if (alias == null) {
            do {
                String newName = aliasGenerator.genTableAlias();
                if (!assignedAliases.contains(newName)) {
                    alias = new SqlAlias();
                    alias.setGenerated(true);
                    alias.setAlias(newName);
                    return alias;
                }
            } while (true);
        }
        return alias;
    }

    @Override
    public void visitSqlAllProjection(SqlAllProjection node) {
        SqlQualifiedName owner = node.getOwner();
        if (owner != null) {
            if (owner.getNext() == null) {
                SqlTableSource source = currentScope.getTableByAlias(owner.getName());
                if (source != null) {
                    replaceAllProjection(node, getSourceSelectItems(source));
                    return;
                }
            }

            SqlPropJoin join = resolvePropPath(currentScope, owner.getLocation(), owner.toPropPath());
            // 加载关联实体的所有字段
            replaceAllProjection(node, getSourceSelectItems(join.getRight()));
        } else {
            SqlQuerySelect select = getQuerySelect(node);

            List<SqlProjection> items = getAllProjections(select);
            replaceAllProjection(node, items);
        }
    }

    List<SqlProjection> getAllProjections(SqlQuerySelect select) {
        SqlFrom from = select.getFrom();
        if (from == null)
            throw new NopException(ERR_EQL_QUERY_NO_FROM_CLAUSE).source(select);

        List<SqlProjection> items = new ArrayList<>();
        for (SqlTableSource source : from.getTableSources()) {
            items.addAll(getSourceSelectItems(source));
        }
        return items;
    }

    void replaceAllProjection(SqlAllProjection proj, List<SqlProjection> projs) {
        SqlQuerySelect select = (SqlQuerySelect) proj.getASTParent();
        List<SqlProjection> replaced = select.getProjections().stream().flatMap(p -> {
            if (p == proj) {
                return projs.stream();
            } else {
                return Stream.of(p);
            }
        }).collect(Collectors.toList());
        select.setProjections(replaced);
        super.visitChildren(select.getProjections());
    }

    List<SqlProjection> getSourceSelectItems(SqlTableSource source) {
        if (source instanceof SqlSingleTableSource) {
            SqlSingleTableSource table = (SqlSingleTableSource) source;
            return buildSelectItems(table, table.getSourceSelect() == null, true);
        } else if (source instanceof SqlSubqueryTableSource) {
            SqlSubqueryTableSource query = (SqlSubqueryTableSource) source;
            resolveSelectFields(query.getQuery());

            return buildSelectItems(source, false, true);
        } else if (source instanceof SqlValuesTableSource) {
            // WI12 交付⑤：select * 对 VALUES 源的展开（元数据由 visitTableSource 期
            // buildValuesTableMeta 设置；onlyColumn=false 与子查询分支同口径——
            // VALUES 列元数据是表达式元数据而非实体列，column-kind 过滤会清空投影）
            return buildSelectItems(source, false, true);
        } else if (source instanceof SqlJoinTableSource) {
            // select * 展开时对join源递归收集左右表的投影
            SqlJoinTableSource join = (SqlJoinTableSource) source;
            List<SqlProjection> items = new ArrayList<>(getSourceSelectItems(join.getLeft()).size()
                    + getSourceSelectItems(join.getRight()).size());
            items.addAll(getSourceSelectItems(join.getLeft()));
            items.addAll(getSourceSelectItems(join.getRight()));
            return items;
        } else {
            throw new NopException(ERR_EQL_ONLY_SUPPORT_SINGLE_TABLE_SOURCE).source(source)
                    .param(ARG_TABLE_SOURCE, source.getDisplayString());
        }
    }

    List<SqlProjection> buildSelectItems(SqlTableSource source, boolean onlyColumn, boolean useAlias) {
        ISqlSelectionMeta tableMeta = source.getResolvedTableMeta();
        Map<String, ISqlExprMeta> fieldMetas = tableMeta.getFieldExprMetas();
        List<SqlProjection> ret = new ArrayList<>(fieldMetas.size());
        for (Map.Entry<String, ISqlExprMeta> entry : fieldMetas.entrySet()) {
            ISqlExprMeta exprMeta = entry.getValue();
            if (onlyColumn) {
                if (!exprMeta.getOrmDataType().getKind().isColumn())
                    continue;
            }
            SqlExprProjection proj = new SqlExprProjection();
            SqlColumnName col = newColNameWithType(source, entry.getKey(), exprMeta);

            proj.setExpr(col);
            if (useAlias)
                proj.setAlias(newColumnAlias());
            ret.add(proj);
        }
        return ret;
    }

    SqlColumnName newColNameWithType(SqlTableSource source, String name, ISqlExprMeta exprMeta) {
        SqlColumnName colName = new SqlColumnName();
        colName.setTableSource(source);
        SqlQualifiedName qn = new SqlQualifiedName();
        qn.setResolvedSource(source);
        qn.setName(source.getAliasName());
        colName.setOwner(qn);
        colName.setName(name);
        colName.setResolvedExprMeta(exprMeta);
        return colName;
    }

    @Override
    public void visitSqlExprProjection(SqlExprProjection node) {
        if (node.getAlias() == null) {
            // update returning语句不需要设置alias
            if (!isSqlUpdate(node.getASTParent())) {
                node.setAlias(newColumnAlias());
            }
        }
        visit(node.getExpr());
    }

    private boolean isSqlUpdate(EqlASTNode node) {
        return node.getASTKind() == EqlASTKind.SqlUpdate;
    }

    @Override
    public void visitSqlColumnName(SqlColumnName node) {
        SqlTableSource source;
        if (node.getOwner() == null) {
            if (inOrderBy || inGroupBy) {
                if (resolveSelectExpr(node))
                    return;
            }
            resolveDefaultTableSource(node);
            return;
        } else if (node.getOwner().getNext() == null) {
            source = currentScope.getTableByAlias(node.getOwner().getName());
            if (source == null) {
                throw new NopException(ERR_EQL_UNKNOWN_ALIAS).source(node).param(ARG_ALIAS, node.getOwner().getName());
            }
        } else {
            SqlPropJoin join = resolvePropPath(currentScope, node.getLocation(), node.getOwner().toPropPath());
            source = join.getRight();
        }
        resolveColName(source, node);
    }

    private void resolveDefaultTableSource(SqlColumnName node) {
        // 没有使用表的别名，例如 select name from UserInfo
        SqlQuerySelect select = getQuerySelect(node);
        if (select == null) {
            ISqlTableSourceSupport tableSupport = resolveTableSource(node);
            if (tableSupport != null) {
                resolveColName(tableSupport.getResolvedTableSource(), node);
                return;
            }
        }

        if (select == null || select.getFrom() == null) {
            throw new NopException(ERR_EQL_QUERY_NO_FROM_CLAUSE)
                    .source(node).param(ARG_COL_NAME, node.getName());
        }

        SqlTableSource source = currentScope.getTableByAlias(node.getName());
        if (source != null) {
            node.setTableSource(source);
            // 如果是参与比较表达式，则返回主键字段
            ISqlTableMeta tableMeta = getTableMeta(source);
            if (node.getASTParent().getASTKind() == EqlASTKind.SqlBinaryExpr) {
                ISqlExprMeta fieldMeta = tableMeta.getFieldExprMeta(OrmEqlConstants.PROP_ID, false);
                node.setResolvedExprMeta(fieldMeta);
                node.setPropModel((IEntityPropModel) fieldMeta.getOrmDataType());
            } else {
                node.setResolvedExprMeta(tableMeta.getEntityExprMeta());
            }
            return;
        }

        // 只考虑from语句的第一个表，而且只考虑单表选择的情况
        source = select.getFrom().getFirstTableSource();
        if (!(source instanceof SqlSingleTableSource)) {
            throw new NopException(ERR_EQL_UNKNOWN_COLUMN_NAME).source(node).param(ARG_COL_NAME, node.getName());
        }
        resolveColName(source, node);
    }

    ISqlTableMeta getTableMeta(SqlTableSource source) {
        if (source instanceof SqlSingleTableSource) {
            SqlSingleTableSource single = (SqlSingleTableSource) source;
            ISqlSelectionMeta tableMeta = single.getTableName().getResolvedTableMeta();
            if (tableMeta instanceof ISqlTableMeta)
                return (ISqlTableMeta) tableMeta;
        }
        throw new NopException(ERR_EQL_ONLY_SUPPORT_SINGLE_TABLE_SOURCE).source(source).param(ARG_TABLE_SOURCE,
                source.getDisplayString());
    }

    void resolveColName(SqlTableSource source, SqlColumnName node) {
        resolveColName(source, node, node.getName());
    }

    void resolveColName(SqlTableSource source, SqlColumnName node, String propName) {
        ISqlSelectionMeta model = source.getResolvedTableMeta();
        if (model == null)
            throw new NopException(ERR_EQL_TABLE_SOURCE_NOT_RESOLVED).source(node)
                    .param(ARG_TABLE_SOURCE, source.toSQL().getText()).param(ARG_COL_NAME, propName);

        ISqlExprMeta propExpr = model.getFieldExprMeta(propName, context.isAllowUnderscoreName());
        if (propExpr != null) {
            node.setTableSource(source);
            node.setResolvedExprMeta(propExpr);

            // 如果是从子查询中选择，则列名改变为子查询结果集中的alias
            SqlSelect query = source.getSourceSelect();
            if (query != null) {
                SqlExprProjection proj = query.getProjectionByExprMeta(propExpr);
                List<String> colNames = new ArrayList<>(propExpr.getColumnCount());
                for (int i = 0, n = propExpr.getColumnCount(); i < n; i++) {
                    String colName = EqlHelper.getAlias(proj.getAlias().getAlias(), i, n);
                    colNames.add(colName);
                }
                node.setResolvedExprMeta(new RenamedSqlExprMeta(propExpr, colNames));
            }
        } else {
            PropPath propPath = model.getAliasPropPath(node.getName());
            if (propPath == null) {
//                if (node.getOwner() == null && (inOrderBy || inGroupBy)) {
//                    // order by段中可以使用selection中的字段别名
//                    SqlQuerySelect select = getQuerySelect(node);
//                    ISqlExprMeta fieldExpr = select.getResolvedTableMeta().getFieldExprMeta(node.getName(), false);
//                    if (fieldExpr != null) {
//                        node.setResolvedExprMeta(fieldExpr);
//                        node.setProjection(select.getProjectionByExprMeta(fieldExpr));
//                        return;
//                    }
//                }
                if (model instanceof ISqlTableMeta) {
                    throw new NopException(ERR_EQL_UNKNOWN_COLUMN_NAME).source(node)
                            .param(ARG_ENTITY_NAME, ((ISqlTableMeta) model).getEntityName())
                            .param(ARG_COL_NAME, node.getName());
                } else {
                    throw new NopException(ERR_EQL_FIELD_NOT_IN_SUBQUERY).source(node).param(ARG_FIELD_NAME,
                            node.getName());
                }
            }

            if (propPath.getNext() == null) {
                resolveColName(source, node, propPath.getName());
            } else {
                SqlPropJoin join = resolvePropPath((SqlSingleTableSource) source, propPath.getOwner());
                resolveColName(join.getRight(), node, propPath.getLast());
            }
        }
    }

    boolean resolveSelectExpr(SqlColumnName node) {
        // order by段中可以使用selection中的字段别名
        SqlQuerySelect select = getQuerySelect(node);
        ISqlExprMeta fieldExpr = select.getResolvedTableMeta().getFieldExprMeta(node.getName(), false);
        if (fieldExpr != null) {
            node.setResolvedExprMeta(fieldExpr);
            node.setProjection(select.getProjectionByExprMeta(fieldExpr));
            return true;
        }
        return false;
    }

    @Override
    public void visitSqlRegularFunction(SqlRegularFunction node) {
        ISQLFunction fn = dialect.getFunction(node.getName());
        if (fn == null)
            throw new NopException(ERR_EQL_UNKNOWN_FUNCTION).source(node).param(ARG_FUNC_NAME, node.getName())
                    .param(ARG_DIALECT, dialect.getName());

        if (fn.isOnlyForWindowExpr()) {
            if (node.getASTParent().getASTKind() != EqlASTKind.SqlWindowExpr)
                throw new NopException(ERR_EQL_FUNC_ONLY_ALLOW_IN_WINDOW_EXPR)
                        .source(node).param(ARG_FUNC_NAME, node.getName())
                        .param(ARG_DIALECT, dialect.getName());
        }

        int argCount = node.getArgs().size();
        if (fn.getMinArgCount() > argCount) {
            throw new NopException(ERR_EQL_FUNC_TOO_FEW_ARGS).source(node).param(ARG_FUNC_NAME, node.getName())
                    .param(ARG_ARG_COUNT, argCount).param(ARG_MIN_ARG_COUNT, fn.getMinArgCount());
        }

        if (fn.getMaxArgCount() < node.getArgs().size()) {
            throw new NopException(ERR_EQL_FUNC_TOO_MANY_ARGS).source(node).param(ARG_FUNC_NAME, node.getName())
                    .param(ARG_ARG_COUNT, argCount).param(ARG_MAX_ARG_COUNT, fn.getMaxArgCount());
        }
        node.setResolvedFunction(fn);


        visitChildren(node.getArgs());
    }

    private String genColumnAlias() {
        do {
            String alias = aliasGenerator.genColumnAlias();
            if (!assignedAliases.contains(alias))
                return alias;
        } while (true);
    }

    private SqlAlias newColumnAlias() {
        SqlAlias ret = new SqlAlias();
        ret.setGenerated(true);
        ret.setAlias(genColumnAlias());
        return ret;
    }

    @Override
    public void visitSqlInsert(SqlInsert node) {
        SqlTableName table = node.getTableName();

        currentScope = new SqlTableScope(node, currentScope);
        ISqlTableMeta tableMeta = resolveEntity(table);

        SqlSingleTableSource source = newSingleTableSource(table, null);
        node.setResolvedTableSource(source);

        writeEntityModel = tableMeta.getEntityName();
        if (tableMeta.getEntityModel().isTenantModel())
            this.useTenantModel = tableMeta.getEntityModel().isTenantModel();

        visitChildren(node.getColumns());

        if (node.getSelect() != null) {
            visit(node.getSelect());
        }

        if (node.getValues() != null) {
            visit(node.getValues());
        }

        currentScope = currentScope.getParent();
    }

    ISqlTableMeta resolveEntity(SqlTableName table) {
        String fullName = table.getFullName();

        ISqlTableMeta tableMeta = context.resolveEntityTableMeta(fullName);

        if (tableMeta != null) {
            addResolvedEntity(table.getLocation(), tableMeta);
            // 对应全类名或者简单类名
            table.setResolvedTableMeta(tableMeta);
            return tableMeta;
        } else {
            throw new NopException(ERR_EQL_UNKNOWN_ENTITY_NAME).source(table).param(ARG_ENTITY_NAME, fullName);
        }
    }

    @Override
    public void visitSqlUpdate(SqlUpdate node) {
        SqlTableName table = node.getTableName();
        node.setAlias(makeTableAlias(node.getAlias()));

        currentScope = new SqlTableScope(node, currentScope);
        ISqlTableMeta tableMeta = resolveEntity(table);

        SqlSingleTableSource source = newSingleTableSource(table, node.getAlias());
        node.setResolvedTableSource(source);

        writeEntityModel = tableMeta.getEntityName();
        if (tableMeta.getEntityModel().isTenantModel())
            this.useTenantModel = tableMeta.getEntityModel().isTenantModel();

        addWriteTenantFilter(node.getWhere(), source, tableMeta, node::setWhere);

        this.visitChildren(node.getAssignments());
        this.visitChild(node.getWhere());

        // 分析所有的projection，并且确保每一列都有一个别名
        // returning * 与显式投影一样依赖方言的returning支持，必须在展开前统一校验
        if ((node.getReturnAll() || (node.getReturnProjections() != null && !node.getReturnProjections().isEmpty()))
                && !dialect.isSupportReturningForUpdate()) {
            throw new NopException(ERR_EQL_DIALECT_NOT_SUPPORT_FEATURE)
                    .param(ARG_DIALECT, dialect.getName())
                    .param(ARG_FEATURE, FEATURE_SUPPORT_RETURNING_FOR_UPDATE);
        }
        if (node.getReturnProjections() == null || node.getReturnProjections().isEmpty()) {
            // select *
            if (node.getReturnAll()) {
                List<SqlProjection> items = buildSelectItems(source, true, false);
                node.setReturnProjections(items);
            }// ELSE 没有Returning语句
        }
        visitChildren(node.getReturnProjections());

        // returning投影可能是函数等非列表达式，与select语句的resolveSelectFields一致地推导表达式类型，
        // 避免SQL生成阶段因resolvedExprMeta为null而出现NPE
        if (node.getReturnProjections() != null && !node.getReturnProjections().isEmpty()) {
            ExprTypeResolver typeResolver = new ExprTypeResolver(dialect);
            for (SqlProjection projection : node.getReturnProjections()) {
                SqlExprProjection proj = (SqlExprProjection) projection;
                typeResolver.resolveExprMeta(proj.getExpr());
            }
        }
        currentScope = currentScope.getParent();
    }

    private SqlSingleTableSource newSingleTableSource(SqlTableName table, SqlAlias alias) {
        SqlSingleTableSource source = new SqlSingleTableSource();
        source.setLocation(table.getLocation());
        source.setTableName(table.deepClone());
        source.getTableName().setResolvedTableMeta(table.getResolvedTableMeta());
        if (alias != null && alias.getAlias() != null) {
            source.setAlias(alias.deepClone());
            currentScope.addTable(alias.getAlias(), source);
        }
        return source;
    }

    @Override
    public void visitSqlDelete(SqlDelete node) {
        SqlTableName table = node.getTableName();
        node.setAlias(makeTableAlias(node.getAlias()));

        currentScope = new SqlTableScope(node, currentScope);

        ISqlTableMeta tableMeta = resolveEntity(table);
        writeEntityModel = tableMeta.getEntityName();
        if (tableMeta.getEntityModel().isTenantModel())
            this.useTenantModel = tableMeta.getEntityModel().isTenantModel();

        SqlSingleTableSource source = newSingleTableSource(table, node.getAlias());
        node.setResolvedTableSource(source);

        addWriteTenantFilter(node.getWhere(), source, tableMeta, node::setWhere);

        this.visitChild(node.getWhere());

        currentScope = currentScope.getParent();
    }

    @Override
    public void visitSqlGroupBy(SqlGroupBy node) {
        inGroupBy = true;
        super.visitSqlGroupBy(node);
        inGroupBy = false;
    }

    @Override
    public void visitSqlOrderBy(SqlOrderBy node) {
        inOrderBy = true;
        super.visitSqlOrderBy(node);
        inOrderBy = false;
    }

    private SqlQuerySelect getQuerySelect(EqlASTNode node) {
        do {
            if (node instanceof SqlQuerySelect)
                return (SqlQuerySelect) node;
            node = node.getASTParent();
        } while (node != null);
        return null;
    }

    private ISqlTableSourceSupport resolveTableSource(EqlASTNode node) {
        do {
            if (node instanceof ISqlTableSourceSupport)
                return (ISqlTableSourceSupport) node;
            node = node.getASTParent();
        } while (node != null);
        return null;
    }

    private SqlSelectWithCte getSelectWithCte(EqlASTNode node) {
        do {
            if (node instanceof SqlSelectWithCte)
                return (SqlSelectWithCte) node;
            node = node.getASTParent();
        } while (node != null);
        return null;
    }

    private SqlSelect getCte(EqlASTNode node, String name) {
        do {
            SqlSelectWithCte selectWithCte = getSelectWithCte(node);
            if (selectWithCte == null)
                return null;
            SqlSelect cte = selectWithCte.getCte(name);
            if (cte != null)
                return cte;
            node = selectWithCte.getASTParent();
        } while (node != null);

        return null;
    }
}
