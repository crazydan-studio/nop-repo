/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.orm.eql.sql;

import io.nop.commons.util.StringHelper;
import io.nop.core.lang.sql.ISqlExpr;
import io.nop.core.lang.sql.SQL;
import io.nop.core.lang.sql.SqlExprList;
import io.nop.core.lang.sql.StringSqlExpr;
import io.nop.orm.eql.ast.EqlASTKind;
import io.nop.orm.eql.ast.EqlASTNode;
import io.nop.orm.eql.ast.EqlASTVisitor;
import io.nop.orm.eql.ast.SqlAggregateFunction;
import io.nop.orm.eql.ast.SqlAlias;
import io.nop.orm.eql.ast.SqlAllProjection;
import io.nop.orm.eql.ast.SqlAndExpr;
import io.nop.orm.eql.ast.SqlAssignment;
import io.nop.orm.eql.ast.SqlBetweenExpr;
import io.nop.orm.eql.ast.SqlBinaryExpr;
import io.nop.orm.eql.ast.SqlBitValueLiteral;
import io.nop.orm.eql.ast.SqlBooleanLiteral;
import io.nop.orm.eql.ast.SqlCaseExpr;
import io.nop.orm.eql.ast.SqlCaseWhenItem;
import io.nop.orm.eql.ast.SqlCastExpr;
import io.nop.orm.eql.ast.SqlColumnName;
import io.nop.orm.eql.ast.SqlCommit;
import io.nop.orm.eql.ast.SqlCompareWithQueryExpr;
import io.nop.orm.eql.ast.SqlCteStatement;
import io.nop.orm.eql.ast.SqlDateTimeLiteral;
import io.nop.orm.eql.ast.SqlDelete;
import io.nop.orm.eql.ast.SqlExistsExpr;
import io.nop.orm.eql.ast.SqlExpr;
import io.nop.orm.eql.ast.SqlExprProjection;
import io.nop.orm.eql.ast.SqlFrom;
import io.nop.orm.eql.ast.SqlGroupBy;
import io.nop.orm.eql.ast.SqlGroupByItem;
import io.nop.orm.eql.ast.SqlHaving;
import io.nop.orm.eql.ast.SqlHexadecimalLiteral;
import io.nop.orm.eql.ast.SqlInQueryExpr;
import io.nop.orm.eql.ast.SqlInValuesExpr;
import io.nop.orm.eql.ast.SqlInsert;
import io.nop.orm.eql.ast.SqlIntervalExpr;
import io.nop.orm.eql.ast.SqlIsNullExpr;
import io.nop.orm.eql.ast.SqlJoinTableSource;
import io.nop.orm.eql.ast.SqlLikeExpr;
import io.nop.orm.eql.ast.SqlLimit;
import io.nop.orm.eql.ast.SqlMultiValueExpr;
import io.nop.orm.eql.ast.SqlNotExpr;
import io.nop.orm.eql.ast.SqlNullLiteral;
import io.nop.orm.eql.ast.SqlNumberLiteral;
import io.nop.orm.eql.ast.SqlOrExpr;
import io.nop.orm.eql.ast.SqlOrderBy;
import io.nop.orm.eql.ast.SqlOrderByItem;
import io.nop.orm.eql.ast.SqlParameterMarker;
import io.nop.orm.eql.ast.SqlPartitionBy;
import io.nop.orm.eql.ast.SqlProgram;
import io.nop.orm.eql.ast.SqlQualifiedName;
import io.nop.orm.eql.ast.SqlQuerySelect;
import io.nop.orm.eql.ast.SqlRollback;
import io.nop.orm.eql.ast.SqlRegularFunction;
import io.nop.orm.eql.ast.SqlSelectWithCte;
import io.nop.orm.eql.ast.SqlSingleTableSource;
import io.nop.orm.eql.ast.SqlStringLiteral;
import io.nop.orm.eql.ast.SqlSubQueryExpr;
import io.nop.orm.eql.ast.SqlSubqueryTableSource;
import io.nop.orm.eql.ast.SqlTableName;
import io.nop.orm.eql.ast.SqlTypeExpr;
import io.nop.orm.eql.ast.SqlUnaryExpr;
import io.nop.orm.eql.ast.SqlUnionSelect;
import io.nop.orm.eql.ast.SqlWindowClause;
import io.nop.orm.eql.ast.SqlWindowDecl;
import io.nop.orm.eql.ast.SqlWindowExpr;
import io.nop.orm.eql.ast.SqlWindowFrame;
import io.nop.orm.eql.ast.SqlWindowFrameBound;
import io.nop.orm.eql.ast.SqlUpdate;
import io.nop.orm.eql.ast.SqlValues;
import io.nop.orm.eql.ast.SqlWhere;
import io.nop.orm.eql.ast.SqlWindowExpr;
import io.nop.orm.eql.enums.SqlCompareRange;
import io.nop.orm.eql.enums.SqlOperator;

import java.util.List;
import java.util.Locale;

public class AstToEqlGenerator extends EqlASTVisitor {
    protected final SQL.SqlBuilder sb;

    private int indentLevel;
    private boolean pretty = true;

    protected String ownerShouldBeIgnored;

    public AstToEqlGenerator(SQL.SqlBuilder sb) {
        this.sb = sb;
    }

    public AstToEqlGenerator() {
        this(SQL.begin());
    }

    public boolean isPretty() {
        return pretty;
    }

    public void setPretty(boolean pretty) {
        this.pretty = pretty;
    }

    public AstToEqlGenerator pretty(boolean pretty) {
        this.pretty = pretty;
        return this;
    }

    public SQL.SqlBuilder getSql() {
        return sb;
    }

    protected void print(char c) {
        sb.append(c);
    }

    protected void print(String text) {
        sb.append(text);
    }

    protected void beginBlock() {
        incIndent();
        println();
    }

    protected void beginBraceBlock() {
        print('(');
        beginBlock();
    }

    protected void endBraceBlock() {
        decIndent();
        println();
        print(')');
    }

    protected void endBlock() {
        decIndent();
        println();
    }

    protected void printAlias(SqlAlias alias) {
        if (alias != null) {
            print(" as ");
            print(alias.getAlias());
        }
    }

    void incIndent() {
        indentLevel++;
    }

    void decIndent() {
        indentLevel--;
    }

    void indent() {
        if (pretty) {
            for (int i = 0; i < this.indentLevel; ++i) {
                print("  ");
            }
        }
    }

    void println() {
        print("\n");
        indent();
    }

    void printLeft(EqlASTNode node, SqlOperator operator) {
        int priority = operator.getPriority();
        if (node.requireParentheses(priority, priority)) {
            sb.append("(");
            visit(node);
            sb.append(")");
        } else {
            visit(node);
        }
    }

    void printRight(EqlASTNode node, SqlOperator operator) {
        int priority = operator.getPriority();
        if (node.requireParentheses(priority, priority)) {
            sb.append("(");
            visit(node);
            sb.append(")");
        } else {
            visit(node);
        }
    }

    void printOperator(SqlOperator operator) {
        print(' ');
        print(operator.getText());
        print(' ');
    }

    void printBinaryExpr(SqlExpr left, SqlOperator operator, SqlExpr right) {
        printLeft(left, operator);
        printOperator(operator);
        printRight(right, operator);
    }

    protected void printList(List<? extends EqlASTNode> list, String separator) {
        if (list != null) {
            for (int i = 0, n = list.size(); i < n; i++) {
                if (i != 0) {
                    print(separator);
                    if (pretty)
                        println();
                }
                visit(list.get(i));
            }
        }
    }

    void printExprList(SqlExprList exprList) {
        for (ISqlExpr expr : exprList.getExprs()) {
            if (expr instanceof EqlASTNode) {
                visit((EqlASTNode) expr);
            } else if (expr instanceof StringSqlExpr) {
                print(((StringSqlExpr) expr).getSqlString());
            } else if (expr instanceof SqlNodeWrapper) {
                printWrappedNode((SqlNodeWrapper) expr);
            } else {
                throw new IllegalArgumentException("not supported:" + expr);
            }
        }
    }

    protected void printWrappedNode(SqlNodeWrapper wrapper) {
        EqlASTNode expr = wrapper.getNode();
        if (expr instanceof SqlQuerySelect) {
            printSelect((SqlQuerySelect) expr);
        } else {
            visit(expr);
        }
    }

    protected static abstract class SqlNodeWrapper implements ISqlExpr {
        private final EqlASTNode node;

        public SqlNodeWrapper(EqlASTNode node) {
            this.node = node;
        }

        public EqlASTNode getNode() {
            return node;
        }

        @Override
        public abstract void appendTo(SQL.SqlBuilder buf);
    }

    protected String normalizeTableName(String tableName) {
        return tableName;
    }

    protected String normalizeColName(String colName) {
        return colName;
    }

    @Override
    public void visitSqlProgram(SqlProgram node) {
        printList(node.getStatements(), ";\n");
    }

    // @Override
    // public void visitSqlIdentifier(SqlIdentifier node) {
    // print(dialect.escapeSQLName(node.getName()));
    // }

    @Override
    public void visitSqlQualifiedName(SqlQualifiedName node) {
        print(node.getFullName());
    }

    @Override
    public void visitSqlTableName(SqlTableName node) {
        sb.markTable(normalizeTableName(node.getFullName()), null, null, false);
    }

    @Override
    public void visitSqlColumnName(SqlColumnName node) {
        if (node.getOwner() != null && !node.getOwner().getFullName().equals(ownerShouldBeIgnored)) {
            visitSqlQualifiedName(node.getOwner());
            print('.');
        }
        String colName = normalizeColName(node.getName());
        print(colName);
    }

    @Override
    public void visitSqlInsert(SqlInsert node) {
        printInsertKeyword();

        print("into ");
        visitSqlTableName(node.getTableName());
        beginBraceBlock();
        printList(node.getColumns(), ",");
        endBraceBlock();
        if (node.getSelect() != null) {
            visit(node.getSelect());
        } else {
            visitSqlValues(node.getValues());
        }
    }

    protected void printInsertKeyword() {
        print("insert ");
    }

    @Override
    public void visitSqlValues(SqlValues node) {
        println();
        print("values(");
        beginBlock();
        printList(node.getValues(), ",");
        endBlock();
        println();
        print(")");
    }

    @Override
    public void visitSqlUpdate(SqlUpdate node) {
        if (node.getAlias() != null)
            this.ownerShouldBeIgnored = node.getAlias().getAlias();

        printUpdateKeyword();
        beginBlock();
        visitSqlTableName(node.getTableName());
        endBlock();
        print("set ");
        beginBlock();
        printList(node.getAssignments(), ",");
        endBlock();
        printWhere(node.getWhere());

        if (node.getReturnProjections() != null && !node.getReturnProjections().isEmpty()) {
            print(" returning ");
            printList(node.getReturnProjections(), ",");
        } else if (node.getReturnAll()) {
            print(" returning *");
        }
    }

    protected void printUpdateKeyword() {
        print("update");
    }

    @Override
    public void visitSqlAlias(SqlAlias node) {
        printAlias(node);
    }

    @Override
    public void visitSqlAssignment(SqlAssignment node) {
        visitSqlColumnName(node.getColumnName());
        print("=");
        printRight(node.getExpr(), SqlOperator.EQ);
    }

    @Override
    public void visitSqlDelete(SqlDelete node) {
        if (node.getAlias() != null)
            this.ownerShouldBeIgnored = node.getAlias().getAlias();

        print("delete\nfrom");
        beginBlock();
        visitSqlTableName(node.getTableName());
        endBlock();
        printWhere(node.getWhere());
    }

    protected void printWhere(SqlWhere where) {
        if (where != null) {
            visitSqlWhere(where);
        }
    }

    @Override
    public void visitSqlWhere(SqlWhere node) {
        if (node.getExpr() == null)
            return;
        print("where ");
        beginBlock();
        visit(node.getExpr());
        endBlock();
    }

    @Override
    public void visitSqlQuerySelect(SqlQuerySelect node) {
        printSelect(node);
    }

    /**
     * Plan 2307 V4：事务控制语句的 EQL round-trip。
     *
     * <p>此前两个输出器都没有 commit/rollback 的 override，落到 Visitor 默认分支，
     * 于是 {@code toEql=[]}——<strong>空字符串</strong>，节点被静默吞掉。
     * 编译通道已由 {@code EqlCompiler} 对其 fail-fast（事务边界不属 EQL 编译器职责），
     * 但 {@code toSqlString()} 旁路仍会被调用来调试/打印 AST，
     * 因此这里补上关键字输出，使 round-trip 无损、不再出现空产物。
     */
    @Override
    public void visitSqlCommit(SqlCommit node) {
        print("commit");
    }

    @Override
    public void visitSqlRollback(SqlRollback node) {
        print("rollback");
    }

    @Override
    public void visitSqlSelectWithCte(SqlSelectWithCte node) {
        List<SqlCteStatement> withCtes = node.getWithCtes();
        if (withCtes != null && !withCtes.isEmpty()) {
            for (int i = 0, n = withCtes.size(); i < n; i++) {
                if (i != 0) {
                    println();
                    print(',');
                } else {
                    print("with ");
                }
                SqlCteStatement stm = withCtes.get(i);
                if (stm.getRecursive()) {
                    print(" recursive ");
                }
                print(stm.getName());
                appendWithColumns(stm);
                print(" as (");
                incIndent();
                println();
                visit(stm.getStatement());
                print(")");
                decIndent();
                println();
            }
        }
        visit(node.getSelect());
    }

    protected void appendWithColumns(SqlCteStatement stm) {

    }

    protected void printSelect(SqlQuerySelect node) {
        print("select ");
        beginBlock();
        if (node.getDistinct()) {
            print("distinct ");
        }
        // WI2 BUG-4: selectAll（select *）此前不回显任何投影文本（`select * from t` 变
        // `select from t`）。仅在解析层形态（selectAll 且 projections 为空）打印 *；
        // transform 展开后的 AST（selectAll 为真且 projections 非空，如分页内嵌渲染）
        // 必须继续打印展开投影，否则裸 * 文本会破坏实体列展开语义。
        if (node.getSelectAll() && node.getProjections().isEmpty()) {
            print("*");
        } else {
            printList(node.getProjections(), ",");
        }
        endBlock();

        if (node.getFrom() != null) {
            visitSqlFrom(node.getFrom());
        }

        printWhere(node);

        if (node.getGroupBy() != null) {
            visitSqlGroupBy(node.getGroupBy());
        }

        if (node.getHaving() != null) {
            visitSqlHaving(node.getHaving());
        }

        if (node.getWindowClause() != null) {
            visitSqlWindowClause(node.getWindowClause());
        }

        if (node.getOrderBy() != null) {
            visitSqlOrderBy(node.getOrderBy());
        }

        printLimit(node);

        if (node.getForUpdate()) {
            printForUpdate(node);
        }
    }

    /**
     * WI2 BUG-4: 回显路径补齐 LIMIT/OFFSET（此前 printSelect 手写遍历从不 visit limit，
     * 回显静默丢弃分页子句）。复用既有 {@code visitSqlLimit}（不删除——
     * {@code _SqlQuerySelect} 的 child 遍历链仍依赖它）。执行路径的 limit 在
     * {@code AstToSqlGenerator.visitSqlQuerySelect} 经
     * {@code dialect.getPaginationHandler().buildPageExpr(...)} 消费并在外层追加分页
     * 文本，子类 override 本方法置空以避免双份 LIMIT/OFFSET。
     */
    protected void printLimit(SqlQuerySelect node) {
        if (node.getLimit() != null) {
            println();
            visitSqlLimit(node.getLimit());
        }
    }

    /**
     * WI1 BUG-3: 回显路径保持硬编码 "for update"（WI0 语料基线只比对 toSqlString()
     * 回显，7 个语料文件均不含 for update，回显治理归 WI2 BUG-4 批次）。执行路径的
     * 方言锁模板消费在子类 AstToSqlGenerator 的 override 中。
     */
    protected void printForUpdate(SqlQuerySelect node) {
        println();
        print("for update");
    }

    protected void printWhere(SqlQuerySelect node) {
        if (node.getWhere() != null) {
            visitSqlWhere(node.getWhere());
        }
    }

    @Override
    public void visitSqlSubQueryExpr(SqlSubQueryExpr node) {
        beginBraceBlock();
        visit(node.getSelect());
        endBraceBlock();
    }

    @Override
    public void visitSqlParameterMarker(SqlParameterMarker node) {
        sb.markValue("?", null, node.isMasked());
    }

    @Override
    public void visitSqlHaving(SqlHaving node) {
        print(" having ");
        beginBlock();
        visit(node.getExpr());
        endBlock();
    }

//    @Override
//    public void visitSqlDecorator(SqlDecorator node) {
//        super.visitSqlDecorator(node);
//    }

    @Override
    public void visitSqlUnionSelect(SqlUnionSelect node) {
        beginBraceBlock();
        visit(node.getLeft());
        endBraceBlock();

        println();
        switch (node.getUnionType()) {
            case UNION_ALL:
                sb.append(" union all ");
                break;
            case INTERSECT_ALL:
                sb.append(" ").append(getIntercectKeyword()).append(" all ");
                break;
            case EXCEPT_ALL:
                sb.append(" ").append(getExceptKeyword()).append(" all ");
                break;
            case INTERSECT:
                sb.append(" ").append(getIntercectKeyword()).append(" ");
                break;
            case EXCEPT:
                sb.append(" ").append(getExceptKeyword()).append(" ");
                break;
            default:
                sb.append(" union ");
        }
        println();
        beginBraceBlock();
        visit(node.getRight());
        endBraceBlock();
    }

    protected String getIntercectKeyword() {
        return "intersect";
    }

    protected String getExceptKeyword() {
        return "except";
    }

    @Override
    public void visitSqlExprProjection(SqlExprProjection node) {
        visit(node.getExpr());
        visitSqlAlias(node.getAlias());
    }

    @Override
    public void visitSqlAllProjection(SqlAllProjection node) {
        if (node.getOwner() != null) {
            visitSqlQualifiedName(node.getOwner());
            print(".");
        }
        print("*");
    }

    @Override
    public void visitSqlOrderBy(SqlOrderBy node) {
        print(" order by ");
        beginBlock();
        printList(node.getItems(), ",");
        endBlock();
    }

    @Override
    public void visitSqlGroupBy(SqlGroupBy node) {
        print("group by ");
        beginBlock();
        printList(node.getItems(), ",");
        endBlock();
    }

    @Override
    public void visitSqlGroupByItem(SqlGroupByItem node) {
        visit(node.getExpr());
    }

    @Override
    public void visitSqlOrderByItem(SqlOrderByItem node) {
        visit(node.getExpr());
        if (node.getAsc()) {
            print(" asc ");
        } else {
            print(" desc ");
        }
        // Plan 2308: 三态 nullsFirst —— null=未请求（不输出任何东西），
        // TRUE/FALSE 分别为 NULLS FIRST / NULLS LAST。
        // 本方法保持**方言无关**：EQL 通道只做字面 round-trip，
        // 方言判定与 CASE 改写全部在 AstToSqlGenerator 的覆写里（见 design §3.8）。
        if (node.getNullsFirst() != null) {
            if (node.getNullsFirst()) {
                print(" nulls first ");
            } else {
                print(" nulls last ");
            }
        }
    }

    @Override
    public void visitSqlLimit(SqlLimit node) {
        if (node.getLimit() != null) {
            print("limit ");
            visit(node.getLimit());
        }
        if (node.getOffset() != null) {
            print(" offset ");
            visit(node.getOffset());
        }
    }

    @Override
    public void visitSqlFrom(SqlFrom node) {
        print("from ");
        beginBlock();
        printList(node.getTableSources(), ",");
        endBlock();
    }

    @Override
    public void visitSqlSingleTableSource(SqlSingleTableSource node) {
        visit(node.getTableName());
        printAlias(node.getAlias());
    }

    @Override
    public void visitSqlJoinTableSource(SqlJoinTableSource node) {
        visit(node.getLeft());
        print(" ");
        incIndent();
        println();
        print(node.getJoinType().getText());
        print(" ");
        visit(node.getRight());
        printJoin(node);
        decIndent();
    }

    /**
     * WI20: render the TUMBLE pseudo-table function back in EQL syntax. The
     * windowed form is stream-only (W2/T1, sql-subset-and-semantics §4c) — the
     * round-trip printing keeps it loud instead of silently dropping the table
     * source (the visitor default visits only interval/alias); the resulting
     * text is NOT executable SQL on an RDBMS, which is the documented boundary.
     */
    @Override
    public void visitSqlTumbleTableSource(io.nop.orm.eql.ast.SqlTumbleTableSource node) {
        print("TUMBLE(");
        print(node.getTableName());
        print(".");
        print(node.getTimeColumn());
        print(", INTERVAL ");
        visit(node.getInterval().getExpr());
        print(" ");
        print(node.getInterval().getIntervalUnit().name());
        print(")");
        printAlias(node.getAlias());
    }

    /**
     * WI12 交付⑤（plan 38）：VALUES 表源回显路径——逐字打印（无方言门，
     * 方言门在子类 AstToSqlGenerator；WI1 BUG-2 lateral 回显同款分层）。
     */
    public void visitSqlValuesTableSource(io.nop.orm.eql.ast.SqlValuesTableSource node) {
        print('(');
        print("values ");
        boolean first = true;
        for (io.nop.orm.eql.ast.SqlMultiValueExpr row : node.getRows()) {
            if (!first)
                print(", ");
            first = false;
            visit(row);
        }
        print(')');
        printAlias(node.getAlias());
        List<String> columns = node.getColumns();
        if (columns != null && !columns.isEmpty()) {
            print('(');
            print(StringHelper.join(columns, ","));
            print(')');
        }
    }

    protected void printJoin(SqlJoinTableSource node) {
        if (node.getCondition() != null) {
            print(" on ");
            visit(node.getCondition());
        }
    }

    @Override
    public void visitSqlSubqueryTableSource(SqlSubqueryTableSource node) {
        // WI1 BUG-2: 回显路径无损打印 lateral 关键字（修复前 lateral (sub) 与 (sub)
        // 输出字节相同）。回显无方言开关——方言门在子类 AstToSqlGenerator。
        // Plan 2307 V1（merge 并集，两分支同缺陷同修复）：LATERAL 必须打印。此前
        // EqlTransformVisitor 会在 getLateral() 为真时放开同级作用域引用（关联子查询），
        // 但输出器从不输出该关键字，导致编译出缺少 LATERAL 的 SQL —— 语义分析认了、
        // 输出没认的静默错误。修复前基线：
        // `select 1 from a, lateral (...) t` -> `from a, ( ... ) as t`
        if (node.getLateral()) {
            print("lateral ");
        }
        print('(');
        beginBlock();
        visit(node.getQuery());
        endBlock();
        print(')');
        printAlias(node.getAlias());
    }

    // @Override
    // public void visitSqlSubQuery(SqlSubQuery node) {
    // print("(");
    // indent();
    // println();
    // visit(node.getSelect());
    // print(")");
    // }

    @Override
    public void visitSqlNotExpr(SqlNotExpr node) {
        printOperator(SqlOperator.NOT);
        print('(');
        println();
        incIndent();
        visit(node.getExpr());
        decIndent();
        println();
        print(')');
    }

    @Override
    public void visitSqlAndExpr(SqlAndExpr node) {
        printBinaryExpr(node.getLeft(), SqlOperator.AND, node.getRight());
    }

    @Override
    public void visitSqlOrExpr(SqlOrExpr node) {
        EqlASTNode parent = node.getASTParent();
        if (parent != null && parent.getASTKind() == EqlASTKind.SqlOrExpr) {
            printBinaryExpr(node.getLeft(), SqlOperator.OR, node.getRight());
        } else {
            print('(');
            printBinaryExpr(node.getLeft(), SqlOperator.OR, node.getRight());
            print(')');
        }
    }

    @Override
    public void visitSqlStringLiteral(SqlStringLiteral node) {
        String str = " '" + StringHelper.escapeSql(node.getValue(), false) + "' ";
        print(str);
    }

    @Override
    public void visitSqlNumberLiteral(SqlNumberLiteral node) {
        print(' ');
        print(node.getValue());
        print(' ');
    }

    @Override
    public void visitSqlDateTimeLiteral(SqlDateTimeLiteral node) {
        print(' ');
        print(node.getType().getText());
        print(" '");
        print(node.getValue());
        print("' ");
    }

    @Override
    public void visitSqlHexadecimalLiteral(SqlHexadecimalLiteral node) {
        print(" X'");
        print(node.getValue());
        print("' ");
    }

    @Override
    public void visitSqlBitValueLiteral(SqlBitValueLiteral node) {
        print(" B'");
        print(node.getValue());
        print("' ");
    }

    @Override
    public void visitSqlBooleanLiteral(SqlBooleanLiteral node) {
        // WI2 BUG-4 字面量一致化（裁定=候选 A）：回显输出 EQL 关键字形态。此前硬编码
        // " 1 "/" 0 "——重解析为 NUMBER 字面量，boolean→integer 类型语义分歧；
        // true/false 经 sqlBooleanLiteral 文法重解析回 SqlBooleanLiteral 同值。
        // 执行路径（AstToSqlGenerator）继续走 dialect.getBooleanValueLiteral 方言形态。
        print(node.getValue() ? " true " : " false ");
    }

    @Override
    public void visitSqlNullLiteral(SqlNullLiteral node) {
        print(" null ");
    }

    @Override
    public void visitSqlBinaryExpr(SqlBinaryExpr node) {
        printBinaryExpr(node.getLeft(), node.getOperator(), node.getRight());
    }

    @Override
    public void visitSqlIsNullExpr(SqlIsNullExpr node) {
        printLeft(node.getExpr(), SqlOperator.IS);
        if (node.getNot()) {
            print(" is not null ");
        } else {
            print(" is null ");
        }
    }

    @Override
    public void visitSqlCompareWithQueryExpr(SqlCompareWithQueryExpr node) {
        printLeft(node.getExpr(), node.getOperator());
        printOperator(node.getOperator());
        if (node.getCompareRange() != null) {
            print(' ');
            printCompareRange(node.getCompareRange());
            print(' ');
        }
        visit(node.getQuery());
    }

    protected void printCompareRange(SqlCompareRange compareRange) {
        print(compareRange.name());
    }

    @Override
    public void visitSqlInQueryExpr(SqlInQueryExpr node) {
        visit(node.getExpr());

        if (node.getNot()) {
            print(" not ");
        }

        print(" in ");
        visit(node.getQuery());
    }

    @Override
    public void visitSqlInValuesExpr(SqlInValuesExpr node) {
        visit(node.getExpr());

        if (node.getNot()) {
            print(" not ");
        }
        print(" in ");

        print("(");
        incIndent();
        println();
        printList(node.getValues(), ",");
        decIndent();
        println();

        print(')');
    }

    @Override
    public void visitSqlBetweenExpr(SqlBetweenExpr node) {
        visit(node.getTest());

        if (node.getNot()) {
            print(" not");
        }
        print(" between ");
        visit(node.getBegin());
        print(" and ");
        visit(node.getEnd());
    }

    @Override
    public void visitSqlLikeExpr(SqlLikeExpr node) {
        if (node.getNot())
            print(" not ");
        printBinaryExpr(node.getExpr(), node.getIgnoreCase() ? SqlOperator.ILIKE : SqlOperator.LIKE, node.getValue());
    }

    @Override
    public void visitSqlUnaryExpr(SqlUnaryExpr node) {
        printOperator(node.getOperator());
        printRight(node.getExpr(), node.getOperator());
    }

    @Override
    public void visitSqlAggregateFunction(SqlAggregateFunction node) {
        print(node.getName());
        print("(");
        if (node.getDistinct()) {
            print(" distinct ");
        }
        if (node.getSelectAll()) {
            print("*");
        } else {
            printList(node.getArgs(), ",");
        }
        print(')');
    }

    @Override
    public void visitSqlRegularFunction(SqlRegularFunction node) {
        print(node.getName());
        print('(');
        printList(node.getArgs(), ",");
        print(')');
    }

    /**
     * WI7b（plan 37，roadmap EC ①）：GROUP BY 位置 grouping 操作符的 echo/执行打印
     * （`ROLLUP(a,b)` / `CUBE(a,b)` 规范大写形态）。执行路径（AstToSqlGenerator）继承本实现
     * ——identity lowering，合法性由 EqlTransformVisitor.visitSqlGroupingOp 的方言能力门保证
     * （裁定文档 §3.2）。GROUPING SETS 永久否决，无第三形态。
     */
    @Override
    public void visitSqlGroupingOp(io.nop.orm.eql.ast.SqlGroupingOp node) {
        print(node.getType().name());
        print('(');
        printList(node.getArgs(), ",");
        print(')');
    }

    @Override
    public void visitSqlMultiValueExpr(SqlMultiValueExpr node) {
        print("(");
        printList(node.getValues(), ",");
        print(")");
    }

    @Override
    public void visitSqlExistsExpr(SqlExistsExpr node) {
        if (node.getNot()) {
            print(" not ");
        }
        print(" exists ");
        visit(node.getQuery());
    }

    // 【merge note / Plan 2307 V3】WI1 BUG-14 的 visitSqlCollectionAccessExpr 显式报错
    // override 已随 master 侧文法删除一并退役：sqlCollectionAccessExpr 规则与
    // SqlCollectionAccessExpr AST 类已移除（无输出器、无语义分析，永不可能产出正确 SQL），
    // 该构造现在于 parse 期即响亮失败（TestEqlRemovedGrammarUnreachable）——比 ours 的
    // 编译期报错更早、同为响亮失败，与本分支排序原则（P1）一致。错误码
    // nop.err.eql.collection-access-not-support 同步退役。

    @Override
    public void visitSqlIntervalExpr(SqlIntervalExpr node) {
        print(" interval ");
        visit(node.getExpr());
        print(" ");
        print(node.getIntervalUnit().name());
    }

    @Override
    public void visitSqlCaseExpr(SqlCaseExpr node) {
        print("case ");
        if (node.getTest() != null) {
            visit(node.getTest());
            print(" ");
        }

        printList(node.getCaseWhens(), " ");

        if (node.getElseExpr() != null) {
            print(" else ");
            visit(node.getElseExpr());
        }

        print(" end");
    }

    @Override
    public void visitSqlCaseWhenItem(SqlCaseWhenItem node) {
        print("when ");
        visit(node.getWhen());
        print(" then ");
        visit(node.getThen());
    }

    @Override
    public void visitSqlCastExpr(SqlCastExpr node) {
        print("cast(");
        visit(node.getExpr());
        print(" as ");
        visit(node.getDataType());
        print(")");
    }

    @Override
    public void visitSqlTypeExpr(SqlTypeExpr node) {
        String typeName = node.getName();
        print(typeName);

        if (node.getPrecision() > 0) {
            print('(');
            print(String.valueOf(node.getPrecision()));
            if (node.getScale() > 0) {
                print(",");
                print(String.valueOf(node.getScale()));
            }
            print(')');
        }
    }

    @Override
    public void visitSqlWindowExpr(SqlWindowExpr node) {
        this.visitChild(node.getFunction());
        if (node.getWindowName() != null) {
            print(" over ");
            print(node.getWindowName());
            return;
        }
        print(" over( ");
        this.visitChild(node.getPartitionBy());
        this.visitChild(node.getOrderBy());
        this.visitChild(node.getFrame());
        print(") ");
    }

    @Override
    public void visitSqlWindowFrame(SqlWindowFrame node) {
        print(' ');
        print(node.getUnit().name().toLowerCase(Locale.ROOT));
        if (node.getEnd() != null) {
            print(" between");
            visitChild(node.getStart());
            print(" and");
            visitChild(node.getEnd());
        } else {
            visitChild(node.getStart());
        }
    }

    @Override
    public void visitSqlWindowFrameBound(SqlWindowFrameBound node) {
        switch (node.getBoundType()) {
            case UNBOUNDED_PRECEDING:
                print(" unbounded preceding");
                break;
            case PRECEDING:
                // offset 表达式打印自带前导间隔，关键字不再补空格
                visitChild(node.getOffset());
                print("preceding");
                break;
            case CURRENT_ROW:
                print(" current row");
                break;
            case FOLLOWING:
                visitChild(node.getOffset());
                print("following");
                break;
            case UNBOUNDED_FOLLOWING:
                print(" unbounded following");
                break;
        }
    }

    @Override
    public void visitSqlWindowClause(SqlWindowClause node) {
        println();
        print("window ");
        List<SqlWindowDecl> decls = node.getItems();
        for (int i = 0, n = decls.size(); i < n; i++) {
            if (i != 0)
                print(", ");
            SqlWindowDecl decl = decls.get(i);
            print(decl.getName());
            print(" as (");
            visitChild(decl.getPartitionBy());
            visitChild(decl.getOrderBy());
            visitChild(decl.getFrame());
            print(" )");
        }
        println();
    }

    @Override
    public void visitSqlPartitionBy(SqlPartitionBy node) {
        print(" partition by ");
        beginBlock();
        printList(node.getItems(), ",");
        endBlock();
    }
}