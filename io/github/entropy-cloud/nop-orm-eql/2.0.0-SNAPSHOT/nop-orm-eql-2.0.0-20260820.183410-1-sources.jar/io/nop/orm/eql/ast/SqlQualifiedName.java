/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.orm.eql.ast;

import io.nop.api.core.util.Guard;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.util.objects.PropPath;
import io.nop.core.lang.ast.ASTNode;
import io.nop.orm.eql.ast._gen._SqlQualifiedName;
import io.nop.orm.eql.enums.SqlCollectionOperator;

public class SqlQualifiedName extends _SqlQualifiedName {
    private SqlTableSource resolvedSource;

    public static SqlQualifiedName valueOf(SourceLocation loc, String name, SqlQualifiedName next) {
        Guard.notEmpty(name, "name");
        SqlQualifiedName ret = new SqlQualifiedName();
        ret.setLocation(loc);
        ret.setName(name);
        ret.setNext(next);
        return ret;
    }

    public SqlCollectionOperator asCollectorOperator() {
        String name = getName();
        return SqlCollectionOperator.fromText(name);
    }

    public boolean containsCollectorOperator() {
        if (asCollectorOperator() != null)
            return true;
        if (getNext() != null)
            return getNext().containsCollectorOperator();
        return false;
    }

    public SqlTableSource getResolvedSource() {
        return resolvedSource;
    }

    public void setResolvedSource(SqlTableSource resolvedSource) {
        this.resolvedSource = resolvedSource;
    }

    @Override
    protected void copyExtFieldsTo(ASTNode node) {
        super.copyExtFieldsTo(node);
        SqlQualifiedName name = (SqlQualifiedName) node;
        name.resolvedSource = resolvedSource;
    }

    public PropPath toPropPath() {
        return toPropPath(null);
    }

    public PropPath toPropPath(PropPath next) {
        return new PropPath(getName(), getNext() == null ? next : getNext().toPropPath(next));
    }

    public String getResolvedName() {
        if (resolvedSource != null)
            return resolvedSource.getAliasName();
        return getFullName();
    }

    public String getFullName() {
        if (getNext() == null)
            return getName();
        StringBuilder sb = new StringBuilder();
        getFullName(sb);
        return sb.toString();
    }

    public void getFullName(StringBuilder sb) {
        if (getNext() == null) {
            sb.append(getName());
        } else {
            sb.append(getName());
            sb.append('.');
            getNext().getFullName(sb);
        }
    }
}
