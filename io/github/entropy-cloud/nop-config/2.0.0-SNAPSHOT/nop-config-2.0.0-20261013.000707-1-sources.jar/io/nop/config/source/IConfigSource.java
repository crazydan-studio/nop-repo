/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.config.source;

import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.ApiStringHelper;
import io.nop.commons.util.objects.ValueWithLocation;

import java.util.Map;

/**
 * 类似于Spring的PropertySource，对应一组配置变量
 */
public interface IConfigSource extends AutoCloseable {
    String getName();

    /**
     * configVars为不变集合，它不会被修改，只会被整体替换。当配置发生变化时，返回的configVars集合将会自动被替换。
     *
     * @return 由本配置源所提供的配置变量
     */
    Map<String, ValueWithLocation> getConfigValues();

    default ValueWithLocation getConfigValue(String name) {
        return getConfigValues().get(name);
    }

    default <T> T getConfigValue(String name, T defaultValue) {
        ValueWithLocation vl = getConfigValue(name);
        if (vl == null)
            return defaultValue;
        Object value = vl.getValue();
        if (ApiStringHelper.isEmptyObject(value))
            return defaultValue;

        if (defaultValue != null) {
            value = ConvertHelper.convertTo(defaultValue.getClass(), value, NopException::new);
        }
        return (T) value;
    }

    /**
     * 当配置发生变化时，会自动触发回调函数。在回调函数中，可以通过configSource.getConfigVars()来获得当前最新的配置变量集合。
     *
     * @param callback 回调函数
     */
    void addOnChange(Runnable callback);

    /**
     * 是否包含以 '%' 为前缀的 profile 变量（如 %dev.xxx）。
     * 返回 false 时跳过 ProfileConfigSource 包装，避免不必要的 map 复制。
     * 默认实现扫描一次 getConfigValues() 的 key 集合。
     */
    default boolean hasProfilePrefixedVars() {
        Map<String, ValueWithLocation> vars = getConfigValues();
        if (vars == null)
            return false;
        for (String name : vars.keySet()) {
            if (!name.isEmpty() && name.charAt(0) == '%')
                return true;
        }
        return false;
    }
}
