/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.dao.jdbc.datasource;

import io.nop.api.core.exceptions.NopException;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.function.Supplier;
import java.util.logging.Logger;

import static io.nop.dao.DaoErrors.ERR_DAO_NO_DATA_SOURCE_AVAILABLE;

public class DynamicDataSource implements DataSource {
    static ThreadLocal<DataSource> s_dataSource = new ThreadLocal<>();

    private DataSource defaultDataSource;

    public DataSource getDefaultDataSource() {
        return defaultDataSource;
    }

    public void setDefaultDataSource(DataSource defaultDataSource) {
        this.defaultDataSource = defaultDataSource;
    }

    public DataSource switchDataSource(DataSource dataSource) {
        DataSource old = s_dataSource.get();
        s_dataSource.set(dataSource);
        return old;
    }

    /**
     * 在指定数据源上执行任务，执行完毕后恢复原数据源。在线程池环境中应优先使用本方法， 而不是手工调用{@link #switchDataSource(DataSource)}，
     * 避免线程复用时遗漏恢复导致跨请求数据串写。
     */
    public static <T> T runWith(DataSource dataSource, Supplier<T> task) {
        DataSource old = s_dataSource.get();
        if (dataSource == null)
            s_dataSource.remove();
        else
            s_dataSource.set(dataSource);
        try {
            return task.get();
        } finally {
            if (old == null)
                s_dataSource.remove();
            else
                s_dataSource.set(old);
        }
    }

    protected DataSource resolveDataSource() {
        DataSource current = s_dataSource.get();
        if (current != null)
            return current;
        DataSource ds = defaultDataSource;
        if (ds == null)
            throw new NopException(ERR_DAO_NO_DATA_SOURCE_AVAILABLE);
        return ds;
    }

    @Override
    public Connection getConnection() throws SQLException {
        return resolveDataSource().getConnection();
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return resolveDataSource().getConnection(username, password);
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return resolveDataSource().getLogWriter();
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {
        resolveDataSource().setLogWriter(out);
    }

    @Override
    public void setLoginTimeout(int seconds) throws SQLException {
        resolveDataSource().setLoginTimeout(seconds);
    }

    @Override
    public int getLoginTimeout() throws SQLException {
        return resolveDataSource().getLoginTimeout();
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isInstance(this)) {
            return (T) this;
        }
        return resolveDataSource().unwrap(iface);
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        if (iface.isInstance(this))
            return true;
        return resolveDataSource().isWrapperFor(iface);
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return resolveDataSource().getParentLogger();
    }
}