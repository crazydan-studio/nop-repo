/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.dao.jdbc;

import io.nop.api.core.time.IEstimatedClock;
import io.nop.core.lang.sql.SQL;
import io.nop.dao.api.ISqlExecutor;
import io.nop.dao.dialect.IDialect;
import io.nop.dao.dialect.IDialectProvider;
import io.nop.dao.metrics.IDaoMetrics;
import io.nop.dao.txn.ITransactionTemplate;
import io.nop.dataset.IDataSetMeta;
import jakarta.annotation.Nonnull;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.function.Function;

public interface IJdbcTemplate extends ISqlExecutor, IDialectProvider {

    IDialect getDialectForQuerySpace(String querySpace);

    IDaoMetrics getDaoMetrics();

    ITransactionTemplate txn();

    Connection currentConnection(String querySpace);

    Connection openConnection(String querySpace);

    <T> T runWithConnection(SQL sql, Function<Connection, T> callback);

    /**
     * 调用数据库函数。sql必须为 {? = call func(...)} 形式的callable语句，
     * 返回第一个OUT参数的值（由框架自动注册），而不是更新计数
     */
    Object callFunc(@Nonnull SQL sql);

    boolean existsTable(String querySpace, String tableName);

    default boolean existsTable(String querySpace, String schemaName, String tableName) {
        return existsTable(querySpace, tableName);
    }

    default boolean existsColumn(String querySpace, String schemaName, String tableName, String columnName) {
        throw new UnsupportedOperationException();
    }

    default boolean existsIndex(String querySpace, String schemaName, String tableName, String indexName) {
        throw new UnsupportedOperationException();
    }

    default boolean existsForeignKey(String querySpace, String schemaName, String tableName, String foreignKeyName) {
        throw new UnsupportedOperationException();
    }

    default boolean existsSequence(String querySpace, String schemaName, String sequenceName) {
        throw new UnsupportedOperationException();
    }

    default boolean existsView(String querySpace, String schemaName, String viewName) {
        throw new UnsupportedOperationException();
    }

    /**
     * 调用数据库的current_timestamp函数来返回数据库当前时间
     *
     * @return 当前时间戳
     */
    Timestamp getDbCurrentTimestamp(String querySpace);

    /**
     * 从数据库获取时间戳本身需要消耗一定的时间，因此返回的是一个时间范围。time = dbTime + now - [fetchBeginTime, fetchEndTime]
     */
    IEstimatedClock getDbEstimatedClock(String querySpace);

    boolean isQuerySpaceDefined(String querySpace);

    IDataSetMeta getTableMeta(String querySpace, String tableName);
}