/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.batch.core.impl;

import io.nop.api.core.context.ContextProvider;
import io.nop.api.core.context.IContext;
import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.time.CoreMetrics;
import io.nop.api.core.util.FutureHelper;
import io.nop.api.core.util.ICancellable;
import io.nop.api.core.util.ProcessResult;
import io.nop.batch.core.BatchTaskGlobals;
import io.nop.batch.core.IBatchChunkContext;
import io.nop.batch.core.IBatchChunkProcessorProvider;
import io.nop.batch.core.IBatchLoaderProvider;
import io.nop.batch.core.IBatchStateStore;
import io.nop.batch.core.IBatchTask;
import io.nop.batch.core.IBatchTaskContext;
import io.nop.batch.core.IBatchTaskMetrics;
import io.nop.batch.core.exceptions.BatchCancelException;
import io.nop.commons.concurrent.executor.GlobalExecutors;
import io.nop.commons.util.StringHelper;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.eval.IEvalFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

import static io.nop.batch.core.BatchErrors.ERR_BATCH_CANCEL_PROCESS;

public class BatchTask<S> implements IBatchTask {
    static final Logger LOG = LoggerFactory.getLogger(BatchTask.class);

    private final String taskName;
    private final long taskVersion;
    private final IEvalFunction taskKeyExpr;
    private final Executor executor;
    private final IBatchLoaderProvider<S> loaderProvider;
    private final IBatchChunkProcessorProvider<S> chunkProcessorProvider;
    private final IBatchStateStore stateStore;
    private final List<Consumer<IBatchTaskContext>> initializers;
    private final int concurrency;

    private final Boolean allowStartIfComplete;
    private final int startLimit;

    public BatchTask(String taskName, long taskVersion,
                     IEvalFunction taskKeyExpr, Executor executor, int concurrency,
                     List<Consumer<IBatchTaskContext>> initializers,
                     IBatchLoaderProvider<S> loaderProvider,
                     IBatchChunkProcessorProvider<S> chunkProcessorProvider, IBatchStateStore stateStore,
                     Boolean allowStartIfComplete, int startLimit) {
        this.taskName = taskName;
        this.taskVersion = taskVersion;
        this.taskKeyExpr = taskKeyExpr;
        this.initializers = initializers;
        this.loaderProvider = loaderProvider;
        this.chunkProcessorProvider = chunkProcessorProvider;
        this.stateStore = stateStore;
        this.concurrency = concurrency <= 0 ? 1 : concurrency;
        this.allowStartIfComplete = allowStartIfComplete;
        this.startLimit = startLimit;
        this.executor = getExecutor(executor);
    }

    static Executor getExecutor(Executor executor) {
        if (executor != null)
            return executor;
        // concurrency在构造器中已归一化为>=1，chunk循环统一由cachedThreadPool执行
        return GlobalExecutors.cachedThreadPool();
    }

    @Override
    public CompletableFuture<Void> executeAsync(IBatchTaskContext context) {
        // 如果context上尚未设置限制，则设置，否则以外部设置的为准
        if (context.getAllowStartIfComplete() == null && allowStartIfComplete != null)
            context.setAllowStartIfComplete(allowStartIfComplete);

        if (context.getStartLimit() <= 0)
            context.setStartLimit(startLimit);

        IBatchTaskMetrics metrics = context.getMetrics();
        Object meter = metrics == null ? null : metrics.beginTask();

        BatchTaskGlobals.provideTaskContext(context);
        try {
            // 如果context中已经设置，则以context中的值为准
            if (context.getTaskName() == null)
                context.setTaskName(taskName);
            if (context.getTaskVersion() == null)
                context.setTaskVersion(taskVersion);

            initTaskKey(context);

            if (stateStore != null) {
                stateStore.loadTaskState(context);
            }

            CompletableFuture<Void> future = new CompletableFuture<>();

            IBatchLoaderProvider.IBatchLoader<S> loader;
            IBatchChunkProcessorProvider.IBatchChunkProcessor<S> chunkProcessor;
            try {
                if (initializers != null)
                    initializers.forEach(initializer -> {
                        initializer.accept(context);
                    });

                if(context.getParams() != null)
                    context.getParams().forEach(context.getEvalScope()::setLocalValue);

                loader = loaderProvider.setup(context);
                chunkProcessor = chunkProcessorProvider.setup(loader, context);

                context.fireTaskBegin();
            } catch (Exception e) {
                // onTaskBegin中有可能分配资源，必须调用onTaskEnd来释放资源
                onTaskComplete(future, meter, e, context);
                return future;
            }

            // 多个线程可以并发执行。loader/processor/consumer都需要是线程安全的
            CompletableFuture<?>[] futures = new CompletableFuture[concurrency];
            for (int i = 0; i < concurrency; i++) {
                futures[i] = executeChunkLoop(context, i, chunkProcessor);
            }

            CompletableFuture.allOf(futures).whenComplete((ret, err) -> {
                onTaskComplete(future, meter, err, context);
            });

            return future;

        } finally {
            BatchTaskGlobals.removeTaskContext();
        }
    }

    static Throwable unwrapCompletionException(Throwable err) {
        while (err instanceof CompletionException && err.getCause() != null)
            err = err.getCause();
        return err;
    }

    void initTaskKey(IBatchTaskContext context) {
        String taskKey = context.getTaskKey();
        if (taskKeyExpr != null && StringHelper.isEmpty(taskKey)) {
            taskKey = ConvertHelper.toString(taskKeyExpr.call1(null, context, context.getEvalScope()));
        }
        if (StringHelper.isEmpty(taskKey))
            taskKey = StringHelper.generateUUID();
        context.setTaskKey(taskKey);
    }

    void onTaskComplete(CompletableFuture<Void> future, Object meter, Throwable err, IBatchTaskContext context) {
        // allOf回调交付的异常被CompletionException包装，这里解包为原始异常，
        // 便于stateStore按异常类型判定任务状态（如BatchCancelException对应KILLED/CANCELLED状态）
        err = unwrapCompletionException(err);

        IBatchTaskMetrics metrics = context.getMetrics();

        try {
            if (err == null) {
                try {
                    context.fireBeforeComplete();

                    // 任务执行完毕之后保存状态到数据库中，然后再触发context.complete()函数通知外部任务完成
                    if (stateStore != null) {
                        stateStore.saveTaskState(true, null, context);
                    }

                    context.complete();
                } catch (Exception e) {
                    err = e;
                }
            }
            if (err != null) {
                try {
                    // 任务执行完毕之后保存状态到数据库中，然后再触发context.complete()函数通知外部任务完成
                    if (stateStore != null) {
                        stateStore.saveTaskState(true, err, context);
                    }
                } finally {
                    context.completeExceptionally(err);
                }
            }
        } finally {
            if (metrics != null)
                metrics.endTask(meter, err == null);

            FutureHelper.complete(future, null, err);
        }
    }

    CompletableFuture<Void> executeChunkLoop(IBatchTaskContext context, int threadIndex,
                                             IBatchChunkProcessorProvider.IBatchChunkProcessor<S> chunkProcessor) {
        CompletableFuture<Void> future = new CompletableFuture<>();

        executor.execute(() -> {
            LOG.info("nop.batch.run-chunk-loop:threadIndex={},threadName={}", threadIndex, Thread.currentThread().getName());
            ContextProvider.runWithContext(ctx -> {
                propagateContext(ctx, context);

                BatchTaskGlobals.provideTaskContext(context);
                try {
                    do {
                        if (context.isCancelled())
                            throw new BatchCancelException(ERR_BATCH_CANCEL_PROCESS);

                        if (processChunk(context, threadIndex, chunkProcessor) != ProcessResult.CONTINUE)
                            break;

                    } while (true);

                    future.complete(null);
                } catch (Exception e) {
                    NopException.logIfNotTraced(LOG, "nop.batch.execute-chunk-loop-fail", e);
                    // 先完成future，确保allOf报告的是原始异常而不是兄弟线程随后抛出的BatchCancelException
                    future.completeExceptionally(e);

                    // fail-fast: 任一chunk失败后通知其他线程尽快停止，避免失败后继续处理剩余数据
                    if (!context.isCancelled())
                        context.cancel(ICancellable.CANCEL_REASON_STOP);
                } finally {
                    BatchTaskGlobals.removeTaskContext();
                }
                return null;
            });

        });
        return future;
    }

    protected void propagateContext(IContext ctx, IBatchTaskContext taskCtx) {
        IServiceContext svcCtx = taskCtx.getServiceContext();
        if (svcCtx == null || svcCtx.getContext() == null || svcCtx.getContext().isClosed()) {
            ctx.setTenantId(null);
            ctx.setLocale(null);
            ctx.setUserName(null);
            ctx.setUserRefNo(null);
            ctx.setUserId(null);
            ctx.setCallIp(null);
            ctx.setTimezone(null);
            ctx.setTraceId(null);
            ctx.setPropagateRpcHeaders(null);
            return;
        }

        IContext baseCtx = svcCtx.getContext();
        if (baseCtx == ctx)
            return;

        ContextProvider.propagateContext(ctx, baseCtx, true);
    }

    /**
     * 读取并处理一个chunk, 返回STOP表示已经读取完毕
     */
    protected ProcessResult processChunk(IBatchTaskContext context, int threadIndex,
                                         IBatchChunkProcessorProvider.IBatchChunkProcessor<S> chunkProcessor) {
        IBatchChunkContext chunkContext = context.newChunkContext();
        chunkContext.setConcurrency(concurrency);
        chunkContext.setThreadIndex(threadIndex);

        IBatchTaskMetrics metrics = context.getMetrics();

        Object meter = metrics == null ? null : metrics.beginChunk();

        long beginTime = CoreMetrics.currentTimeMillis();
        LOG.info("nop.batch.process-chunk-begin:taskName={},taskId={},taskKey={},threadIndex={},processCount={}.skipCount={},retryCount={},completeCount={},completedIndex={}",
                context.getTaskName(), context.getTaskId(), context.getTaskKey(), threadIndex,
                context.getProcessItemCount(), context.getSkipItemCount(), context.getRetryItemCount(),
                context.getCompleteItemCount(), context.getCompletedIndex());

        boolean syncCount = false;
        ProcessResult result;
        boolean success = true;
        try {
            chunkContext.getTaskContext().fireChunkBegin(chunkContext);

            result = chunkProcessor.process(chunkContext);

            chunkContext.fireBeforeComplete();

            chunkContext.getTaskContext().fireBeforeChunkEnd(chunkContext);

            incCount(context, chunkContext);

            syncCount = true;

            if (stateStore != null)
                stateStore.saveTaskState(false, null, context);

            chunkContext.complete();
            chunkContext.getTaskContext().fireChunkEnd(chunkContext, null);

        } catch (Exception e) {
            success = false;
            LOG.error("nop.err.batch.task-chunk-fail:taskName={},taskId={},taskKey={},threadIndex={}",
                    context.getTaskName(), context.getTaskId(), context.getTaskKey(), threadIndex,
                    e);

            if (!syncCount) {
                incCount(context, chunkContext);
            }

            try {
                chunkContext.getTaskContext().fireChunkEnd(chunkContext, e);

                if (stateStore != null)
                    stateStore.saveTaskState(false, e, context);
            } finally {
                chunkContext.completeExceptionally(e);
            }

            // chunk处理失败时退出循环
            throw e;
        } finally {
            long endTime = CoreMetrics.currentTimeMillis();
            LOG.info("nop.batch.process-chunk-end:taskName={},taskId={},taskKey={},threadIndex={},usedTime={}," +
                            "processCount={}.skipCount={},retryCount={},completeCount={},historyCount={},completedIndex={}", context.getTaskName(),
                    context.getTaskId(), context.getTaskKey(), threadIndex, endTime - beginTime,
                    context.getProcessItemCount(), context.getSkipItemCount(), context.getRetryItemCount(),
                    context.getCompleteItemCount(), context.getHistoryItemCount(), context.getCompletedIndex());

            if (metrics != null)
                metrics.endChunk(meter, success);
        }

        return result;
    }

    void incCount(IBatchTaskContext context, IBatchChunkContext chunkContext) {
        context.incCompleteItemCount(chunkContext.getCompletedItemCount() - chunkContext.getHistoryItemCount());
        context.incHistoryItemCount(chunkContext.getHistoryItemCount());
    }
}