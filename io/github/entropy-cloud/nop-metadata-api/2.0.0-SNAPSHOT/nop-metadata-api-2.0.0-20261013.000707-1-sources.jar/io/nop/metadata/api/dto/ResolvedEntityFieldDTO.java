
package io.nop.metadata.api.dto;

import io.nop.api.core.annotations.data.DataBean;

import java.io.Serializable;

/**
 * 解析后字段 DTO（来源：{@code NopMetaEntityBizModel.resolveEntityFields}）。
 */
@DataBean
public class ResolvedEntityFieldDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String sourceType;
    private String type;

    public ResolvedEntityFieldDTO() {
    }

    public ResolvedEntityFieldDTO(String name, String sourceType, String type) {
        this.name = name;
        this.sourceType = sourceType;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
