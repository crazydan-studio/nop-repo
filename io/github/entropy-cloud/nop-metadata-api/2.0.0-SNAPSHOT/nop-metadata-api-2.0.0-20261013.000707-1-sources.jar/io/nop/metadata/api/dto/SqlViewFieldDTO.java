
package io.nop.metadata.api.dto;

import io.nop.api.core.annotations.data.DataBean;

import java.io.Serializable;

/**
 * SQL 视图字段 DTO（来源：{@code NopMetaEntityBizModel.createSqlView} / {@code previewSqlFields}）。
 */
@DataBean
public class SqlViewFieldDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String alias;
    private String type;

    public SqlViewFieldDTO() {
    }

    public SqlViewFieldDTO(String name, String alias, String type) {
        this.name = name;
        this.alias = alias;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
