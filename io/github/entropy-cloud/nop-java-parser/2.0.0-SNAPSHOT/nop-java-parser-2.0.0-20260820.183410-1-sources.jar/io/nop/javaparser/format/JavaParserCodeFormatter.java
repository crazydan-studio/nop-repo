package io.nop.javaparser.format;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.printer.DefaultPrettyPrinter;
import com.github.javaparser.printer.configuration.DefaultConfigurationOption;
import com.github.javaparser.printer.configuration.DefaultPrinterConfiguration;
import com.github.javaparser.printer.configuration.PrinterConfiguration;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.text.formatter.ITextFormatter;
import io.nop.commons.util.StringHelper;
import io.nop.javaparser.utils.JavaParserHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static io.nop.javaparser.JavaParserErrors.ARG_PARSE_RESULT;
import static io.nop.javaparser.JavaParserErrors.ERR_JAVA_PARSER_PARSE_FAILED;

public class JavaParserCodeFormatter implements ITextFormatter {
    static final Logger LOG = LoggerFactory.getLogger(JavaParserCodeFormatter.class);

    public static JavaParserCodeFormatter INSTANCE = new JavaParserCodeFormatter();

    // 默认配置
    private static final PrinterConfiguration DEFAULT_CONFIG =
            new DefaultPrinterConfiguration()
                    .addOption(new DefaultConfigurationOption(
                            DefaultPrinterConfiguration.ConfigOption.END_OF_LINE_CHARACTER, "\n"));

    // 使用 JAVA_17 语言级别创建 JavaParser
    private static final JavaParser JAVA_PARSER = new JavaParser(
            new ParserConfiguration().setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_17));

    public String formatCompilationUnit(CompilationUnit cu) {
        return new DefaultPrettyPrinter(DEFAULT_CONFIG).print(cu);
    }

    @Override
    public String format(SourceLocation loc, String sourceCode, boolean ignoreErrors) {
        if (StringHelper.isBlank(sourceCode)) {
            if (ignoreErrors)
                return sourceCode;
            else
                throw new IllegalArgumentException("sourceCode is empty");
        }

        // 解析源代码（使用 JAVA_17 语言级别）
        ParseResult<CompilationUnit> parseResult = JAVA_PARSER.parse(sourceCode);

        if (parseResult.isSuccessful() && parseResult.getResult().isPresent()) {
            // 格式化代码
            return formatCompilationUnit(parseResult.getResult().get());
        } else {
            SourceLocation problemLoc = JavaParserHelper.getProblemLocation(loc, parseResult.getProblems().get(0));
            // 解析失败时返回原始代码（或可以抛出异常）
            if (ignoreErrors) {
                LOG.info("nop.java.parse-failed:loc={},result={}", problemLoc, parseResult);
                return sourceCode;
            }

            throw new NopException(ERR_JAVA_PARSER_PARSE_FAILED).loc(problemLoc).param(ARG_PARSE_RESULT, parseResult.toString());
        }
    }
}
