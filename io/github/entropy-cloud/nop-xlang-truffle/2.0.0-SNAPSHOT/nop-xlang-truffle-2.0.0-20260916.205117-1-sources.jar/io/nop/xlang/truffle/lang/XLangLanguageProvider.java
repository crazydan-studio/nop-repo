// CheckStyle: start generated
package io.nop.xlang.truffle.lang;

import com.oracle.truffle.api.TruffleLanguage.ContextPolicy;
import com.oracle.truffle.api.TruffleLanguage.Registration;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.provider.TruffleLanguageProvider;
import java.util.Collection;
import java.util.List;

@GeneratedBy(XLangLanguage.class)
@Registration(characterMimeTypes = "application/x-xlang", contextPolicy = ContextPolicy.SHARED, defaultMimeType = "application/x-xlang", id = "xl", name = "XLang", version = "1.0.0")
public final class XLangLanguageProvider extends TruffleLanguageProvider {

    @Override
    protected String getLanguageClassName() {
        return "io.nop.xlang.truffle.lang.XLangLanguage";
    }

    @Override
    protected Object create() {
        return new XLangLanguage();
    }

    @Override
    protected Collection<String> getServicesClassNames() {
        return List.of();
    }

    @Override
    protected List<?> createFileTypeDetectors() {
        return List.of();
    }

    @Override
    protected List<String> getInternalResourceIds() {
        return List.of();
    }

    @Override
    protected Object createInternalResource(String resourceId) {
        throw new IllegalArgumentException(String.format("Unsupported internal resource id %s, supported ids are ", resourceId));
    }

}
