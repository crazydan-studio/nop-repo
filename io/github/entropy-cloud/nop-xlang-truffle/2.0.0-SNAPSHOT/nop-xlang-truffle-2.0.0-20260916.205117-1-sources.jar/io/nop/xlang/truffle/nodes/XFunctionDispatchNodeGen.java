// CheckStyle: start generated
package io.nop.xlang.truffle.nodes;

import com.oracle.truffle.api.CallTarget;
import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.HostCompilerDirectives.InliningRoot;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.NeverDefault;
import com.oracle.truffle.api.dsl.DSLSupport.SpecializationDataNode;
import com.oracle.truffle.api.dsl.InlineSupport.ReferenceField;
import com.oracle.truffle.api.dsl.InlineSupport.UnsafeAccessedField;
import com.oracle.truffle.api.nodes.DenyReplace;
import com.oracle.truffle.api.nodes.DirectCallNode;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import io.nop.api.core.util.SourceLocation;
import io.nop.core.lang.eval.IEvalScope;
import java.lang.invoke.MethodHandles;

/**
 * Debug Info: <pre>
 *   Specialization {@link XFunctionDispatchNode#dispatchDirect}
 *     Activation probability: 0.65000
 *     With/without class size: 22/8 bytes
 *   Specialization {@link XFunctionDispatchNode#dispatchGeneric}
 *     Activation probability: 0.35000
 *     With/without class size: 8/0 bytes
 * </pre> */
@GeneratedBy(XFunctionDispatchNode.class)
@SuppressWarnings("javadoc")
public final class XFunctionDispatchNodeGen extends XFunctionDispatchNode {

    static final ReferenceField<DispatchDirectData> DISPATCH_DIRECT_CACHE_UPDATER = ReferenceField.create(MethodHandles.lookup(), "dispatchDirect_cache", DispatchDirectData.class);

    /**
     * State Info: <pre>
     *   0: SpecializationActive {@link XFunctionDispatchNode#dispatchDirect}
     *   1: SpecializationActive {@link XFunctionDispatchNode#dispatchGeneric}
     * </pre> */
    @CompilationFinal private int state_0_;
    @UnsafeAccessedField @Child private DispatchDirectData dispatchDirect_cache;

    private XFunctionDispatchNodeGen() {
    }

    @InliningRoot
    @ExplodeLoop
    @Override
    public Object executeDispatch(SourceLocation arg0Value, String arg1Value, boolean arg2Value, IEvalScope arg3Value, Object arg4Value, Object[] arg5Value) {
        int state_0 = this.state_0_;
        if (state_0 != 0 /* is SpecializationActive[XFunctionDispatchNode.dispatchDirect(SourceLocation, String, boolean, IEvalScope, Object, Object[], CallTarget, DirectCallNode)] || SpecializationActive[XFunctionDispatchNode.dispatchGeneric(SourceLocation, String, boolean, IEvalScope, Object, Object[])] */) {
            if ((state_0 & 0b1) != 0 /* is SpecializationActive[XFunctionDispatchNode.dispatchDirect(SourceLocation, String, boolean, IEvalScope, Object, Object[], CallTarget, DirectCallNode)] */ && (XFunctionDispatchNode.isTruffleFunction(arg4Value))) {
                DispatchDirectData s0_ = this.dispatchDirect_cache;
                while (s0_ != null) {
                    if ((XFunctionDispatchNode.targetOf(arg4Value) == s0_.cachedTarget_)) {
                        return dispatchDirect(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, s0_.cachedTarget_, s0_.callNode_);
                    }
                    s0_ = s0_.next_;
                }
            }
            if ((state_0 & 0b10) != 0 /* is SpecializationActive[XFunctionDispatchNode.dispatchGeneric(SourceLocation, String, boolean, IEvalScope, Object, Object[])] */) {
                return dispatchGeneric(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
    }

    private Object executeAndSpecialize(SourceLocation arg0Value, String arg1Value, boolean arg2Value, IEvalScope arg3Value, Object arg4Value, Object[] arg5Value) {
        int state_0 = this.state_0_;
        if (((state_0 & 0b10)) == 0 /* is-not SpecializationActive[XFunctionDispatchNode.dispatchGeneric(SourceLocation, String, boolean, IEvalScope, Object, Object[])] */ && (XFunctionDispatchNode.isTruffleFunction(arg4Value))) {
            while (true) {
                int count0_ = 0;
                DispatchDirectData s0_ = DISPATCH_DIRECT_CACHE_UPDATER.getVolatile(this);
                DispatchDirectData s0_original = s0_;
                while (s0_ != null) {
                    if ((XFunctionDispatchNode.targetOf(arg4Value) == s0_.cachedTarget_)) {
                        break;
                    }
                    count0_++;
                    s0_ = s0_.next_;
                }
                if (s0_ == null) {
                    {
                        CallTarget cachedTarget__ = (XFunctionDispatchNode.targetOf(arg4Value));
                        if ((XFunctionDispatchNode.targetOf(arg4Value) == cachedTarget__) && count0_ < (3)) {
                            s0_ = this.insert(new DispatchDirectData(s0_original));
                            s0_.cachedTarget_ = cachedTarget__;
                            s0_.callNode_ = s0_.insert((XFunctionDispatchNode.createDirectCall(cachedTarget__)));
                            if (!DISPATCH_DIRECT_CACHE_UPDATER.compareAndSet(this, s0_original, s0_)) {
                                continue;
                            }
                            state_0 = state_0 | 0b1 /* add SpecializationActive[XFunctionDispatchNode.dispatchDirect(SourceLocation, String, boolean, IEvalScope, Object, Object[], CallTarget, DirectCallNode)] */;
                            this.state_0_ = state_0;
                        }
                    }
                }
                if (s0_ != null) {
                    return dispatchDirect(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value, s0_.cachedTarget_, s0_.callNode_);
                }
                break;
            }
        }
        this.dispatchDirect_cache = null;
        state_0 = state_0 & 0xfffffffe /* remove SpecializationActive[XFunctionDispatchNode.dispatchDirect(SourceLocation, String, boolean, IEvalScope, Object, Object[], CallTarget, DirectCallNode)] */;
        state_0 = state_0 | 0b10 /* add SpecializationActive[XFunctionDispatchNode.dispatchGeneric(SourceLocation, String, boolean, IEvalScope, Object, Object[])] */;
        this.state_0_ = state_0;
        return dispatchGeneric(arg0Value, arg1Value, arg2Value, arg3Value, arg4Value, arg5Value);
    }

    @NeverDefault
    public static XFunctionDispatchNode create() {
        return new XFunctionDispatchNodeGen();
    }

    @GeneratedBy(XFunctionDispatchNode.class)
    @DenyReplace
    private static final class DispatchDirectData extends Node implements SpecializationDataNode {

        @Child DispatchDirectData next_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link XFunctionDispatchNode#dispatchDirect}
         *   Parameter: {@link CallTarget} cachedTarget</pre> */
        @CompilationFinal CallTarget cachedTarget_;
        /**
         * Source Info: <pre>
         *   Specialization: {@link XFunctionDispatchNode#dispatchDirect}
         *   Parameter: {@link DirectCallNode} callNode</pre> */
        @Child DirectCallNode callNode_;

        DispatchDirectData(DispatchDirectData next_) {
            this.next_ = next_;
        }

    }
}
