/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://github.com/entropy-cloud/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.rocksdb;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.nop.stream.core.common.accumulators.SimpleAccumulator;
import io.nop.stream.core.common.functions.AggregateFunction;
import io.nop.stream.core.common.state.AggregatingState;
import io.nop.stream.core.common.state.AggregatingStateDescriptor;
import io.nop.stream.core.common.state.InternalAppendingState;
import io.nop.stream.core.common.state.InternalListState;
import io.nop.stream.core.common.state.ListState;
import io.nop.stream.core.common.state.ListStateDescriptor;
import io.nop.stream.core.common.state.MapState;
import io.nop.stream.core.common.state.MapStateDescriptor;
import io.nop.stream.core.common.state.ReducingState;
import io.nop.stream.core.common.state.ReducingStateDescriptor;
import io.nop.stream.core.common.state.StateDescriptor;
import io.nop.stream.core.common.state.StateSchemaResolver;
import io.nop.stream.core.common.state.TtlContext;
import io.nop.stream.core.common.state.ValueState;
import io.nop.stream.core.common.state.ValueStateDescriptor;
import io.nop.stream.core.checkpoint.SerializerFingerprint;
import io.nop.stream.core.common.state.backend.ContainerValueCodec;
import io.nop.stream.core.common.state.backend.StateSnapshot;
import io.nop.stream.core.common.state.shard.KeyGroupRange;
import io.nop.stream.core.common.state.shard.KeyGroupRangeRestoreFilter;
import io.nop.stream.core.util.ClassNameValidator;

import org.rocksdb.ColumnFamilyHandle;
import org.rocksdb.RocksIterator;

import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_STATE_ERROR;

/**
 * Snapshot/restore for {@link RocksDBKeyedStateBackend}.
 *
 * <p>Produces a {@link StateSnapshot} byte-compatible with
 * {@code MemoryStateSerDe}: the same 8 {@code stateType} branches, per-type
 * info-map keys, and entry discriminators. Snapshot persists raw user keys;
 * restore re-routes via the backend's shard logic.
 */
final class RocksDBSnapshotSerDe {

    private RocksDBSnapshotSerDe() {
    }

    /**
     * Returns {@code true} if the base composite key of {@code fullKey} is marked expired
     * by {@code ttl}. For non-map states the base key is the full key; for map state the
     * base key is the prefix shared by all entries of one map, so the whole map is skipped.
     * When {@code ttl} is {@code null} (TTL disabled) nothing is skipped.
     */
    private static boolean expiredForSnapshot(TtlContext<ByteBuffer> ttl, byte[] fullKey) {
        if (ttl == null) {
            return false;
        }
        int baseLen = RocksDBKeyEncoder.baseKeyLength(fullKey);
        return ttl.isExpiredForSnapshot(ByteBuffer.wrap(fullKey, 0, baseLen));
    }

    // ------------------------------------------------------------------------
    //  snapshot
    // ------------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    static StateSnapshot snapshotState(RocksDBKeyedStateBackend<?> backend) throws Exception {
        Map<String, Object> states = backend.getStates();
        if (states.isEmpty()) {
            return null;
        }

        Map<String, Object> stateData = new LinkedHashMap<>();
        stateData.put("keyType", backend.getKeyType().getName());
        // Stage 34: stamp the binary key-layout version for observability and
        // so the restore path can detect (and reject) incompatible legacy
        // RocksDB snapshots. The full snapshot stores raw user keys, so an
        // absent version (cross-backend Memory snapshot) remains restorable.
        stateData.put(RocksDBKeyEncoder.KEY_LAYOUT_VERSION_FIELD, RocksDBKeyEncoder.KEY_LAYOUT_VERSION);

        Map<String, Object> statesMap = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : states.entrySet()) {
            String stateName = entry.getKey();
            Object stateObj = entry.getValue();

            if (stateObj instanceof RocksDBValueState) {
                statesMap.put(stateName, snapshotValueState(backend, (RocksDBValueState<?>) stateObj));
            } else if (stateObj instanceof RocksDBMapState) {
                statesMap.put(stateName, snapshotMapState(backend, (RocksDBMapState<?, ?>) stateObj));
            } else if (stateObj instanceof RocksDBListState) {
                statesMap.put(stateName, snapshotListState(backend, (RocksDBListState<?>) stateObj, "ListState",
                        StateSchemaResolver.STATE_TYPE_LIST));
            } else if (stateObj instanceof RocksDBInternalListState) {
                statesMap.put(stateName, snapshotInternalListState(backend,
                        (RocksDBInternalListState<?, ?, ?>) stateObj));
            } else if (stateObj instanceof RocksDBInternalAppendingState) {
                statesMap.put(stateName, snapshotAppendingState(backend,
                        (RocksDBInternalAppendingState<?, ?, ?>) stateObj));
            } else if (stateObj instanceof RocksDBInternalAggregatingState) {
                statesMap.put(stateName, snapshotInternalAggregatingState(backend,
                        (RocksDBInternalAggregatingState<?, ?, ?, ?, ?>) stateObj));
            } else if (stateObj instanceof RocksDBReducingState) {
                statesMap.put(stateName, snapshotReducingState(backend, (RocksDBReducingState<?>) stateObj));
            } else if (stateObj instanceof RocksDBAggregatingState) {
                statesMap.put(stateName, snapshotAggregatingState(backend,
                        (RocksDBAggregatingState<?, ?, ?>) stateObj));
            } else {
                throw new StreamException(ERR_STREAM_STATE_ERROR)
                        .param(ARG_DETAIL, "Unknown state type during snapshot: " + stateObj.getClass().getName());
            }
        }
        stateData.put("states", statesMap);

        return new StateSnapshot(stateData);
    }

    private static void embedSchemaFingerprint(Map<String, Object> info, String stateType,
                                               StateDescriptor<?> descriptor, int shardCount) {
        SerializerFingerprint fingerprint = StateSchemaResolver.fromDescriptor(stateType, descriptor);
        info.put("schemaChecksum", fingerprint.getSchemaChecksum());
        info.put("schemaVersion", fingerprint.getSchemaVersion());
        if (shardCount > 1) {
            info.put("shardCount", shardCount);
        }
    }

    private static Map<String, Object> snapshotValueState(RocksDBKeyedStateBackend<?> backend,
                                                          RocksDBValueState<?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "ValueState");
        info.put("valueType", state.descriptor.getValueType().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_VALUE, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                Object value = RocksDBValueSerDe.deserialize(it.value(), state.descriptor.getValueType());
                entry.put("value", value);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotMapState(RocksDBKeyedStateBackend<?> backend,
                                                       RocksDBMapState<?, ?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "MapState");
        info.put("valueType", state.descriptor.getValueType().getName());
        info.put("mapKeyType", state.descriptor.getKeyClass().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_MAP, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        Map<String, Map<String, Object>> grouped = new LinkedHashMap<>();
        Map<String, List<List<Object>>> groupedMapValues = new LinkedHashMap<>();

        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                byte[] fullKey = it.key();
                if (expiredForSnapshot(ttl, fullKey)) {
                    continue;
                }
                int baseLen = RocksDBKeyEncoder.baseKeyLength(fullKey);
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(fullKey, backend.getKeyType());
                String groupKey = dk.namespace + "|" + dk.rawKey;
                Map<String, Object> entry = grouped.get(groupKey);
                if (entry == null) {
                    entry = new LinkedHashMap<>();
                    entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                    entry.put("key", dk.rawKey);
                    grouped.put(groupKey, entry);
                    groupedMapValues.put(groupKey, new ArrayList<>());
                }
                Object mapKey = extractMapKey(fullKey, baseLen, state.descriptor.getKeyClass());
                // P1-21-01: container values are stored as the element-type wrapper
                // (see ContainerValueCodec); parse them JSON-natively so the snapshot
                // carries the wrapper (same format as the Memory backend after the
                // storage-layer JSON round trip). Non-container values keep the plain
                // deserialize path.
                Object mapValue;
                Class<?> valueType = state.descriptor.getValueType();
                if (ContainerValueCodec.isContainerType(valueType)) {
                    mapValue = io.nop.core.lang.json.JsonTool.parseNonStrict(
                            new String(it.value(), java.nio.charset.StandardCharsets.UTF_8));
                } else {
                    mapValue = RocksDBValueSerDe.deserialize(it.value(), valueType);
                }
                List<Object> pair = new ArrayList<>();
                pair.add(mapKey);
                pair.add(mapValue);
                groupedMapValues.get(groupKey).add(pair);
            }
        }
        for (Map.Entry<String, Map<String, Object>> e : grouped.entrySet()) {
            e.getValue().put("mapValue", groupedMapValues.get(e.getKey()));
            entries.add(e.getValue());
        }
        info.put("entries", entries);
        return info;
    }

    @SuppressWarnings("unchecked")
    private static Object extractMapKey(byte[] fullKey, int baseLen, Class<?> mapKeyClass) {
        int mapKeyLen = ((fullKey[baseLen] & 0xFF) << 24)
                | ((fullKey[baseLen + 1] & 0xFF) << 16)
                | ((fullKey[baseLen + 2] & 0xFF) << 8)
                | (fullKey[baseLen + 3] & 0xFF);
        byte[] mapKeyBytes = new byte[mapKeyLen];
        System.arraycopy(fullKey, baseLen + 4, mapKeyBytes, 0, mapKeyLen);
        if (mapKeyBytes.length == 0) {
            return null;
        }
        String json = new java.lang.String(mapKeyBytes, java.nio.charset.StandardCharsets.UTF_8);
        if (mapKeyClass != null && mapKeyClass != Object.class) {
            return io.nop.core.lang.json.JsonTool.parseBeanFromText(json, mapKeyClass);
        }
        return io.nop.core.lang.json.JsonTool.parseNonStrict(json);
    }

    private static Map<String, Object> snapshotListState(RocksDBKeyedStateBackend<?> backend,
                                                         RocksDBListState<?> state, String stateTypeName,
                                                         String schemaStateType) throws Exception {
        ListStateDescriptor<?> descriptor = state.descriptor;
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", stateTypeName);
        info.put("valueType", descriptor.getValueType().getName());
        embedSchemaFingerprint(info, schemaStateType, descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                List<Object> list = RocksDBValueSerDe.deserializeList(it.value(), descriptor.getValueType());
                entry.put("listValue", list);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotInternalListState(RocksDBKeyedStateBackend<?> backend,
                                                                 RocksDBInternalListState<?, ?, ?> state) throws Exception {
        ListStateDescriptor<?> descriptor = state.descriptor;
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "InternalListState");
        info.put("valueType", descriptor.getValueType().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_INTERNAL_LIST, descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                List<Object> list = RocksDBValueSerDe.deserializeList(it.value(), descriptor.getValueType());
                entry.put("listValue", list);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotAppendingState(RocksDBKeyedStateBackend<?> backend,
                                                              RocksDBInternalAppendingState<?, ?, ?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "AppendingState");
        info.put("valueType", state.descriptor.getValueType().getName());
        info.put("accumulatorType", state.descriptor.getAccumulatorType().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_APPENDING, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                Object value = RocksDBValueSerDe.deserialize(it.value(), state.descriptor.getValueType());
                if (value instanceof List) {
                    entry.put("value", new ArrayList<>((List<?>) value));
                } else {
                    entry.put("value", value);
                }
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotReducingState(RocksDBKeyedStateBackend<?> backend,
                                                             RocksDBReducingState<?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "ReducingState");
        info.put("valueType", state.descriptor.getValueType().getName());
        info.put("accumulatorType", state.descriptor.getAccumulatorType().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_REDUCING, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                Object value = RocksDBValueSerDe.deserialize(it.value(), state.descriptor.getValueType());
                entry.put("value", value);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotAggregatingState(RocksDBKeyedStateBackend<?> backend,
                                                               RocksDBAggregatingState<?, ?, ?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "AggregatingState");
        info.put("valueType", state.descriptor.getValueType().getName());
        info.put("aggregateFunctionType", state.descriptor.getAggregateFunction().getClass().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_AGGREGATING, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                Object value = RocksDBValueSerDe.deserialize(it.value(), state.descriptor.getValueType());
                entry.put("value", value);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    private static Map<String, Object> snapshotInternalAggregatingState(RocksDBKeyedStateBackend<?> backend,
                                                                       RocksDBInternalAggregatingState<?, ?, ?, ?, ?> state) throws Exception {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("stateType", "InternalAggregatingState");
        info.put("valueType", state.descriptor.getValueType().getName());
        info.put("aggregateFunctionType", state.descriptor.getAggregateFunction().getClass().getName());
        embedSchemaFingerprint(info, StateSchemaResolver.STATE_TYPE_INTERNAL_AGGREGATING, state.descriptor, backend.getShardCount());

        List<Map<String, Object>> entries = new ArrayList<>();
        TtlContext<ByteBuffer> ttl = state.ttlContext();
        try (RocksIterator it = backend.getDb().newIterator(state.cfHandle)) {
            for (it.seekToFirst(); it.isValid(); it.next()) {
                if (expiredForSnapshot(ttl, it.key())) {
                    continue;
                }
                RocksDBKeyEncoder.DecodedKey dk = RocksDBKeyEncoder.decode(it.key(), backend.getKeyType());
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("namespace", RocksDBKeyEncoder.serializeNamespace(dk.namespace));
                entry.put("key", dk.rawKey);
                Object value = RocksDBValueSerDe.deserialize(it.value(), state.descriptor.getValueType());
                entry.put("value", value);
                entries.add(entry);
            }
        }
        info.put("entries", entries);
        return info;
    }

    // ------------------------------------------------------------------------
    //  restore
    // ------------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    static void restoreState(RocksDBKeyedStateBackend<?> backend, StateSnapshot snapshot) throws Exception {
        if (snapshot == null || snapshot.isEmpty()) {
            return;
        }

        // Stage 34: reject snapshots that carry an incompatible RocksDB binary
        // key layout. An absent version field is tolerated on the full path
        // (raw user keys are layout-agnostic, e.g. cross-backend Memory snapshots).
        RocksDBKeyEncoder.verifyKeyLayoutVersion(snapshot.getStateData(), false);

        Map<String, Object> stateData = snapshot.getStateData();
        Map<String, Object> statesMap = (Map<String, Object>) stateData.get("states");
        if (statesMap == null || statesMap.isEmpty()) {
            return;
        }

        clearAllStates(backend);
        backend.getStates().clear();

        // Stage 35: per-subtask partial restore. When the backend carries a
        // target KeyGroupRange, reduce each state's entries to those whose key
        // is owned by the range before writing them to RocksDB. This is the
        // in-memory entry-filter counterpart of the incremental SST range scan.
        KeyGroupRange range = backend.getTargetKeyGroupRange();
        Map<String, Object> effectiveStatesMap = statesMap;
        if (range != null) {
            effectiveStatesMap = KeyGroupRangeRestoreFilter.filterKeyedStates(
                    statesMap, range, backend.getMaxParallelism());
        }

        for (Map.Entry<String, Object> entry : effectiveStatesMap.entrySet()) {
            String stateName = entry.getKey();
            Map<String, Object> stateInfo = (Map<String, Object>) entry.getValue();
            String stateType = (String) stateInfo.get("stateType");

            switch (stateType) {
                case "ValueState":
                    restoreValueState(backend, stateName, stateInfo);
                    break;
                case "MapState":
                    restoreMapState(backend, stateName, stateInfo);
                    break;
                case "AppendingState":
                    restoreAppendingState(backend, stateName, stateInfo);
                    break;
                case "ListState":
                    restoreListState(backend, stateName, stateInfo);
                    break;
                case "InternalListState":
                    restoreInternalListState(backend, stateName, stateInfo);
                    break;
                case "ReducingState":
                    restoreReducingState(backend, stateName, stateInfo);
                    break;
                case "AggregatingState":
                    restoreAggregatingState(backend, stateName, stateInfo);
                    break;
                case "InternalAggregatingState":
                    restoreInternalAggregatingState(backend, stateName, stateInfo);
                    break;
                default:
                    throw new StreamException(ERR_STREAM_STATE_ERROR)
                            .param(ARG_DETAIL, "Unknown state type during restore: " + stateType);
            }
        }
    }

    private static void clearAllStates(RocksDBKeyedStateBackend<?> backend) throws Exception {
        for (ColumnFamilyHandle cf : backend.getCfHandles().values()) {
            try (RocksIterator it = backend.getDb().newIterator(cf)) {
                List<byte[]> keys = new ArrayList<>();
                for (it.seekToFirst(); it.isValid(); it.next()) {
                    keys.add(it.key());
                }
                for (byte[] key : keys) {
                    backend.getDb().delete(cf, key);
                }
            }
        }
    }

    private static void putEntry(RocksDBKeyedStateBackend<?> backend, ColumnFamilyHandle cf,
                                 Object namespace, Object rawKey, byte[] valueBytes) {
        int keyGroupId = backend.computeKeyGroupId(rawKey);
        byte[] key = RocksDBKeyEncoder.encode(
                RocksDBKeyEncoder.deserializeNamespace(namespace), rawKey, keyGroupId);
        try {
            backend.getDb().put(cf, key, valueBytes);
        } catch (Exception e) {
            throw new StreamException("Failed to restore entry", e);
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreValueState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                          Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = resolveTypeName(stateInfo, "valueTypeName", "valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);

        ValueStateDescriptor<Object> descriptor = new ValueStateDescriptor<>(stateName, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBValueState<Object> state = new RocksDBValueState<>(backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, ValueState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object value = RocksDBValueSerDe.deserializeObject(e.get("value"), valueClass);
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(value));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreMapState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                        Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = resolveTypeName(stateInfo, "valueTypeName", "valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);
        String keyTypeName = resolveTypeName(stateInfo, "mapKeyTypeName", "mapKeyType");
        Class<Object> mapKeyClass = null;
        if (keyTypeName != null) {
            ClassNameValidator.validateClassName(keyTypeName);
            mapKeyClass = (Class<Object>) Class.forName(keyTypeName);
        }

        MapStateDescriptor<Object, Object> descriptor = new MapStateDescriptor<>(stateName, mapKeyClass, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBMapState<Object, Object> state = new RocksDBMapState<>(backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, MapState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object namespace = RocksDBKeyEncoder.deserializeNamespace(e.get("namespace"));
                Object rawKey = e.get("key");
                int keyGroupId = backend.computeKeyGroupId(rawKey);
                byte[] baseKey = RocksDBKeyEncoder.encode(namespace, rawKey, keyGroupId);
                List<List<Object>> mapEntries = (List<List<Object>>) e.get("mapValue");
                if (mapEntries != null) {
                    for (List<Object> me : mapEntries) {
                        Object mk = me.get(0);
                        // P1-21-01: container values arrive as the element-type wrapper
                        // (or as a raw JSON form for legacy snapshots); decode re-materializes
                        // inner elements (warn on legacy degradation), then re-encode so the
                        // stored bytes carry the wrapper for the runtime read path.
                        Object mv;
                        if (ContainerValueCodec.isContainerType(valueClass)) {
                            mv = ContainerValueCodec.decode(me.get(1), valueClass,
                                    "RocksDB MapState '" + stateName + "'");
                        } else {
                            mv = RocksDBValueSerDe.deserializeObject(me.get(1), valueClass);
                        }
                        byte[] fullKey = appendMapKey(baseKey, mk);
                        backend.getDb().put(cf, fullKey,
                                RocksDBValueSerDe.serialize(ContainerValueCodec.encode(mv)));
                    }
                }
            }
        }
    }

    private static byte[] appendMapKey(byte[] baseKey, Object mapKey) {
        byte[] mapKeyBytes = mapKey != null
                ? io.nop.core.lang.json.JsonTool.serialize(mapKey, false).getBytes(java.nio.charset.StandardCharsets.UTF_8)
                : RocksDBKeyEncoder.EMPTY_BYTES;
        byte[] result = new byte[baseKey.length + 4 + mapKeyBytes.length];
        System.arraycopy(baseKey, 0, result, 0, baseKey.length);
        int off = baseKey.length;
        result[off] = (byte) ((mapKeyBytes.length >>> 24) & 0xFF);
        result[off + 1] = (byte) ((mapKeyBytes.length >>> 16) & 0xFF);
        result[off + 2] = (byte) ((mapKeyBytes.length >>> 8) & 0xFF);
        result[off + 3] = (byte) (mapKeyBytes.length & 0xFF);
        System.arraycopy(mapKeyBytes, 0, result, off + 4, mapKeyBytes.length);
        return result;
    }

    @SuppressWarnings("unchecked")
    private static void restoreAppendingState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                              Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = resolveTypeName(stateInfo, "valueTypeName", "valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);
        String accumulatorTypeName = resolveTypeName(stateInfo, "accumulatorTypeName", "accumulatorType");
        ClassNameValidator.validateAccumulatorClass(accumulatorTypeName);
        Class<? extends SimpleAccumulator<Object>> accumulatorClass =
                (Class<? extends SimpleAccumulator<Object>>) Class.forName(accumulatorTypeName);

        ReducingStateDescriptor<Object> descriptor =
                new ReducingStateDescriptor<>(stateName, valueClass, accumulatorClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBInternalAppendingState<Object, Object, Object> state =
                new RocksDBInternalAppendingState<>((RocksDBKeyedStateBackend<Object>) backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, InternalAppendingState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object value = RocksDBValueSerDe.deserializeObject(e.get("value"), valueClass);
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(value));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreListState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                         Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = resolveTypeName(stateInfo, "valueTypeName", "valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);

        ListStateDescriptor<Object> descriptor = new ListStateDescriptor<>(stateName, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBListState<Object> state = new RocksDBListState<>(backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, ListState.class);

        restoreListEntries(backend, cf, stateInfo, valueClass);
    }

    @SuppressWarnings("unchecked")
    private static void restoreInternalListState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                                 Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = resolveTypeName(stateInfo, "valueTypeName", "valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);

        ListStateDescriptor<Object> descriptor = new ListStateDescriptor<>(stateName, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBInternalListState<Object, Object, Object> state =
                new RocksDBInternalListState<>((RocksDBKeyedStateBackend<Object>) backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, InternalListState.class);

        restoreListEntries(backend, cf, stateInfo, valueClass);
    }

    @SuppressWarnings("unchecked")
    private static void restoreListEntries(RocksDBKeyedStateBackend<?> backend, ColumnFamilyHandle cf,
                                           Map<String, Object> stateInfo, Class<?> valueClass) {
        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                List<Object> values = (List<Object>) e.get("listValue");
                List<Object> list = new ArrayList<>();
                if (values != null) {
                    for (Object v : values) {
                        list.add(RocksDBValueSerDe.deserializeObject(v, valueClass));
                    }
                }
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(list));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreReducingState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                             Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = (String) stateInfo.get("valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);
        String accumulatorTypeName = (String) stateInfo.get("accumulatorType");
        ClassNameValidator.validateAccumulatorClass(accumulatorTypeName);
        Class<? extends SimpleAccumulator<Object>> accumulatorClass =
                (Class<? extends SimpleAccumulator<Object>>) Class.forName(accumulatorTypeName);

        ReducingStateDescriptor<Object> descriptor =
                new ReducingStateDescriptor<>(stateName, valueClass, accumulatorClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBReducingState<Object> state = new RocksDBReducingState<>(backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, ReducingState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object value = RocksDBValueSerDe.deserializeObject(e.get("value"), valueClass);
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(value));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreAggregatingState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                                Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = (String) stateInfo.get("valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);
        String aggregateFunctionTypeName = (String) stateInfo.get("aggregateFunctionType");
        AggregateFunction<Object, Object, Object> aggregateFunction =
                resolveAggregateFunction(backend, stateName, aggregateFunctionTypeName);
        valueClass = (Class<Object>) inferAccumulatorType(aggregateFunction, valueClass);

        AggregatingStateDescriptor<Object, Object, Object> descriptor =
                new AggregatingStateDescriptor<>(stateName, aggregateFunction, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBAggregatingState<Object, Object, Object> state = new RocksDBAggregatingState<>(backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, AggregatingState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object value = RocksDBValueSerDe.deserializeObject(e.get("value"), valueClass);
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(value));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreInternalAggregatingState(RocksDBKeyedStateBackend<?> backend, String stateName,
                                                       Map<String, Object> stateInfo) throws Exception {
        String valueTypeName = (String) stateInfo.get("valueType");
        ClassNameValidator.validateClassName(valueTypeName);
        Class<Object> valueClass = (Class<Object>) Class.forName(valueTypeName);
        String aggregateFunctionTypeName = (String) stateInfo.get("aggregateFunctionType");
        AggregateFunction<Object, Object, Object> aggregateFunction =
                resolveAggregateFunction(backend, stateName, aggregateFunctionTypeName);
        valueClass = (Class<Object>) inferAccumulatorType(aggregateFunction, valueClass);

        AggregatingStateDescriptor<Object, Object, Object> descriptor =
                new AggregatingStateDescriptor<>(stateName, aggregateFunction, valueClass);
        ColumnFamilyHandle cf = backend.getOrCreateColumnFamily(stateName);
        RocksDBInternalAggregatingState<Object, Object, Object, Object, Object> state =
                new RocksDBInternalAggregatingState<>((RocksDBKeyedStateBackend<Object>) backend, cf, descriptor);
        backend.getStates().put(stateName, state);
        backend.putRestoredDescriptor(stateName, descriptor);
        backend.getStateTypes().put(stateName, InternalAppendingState.class);

        List<Map<String, Object>> entries = (List<Map<String, Object>>) stateInfo.get("entries");
        if (entries != null) {
            for (Map<String, Object> e : entries) {
                Object value = RocksDBValueSerDe.deserializeObject(e.get("value"), valueClass);
                putEntry(backend, cf, e.get("namespace"), e.get("key"), RocksDBValueSerDe.serialize(value));
            }
        }
    }

    /**
     * The window descriptor path (WindowedStreamImpl.aggregate/reduce) records the
     * accumulator type as {@code java.lang.Object} (generic erasure), so the snapshot's
     * recorded valueType cannot drive value re-materialization: a JSON array round-trip
     * of a {@code long[]} accumulator would be restored as an ArrayList and the user
     * function's {@code add} would ClassCastException. When the recorded type is the
     * generic {@code Object}, infer the real accumulator type from the LIVE aggregate
     * function's {@code createAccumulator()} (registered by the operator before restore).
     * Functions whose {@code createAccumulator()} returns {@code null} (e.g. the
     * reduce-function wrapper) keep the recorded type — JSON-native accumulators
     * (String/numbers) restore correctly without the inference.
     */
    private static Class<?> inferAccumulatorType(AggregateFunction<?, ?, ?> aggregateFunction, Class<?> recordedType) {
        if (recordedType != Object.class || aggregateFunction == null) {
            return recordedType;
        }
        try {
            Object accumulator = aggregateFunction.createAccumulator();
            if (accumulator != null) {
                return accumulator.getClass();
            }
        } catch (Exception e) {
            // Keep the recorded (generic) type; JSON-native accumulators restore
            // correctly either way.
        }
        return recordedType;
    }

    /**
     * P1-01 (Decision: 方案 1 = live function reuse): resolves the aggregate
     * function used to rebuild aggregating state on restore.
     *
     * <p>Priority order: (1) the LIVE function registered via
     * {@code IKeyedStateBackend#registerRestoreAggregateFunction} (the
     * operator's descriptor function — required for capturing anonymous
     * classes / lambdas, and also restores old snapshots); (2) class-name +
     * no-arg reflection (legacy path). Reflection failure with no registered
     * provider fails fast with a clear error (No-Silent-No-Op rule #24).
     */
    @SuppressWarnings("unchecked")
    private static AggregateFunction<Object, Object, Object> resolveAggregateFunction(
            RocksDBKeyedStateBackend<?> backend, String stateName, String aggregateFunctionTypeName) throws Exception {
        AggregateFunction<?, ?, ?> live = backend.getRestoreAggregateFunction(stateName);
        if (live != null) {
            return (AggregateFunction<Object, Object, Object>) live;
        }
        ClassNameValidator.validateAccumulatorClass(aggregateFunctionTypeName);
        Class<? extends AggregateFunction<?, ?, ?>> aggregateFunctionClass =
                (Class<? extends AggregateFunction<?, ?, ?>>) Class.forName(aggregateFunctionTypeName);
        try {
            return (AggregateFunction<Object, Object, Object>)
                    aggregateFunctionClass.getDeclaredConstructor().newInstance();
        } catch (NoSuchMethodException e) {
            throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                    .param(ARG_DETAIL, "AggregateFunction class " + aggregateFunctionTypeName
                            + " has no no-arg constructor and no live function was registered for state '"
                            + stateName + "' — the operator must register its descriptor's function via "
                            + "IKeyedStateBackend.registerRestoreAggregateFunction before restore "
                            + "(window operators do this in open() prior to applyPendingRestoreState)");
        }
    }

    private static String resolveTypeName(Map<String, Object> stateInfo, String primary, String fallback) {
        String name = (String) stateInfo.get(primary);
        if (name == null) {
            name = (String) stateInfo.get(fallback);
        }
        return name;
    }
}
