/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.nosql.lettuce.impl;

import io.lettuce.core.GetExArgs;
import io.lettuce.core.KeyScanCursor;
import io.lettuce.core.KeyValue;
import io.lettuce.core.ScanArgs;
import io.lettuce.core.ScanCursor;
import io.lettuce.core.ScriptOutputType;
import io.lettuce.core.SetArgs;
import io.lettuce.core.cluster.api.sync.RedisClusterCommands;
import io.nop.api.core.message.IMessageService;
import io.nop.api.core.util.FutureHelper;
import io.nop.commons.functional.Functionals;
import io.nop.commons.util.StringHelper;
import io.nop.nosql.core.INosqlCounter;
import io.nop.nosql.core.INosqlHashOperations;
import io.nop.nosql.core.INosqlListOperations;
import io.nop.nosql.core.INosqlLock;
import io.nop.nosql.core.INosqlQueue;
import io.nop.nosql.core.INosqlRanking;
import io.nop.nosql.core.INosqlRateLimiter;
import io.nop.nosql.core.INosqlService;
import io.nop.nosql.core.INosqlSessionStore;
import io.nop.nosql.core.INosqlSetOperations;
import io.nop.nosql.core.INosqlZSetOperations;
import io.nop.nosql.core.RateLimiterConfig;
import io.nop.nosql.core.script.RedisScripts;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class LettuceMessageService extends AbstractLettuceOperations implements INosqlService {

    public LettuceMessageService(LettuceRedisConnectionProvider client) {
        super(client);
    }

    @Override
    public long getSize() {
        return sync().dbsize();
    }

    @Override
    public Object get(String key) {
        return sync().get(key);
    }

    @Override
    public Object computeIfAbsent(String key, Function<? super String, ?> mappingFunction) {
        RedisClusterCommands<String, Object> commands = sync();
        Object value = commands.get(key);
        if (value == null) {
            value = mappingFunction.apply(key);
            commands.set(key, value);
        }
        return value;
    }

    @Override
    public Map<String, Object> getAll(Collection<? extends String> keys) {
        if (keys == null || keys.isEmpty())
            return new HashMap<>(0);
        List<KeyValue<String, Object>> list = sync().mget(keys.toArray(new String[0]));
        return LettuceHelper.toMap(list);
    }

    @Override
    public boolean containsKey(String key) {
        return sync().exists(key) == 1;
    }

    @Override
    public void put(String key, Object value) {
        sync().set(key, value);
    }

    @SuppressWarnings("unchecked") // Lettuce mset requires Map<String, Object>, wildcard capture is safe at runtime
    @Override
    public void putAll(Map<? extends String, ?> map) {
        if (map == null || map.isEmpty())
            return;

        sync().mset((Map<String, Object>) map);
    }

    @Override
    public boolean putIfAbsent(String key, Object value) {
        return FutureHelper.syncGet(putIfAbsentAsync(key, value));
    }

    @Override
    public Object getAndSet(String key, Object value) {
        return FutureHelper.syncGet(getAndSetAsync(key, value));
    }

    @Override
    public void remove(String key) {
        sync().del(key);
    }

    @Override
    public boolean removeIfMatch(String key, Object object) {
        return FutureHelper.syncGet(removeIfMatchAsync(key, object));
    }

    @Override
    public void removeAll(Collection<? extends String> keys) {
        if (keys == null || keys.isEmpty())
            return;
        sync().del(keys.toArray(new String[0]));
    }

    @Override
    public void clear() {
        sync().flushdb();
    }

    @Override
    public void forEachEntry(BiConsumer<? super String, ? super Object> consumer) {
        ScanCursor cursor = ScanCursor.INITIAL;
        ScanArgs args = new ScanArgs().limit(100);
        do {
            KeyScanCursor<String> result = sync().scan(cursor, args);
            List<String> keys = result.getKeys();
            if (keys != null && !keys.isEmpty()) {
                List<KeyValue<String, Object>> values = sync().mget(keys.toArray(new String[0]));
                for (KeyValue<String, Object> kv : values) {
                    if (kv.hasValue()) {
                        consumer.accept(kv.getKey(), kv.getValue());
                    }
                }
            }
            cursor = result;
        } while (!cursor.isFinished());
    }

    @Override
    public CompletionStage<Object> getAsync(String key) {
        return async().get(key);
    }

    @Override
    public CompletionStage<Object> computeIfAbsentAsync(String key, Function<? super String, ?> mappingFunction) {
        return async().get(key).thenCompose(value -> {
            if (value == null) {
                value = mappingFunction.apply(key);
                Object ret = value;
                return async().set(key, value).thenApply(v -> ret);
            } else {
                return FutureHelper.success(value);
            }
        });
    }

    @Override
    public CompletionStage<Map<String, Object>> getAllAsync(Collection<? extends String> keys) {
        if (keys == null || keys.isEmpty())
            return CompletableFuture.completedFuture(new HashMap<>(0));
        return async().mget(StringHelper.toStringArray(keys)).thenApply(LettuceHelper::toMap);
    }

    @Override
    public CompletionStage<Boolean> containsKeyAsync(String key) {
        return async().exists(key).thenApply(value -> value == 1);
    }

    @Override
    public CompletionStage<Void> putAsync(String key, Object value) {
        return async().set(key, value).thenApply(Functionals.toVoid());
    }

    @SuppressWarnings("unchecked") // Lettuce mset requires Map<String, Object>, wildcard capture is safe at runtime
    @Override
    public CompletionStage<Void> putAllAsync(Map<? extends String, ?> map) {
        if (map == null || map.isEmpty())
            return CompletableFuture.completedFuture(null);
        return async().mset((Map) map);
    }

    @Override
    public CompletionStage<Boolean> putIfAbsentAsync(String key, Object value) {
        return async().setnx(key, value);
    }

    @Override
    public CompletionStage<Object> getAndSetAsync(String key, Object value) {
        return async().getset(key, value);
    }

    @Override
    public CompletionStage<Void> removeAsync(String key) {
        return async().del(key).thenApply(Functionals.toVoid());
    }

    @Override
    public CompletionStage<Boolean> removeIfMatchAsync(String key, Object object) {
        return LettuceExecutor.evalScript(async(), RedisScripts.REMOVE_IF_MATCH, ScriptOutputType.BOOLEAN,
                new String[]{key}, new Object[]{object});
    }

    @Override
    public CompletionStage<Void> removeAllAsync(Collection<? extends String> keys) {
        if (keys == null || keys.isEmpty())
            return CompletableFuture.completedFuture(null);
        return async().del(StringHelper.toStringArray(keys)).thenApply(Functionals.toVoid());
    }

    @Override
    public CompletionStage<Void> clearAsync() {
        return async().flushdb().thenApply(Functionals.toVoid());
    }

    @Override
    public CompletionStage<Void> forEachEntryAsync(BiConsumer<? super String, ? super Object> consumer) {
        ScanCursor cursor = ScanCursor.INITIAL;
        ScanArgs args = new ScanArgs().limit(100);
        return scanAndProcessAsync(cursor, args, consumer);
    }

    private CompletionStage<Void> scanAndProcessAsync(
            ScanCursor cursor, ScanArgs args,
            BiConsumer<? super String, ? super Object> consumer) {
        return async().scan(cursor, args).thenCompose(result -> {
            List<String> keys = result.getKeys();
            if (keys == null || keys.isEmpty()) {
                if (!result.isFinished()) {
                    return scanAndProcessAsync(result, args, consumer);
                }
                return CompletableFuture.completedFuture(null);
            }

            // batch fetch the whole scan page with one MGET instead of N GET round trips
            return async().mget(StringHelper.toStringArray(keys))
                    .thenAccept(values -> {
                        for (KeyValue<String, Object> kv : values) {
                            if (kv.hasValue()) {
                                consumer.accept(kv.getKey(), kv.getValue());
                            }
                        }
                    })
                    .thenCompose(v -> {
                        if (!result.isFinished()) {
                            return scanAndProcessAsync(result, args, consumer);
                        }
                        return CompletableFuture.completedFuture(null);
                    });
        });
    }

    @Override
    public CompletionStage<Long> getSizeAsync() {
        return async().dbsize();
    }

    @Override
    public CompletionStage<Void> putExAsync(String key, Object value, long timeout) {
        return async().psetex(key, timeout, value).thenApply(Functionals.toVoid());
    }

    @Override
    public CompletionStage<Object> getExAsync(String key, long timeout) {
        if (timeout < 0)
            return getAsync(key);

        GetExArgs args = new GetExArgs();
        args.px(timeout);
        return async().getex(key, args);
    }

    @Override
    public CompletionStage<Boolean> putIfAbsentExAsync(String key, Object value, long timeout) {
        if (timeout < 0)
            return putIfAbsentAsync(key, value);

        SetArgs args = new SetArgs();
        args.px(timeout);
        args.nx();
        return async().set(key, value, args).thenApply(s -> "OK".equals(s));
    }

    @Override
    public CompletionStage<String> putIfAbsentOrMatchExAsync(String key, String value, long timeout) {
        return LettuceExecutor.evalScript(async(), RedisScripts.PUT_IF_ABSENT_OR_MATCH,
                ScriptOutputType.VALUE, new String[]{key}, new Object[]{value, timeout})
                .thenApply(v -> (String) v);
    }

    @Override
    public CompletionStage<Object> getAndSetExAsync(String key, Object value, long timeout) {
        if (timeout < 0)
            return getAndSetAsync(key, value);

        SetArgs args = new SetArgs();
        args.px(timeout);
        return async().setGet(key, value, args);
    }

    @Override
    public CompletionStage<Long> getTimeoutAsync(String key) {
        return async().pttl(key);
    }

    @Override
    public CompletionStage<Boolean> setTimeoutAsync(String key, long timeout) {
        return async().pexpire(key, timeout);
    }

    @Override
    public INosqlHashOperations hashOps(String key) {
        return new LettuceHashOperations(client, key);
    }

    @Override
    public INosqlListOperations listOps(String key) {
        return new LettuceListOperations(client, key);
    }

    @Override
    public INosqlSetOperations setOps(String key) {
        return new LettuceSetOperations(client, key);
    }

    @Override
    public INosqlZSetOperations zSetOps(String key) {
        return new LettuceZSetOperations(client, key);
    }

    private volatile LettucePubSubService pubSubService;

    @Override
    public IMessageService getMessageService() {
        if (pubSubService == null) {
            synchronized (this) {
                if (pubSubService == null) {
                    pubSubService = new LettucePubSubService(client);
                    pubSubService.start();
                }
            }
        }
        return pubSubService;
    }

    @Override
    public INosqlQueue queue(String key) {
        return new LettuceQueue(client, key);
    }

    @Override
    public INosqlLock lock(String key) {
        return new LettuceLock(client, key);
    }

    @Override
    public INosqlRateLimiter rateLimiter(String key, RateLimiterConfig config) {
        return new LettuceRateLimiter(client, key, config);
    }

    @Override
    public INosqlRanking ranking(String key) {
        return new LettuceRanking(client, key);
    }

    @Override
    public INosqlCounter counter(String key) {
        return new LettuceCounter(client, key);
    }

    @Override
    public INosqlSessionStore sessionStore(String prefix) {
        return new LettuceSessionStore(client, prefix);
    }
}
