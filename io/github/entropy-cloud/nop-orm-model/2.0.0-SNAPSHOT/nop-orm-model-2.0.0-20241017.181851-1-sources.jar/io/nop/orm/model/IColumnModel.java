/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.orm.model;

import io.nop.commons.type.StdDataType;
import io.nop.commons.type.StdSqlType;
import io.nop.commons.util.StringHelper;

import java.util.List;
import java.util.Objects;

public interface IColumnModel extends IEntityPropModel {

    String getName();

    String getDomain();

    default String getBaseDomain() {
        String domain = getDomain();
        if (Objects.equals(domain, getStdDomain()))
            return domain;
        return StringHelper.firstPart(domain, '-');
    }

    String getStdDomain();

    String getCode();

    int getPropId();

    boolean isInsertable();

    boolean isUpdatable();

    String getSqlText();

    boolean isMandatory();

    boolean isPrimary();

    StdSqlType getStdSqlType();

    String getDefaultValue();

    Integer getPrecision();

    Integer getScale();

    StdDataType getStdDataType();

    /**
     * 列所对应的to-one引用对象。例如status_id字段关联Status表，对应引用对象status。一般情况下一个字段最多只有唯一一个关联对象
     */
    List<IEntityRelationModel> getColumnRefs();

    default String getJavaTypeName() {
        return getJavaClassName();
    }

    default Class<?> getJavaClass() {
        return getStdDataType().getJavaClass();
    }

    default String getJavaClassName() {
        return getJavaClass().getName();
    }
}