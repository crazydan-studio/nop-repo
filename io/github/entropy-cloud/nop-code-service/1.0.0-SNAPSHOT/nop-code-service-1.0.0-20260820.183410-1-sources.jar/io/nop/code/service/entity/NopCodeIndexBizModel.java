package io.nop.code.service.entity;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jakarta.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.api.core.annotations.data.DataBean;
import io.nop.api.core.annotations.directive.Auth;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.code.biz.INopCodeIndexBiz;
import io.nop.code.core.model.CodeFileAnalysisResult;
import io.nop.code.dao.entity.NopCodeIndex;
import io.nop.code.flow.ChangeAnalysisResult;
import io.nop.code.flow.ExecutionFlow;
import io.nop.code.service.api.ICodeIndexService;
import io.nop.code.api.dto.*;
import io.nop.code.service.api.dto.FileAnalysisDTO;

import static io.nop.code.service.NopCodeErrors.*;
@BizModel("NopCodeIndex")
public class NopCodeIndexBizModel extends CrudBizModel<NopCodeIndex> implements INopCodeIndexBiz {

    private static final Logger LOG = LoggerFactory.getLogger(NopCodeIndexBizModel.class);

    private static final int MAX_STATUS_ENTRIES = 100;

    private static final int MAX_SOURCE_CODE_BYTES = 1024 * 1024;

    @Inject
    protected ICodeIndexService codeIndexService;

    private final Map<String, IncrementalStatus> incrementalStatusMap = Collections.synchronizedMap(
            new LinkedHashMap<String, IncrementalStatus>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, IncrementalStatus> eldest) {
                    return size() > MAX_STATUS_ENTRIES;
                }
            });

    public NopCodeIndexBizModel() {
        setEntityName(NopCodeIndex.class.getName());
    }

    @BizMutation
    @Auth(roles = "admin")
    public String triggerFullIndex(
            @Name("indexId") String indexId,
            @Name("projectPath") String projectPath) {
        int fileCount = codeIndexService.indexDirectory(indexId, projectPath, null);

        IncrementalStatus status = new IncrementalStatus();
        status.setIndexId(indexId);
        status.setMode("full");
        status.setFileCount(fileCount);
        status.setCompleted(true);
        incrementalStatusMap.put(indexId, status);

        LOG.info("Full index completed: indexId={}, files={}", indexId, fileCount);
        return indexId;
    }

    @BizMutation
    @Auth(roles = "admin")
    public int triggerIncrementalIndex(
            @Name("indexId") String indexId,
            @Name("projectPath") String projectPath,
            @Name("manifestPath") String manifestPath) {
        try {
            int fileCount = codeIndexService.triggerIncrementalIndex(
                    indexId, projectPath, manifestPath);

            IncrementalStatus status = new IncrementalStatus();
            status.setIndexId(indexId);
            status.setMode("incremental");
            status.setFileCount(fileCount);
            status.setCompleted(true);
            incrementalStatusMap.put(indexId, status);

            LOG.info("Incremental index completed: indexId={}, files={}", indexId, fileCount);
            return fileCount;
        } catch (Exception e) {
            IncrementalStatus status = new IncrementalStatus();
            status.setIndexId(indexId);
            status.setMode("incremental");
            status.setCompleted(false);
            status.setErrorMessage(e.getMessage());
            incrementalStatusMap.put(indexId, status);
            throw e;
        }
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public IncrementalStatus getIncrementalStatus(@Name("indexId") String indexId) {
        return incrementalStatusMap.get(indexId);
    }

    @BizMutation
    @Auth(roles = "admin")
    public int indexDirectory(
            @Name("indexId") String indexId,
            @Name("directoryPath") String directoryPath,
            @Name("filePattern") @Optional String filePattern) {
        return codeIndexService.indexDirectory(indexId, directoryPath, filePattern);
    }

    @BizMutation
    @Auth(roles = "admin")
    public FileAnalysisDTO indexFile(
            @Name("indexId") String indexId,
            @Name("filePath") String filePath,
            @Name("sourceCode") String sourceCode) {
        if (sourceCode != null && sourceCode.length() > MAX_SOURCE_CODE_BYTES) {
            throw new NopException(ERR_CODE_SOURCE_CODE_TOO_LARGE)
                    .param(ARG_FILE_PATH, filePath)
                    .param(ARG_INDEX_ID, indexId);
        }
        CodeFileAnalysisResult result = codeIndexService.indexFile(indexId, filePath, sourceCode);
        return FileAnalysisDTO.fromCodeFileAnalysisResult(result);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public IndexStatsDTO getStats(@Name("indexId") String indexId) {
        return codeIndexService.getIndexStats(indexId);
    }

    @BizMutation
    @Auth(roles = "admin")
    public boolean deleteIndex(@Name("indexId") String indexId) {
        codeIndexService.deleteIndex(indexId);
        incrementalStatusMap.remove(indexId);
        return true;
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public CommunityDetectionResultDTO detectCommunities(@Name("indexId") String indexId) {
        CommunityDetectionResultDTO result = codeIndexService.detectCommunities(indexId);
        if (result == null) {
            result = new CommunityDetectionResultDTO();
            result.setCommunities(Collections.emptyList());
            result.setTotalSymbols(0);
            result.setTotalCommunities(0);
            result.setAverageCohesion(0.0);
            result.setAlgorithmUsed(null);
            result.setModularity(0.0);
            result.setProcessingTimeMs(0);
        }
        return result;
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public GraphAnalysisResultDTO getGraphAnalysis(
            @Name("indexId") String indexId,
            @Name("topN") @Optional Integer topN) {
        int limit = topN != null && topN > 0 ? topN : 20;
        return codeIndexService.getGraphAnalysis(indexId, limit);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public ImpactResultDTO getImpactAnalysis(
            @Name("indexId") String indexId,
            @Name("symbolId") String symbolId,
            @Name("depth") @Optional Integer depth) {
        int maxDepth = depth != null && depth > 0 ? depth : 3;
        return codeIndexService.getImpactAnalysis(indexId, symbolId, maxDepth);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public DepGraphDTO getDeps(
            @Name("indexId") String indexId,
            @Name("filePath") String filePath,
            @Name("depth") @Optional Integer depth) {
        int maxDepth = depth != null && depth > 0 ? depth : 3;
        return codeIndexService.getDeps(indexId, filePath, maxDepth);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public DepGraphDTO getReverseDeps(
            @Name("indexId") String indexId,
            @Name("filePath") String filePath,
            @Name("depth") @Optional Integer depth,
            @Name("limit") @Optional Integer limit) {
        int maxDepth = depth != null && depth > 0 ? depth : 3;
        int maxLimit = limit != null && limit > 0 ? limit : 100;
        return codeIndexService.getReverseDeps(indexId, filePath, maxDepth, maxLimit);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public List<List<String>> findCycles(
            @Name("indexId") String indexId,
            @Name("minSize") @Optional Integer minSize) {
        int min = minSize != null && minSize > 0 ? minSize : 2;
        return codeIndexService.findCycles(indexId, min);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public DepGraphDTO getDepGraph(
            @Name("indexId") String indexId,
            @Name("includeExternal") @Optional Boolean includeExternal) {
        return codeIndexService.getDepGraph(indexId,
                includeExternal != null && includeExternal);
    }

    @BizMutation
    @Auth(roles = "admin")
    public List<ExecutionFlow> detectFlows(@Name("indexId") String indexId) {
        return codeIndexService.detectFlows(indexId);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public List<ExecutionFlow> listFlows(@Name("indexId") String indexId) {
        return codeIndexService.listFlows(indexId);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public ExecutionFlow getFlow(
            @Name("indexId") String indexId,
            @Name("flowId") String flowId) {
        return codeIndexService.getFlow(indexId, flowId);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public List<ExecutionFlow> getAffectedFlows(
            @Name("indexId") String indexId,
            @Name("changedFilePaths") List<String> changedFilePaths) {
        return codeIndexService.getAffectedFlows(indexId, changedFilePaths);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public ChangeAnalysisResult analyzeChanges(
            @Name("indexId") String indexId,
            @Name("baselineCommitish") String baselineCommitish,
            @Name("targetCommitish") String targetCommitish) {
        return codeIndexService.analyzeChanges(indexId, baselineCommitish, targetCommitish);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public CriticalNodeResultDTO getCriticalNodes(
            @Name("indexId") String indexId,
            @Name("topN") @Optional Integer topN) {
        int limit = topN != null && topN > 0 ? topN : 20;
        return codeIndexService.getCriticalNodes(indexId, limit);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public KnowledgeGapResultDTO getKnowledgeGaps(@Name("indexId") String indexId) {
        return codeIndexService.getKnowledgeGaps(indexId);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public String exportGraph(
            @Name("indexId") String indexId,
            @Name("format") String format,
            @Name("communityView") @Optional Boolean communityView) {
        return codeIndexService.exportGraph(indexId, format,
                communityView != null && communityView);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public GraphDiffDTO diffGraph(
            @Name("baselineIndexId") String baselineIndexId,
            @Name("targetIndexId") String targetIndexId) {
        return codeIndexService.diffGraph(baselineIndexId, targetIndexId);
    }

    @BizQuery
    @Auth(permissions = "NopCodeIndex:query")
    public List<String> findDependentFiles(
            @Name("indexId") String indexId,
            @Name("filePath") String filePath) {
        return codeIndexService.findDependentFiles(indexId, filePath);
    }

    @DataBean
    public static class IncrementalStatus {
        private String indexId;
        private String mode;
        private int fileCount;
        private int symbolCount;
        private boolean completed;
        private String errorMessage;

        public String getIndexId() {
            return indexId;
        }

        public void setIndexId(String indexId) {
            this.indexId = indexId;
        }

        public String getMode() {
            return mode;
        }

        public void setMode(String mode) {
            this.mode = mode;
        }

        public int getFileCount() {
            return fileCount;
        }

        public void setFileCount(int fileCount) {
            this.fileCount = fileCount;
        }

        public int getSymbolCount() {
            return symbolCount;
        }

        public void setSymbolCount(int symbolCount) {
            this.symbolCount = symbolCount;
        }

        public boolean isCompleted() {
            return completed;
        }

        public void setCompleted(boolean completed) {
            this.completed = completed;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }

}
