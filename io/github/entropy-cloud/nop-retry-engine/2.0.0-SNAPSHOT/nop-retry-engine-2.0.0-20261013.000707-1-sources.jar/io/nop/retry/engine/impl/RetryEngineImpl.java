/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.retry.engine.impl;

import io.nop.api.core.beans.ApiRequest;
import io.nop.api.core.beans.ApiResponse;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.exceptions.NopRebuildException;
import io.nop.api.core.rpc.IRpcServiceInvoker;
import io.nop.api.core.util.FutureHelper;
import io.nop.api.core.util.ICancelToken;
import io.nop.commons.concurrent.executor.GlobalExecutors;
import io.nop.commons.concurrent.executor.IScheduledExecutor;
import io.nop.commons.service.LifeCycleSupport;
import io.nop.commons.util.StringHelper;
import io.nop.core.exceptions.ErrorMessageManager;
import io.nop.core.lang.json.JsonTool;
import io.nop.dao.DaoErrors;
import io.nop.retry.api.IRetryEngine;
import io.nop.retry.api.IRetryTask;
import io.nop.retry.dao.entity.NopRetryAttempt;
import io.nop.retry.dao.entity.NopRetryDeadLetter;
import io.nop.retry.dao.entity.NopRetryPolicy;
import io.nop.retry.dao.entity.NopRetryRecord;
import io.nop.retry.engine.NopRetryConstants;
import io.nop.retry.engine.scanner.IRetryScanner;
import io.nop.retry.engine.store.IRetryRecordStore;
import io.nop.api.core.beans.ErrorBean;

import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;

import static io.nop.retry.engine.NopRetryErrors.*;

public class RetryEngineImpl extends LifeCycleSupport implements IRetryEngine {

    static final Logger LOG = LoggerFactory.getLogger(RetryEngineImpl.class);

    private IRpcServiceInvoker rpcServiceInvoker;
    private IRetryRecordStore recordStore;
    private IRetryScanner retryScanner;
    private IScheduledExecutor executor;

    @Inject
    public void setRpcServiceInvoker(IRpcServiceInvoker rpcServiceInvoker) {
        this.rpcServiceInvoker = rpcServiceInvoker;
    }

    @Inject
    public void setRecordStore(IRetryRecordStore recordStore) {
        this.recordStore = recordStore;
    }

    @Inject
    public void setRetryScanner(IRetryScanner retryScanner) {
        this.retryScanner = retryScanner;
    }

    @Override
    public IRetryTask newRetryTask(String serviceName, String serviceMethod) {
        return new RetryTaskImpl(this, serviceName, serviceMethod);
    }

    @Override
    public CompletionStage<ApiResponse<?>> retryFromDeadLetter(String deadLetterId, ICancelToken cancelToken) {
        NopRetryDeadLetter deadLetter = recordStore.loadDeadLetter(deadLetterId);

        if (deadLetter == null) {
            CompletableFuture<ApiResponse<?>> future = new CompletableFuture<>();
            future.completeExceptionally(
                    new NopException(ERR_RETRY_DEAD_LETTER_NOT_FOUND)
                            .param(ARG_DEAD_LETTER_ID, deadLetterId));
            return future;
        }

        String serviceName = deadLetter.getServiceName();
        String serviceMethod = deadLetter.getServiceMethod();
        String requestPayload = deadLetter.getRequestPayload();

        if (StringHelper.isEmpty(serviceName) || StringHelper.isEmpty(serviceMethod)) {
            CompletableFuture<ApiResponse<?>> future = new CompletableFuture<>();
            future.completeExceptionally(
                    new NopException(ERR_RETRY_DEAD_LETTER_INVALID_EXECUTOR)
                            .param(ARG_DEAD_LETTER_ID, deadLetterId));
            return future;
        }

        if (StringHelper.isEmpty(requestPayload)) {
            CompletableFuture<ApiResponse<?>> future = new CompletableFuture<>();
            future.completeExceptionally(
                    new NopException(ERR_RETRY_DEAD_LETTER_INVALID_REQUEST)
                            .param(ARG_DEAD_LETTER_ID, deadLetterId));
            return future;
        }

        ApiRequest<?> request = JsonTool.parseBeanFromText(requestPayload, ApiRequest.class);
        return rpcServiceInvoker.invokeAsync(serviceName, serviceMethod, request, null);
    }

    @Override
    public void pause(String recordId) {
        NopRetryRecord record = recordStore.loadRecord(recordId);

        if (record == null) {
            throw new NopException(ERR_RETRY_RECORD_NOT_FOUND)
                    .param(ARG_RECORD_ID, recordId);
        }

        int status = record.getStatus() != null ? record.getStatus() : 0;

        if (status == NopRetryConstants.RETRY_RECORD_STATUS_SUSPENDED) {
            throw new NopException(ERR_RETRY_RECORD_ALREADY_SUSPENDED)
                    .param(ARG_RECORD_ID, recordId);
        }

        if (status == NopRetryConstants.RETRY_RECORD_STATUS_COMPLETED) {
            throw new NopException(ERR_RETRY_RECORD_ALREADY_COMPLETED)
                    .param(ARG_RECORD_ID, recordId);
        }

        record.setStatus(NopRetryConstants.RETRY_RECORD_STATUS_SUSPENDED);
        recordStore.updateRecord(record);
    }

    @Override
    public void resume(String recordId) {
        NopRetryRecord record = recordStore.loadRecord(recordId);

        if (record == null) {
            throw new NopException(ERR_RETRY_RECORD_NOT_FOUND)
                    .param(ARG_RECORD_ID, recordId);
        }

        int status = record.getStatus() != null ? record.getStatus() : 0;

        if (status != NopRetryConstants.RETRY_RECORD_STATUS_SUSPENDED) {
            throw new NopException(ERR_RETRY_RECORD_NOT_SUSPENDED)
                    .param(ARG_RECORD_ID, recordId);
        }

        record.setStatus(NopRetryConstants.RETRY_RECORD_STATUS_PENDING);
        record.setNextTriggerTime(new Timestamp(recordStore.getCurrentTime()));
        recordStore.updateRecord(record);
    }

    /**
     * policyId 是可选配置（newRetryTask 不设置时为null），无策略时使用内置默认策略，
     * 避免落库后在 executeWithRetry 中NPE并留下被扫描器反复接管的孤儿记录
     */
    private NopRetryPolicy loadPolicyOrDefault(String policyId) {
        NopRetryPolicy policy = recordStore.loadPolicy(policyId);
        if (policy != null)
            return policy;
        return new NopRetryPolicy();
    }

    CompletionStage<ApiResponse<?>> executeTask(IRetryTask task, ApiRequest<?> request, ICancelToken cancelToken) {
        NopRetryPolicy policy = loadPolicyOrDefault(task.getPolicyId());

        NopRetryRecord existingRecord = recordStore.findRecordByIdempotentId(
                task.getNamespaceId(), task.getGroupId(), task.getIdempotentId());
        if (existingRecord != null) {
            return handleExistingRecord(existingRecord, policy, request, cancelToken, task);
        }

        NopRetryRecord record = recordStore.newRecord(task, request);
        try {
            recordStore.saveRecord(record);
        } catch (Exception e) {
            NopRetryRecord raceWinner = resolveInsertRaceWinner(task, e);
            if (raceWinner == null)
                throw e;
            // 并发首提的TOCTOU窗口（plan 2282 G7-14-01）：唯一键冲突兜底，
            // 与先查后插同样按记录状态分流，不再以裸数据库约束冲突暴露
            return handleExistingRecord(raceWinner, policy, request, cancelToken, task);
        }
        return executeWithRetry(record, policy, request, cancelToken, task);
    }

    /**
     * 幂等键生命周期语义（plan 2282 G7-14-01 修复裁定，二选一中选择"复用终态结果"）：
     * <ul>
     * <li>COMPLETED 记录：上次同键提交已成功，重提交按幂等重放处理——直接返回成功，
     *     不重新执行业务副作用，也不咨询OVERWRITE策略（覆盖已成功的记录重新执行副作用
     *     超出重复提交的授权范围；需要重新驱动时走死信/暂停恢复等显式运维入口）。</li>
     * <li>其余状态（PENDING/RETRYING/SUSPENDED）：按blockStrategy处理。SUSPENDED是运维
     *     主动暂停，重复提交不允许偷偷恢复执行——DISCARD保持暂停，OVERWRITE显式重建。</li>
     * </ul>
     * 不选"显式删除重建"的原因：删除COMPLETED记录会让下一次重放重新执行业务副作用，
     * 违背幂等键契约；且死信路径已提供显式的重新驱动入口。
     */
    private CompletionStage<ApiResponse<?>> handleExistingRecord(
            NopRetryRecord existingRecord,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task) {

        int status = existingRecord.getStatus() != null ? existingRecord.getStatus() : 0;
        if (status == NopRetryConstants.RETRY_RECORD_STATUS_COMPLETED) {
            LOG.info("nop.retry.idempotent-replay-completed:recordId={},idempotentId={}",
                    existingRecord.getSid(), existingRecord.getIdempotentId());
            return FutureHelper.success(ApiResponse.success(null));
        }
        return handleBlockStrategy(existingRecord, policy, request, cancelToken, task);
    }

    /**
     * 插入唯一键冲突时判定是否为并发首提竞争：是则返回竞胜者的记录（已提交可见），否则返回null。
     */
    private NopRetryRecord resolveInsertRaceWinner(IRetryTask task, Exception e) {
        if (!isDuplicateKeyError(e))
            return null;

        NopRetryRecord winner = recordStore.findRecordByIdempotentId(
                task.getNamespaceId(), task.getGroupId(), task.getIdempotentId());
        if (winner == null) {
            // 冲突行在我们读取前被删除（如并发OVERWRITE/死信迁移）：保留原始错误暴露给调用方
            LOG.warn("nop.retry.insert-conflict-without-winner:idempotentId={}", task.getIdempotentId(), e);
            return null;
        }
        LOG.info("nop.retry.concurrent-submit-race-lost:recordId={},idempotentId={}",
                winner.getSid(), task.getIdempotentId());
        return winner;
    }

    private static boolean isDuplicateKeyError(Throwable e) {
        return e instanceof NopException
                && DaoErrors.ERR_SQL_DUPLICATE_KEY.getErrorCode().equals(((NopException) e).getErrorCode());
    }

    private CompletionStage<ApiResponse<?>> handleBlockStrategy(
            NopRetryRecord existingRecord,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task) {

        switch (policy.getBlockStrategyOrDefault()) {
            case NopRetryConstants.BLOCK_STRATEGY_DISCARD:
                LOG.info("nop.retry.block-strategy-discard:recordId={}", existingRecord.getSid());
                return FutureHelper.success(ApiResponse.success(null));

            case NopRetryConstants.BLOCK_STRATEGY_OVERWRITE:
                LOG.info("nop.retry.block-strategy-overwrite:recordId={}", existingRecord.getSid());
                recordStore.deleteRecord(existingRecord);
                NopRetryRecord newRecord = recordStore.newRecord(task, request);
                recordStore.saveRecord(newRecord);
                return executeWithRetry(newRecord, policy, request, cancelToken, task);

            default:
                LOG.info("nop.retry.block-strategy-discard:recordId={}", existingRecord.getSid());
                return FutureHelper.success(ApiResponse.success(null));
        }
    }

    CompletionStage<ApiResponse<?>> executeRetryFromScanner(NopRetryRecord record, ICancelToken cancelToken) {
        String serviceName = record.getServiceName();
        String serviceMethod = record.getServiceMethod();
        String requestPayload = record.getRequestPayload();

        // 无法执行的坏记录直接进死信。此前仅返回失败future不改记录状态/retryCount，
        // 记录每个租约周期被重扫一次，永不进死信
        if (StringHelper.isEmpty(serviceName) || StringHelper.isEmpty(serviceMethod)) {
            NopException ex = new NopException(ERR_RETRY_DEAD_LETTER_INVALID_EXECUTOR)
                    .param(ARG_RECORD_ID, record.getSid());
            moveToDeadLetter(record, ex);
            return CompletableFuture.failedStage(ex);
        }

        if (StringHelper.isEmpty(requestPayload)) {
            NopException ex = new NopException(ERR_RETRY_DEAD_LETTER_INVALID_REQUEST)
                    .param(ARG_RECORD_ID, record.getSid());
            moveToDeadLetter(record, ex);
            return CompletableFuture.failedStage(ex);
        }

        NopRetryPolicy policy = loadPolicyOrDefault(record.getPolicyId());
        ApiRequest<?> request = ApiRequest.build(JsonTool.parseMap(requestPayload));

        return executeWithRetry(record, policy, request, cancelToken, null);
    }

    private CompletionStage<ApiResponse<?>> executeWithRetry(
            NopRetryRecord record,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task) {

        long deadlineTimeoutMs = policy.getDeadlineTimeoutMsOrDefault();
        if (deadlineTimeoutMs > 0) {
            Timestamp createTime = record.getCreateTime();
            if (createTime != null) {
                long elapsed = recordStore.getCurrentTime() - createTime.getTime();
                if (elapsed > deadlineTimeoutMs) {
                    return handleDeadlineExceeded(record);
                }
            }
        }

        if (isImmediateRetryPhase(record, policy)) {
            return executeImmediateRetry(record, policy, request, cancelToken, task);
        } else {
            return executeSingleAttempt(record, policy, request, cancelToken, task);
        }
    }

    private boolean isImmediateRetryPhase(NopRetryRecord record, NopRetryPolicy policy) {
        int immediateRetryCount = policy.getImmediateRetryCountOrDefault();
        if (immediateRetryCount <= 0) {
            return false;
        }
        int retryCount = record.getRetryCount() != null ? record.getRetryCount() : 0;
        return retryCount < immediateRetryCount;
    }

    private CompletionStage<ApiResponse<?>> executeImmediateRetry(
            NopRetryRecord record,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task) {

        CompletableFuture<ApiResponse<?>> result = new CompletableFuture<>();
        int immediateRetryCount = policy.getImmediateRetryCountOrDefault();
        long immediateRetryIntervalMs = policy.getImmediateRetryIntervalMsOrDefault();

        doExecute(record, request, cancelToken)
                .whenComplete((response, ex) -> {
                    if (ex != null) {
                        int retryCount = (record.getRetryCount() != null ? record.getRetryCount() : 0) + 1;
                        if (retryCount < immediateRetryCount) {
                            record.setRetryCount(retryCount);
                            recordStore.updateRecord(record);
                            scheduleImmediateRetry(record, policy, request, cancelToken, task, immediateRetryIntervalMs)
                                    .whenComplete((r, e) -> {
                                        if (e != null) {
                                            result.completeExceptionally(e);
                                        } else {
                                            result.complete(r);
                                        }
                                    });
                        } else {
                            handleExecutionFailure(record, policy, ex, task);
                            result.completeExceptionally(ex);
                        }
                    } else if (response != null && response.isOk()) {
                        handleExecutionSuccess(record, policy, task);
                        result.complete(response);
                    } else {
                        NopException failureEx = response != null
                                ? NopRebuildException.rebuild(response)
                                : new NopException(ERR_RETRY_DEAD_LETTER_INVALID_EXECUTOR);
                        if (failureEx.isBizFatal()) {
                            // bizFatal 不重试，直接移入死信
                            moveToDeadLetter(record, failureEx);
                            result.complete(response);
                        } else {
                            int retryCount = (record.getRetryCount() != null ? record.getRetryCount() : 0) + 1;
                            if (retryCount < immediateRetryCount) {
                                record.setRetryCount(retryCount);
                                recordStore.updateRecord(record);
                                scheduleImmediateRetry(record, policy, request, cancelToken, task, immediateRetryIntervalMs)
                                        .whenComplete((r, e) -> {
                                            if (e != null) {
                                                result.completeExceptionally(e);
                                            } else {
                                                result.complete(r);
                                            }
                                        });
                            } else {
                                handleExecutionFailure(record, policy, failureEx, task);
                                result.complete(response);
                            }
                        }
                    }
                });

        return result;
    }

    private CompletionStage<ApiResponse<?>> scheduleImmediateRetry(
            NopRetryRecord record,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task,
            long immediateRetryIntervalMs) {

        // Capture the executor at scheduling time to prevent stale callbacks from
        // leaking retries into a different test's executor (gh-xxx stale-callback race).
        IScheduledExecutor executor = getExecutor();
        CompletableFuture<ApiResponse<?>> future = new CompletableFuture<>();

        executor.schedule(() -> {
            executeImmediateRetry(record, policy, request, cancelToken, task)
                    .whenComplete((resp, ex) -> {
                        if (ex != null) {
                            future.completeExceptionally(ex);
                        } else {
                            future.complete(resp);
                        }
                    });
            return null;
        }, immediateRetryIntervalMs, TimeUnit.MILLISECONDS);

        return future;
    }

    private CompletionStage<ApiResponse<?>> executeSingleAttempt(
            NopRetryRecord record,
            NopRetryPolicy policy,
            ApiRequest<?> request,
            ICancelToken cancelToken,
            IRetryTask task) {

        return doExecute(record, request, cancelToken)
                .whenComplete((response, ex) -> {
                    if (ex != null) {
                        handleExecutionFailure(record, policy, ex, task);
                    } else if (response != null && response.isOk()) {
                        handleExecutionSuccess(record, policy, task);
                    } else {
                        NopException failureEx = response != null
                                ? NopRebuildException.rebuild(response)
                                : new NopException(ERR_RETRY_DEAD_LETTER_INVALID_EXECUTOR);
                        if (failureEx.isBizFatal()) {
                            // bizFatal 不重试，直接移入死信
                            moveToDeadLetter(record, failureEx);
                        } else {
                            handleExecutionFailure(record, policy, failureEx, task);
                        }
                    }
                });
    }

    private CompletionStage<ApiResponse<?>> doExecute(
            NopRetryRecord record,
            ApiRequest<?> request,
            ICancelToken cancelToken) {

        NopRetryAttempt attempt = recordStore.newAttempt(record);
        attempt.setStatus(NopRetryConstants.RETRY_ATTEMPT_STATUS_RUNNING);
        recordStore.saveAttempt(attempt);

        return rpcServiceInvoker.invokeAsync(
                record.getServiceName(),
                record.getServiceMethod(),
                request,
                cancelToken
        ).whenComplete((response, ex) -> {
            long endTime = recordStore.getCurrentTime();
            Timestamp startTime = attempt.getStartTime();
            attempt.setEndTime(new Timestamp(endTime));
            attempt.setDurationMs(startTime != null ? endTime - startTime.getTime() : null);

            if (ex != null) {
                attempt.setStatus(NopRetryConstants.RETRY_ATTEMPT_STATUS_FAILED);
                ErrorBean errorBean = ErrorMessageManager.instance().buildErrorMessage(null, ex);
                attempt.setErrorCode(errorBean.getErrorCode());
                attempt.setErrorMessage(errorBean.getDescription());
                attempt.setErrorStack(errorBean.getErrorStack());
            } else if (response != null && response.isOk()) {
                attempt.setStatus(NopRetryConstants.RETRY_ATTEMPT_STATUS_SUCCESS);
            } else {
                attempt.setStatus(NopRetryConstants.RETRY_ATTEMPT_STATUS_FAILED);
                ErrorBean errorBean = response != null
                        ? ErrorMessageManager.instance().buildErrorMessage(null, NopRebuildException.rebuild(response))
                        : ErrorMessageManager.instance().buildErrorMessage(null,
                                new NopException(ERR_RETRY_DEAD_LETTER_INVALID_EXECUTOR));
                attempt.setErrorCode(errorBean.getErrorCode());
                attempt.setErrorMessage(errorBean.getDescription());
                attempt.setErrorStack(errorBean.getErrorStack());
            }
            recordStore.saveAttempt(attempt);
        });
    }

    private CompletionStage<ApiResponse<?>> handleDeadlineExceeded(NopRetryRecord record) {
        LOG.warn("nop.retry.deadline-exceeded:recordId={}", record.getSid());
        moveToDeadLetter(record, "DEADLINE_EXCEEDED", "Deadline timeout exceeded", null);
        return CompletableFuture.failedStage(
                new NopException(ERR_RETRY_DEADLINE_EXCEEDED)
                        .param(ARG_RECORD_ID, record.getSid()));
    }

    private void handleExecutionSuccess(NopRetryRecord record, NopRetryPolicy policy, IRetryTask task) {
        record.setStatus(NopRetryConstants.RETRY_RECORD_STATUS_COMPLETED);
        recordStore.updateRecord(record);
        LOG.info("nop.retry.task-completed:recordId={}", record.getSid());

        if (policy.hasCallbackPolicy() && shouldTriggerCallback(policy, true)) {
            triggerCallback(record, policy, true, null);
        }
    }

    private void handleExecutionFailure(NopRetryRecord record, NopRetryPolicy policy, Throwable ex, IRetryTask task) {
        LOG.error("nop.retry.task-failed:recordId={}", record.getSid(), ex);

        int retryCount = (record.getRetryCount() != null ? record.getRetryCount() : 0) + 1;
        record.setRetryCount(retryCount);
        int maxRetryCount = record.getMaxRetryCount() != null ? record.getMaxRetryCount() : policy.getMaxRetryCountOrDefault();

        if (retryCount >= maxRetryCount) {
            moveToDeadLetter(record, ex);
            if (policy.hasCallbackPolicy() && shouldTriggerCallback(policy, false)) {
                triggerCallback(record, policy, false, ex);
            }
        } else {
            long nextTriggerTime = calculateNextTriggerTime(record, policy);
            record.setNextTriggerTime(new Timestamp(nextTriggerTime));
            record.setStatus(NopRetryConstants.RETRY_RECORD_STATUS_PENDING);
            recordStore.updateRecord(record);
        }
    }

    private boolean shouldTriggerCallback(NopRetryPolicy policy, boolean success) {
        switch (policy.getCallbackTriggerTypeOrDefault()) {
            case NopRetryConstants.CALLBACK_TRIGGER_TYPE_ON_SUCCESS:
                return success;
            case NopRetryConstants.CALLBACK_TRIGGER_TYPE_ON_FAILURE:
                return !success;
            case NopRetryConstants.CALLBACK_TRIGGER_TYPE_ALWAYS:
            default:
                return true;
        }
    }

    private void triggerCallback(NopRetryRecord record, NopRetryPolicy policy, boolean success, Throwable error) {
        if (!policy.hasCallbackPolicy()) {
            LOG.debug("nop.retry.callback-policy-not-configured:recordId={}", record.getSid());
            return;
        }

        String callbackService = record.getServiceName();
        String callbackMethod = record.getServiceMethod();
        if (StringHelper.isEmpty(callbackService) || StringHelper.isEmpty(callbackMethod)) {
            LOG.warn("nop.retry.callback-service-not-configured:recordId={}", record.getSid());
            return;
        }

        // 创建回调任务，使用 callbackPolicyId 作为策略
        IRetryTask callbackTask = newRetryTask(callbackService, callbackMethod)
                .withPolicyId(policy.getCallbackPolicyId())
                .withIdempotentId(record.getIdempotentId() + "_callback");

        ApiRequest<Object> callbackRequest = new ApiRequest<>();
        callbackRequest.setData(buildCallbackData(record, success, error));

        // 异步执行回调任务
        executeTask(callbackTask, callbackRequest, null)
                .whenComplete((resp, ex) -> {
                    if (ex != null) {
                        LOG.error("nop.retry.callback-failed:recordId={}", record.getSid(), ex);
                    } else if (resp != null && resp.isOk()) {
                        LOG.info("nop.retry.callback-success:recordId={}", record.getSid());
                    } else {
                        LOG.warn("nop.retry.callback-response-error:recordId={},status={}",
                                record.getSid(), resp != null ? resp.getStatus() : null);
                    }
                });
    }

    private Object buildCallbackData(NopRetryRecord record, boolean success, Throwable error) {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        data.put("recordId", record.getSid());
        data.put("idempotentId", record.getIdempotentId());
        data.put("success", success);
        data.put("retryCount", record.getRetryCount());
        if (error != null) {
            data.put("errorCode", error instanceof NopException ? ((NopException) error).getErrorCode() : "UNKNOWN");
            data.put("errorMessage", error.getMessage());
        }
        return data;
    }

    private void moveToDeadLetter(NopRetryRecord record, Throwable ex) {
        ErrorBean errorBean = ErrorMessageManager.instance().buildErrorMessage(null, ex);
        recordStore.moveToDeadLetter(record, errorBean.getErrorCode(), errorBean.getDescription(), errorBean.getErrorStack());
        LOG.warn("nop.retry.task-moved-to-dead-letter:recordId={}", record.getSid());
    }

    private void moveToDeadLetter(NopRetryRecord record, String errorCode, String errorMessage, String errorStack) {
        recordStore.moveToDeadLetter(record, errorCode, errorMessage, errorStack);
        LOG.warn("nop.retry.task-moved-to-dead-letter:recordId={}", record.getSid());
    }

    private long calculateNextTriggerTime(NopRetryRecord record, NopRetryPolicy policy) {
        int retryCount = record.getRetryCount() != null ? record.getRetryCount() : 0;

        long interval;
        if (policy.getBackoffStrategyOrDefault() == NopRetryConstants.BACKOFF_STRATEGY_EXPONENTIAL_BACKOFF) {
            interval = policy.getInitialIntervalMsOrDefault() * (1L << Math.min(retryCount - 1, 10));
        } else {
            interval = policy.getInitialIntervalMsOrDefault();
        }

        interval = Math.min(interval, policy.getMaxIntervalMsOrDefault());

        double jitterRatio = policy.getJitterRatioOrDefault();
        if (jitterRatio > 0) {
            double jitterFactor = 1.0 + (Math.random() * 2 - 1) * jitterRatio;
            interval = (long) (interval * jitterFactor);
        }

        return recordStore.getCurrentTime() + interval;
    }

    protected IScheduledExecutor getExecutor() {
        if (executor == null) {
            executor = GlobalExecutors.globalTimer().executeOn(GlobalExecutors.globalWorker());
        }
        return executor;
    }

    public void setExecutor(IScheduledExecutor executor) {
        this.executor = executor;
    }

    @Override
    protected void doStart() {
        if (retryScanner != null) {
            retryScanner.startScanning(records -> {
                // 内部并发执行每个 record
                CompletableFuture<?>[] futures = records.stream()
                        .map(record -> executeRetryFromScanner(record, null)
                                .whenComplete((resp, ex) -> {
                                    if (ex != null) {
                                        LOG.error("nop.retry.scanner.execute-failed:recordId={}", record.getSid(), ex);
                                    }
                                })
                                .toCompletableFuture())
                        .toArray(CompletableFuture[]::new);

                // 等待所有 record 执行完成
                CompletableFuture.allOf(futures).join();
            });
            LOG.info("nop.retry.scanner-started");
        }
    }

    @Override
    protected void doStop() {
        if (retryScanner != null) {
            retryScanner.stopScanning();
            LOG.info("nop.retry.scanner-stopped");
        }
    }
}
