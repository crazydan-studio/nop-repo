/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.ioc.api;

import io.nop.api.core.config.IConfigProvider;
import io.nop.api.core.ioc.BeanContainerStartMode;
import io.nop.api.core.ioc.IBeanContainer;
import io.nop.commons.lang.IClassLoader;
import io.nop.commons.service.ILifeCycle;
import io.nop.core.lang.xml.XNode;
import io.nop.ioc.impl.BeanCreationContext;
import io.nop.ioc.impl.IBeanClassIntrospection;
import jakarta.annotation.Nonnull;

import java.lang.annotation.Annotation;
import java.util.Map;

public interface IBeanContainerImplementor extends IBeanContainer, ILifeCycle {
    boolean isStarted();

    void restart();

    BeanContainerStartMode getStartMode();

    Object getConfigValue(String varName);

    default Map<String, Object> getConfigValueWithPrefix(String prefix) {
        return getConfigProvider().getConfigValueForPrefix(prefix);
    }

    IConfigProvider getConfigProvider();

    void refreshConfig(String beanId);

    void destroyBean(String beanName, Object bean);

    IBeanClassIntrospection getClassIntrospection();

    IClassLoader getClassLoader();

    Object getBean(@Nonnull String name, boolean includeCreating, BeanCreationContext beanCtx);

    <T> T getBeanByType(Class<T> requiredType, boolean includeCreating, BeanCreationContext beanCtx);

    String findAutowireCandidate(Class<?> beanType);

    /**
     * 返回当前所有激活的bean对应的配置
     */
    XNode toConfigNode();

    IBeanDefinition getBeanDefinition(String name);

    Map<String, IBeanDefinition> getBeanDefinitionsByType(Class<?> requiredType);

    Map<String, IBeanDefinition> getBeanDefinitionsByAnnotation(Class<? extends Annotation> annClass);

    IBeanContainer buildNewInstance(IBeanContainer parentContainer);
}