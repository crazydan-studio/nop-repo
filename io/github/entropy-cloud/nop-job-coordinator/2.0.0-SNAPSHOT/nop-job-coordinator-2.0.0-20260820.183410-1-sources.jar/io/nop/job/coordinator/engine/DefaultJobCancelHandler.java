package io.nop.job.coordinator.engine;

import io.nop.api.core.ApiConstants;
import io.nop.api.core.ioc.BeanContainer;
import io.nop.job.api.JobInstanceState;
import io.nop.job.api.execution.IJobExecutionContext;
import io.nop.job.api.execution.IJobInvoker;
import io.nop.job.core._NopJobCoreConstants;
import io.nop.job.dao.entity.NopJobFire;
import io.nop.job.dao.entity.NopJobSchedule;
import io.nop.job.dao.entity.NopJobTask;
import io.nop.job.dao.helper.JobScheduleStateMachine;
import io.nop.job.dao.helper.JobTaskStateMachine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;

public class DefaultJobCancelHandler implements IJobCancelHandler {
    static final Logger LOG = LoggerFactory.getLogger(DefaultJobCancelHandler.class);
    static final String INVOKER_PREFIX = "nopJobInvoker_";

    @Override
    public void cancelRunningTask(NopJobSchedule schedule, NopJobFire fire, NopJobTask task) {
        String executorKind = resolveExecutorKind(schedule, fire);
        IJobInvoker invoker = resolveInvoker(executorKind);
        if (invoker == null) {
            LOG.debug("nop.job.cancel.invoker-not-found:scheduleId={},fireId={},taskId={},executorKind={}",
                    schedule.getJobScheduleId(), fire.getJobFireId(), task.getJobTaskId(), executorKind);
            return;
        }

        try {
            CompletionStage<Boolean> promise = invoker.cancelAsync(new CancelJobExecutionContext(schedule, fire, task));
            if (promise != null) {
                promise.whenComplete((ret, err) -> {
                    if (err != null) {
                        LOG.warn("nop.job.cancel.invoke-failed:scheduleId={},fireId={},taskId={}",
                                schedule.getJobScheduleId(), fire.getJobFireId(), task.getJobTaskId(), err);
                    }
                });
            }
        } catch (Exception e) {
            LOG.warn("nop.job.cancel.invoke-failed:scheduleId={},fireId={},taskId={}",
                    schedule.getJobScheduleId(), fire.getJobFireId(), task.getJobTaskId(), e);
        }
    }

    private IJobInvoker resolveInvoker(String executorKind) {
        if (executorKind == null || executorKind.isBlank() || !BeanContainer.isInitialized()) {
            return null;
        }
        Object bean = BeanContainer.tryGetBean(INVOKER_PREFIX + executorKind);
        return bean instanceof IJobInvoker ? (IJobInvoker) bean : null;
    }

    private String resolveExecutorKind(NopJobSchedule schedule, NopJobFire fire) {
        String kind = fire.getExecutorKind();
        return kind != null ? kind : schedule.getExecutorKind();
    }

    private static Map<String, Object> resolveJobParams(NopJobSchedule schedule, NopJobFire fire, NopJobTask task) {
        Map<String, Object> jobParams = task.getEffectiveParams(fire);
        if (jobParams.isEmpty() && schedule != null) {
            Map<String, Object> scheduleParams = schedule.getJobParamsComponent().get_jsonMap();
            if (scheduleParams != null) {
                jobParams = new LinkedHashMap<>(scheduleParams);
            }
        }

        if (task.getTargetHost() != null && !task.getTargetHost().isBlank()) {
            @SuppressWarnings("unchecked")
            Map<String, Object> headers = (Map<String, Object>) jobParams.computeIfAbsent("headers", k -> new LinkedHashMap<String, Object>());
            headers.put(ApiConstants.HEADER_SVC_TARGET_HOST, task.getTargetHost());
        }

        return jobParams;
    }

    private static final class CancelJobExecutionContext extends JobInstanceState implements IJobExecutionContext {
        private final long minScheduleTime;
        private final long maxScheduleTime;
        private final long maxExecutionCount;
        private final boolean jobFinished;
        private final boolean instanceRunning;
        private final boolean scheduleEnabled;

        private CancelJobExecutionContext(NopJobSchedule schedule, NopJobFire fire, NopJobTask task) {
            setJobDefId(schedule.getJobScheduleId());
            setJobGroup(schedule.getGroupId());
            setJobName(schedule.getJobName());
            setJobVersion(0L);
            setJobParams(resolveJobParams(schedule, fire, task));
            setInstanceId(task.getJobTaskId());
            setExecCount(defaultLong(schedule.getFireCount()));
            setScheduledExecTime(toTime(fire.getScheduledFireTime()));
            setExecBeginTime(toTime(task.getStartTime()));
            setExecEndTime(toTime(task.getEndTime()));
            setOnceTask(schedule.getTriggerType() != null
                    && schedule.getTriggerType() == _NopJobCoreConstants.TRIGGER_TYPE_ONCE);
            setManualFire(fire.getTriggerSource() != null
                    && fire.getTriggerSource() == _NopJobCoreConstants.TRIGGER_SOURCE_MANUAL);
            setFiredBy(fire.getTriggeredBy());
            setChangeVersion(defaultLong(task.getVersion()));
            setInstanceStatus(defaultInt(task.getTaskStatus()));

            if (task.getTargetHost() != null && !task.getTargetHost().isBlank()) {
                setAttribute("targetHost", task.getTargetHost());
            }

            this.minScheduleTime = toTime(schedule.getMinScheduleTime());
            this.maxScheduleTime = toTime(schedule.getMaxScheduleTime());
            this.maxExecutionCount = defaultLong(schedule.getMaxExecutionCount());
            this.jobFinished = JobScheduleStateMachine.isCompleted(schedule.getScheduleStatus());
            this.instanceRunning = JobTaskStateMachine.isRunning(task.getTaskStatus());
            this.scheduleEnabled = JobScheduleStateMachine.isEnabled(schedule.getScheduleStatus());
        }

        @Override
        public long getMinScheduleTime() {
            return minScheduleTime;
        }

        @Override
        public long getMaxScheduleTime() {
            return maxScheduleTime;
        }

        @Override
        public long getMaxExecutionCount() {
            return maxExecutionCount;
        }

        @Override
        public long getMaxFailedCount() {
            return 0;
        }

        @Override
        public boolean isJobFinished() {
            return jobFinished;
        }

        @Override
        public boolean isInstanceRunning() {
            return instanceRunning;
        }

        @Override
        public boolean isScheduleEnabled() {
            return scheduleEnabled;
        }

        private static long toTime(java.sql.Timestamp value) {
            return value == null ? 0L : value.getTime();
        }

        private static long defaultLong(Number value) {
            return value == null ? 0L : value.longValue();
        }

        private static int defaultInt(Integer value) {
            return value == null ? 0 : value;
        }
    }
}
