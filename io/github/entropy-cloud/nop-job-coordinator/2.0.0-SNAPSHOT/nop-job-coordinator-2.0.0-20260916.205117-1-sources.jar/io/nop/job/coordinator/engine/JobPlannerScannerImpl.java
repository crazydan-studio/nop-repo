package io.nop.job.coordinator.engine;

import io.nop.job.core.JobCoreErrors;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.annotations.ioc.InjectValue;
import io.nop.api.core.annotations.orm.SingleSession;
import io.nop.api.core.beans.IntRangeSet;
import io.nop.api.core.config.AppConfig;
import io.nop.commons.util.StringHelper;
import io.nop.dao.api.IDaoProvider;
import io.nop.job.api.spec.TriggerSpec;
import io.nop.job.coordinator.metrics.IJobPlannerMetrics;
import io.nop.job.coordinator.metrics.JobPlannerMetricsImpl;
import io.nop.job.core.AbstractBatchScanner;
import io.nop.job.core.ITriggerEvalContext;
import io.nop.job.core._NopJobCoreConstants;
import io.nop.job.core.trigger.JobTriggerCalculator;
import io.nop.job.dao.entity.NopJobFire;
import io.nop.job.dao.entity.NopJobSchedule;
import io.nop.job.dao.helper.JobScheduleStateMachine;
import io.nop.job.dao.helper.TriggerSpecHelper;
import io.nop.job.dao.store.IJobScheduleStore;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class JobPlannerScannerImpl extends AbstractBatchScanner implements IJobPlannerScanner {
    static final Logger LOG = LoggerFactory.getLogger(JobPlannerScannerImpl.class);

    private IJobScheduleStore scheduleStore;
    private IJobPlannerMetrics plannerMetrics = new JobPlannerMetricsImpl();
    private IDaoProvider daoProvider;
    private long planningTimeoutMs = 60000;

    @Inject
    public void setScheduleStore(IJobScheduleStore scheduleStore) {
        this.scheduleStore = scheduleStore;
    }

    public void setPlannerMetrics(IJobPlannerMetrics plannerMetrics) {
        this.plannerMetrics = plannerMetrics;
    }

    @Inject
    public void setDaoProvider(IDaoProvider daoProvider) {
        this.daoProvider = daoProvider;
    }

    @InjectValue("@cfg:nop.job.coordinator.planner.scan-interval-ms|5000")
    public void setScanIntervalMs(int scanIntervalMs) {
        applyScanIntervalMs(scanIntervalMs);
    }

    @InjectValue("@cfg:nop.job.coordinator.planner.batch-size|100")
    public void setBatchSize(int batchSize) {
        applyBatchSize(batchSize);
    }

    @InjectValue("@cfg:nop.job.coordinator.planner.lock-timeout-ms|60000")
    public void setPlanningTimeoutMs(long planningTimeoutMs) {
        if (planningTimeoutMs < 1000) {
            throw new NopException(JobCoreErrors.ERR_JOB_CONFIG_INVALID)
                    .param(JobCoreErrors.ARG_CONFIG_KEY, "nop.job.planner.lock-timeout-ms")
                    .param(JobCoreErrors.ARG_VALUE, planningTimeoutMs);
        }
        this.planningTimeoutMs = planningTimeoutMs;
    }

    @Override
    protected void onScanFailed(Exception e) {
        LOG.error("nop.job.planner.scan-failed", e);
    }

    @Override
    @SingleSession
    protected boolean scanBatch() {
        IntRangeSet partitions = resolvePartitions();
        List<NopJobSchedule> schedules = scheduleStore.fetchDueSchedules(batchSize, partitions);
        if (schedules.isEmpty()) {
            return false;
        }

        // Snapshot the due fire time BEFORE tryLockSchedulesForPlan: that method overwrites
        // schedule.nextFireTime with a future lock deadline (now + lockTimeoutMs) as the
        // planner's optimistic lock, so the original due time would be lost if read back
        // from the entity afterwards. The snapshot is passed to planSchedule → buildFire to
        // set fire.scheduledFireTime to the real due time (not the lock deadline).
        Map<String, Timestamp> dueFireTimes = new HashMap<>(schedules.size());
        for (NopJobSchedule schedule : schedules) {
            dueFireTimes.put(schedule.getJobScheduleId(), schedule.getNextFireTime());
        }

        List<NopJobSchedule> locked = scheduleStore.tryLockSchedulesForPlan(
                schedules,
                AppConfig.hostId(),
                planningTimeoutMs
        );

        int dueCount = schedules.size();
        int lockedCount = locked.size();
        int conflictCount = dueCount - lockedCount;

        if (dueCount > 0) {
            plannerMetrics.onDueSchedules(dueCount);
        }

        if (conflictCount > 0) {
            plannerMetrics.onLockConflicts(conflictCount);
        }

        if (conflictCount > 0 && LOG.isDebugEnabled()) {
            List<String> conflictIds = schedules.stream()
                    .map(NopJobSchedule::getJobScheduleId)
                    .filter(id -> locked.stream().noneMatch(l -> l.getJobScheduleId().equals(id)))
                    .collect(Collectors.toList());
            LOG.debug("nop.job.planner.lock-conflict:dueCount={},lockedCount={},conflictIds={}",
                    dueCount, lockedCount, conflictIds);
        }

        for (NopJobSchedule schedule : locked) {
            try {
                planSchedule(schedule, dueFireTimes.get(schedule.getJobScheduleId()));
            } catch (Exception e) {
                LOG.error("nop.job.planner.plan-schedule-failed:scheduleId={}", schedule.getJobScheduleId(), e);
            }
        }

        return schedules.size() >= batchSize;
    }

    private NopJobFire buildFire(NopJobSchedule schedule, Timestamp dueFireTime) {
        NopJobFire fire = daoProvider.daoFor(NopJobFire.class).newEntity();
        fire.setJobScheduleId(schedule.getJobScheduleId());
        fire.setNamespaceId(schedule.getNamespaceId());
        fire.setGroupId(schedule.getGroupId());
        fire.setJobName(schedule.getJobName());
        fire.setTriggerSource(_NopJobCoreConstants.TRIGGER_SOURCE_SCHEDULE);
        fire.setScheduledFireTime(dueFireTime);
        fire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_WAITING);
        fire.setPlannerInstanceId(AppConfig.hostId());
        fire.setPartitionIndex(schedule.getPartitionIndex());
        fire.setRetryPolicyId(schedule.getRetryPolicyId());
        fire.getJobParamsSnapshotComponent().set_jsonValue(copyMap(schedule.getJobParamsComponent().get_jsonMap()));
        fire.setExecutorKind(schedule.getExecutorKind());
        fire.setDispatchMode(schedule.getDispatchMode());
        return fire;
    }

    private void planSchedule(NopJobSchedule schedule, Timestamp dueFireTime) {
        Timestamp nextFireTime = calculateNextFireTime(schedule);

        if (schedule.getScheduleStatus() != null
                && !JobScheduleStateMachine.isEnabled(schedule.getScheduleStatus())) {
            LOG.debug("nop.job.planner.schedule-no-longer-enabled:scheduleId={},status={}",
                    schedule.getJobScheduleId(), schedule.getScheduleStatus());
            return;
        }

        if (isTriggerExhausted(schedule, nextFireTime, dueFireTime)) {
            // check2 [P0]: trigger 链已耗尽（OnceTrigger 的持久化 once 判定/misfire 丢弃返回-1）。
            // 当前 due 槽位已被消费（lastFireTime >= dueFireTime，如 once schedule 首次触发后
            // nextFireTime 被写回为同一个过去时刻导致重复 due）或 once 型 schedule 被判定耗尽时，
            // 不得再插入任何新 fire，直接置 nextFireTime=null 使 schedule 转入 dormant。
            // 注意与 fixed-delay 区分：其 nextFireTime=null 是设计语义（完成时才计算下一次），
            // 由 isFixedDelay 提前短路，不进本分支。
            LOG.info("nop.job.planner.trigger-exhausted:scheduleId={},dueFireTime={}",
                    schedule.getJobScheduleId(), dueFireTime);
            scheduleStore.advanceScheduleAfterSkip(schedule, null);
            return;
        }

        // check2 [P3-2]: 未知 blockStrategy 统一按 DISCARD 处理（跳过 + warn）。此前该分支以
        // activeFireCount>0 为前提——忙时跳过、闲时落入普通插入执行，同一非法配置产生两种行为
        // 且 warn 只在忙时出现；现与忙闲状态解耦，行为一致、排障日志恒可见。
        if (schedule.getBlockStrategy() != null
                && !isKnownBlockStrategy(schedule.getBlockStrategy())) {
            LOG.warn("nop.job.planner.unknown-block-strategy:scheduleId={},blockStrategy={},defaulting to DISCARD",
                    schedule.getJobScheduleId(), schedule.getBlockStrategy());
            scheduleStore.advanceScheduleAfterSkip(schedule, nextFireTime);
            return;
        }

        if (shouldDiscard(schedule)) {
            scheduleStore.advanceScheduleAfterSkip(schedule, nextFireTime);
            return;
        }

        if (shouldRecovery(schedule)) {
            scheduleStore.recoveryFireAndAdvanceSchedule(schedule, nextFireTime);
            return;
        }

        NopJobFire fire = buildFire(schedule, dueFireTime);
        if (shouldOverlay(schedule)) {
            scheduleStore.overlayFireAndAdvanceSchedule(schedule, fire, nextFireTime,
                    _NopJobCoreConstants.FIRE_STATUS_WAITING);
            return;
        }

        if (shouldParallel(schedule)) {
            scheduleStore.insertFireAndAdvanceSchedule(schedule, fire, nextFireTime,
                    _NopJobCoreConstants.FIRE_STATUS_WAITING);
            return;
        }

        scheduleStore.insertFireAndAdvanceSchedule(schedule, fire, nextFireTime,
                _NopJobCoreConstants.FIRE_STATUS_WAITING);
    }

    private Timestamp calculateNextFireTime(NopJobSchedule schedule) {
        if (schedule.getTriggerType() != null &&
                schedule.getTriggerType() == _NopJobCoreConstants.TRIGGER_TYPE_FIXED_DELAY) {
            return null;
        }

        long next = JobTriggerCalculator.calculateNextFireTime(
                toTriggerSpec(schedule),
                toEvalContext(schedule),
                scheduleStore.getCurrentTime()
        );
        return next <= 0 ? null : new Timestamp(next);
    }

    /**
     * check2 [P0]：非 fixed-delay 的 schedule 计算结果为 null 表示 trigger 链已耗尽。此时：
     * <ul>
     * <li>once 型（无 cron 且 repeatInterval<=0，对应 OnceTrigger）：耗尽即终局——无论 due 槽位
     * 是否已消费（已触发过 lastFireTime>=onceTime，或 misfire 丢弃），都不得再创建 fire；</li>
     * <li>周期型（cron/fixed-rate）：仅当 due 槽位已被消费（lastFireTime >= dueFireTime，重复 due）
     * 时跳过；due 槽位尚未消费（如到达 maxScheduleTime 边界的最后一次 catch-up 触发）仍照常触发。</li>
     * </ul>
     */
    private boolean isTriggerExhausted(NopJobSchedule schedule, Timestamp nextFireTime, Timestamp dueFireTime) {
        if (nextFireTime != null) {
            return false;
        }
        if (schedule.getTriggerType() != null
                && schedule.getTriggerType() == _NopJobCoreConstants.TRIGGER_TYPE_FIXED_DELAY) {
            return false;
        }
        boolean onceLike = StringHelper.isEmpty(schedule.getCronExpr())
                && defaultLong(schedule.getRepeatIntervalMs()) <= 0;
        if (onceLike) {
            return true;
        }
        Timestamp lastFireTime = schedule.getLastFireTime();
        return lastFireTime != null && !dueFireTime.after(lastFireTime);
    }

    private long defaultLong(Long value) {
        return value == null ? 0L : value;
    }

    private TriggerSpec toTriggerSpec(NopJobSchedule schedule) {
        return TriggerSpecHelper.toTriggerSpec(schedule);
    }

    private ITriggerEvalContext toEvalContext(NopJobSchedule schedule) {
        return TriggerSpecHelper.toEvalContext(schedule);
    }

    private Map<String, Object> copyMap(Map<String, Object> map) {
        return map == null ? Collections.emptyMap() : map;
    }

    private boolean shouldDiscard(NopJobSchedule schedule) {
        return defaultInt(schedule.getActiveFireCount()) > 0
                && schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_DISCARD;
    }

    private boolean shouldOverlay(NopJobSchedule schedule) {
        return defaultInt(schedule.getActiveFireCount()) > 0
                && schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_OVERLAY;
    }

    private boolean shouldRecovery(NopJobSchedule schedule) {
        return defaultInt(schedule.getActiveFireCount()) > 0
                && schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_RECOVERY;
    }

    private boolean shouldParallel(NopJobSchedule schedule) {
        return schedule.getBlockStrategy() != null
                && schedule.getBlockStrategy() == _NopJobCoreConstants.BLOCK_STRATEGY_PARALLEL;
    }

    private boolean isKnownBlockStrategy(Integer blockStrategy) {
        return blockStrategy == _NopJobCoreConstants.BLOCK_STRATEGY_DISCARD
                || blockStrategy == _NopJobCoreConstants.BLOCK_STRATEGY_OVERLAY
                || blockStrategy == _NopJobCoreConstants.BLOCK_STRATEGY_RECOVERY
                || blockStrategy == _NopJobCoreConstants.BLOCK_STRATEGY_PARALLEL;
    }

    private int defaultInt(Integer value) {
        return value == null ? 0 : value;
    }
}
