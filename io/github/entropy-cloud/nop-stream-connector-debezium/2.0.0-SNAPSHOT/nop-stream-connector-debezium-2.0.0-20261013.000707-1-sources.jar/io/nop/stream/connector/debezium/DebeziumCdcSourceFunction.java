/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.connector.debezium;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.nop.api.core.util.ICancellable;
import io.nop.credential.api.ICredentialProvider;
import io.nop.message.debezium.ChangeEvent;
import io.nop.message.debezium.DebeziumConfig;
import io.nop.message.debezium.DebeziumMessageSource;
import io.nop.message.debezium.engine.DebeziumEngineWrapper;
import io.nop.message.debezium.engine.NopStreamOffsetBackingStore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.stream.core.checkpoint.OperatorSnapshotResult;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.common.functions.source.CheckpointedSourceFunction;
import io.nop.stream.core.common.functions.source.SourceConsistencyCapability;
import io.nop.stream.core.common.functions.source.SourceFunction;
import io.nop.stream.core.common.functions.source.SubtaskShardedSourceFunction;
import io.nop.stream.core.connector.ConnectivityCheckable;
import io.nop.stream.core.connector.DrainableSource;
import io.nop.stream.core.credentials.StreamCredentialSupport;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_STATE_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CONFIG_ERROR;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_STATE_ERROR;

/**
 * CDC source function wrapping the embedded Debezium engine.
 *
 * <p>Implements {@link CheckpointedSourceFunction} so the CDC consumption offset participates in
 * the nop-stream checkpoint protocol. On checkpoint the Debezium offset map held by a
 * {@link NopStreamOffsetBackingStore} is snapshotted into the operator state under key
 * {@value #CDC_OFFSETS_KEY}; on recovery the offset map is restored into a freshly created store
 * so the engine resumes from the checkpointed position (no duplicates, no data loss).
 *
 * <p>See {@code ai-dev/design/nop-stream/connector-design.md} §5.4 for the full design rationale.
 */
public class DebeziumCdcSourceFunction implements SubtaskShardedSourceFunction<ChangeEvent>,
        DrainableSource<ChangeEvent>,
        CheckpointedSourceFunction<ChangeEvent>, ConnectivityCheckable {

    private static final long serialVersionUID = 1L;

    private static final Logger LOG = LoggerFactory.getLogger(DebeziumCdcSourceFunction.class);

    /**
     * Operator-state key under which the CDC offset map is persisted in the checkpoint snapshot.
     */
    public static final String CDC_OFFSETS_KEY = "cdc-offsets";

    /**
     * Debezium connector configuration. No longer {@code transient}: {@link DebeziumConfig}
     * implements {@link java.io.Serializable}, so the connection info survives cross-JVM recovery.
     * Credential fields may hold {@code credential:{id}#{field}} REFERENCES — the reference
     * string (not plaintext) is what persists here and in every serialization path (D4).
     */
    private DebeziumConfig config;

    /**
     * Item 20 (P-REQ-14, D4): the platform credential decryption point, injected per
     * JVM assembly (constructor or {@link #setCredentialProvider}). {@code transient}
     * on purpose: the function's Java-serialization path (deployment descriptor /
     * checkpoint recovery) must not carry the provider; each JVM re-injects it. When
     * the config carries credential references and this field is null, decryption
     * fails closed (typed error, never silent empty).
     */
    private transient volatile ICredentialProvider credentialProvider;

    private volatile boolean running = true;
    private volatile boolean draining = false;
    private final AtomicBoolean runEntered = new AtomicBoolean(false);
    private transient volatile CountDownLatch completionLatch;
    private volatile DebeziumMessageSource source;
    private volatile ICancellable subscription;
    /**
     * R5-CON-02/CON-03: first error observed on the CDC path — either the downstream
     * collector throwing inside the subscription consumer (previously swallowed by the
     * upstream dispatcher, silently dropping the event while its offset still advanced)
     * or a terminal Debezium engine failure (previously only an ERROR log line, leaving
     * the task RUNNING with a dead CDC stream). {@code run()} rethrows it after the wait
     * loop exits so the task is recognized as FAILED and the checkpoint offset is not
     * advanced past the failure.
     */
    private transient volatile Throwable pendingError;

    /**
     * Offset backing store backing the checkpoint round-trip. {@code transient} because it is
     * rebuilt by {@link #initializeState(TaskStateSnapshot)} on recovery (the offset data itself
     * is carried in the checkpoint, not in the serialized source instance).
     */
    private transient NopStreamOffsetBackingStore offsetStore;

    /**
     * WI9 data-migration contract (ai-dev/design/nop-orm-data-migration-pipeline-design.md §4.2):
     * first-run CDC offset seeding. When non-null and the job has NO prior checkpoint
     * ({@code state == null}), the offset store is seeded with these entries AFTER the AR-03
     * stale-registry clear, so the engine resumes from the orchestrator-pinned position P0
     * (with {@code snapshot.mode=never}) instead of starting fresh. Serialized form is
     * {@code NopStreamOffsetBackingStore.toSerializable} (base64 key/value), which survives
     * Java serialization of this function. On recovery paths ({@code state != null}) the seed
     * is ignored — the checkpoint remains the single source of truth.
     */
    private Map<String, String> initialOffsets;

    /**
     * B-layer sharding identity (cdc-design.md §3.3): this copy's subtask index and the
     * total parallelism recorded at {@link #validateParallelism(int)} time. Defaults to the
     * single-instance identity (0, 1) — every pre-existing single-instance behavior is the
     * {@code totalParallelism == 1} path.
     */
    private int subtaskIndex;
    private int totalParallelism = 1;

    public DebeziumCdcSourceFunction(DebeziumConfig config) {
        this(config, null);
    }

    /**
     * Item 20 (P-REQ-14, D4): full constructor with the platform credential provider.
     * The provider decrypts {@code credential:{id}#{field}} references on the
     * engine-side transient path only — the original config (and therefore every
     * serialization/checkpoint path) keeps the reference string, never plaintext.
     */
    public DebeziumCdcSourceFunction(DebeziumConfig config, ICredentialProvider credentialProvider) {
        if (config == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "config");
        }
        this.config = config;
        this.credentialProvider = credentialProvider;
        this.completionLatch = new CountDownLatch(1);
    }

    /**
     * Per-JVM (re-)injection point for the credential provider, e.g. after Java
     * deserialization of the deployment pipeline spec (the transient field is null
     * on the deserialized instance until the host injects it).
     */
    public void setCredentialProvider(ICredentialProvider credentialProvider) {
        this.credentialProvider = credentialProvider;
    }

    /** Test visibility: the persistent config (credential REFERENCE strings, not plaintext). */
    DebeziumConfig getConfigForTest() {
        return config;
    }

    /** Test visibility: the transient per-JVM credential provider. */
    ICredentialProvider getCredentialProviderForTest() {
        return credentialProvider;
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        if (config == null) {
            config = new DebeziumConfig();
        }
        completionLatch = new CountDownLatch(1);
    }

    /**
     * Returns the offset store currently bound to this source (may be null before
     * {@link #initializeState(TaskStateSnapshot)} runs). Primarily for tests.
     */
    public NopStreamOffsetBackingStore getOffsetStore() {
        return offsetStore;
    }

    /**
     * WI9 first-run offset seeding (data-migration pipeline, design §4.2). The serialized map
     * is injected before deployment; it only takes effect on the true first run (no prior
     * checkpoint), keeping the AR-03 no-stale-inheritance semantics intact.
     */
    public void setInitialOffsets(Map<String, String> initialOffsets) {
        this.initialOffsets = initialOffsets;
    }

    /** Test visibility: the persistent first-run seed (may be null). */
    Map<String, String> getInitialOffsetsForTest() {
        return initialOffsets;
    }

    /**
     * Always creates a fresh completion latch. Reusing the previous run's latch is
     * unsafe: {@link #cancel()} already counted it down, so {@code await} would return
     * immediately and the run loop would exit (silent EOS) on a region-restart re-run.
     */
    private void initCompletionLatch() {
        this.completionLatch = new CountDownLatch(1);
    }

    /**
     * Creates the {@link DebeziumMessageSource} used by {@link #run(SourceContext)}. Protected so
     * tests can inject a mock/test-double source without spinning up a real Debezium engine.
     *
     * @param config      the Debezium configuration
     * @param offsetStore the offset store (may be null on first run with no prior checkpoint)
     * @return a new message source wired to the offset store
     */
    protected DebeziumMessageSource createMessageSource(DebeziumConfig config,
                                                        NopStreamOffsetBackingStore offsetStore) {
        return new DebeziumMessageSource(config, offsetStore);
    }

    @Override
    public void run(SourceContext<ChangeEvent> ctx) throws Exception {
        if (!runEntered.compareAndSet(false, true)) {
            return;
        }
        // Reset lifecycle state: a region restart reuses this instance (the rebuilt
        // operator chain shares the source function) after cancel() set running=false.
        // Without this reset the loop below exits immediately and the CDC source is
        // silently treated as EOS (missed changes, no error).
        this.running = true;
        this.draining = false;
        this.pendingError = null;
        initCompletionLatch();
        String connectorName = null;

        try {
            connectorName = resolveConnectorName();

            // R5-CON-03: a terminal engine failure (run() threw / CompletionCallback
            // success=false) must fail THIS task instead of leaving it RUNNING with a
            // silently dead CDC stream. The engine failure surfaces through the wrapper's
            // connector-name-keyed failure listener; it lands in pendingError and the wait
            // loop below exits and rethrows (same path as collector errors, R5-CON-02).
            DebeziumEngineWrapper.registerFailureListener(connectorName, error -> {
                if (pendingError == null) {
                    pendingError = error;
                }
                CountDownLatch latch = this.completionLatch;
                if (latch != null) {
                    latch.countDown();
                }
            });

            source = createMessageSource(effectiveEngineConfig(), offsetStore);
            try {
                subscription = source.subscribe(event -> {
                    try {
                        ctx.collect(event);
                    } catch (Exception e) {
                        // R5-CON-02: capture-and-rethrow. The upstream dispatcher swallows
                        // consumer exceptions by design; recording the first one here and
                        // failing run() keeps the declared REPLAYABLE semantics — the task
                        // fails and restarts from the last CHECKPOINTED offset instead of
                        // silently advancing past a dropped event.
                        if (pendingError == null) {
                            pendingError = e;
                        }
                        CountDownLatch latch = this.completionLatch;
                        if (latch != null) {
                            latch.countDown();
                        }
                    }
                });
            } catch (Exception e) {
                source.stop();
                throw e;
            }

            while (running && !draining) {
                if (pendingError != null) {
                    break;
                }
                if (completionLatch.await(1, TimeUnit.SECONDS)) {
                    break;
                }
            }

            if (pendingError != null) {
                // Rethrow after the finally block has unsubscribed and stopped the
                // source, so cleanup never races the failure propagation.
                throwPendingError();
            }
        } finally {
            DebeziumEngineWrapper.unregisterFailureListener(connectorName);
            if (subscription != null) {
                try {
                    subscription.cancel();
                } catch (Exception e) {
                    // cleanup path: never masks the primary result, but stays observable
                    LOG.warn("Failed to cancel CDC subscription during cleanup", e);
                }
                subscription = null;
            }
            if (source != null) {
                try {
                    source.stop();
                } catch (Exception e) {
                    // cleanup path: never masks the primary result, but stays observable
                    LOG.warn("Failed to stop Debezium message source during cleanup", e);
                }
                source = null;
            }
            runEntered.set(false);
        }
    }

    private void throwPendingError() throws Exception {
        Throwable error = pendingError;
        if (error instanceof Exception) {
            throw (Exception) error;
        }
        throw new StreamException(ERR_STREAM_STATE_ERROR).param(ARG_DETAIL,
                "Debezium CDC engine failed: " + error);
    }

    @Override
    public void cancel() {
        running = false;
        if (completionLatch != null) {
            completionLatch.countDown();
        }
        ICancellable sub = this.subscription;
        if (sub != null) {
            sub.cancel();
        }
        DebeziumMessageSource msgSource = this.source;
        if (msgSource != null) {
            msgSource.stop();
        }
    }

    @Override
    public SourceConsistencyCapability getSourceConsistency() {
        return SourceConsistencyCapability.REPLAYABLE;
    }

    @Override
    public void truncateForDrain() throws Exception {
        draining = true;
        ICancellable sub = this.subscription;
        if (sub != null) {
            sub.cancel();
            subscription = null;
        }
        DebeziumMessageSource msgSource = this.source;
        if (msgSource != null) {
            msgSource.stop();
            source = null;
        }
        if (completionLatch != null) {
            completionLatch.countDown();
        }
    }

    public boolean isDraining() {
        return draining;
    }

    // ---- CheckpointedSourceFunction ----

    @Override
    public OperatorSnapshotResult snapshotState(long checkpointId) throws Exception {
        OperatorSnapshotResult result = new OperatorSnapshotResult();
        result.setCheckpointId(checkpointId);

        NopStreamOffsetBackingStore store = this.offsetStore;
        if (store == null) {
            // No offset store bound (e.g. snapshot before run/initializeState). Persist an empty
            // offset map so restore sees a well-formed entry rather than a missing one.
            result.putOperatorState(CDC_OFFSETS_KEY, new java.util.TreeMap<>());
            return result;
        }

        Map<java.nio.ByteBuffer, java.nio.ByteBuffer> offsets = store.getOffsets();
        result.putOperatorState(CDC_OFFSETS_KEY, NopStreamOffsetBackingStore.toSerializable(offsets));
        return result;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initializeState(TaskStateSnapshot state) throws Exception {
        if (state == null) {
            // First run: no prior checkpoint. Clear any stale static-registry offset left by a
            // previous run in the same JVM (crashed run / redeploy / another pipeline reusing
            // the connector name), then create an empty store so the engine starts fresh.
            this.offsetStore = newFreshOffsetStore();
            // WI9 data-migration seeding (design §4.2): after the AR-03 stale clear, seed the
            // orchestrator-pinned position P0 so the engine resumes from P0 (snapshot.mode=never)
            // instead of starting fresh. Only the "no CDC offset truth" runs consume the seed.
            seedOffsetStoreIfPresent();
            return;
        }

        Object raw = state.getOperatorState(CDC_OFFSETS_KEY);
        if (raw == null) {
            // Prior checkpoint existed but carried no CDC offset entry. Start fresh rather than
            // silently dropping the offset: clear stale static-registry offsets and bind an
            // empty store.
            this.offsetStore = newFreshOffsetStore();
            // WI9 seeding applies here too: the core runtime's first-run path passes a NON-null
            // empty TaskStateSnapshot (StreamSourceOperator builds one when no prior checkpoint
            // exists), so the seed must be honored on every "no CDC offset truth" path.
            seedOffsetStoreIfPresent();
            return;
        }

        if (!(raw instanceof Map)) {
            throw new StreamException(ERR_STREAM_STATE_ERROR)
                    .param(ARG_STATE_NAME, CDC_OFFSETS_KEY)
                    .param(ARG_DETAIL, "CDC offset state is not a Map: " + raw.getClass().getName());
        }

        Map<String, String> serialized = (Map<String, String>) raw;
        Map<java.nio.ByteBuffer, java.nio.ByteBuffer> restored =
                NopStreamOffsetBackingStore.fromSerializable(serialized);

        this.offsetStore = NopStreamOffsetBackingStore.forConnector(resolveConnectorName());
        this.offsetStore.setOffsets(restored);
    }

    /**
     * AR-03: first-run paths must never inherit the static offset registry entry left by a
     * previous run in the same JVM. Clearing the entry before binding forces the engine to start
     * from the beginning (fresh snapshot) instead of silently resuming from a stale offset.
     */
    private NopStreamOffsetBackingStore newFreshOffsetStore() {
        String name = resolveConnectorName();
        NopStreamOffsetBackingStore.clearConnector(name);
        return NopStreamOffsetBackingStore.forConnector(name);
    }

    /**
     * WI9 data-migration seeding (design §4.2 contract): apply the injected P0 seed to the
     * freshly-cleared first-run store. {@code NopStreamOffsetBackingStore.setOffsets} has REPLACE
     * semantics, so the seed deterministically supersedes any stale same-JVM registry leftovers.
     * Restore paths with a real checkpoint offset never reach this (seed ignored there — the
     * checkpoint is the single source of truth).
     */
    private void seedOffsetStoreIfPresent() {
        if (initialOffsets == null || initialOffsets.isEmpty())
            return;
        this.offsetStore.setOffsets(NopStreamOffsetBackingStore.fromSerializable(initialOffsets));
        LOG.info("cdc.offset-seeded-on-first-run:connector={},entries={}", resolveConnectorName(),
                initialOffsets.size());
    }

    private String resolveConnectorName() {
        DebeziumConfig cfg = this.config;
        if (cfg != null && cfg.getName() != null && !cfg.getName().isEmpty()) {
            return instanceName(cfg.getName());
        }
        // AR-03: unnamed connectors silently share the "_default_" offset bucket and overwrite
        // each other's offsets in the same JVM. Fail fast with configuration guidance.
        throw new StreamException(ERR_STREAM_CONFIG_ERROR)
                .param(ARG_DETAIL,
                        "Debezium connector name is required: set DebeziumConfig.name so the offset "
                                + "registry bucket is unique per connector (unnamed connectors share "
                                + "the '_default_' bucket and silently overwrite each other's offsets)");
    }

    // ------------------------------------------------------------------
    // B-layer subtask sharding (cdc-design.md §3.3): deterministic table routing
    // ------------------------------------------------------------------

    /**
     * Deployment-time parallelism validation on the TEMPLATE instance, invoked by the
     * execution-plan builders before any subtask copy exists. Records the parallelism so
     * {@link #copyForSubtask(int)} copies route deterministically, and simulates the hash
     * routing so an instance that would receive zero tables fails at deployment instead of
     * starting a silent idle engine.
     */
    @Override
    public void validateParallelism(int parallelism) {
        if (parallelism <= 1) {
            this.totalParallelism = 1;
            this.subtaskIndex = 0;
            return;
        }
        List<String> tables = includeListEntries(config.getTableIncludeList());
        if (tables.isEmpty()) {
            throw new StreamException(ERR_STREAM_CONFIG_ERROR)
                    .param(ARG_DETAIL, "DebeziumConfig.tableIncludeList is required when the CDC source"
                            + " parallelism > 1: table sharding is the B-layer routing domain"
                            + " (single-table parallel snapshot: use snapshotMaxThreads, layer A)");
        }
        if (tables.size() < parallelism) {
            throw new StreamException(ERR_STREAM_CONFIG_ERROR)
                    .param(ARG_DETAIL, "CDC source parallelism " + parallelism
                            + " exceeds tableIncludeList size " + tables.size()
                            + ": route at most one parallelism per table; for intra-table parallel"
                            + " snapshot use snapshotMaxThreads (layer A)");
        }
        for (int shard = 0; shard < parallelism; shard++) {
            if (route(tables, parallelism, shard).isEmpty()) {
                throw new StreamException(ERR_STREAM_CONFIG_ERROR)
                        .param(ARG_DETAIL, "table routing would leave subtask " + shard
                                + " with zero tables (hash collision at parallelism " + parallelism
                                + "): adjust the table list or reduce the parallelism");
            }
        }
        this.totalParallelism = parallelism;
    }

    /**
     * Per-subtask copy via a serialization round-trip of this (serializable) function, then
     * bound to the shard for {@code subtaskIndex}. The original template instance is never
     * mutated; each copy owns its own config object.
     */
    @Override
    public SubtaskShardedSourceFunction<ChangeEvent> copyForSubtask(int subtaskIndex) {
        DebeziumCdcSourceFunction copy = serializationRoundTripCopy(this);
        copy.credentialProvider = null;
        copy.subtaskIndex = subtaskIndex;
        copy.totalParallelism = Math.max(1, this.totalParallelism);
        return copy;
    }

    /**
     * The shard of a table entry: floor-mod of the entry's {@code String.hashCode()}
     * (stable across JVMs by JLS) over the total parallelism — deterministic and
     * negative-safe.
     */
    static int shardOf(String tableEntry, int totalParallelism) {
        return Math.floorMod(tableEntry.hashCode(), totalParallelism);
    }

    private List<String> includeListEntries(String includeList) {
        if (includeList == null || includeList.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> entries = new java.util.ArrayList<>();
        for (String entry : includeList.split(",")) {
            String trimmed = entry.trim();
            if (!trimmed.isEmpty()) {
                entries.add(trimmed);
            }
        }
        return entries;
    }

    static List<String> route(List<String> tables, int totalParallelism, int subtaskIndex) {
        List<String> routed = new java.util.ArrayList<>();
        for (String table : tables) {
            if (shardOf(table, totalParallelism) == subtaskIndex) {
                routed.add(table);
            }
        }
        return routed;
    }

    /**
     * The include list THIS instance passes to its Debezium engine: the full list when
     * single-instance, otherwise the hash-routed subset for {@link #subtaskIndex}.
     */
    private String routedIncludeList() {
        if (totalParallelism <= 1) {
            return config.getTableIncludeList();
        }
        List<String> routed = route(includeListEntries(config.getTableIncludeList()),
                totalParallelism, subtaskIndex);
        return String.join(",", routed);
    }

    /**
     * The engine-visible connector identity: the base name when single-instance, otherwise
     * {@code name-<subtaskIndex>} so the offset registry, the failure-listener registry and
     * the Debezium {@code name} property are unique per instance (AR-03 lifecycle applies
     * per instance name).
     */
    private String instanceName(String baseName) {
        return totalParallelism > 1 ? baseName + "-" + subtaskIndex : baseName;
    }

    int getSubtaskIndexForTest() {
        return subtaskIndex;
    }

    int getTotalParallelismForTest() {
        return totalParallelism;
    }

    String instanceConnectorNameForTest() {
        return resolveConnectorName();
    }

    String routedIncludeListForTest() {
        return routedIncludeList();
    }

    DebeziumConfig effectiveEngineConfigForTest() {
        return effectiveEngineConfig();
    }

    /**
     * Item 20 (P-REQ-13, D3-⑤): pre-submit probe at construction/parameter level —
     * validates that the connector is fully parameterized (connector name present,
     * {@link #resolveConnectorName()} typed fail-fast) and that any credential
     * references on the connection fields are resolvable (D4, fail-closed). It does
     * NOT start the Debezium engine and does NOT open a database connection: the
     * Debezium connection semantics belong to the engine startup phase and cannot be
     * reached without invasive side effects (design adjudication; {@code run()}+
     * {@code cancel()} was rejected because it spins up a real engine).
     */
    @Override
    public void checkConnection() {
        if (config == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "config");
        }
        resolveConnectorName();
        verifyCredentialReferences();
    }

    // ------------------------------------------------------------------
    // Credential reference handling (D4: reference persists, transient decrypt)
    // ------------------------------------------------------------------

    private static final String FIELD_DATABASE_USER = "databaseUser";
    private static final String FIELD_DATABASE_PASSWORD = "databasePassword";
    private static final String FIELD_SCHEMA_HISTORY_USER = "schemaHistoryJdbcUser";
    private static final String FIELD_SCHEMA_HISTORY_PASSWORD = "schemaHistoryJdbcPassword";

    private boolean hasCredentialReferences() {
        return StreamCredentialSupport.isCredentialReference(config.getDatabaseUser())
                || StreamCredentialSupport.isCredentialReference(config.getDatabasePassword())
                || StreamCredentialSupport.isCredentialReference(config.getSchemaHistoryJdbcUser())
                || StreamCredentialSupport.isCredentialReference(config.getSchemaHistoryJdbcPassword());
    }

    /**
     * Credential reachability check for dry-run (D4): a successful decryption IS the
     * reachability verdict — deliberately NOT {@code testCredential()} (the platform
     * stub always returns {@code success=false}; depending on it would produce a
     * systematic false negative). Plaintext is never logged or reported.
     */
    private void verifyCredentialReferences() {
        resolveIfReference(config.getDatabaseUser(), FIELD_DATABASE_USER);
        resolveIfReference(config.getDatabasePassword(), FIELD_DATABASE_PASSWORD);
        resolveIfReference(config.getSchemaHistoryJdbcUser(), FIELD_SCHEMA_HISTORY_USER);
        resolveIfReference(config.getSchemaHistoryJdbcPassword(), FIELD_SCHEMA_HISTORY_PASSWORD);
    }

    private String resolveIfReference(String value, String field) {
        if (StreamCredentialSupport.isCredentialReference(value)) {
            return StreamCredentialSupport.resolve(value, field, credentialProvider);
        }
        return value;
    }

    /**
     * The config handed to the engine: the ORIGINAL config when it carries no
     * credential references; otherwise a TRANSIENT DECRYPTED COPY (built via
     * serialization round-trip so every field survives) whose credential-reference
     * fields are resolved plaintext. The plaintext lives only inside this method's local
     * path and the engine instance it constructs — the original config object and
     * every serialization path keep the reference string (D4: reference persists,
     * decrypt is engine-side transient).
     */
    private DebeziumConfig effectiveEngineConfig() {
        DebeziumConfig cfg = this.config;
        DebeziumConfig result;
        if (!hasCredentialReferences()) {
            result = cfg;
        } else {
            result = serializationRoundTripCopy(cfg);
            result.setDatabaseUser(resolveIfReference(cfg.getDatabaseUser(), FIELD_DATABASE_USER));
            result.setDatabasePassword(resolveIfReference(cfg.getDatabasePassword(), FIELD_DATABASE_PASSWORD));
            result.setSchemaHistoryJdbcUser(resolveIfReference(cfg.getSchemaHistoryJdbcUser(), FIELD_SCHEMA_HISTORY_USER));
            result.setSchemaHistoryJdbcPassword(
                    resolveIfReference(cfg.getSchemaHistoryJdbcPassword(), FIELD_SCHEMA_HISTORY_PASSWORD));
        }
        if (totalParallelism > 1) {
            // B-layer routing: the engine of THIS instance only sees its own identity and
            // table shard. The original config object is never mutated (it is shared by the
            // template instance and every serialization path).
            if (result == cfg) {
                result = serializationRoundTripCopy(cfg);
            }
            String instance = instanceName(resolveBaseName());
            result.setName(instance);
            result.setTableIncludeList(routedIncludeList());
            // serverName 同步实例化：它决定 Debezium 指标 MBean 的 ObjectName 与 topic 前缀，
            // 同 JVM 双实例共享 serverName 会让后注册者卡死在 JmxUtils.registerMXBean 重试循环
            result.setServerName(instance);
            qualifySchemaHistoryPerInstance(result, instance);
        }
        return result;
    }

    /**
     * Schema history MUST be instance-qualified in B-layer parallel mode: two instances
     * sharing one history store adopt each other's DDL records during recovery (the
     * second connector sees "storage was found, use pre-existing storage" and stalls
     * against the first instance's state). File history gets an instance-prefixed file
     * name under the same directory; JDBC history gets an instance-suffixed table name.
     */
    private static void qualifySchemaHistoryPerInstance(DebeziumConfig config, String instance) {
        String path = config.getSchemaHistoryPath();
        if (path != null && !path.isEmpty()) {
            java.nio.file.Path p = java.nio.file.Path.of(path);
            java.nio.file.Path parent = p.getParent();
            config.setSchemaHistoryPath((parent == null ? "" : parent + "/")
                    + instance + "-" + p.getFileName());
        }
        String table = config.getSchemaHistoryJdbcTable();
        // R5 REG-3: suffix with the FULL sanitized instance name — the previous
        // lastSegment(instance) collapsed "cdcA-2" and "cdcB-2" to the same "2",
        // so two connectors sharing one database collided on the same history
        // table and recovery dead-locked.
        config.setSchemaHistoryJdbcTable(
                (table == null || table.isEmpty() ? "nop_cdc_schema_history" : table)
                        + "_" + sanitizeIdentifier(instance));
    }

    private static String sanitizeIdentifier(String instance) {
        return instance.replaceAll("[^A-Za-z0-9]", "_");
    }

    private String resolveBaseName() {
        DebeziumConfig cfg = this.config;
        if (cfg != null && cfg.getName() != null && !cfg.getName().isEmpty()) {
            return cfg.getName();
        }
        throw new StreamException(ERR_STREAM_CONFIG_ERROR)
                .param(ARG_DETAIL, "Debezium connector name is required");
    }

    private static <X> X serializationRoundTripCopy(X obj) {
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            try (java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(bos)) {
                oos.writeObject(obj);
            }
            try (java.io.ObjectInputStream ois = new java.io.ObjectInputStream(
                    new java.io.ByteArrayInputStream(bos.toByteArray()))) {
                @SuppressWarnings("unchecked")
                X copy = (X) ois.readObject();
                return copy;
            }
        } catch (Exception e) {
            throw new StreamException(ERR_STREAM_CONFIG_ERROR, e)
                    .param(ARG_DETAIL, "failed to build the serialization round-trip copy");
        }
    }
}
