/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.execution;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATION;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.commons.partition.IPartitioner;

import io.nop.stream.core.checkpoint.CheckpointBarrier;
import io.nop.stream.core.execution.flow.EdgeConfig;
import io.nop.stream.core.execution.flow.FlowControlPolicy;
import io.nop.stream.core.streamrecord.StreamElement;
import io.nop.stream.core.streamrecord.StreamRecord;
import io.nop.stream.core.streamrecord.watermark.Watermark;
import io.nop.stream.core.exceptions.StreamException;

import io.nop.stream.core.exceptions.NopStreamErrors;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INTERRUPTED_WRITE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;

/**
 * Writes stream elements to one or more downstream {@link ResultPartition} instances.
 *
 * <p>When an {@link IPartitioner} is provided, records are routed to a specific
 * partition based on the partitioning logic. Watermarks and barriers are broadcast
 * to all partitions.
 *
 * <p>Without a partitioner (single downstream), all elements are forwarded to the
 * sole partition.
 */
public class RecordWriter<T> {

    private static final Logger LOG = LoggerFactory.getLogger(RecordWriter.class);

    private final ResultPartition[] partitions;
    private final IPartitioner<T> partitioner;
    private final EdgeConfig edgeConfig;
    private final PartitionRouter partitionRouter;
    private final boolean isBroadcast;

    /**
     * Creates a RecordWriter that forwards to a single partition.
     *
     * @param partition the single downstream partition
     */
    public RecordWriter(ResultPartition partition) {
        this(partition, null);
    }

    /**
     * Creates a RecordWriter that forwards to a single partition with optional EdgeConfig.
     *
     * @param partition  the single downstream partition
     * @param edgeConfig optional edge configuration for flow control (nullable)
     */
    public RecordWriter(ResultPartition partition, EdgeConfig edgeConfig) {
        if (partition == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "partition");
        }
        this.partitions = new ResultPartition[]{partition};
        this.partitioner = null;
        this.edgeConfig = edgeConfig;
        this.partitionRouter = null;
        this.isBroadcast = false;
        validateFlowControlPolicy();
    }

    /**
     * Creates a RecordWriter with multiple partitions and an optional partitioner.
     *
     * @param partitions  the downstream partitions (must not be null or empty)
     * @param partitioner optional partitioner for record routing; null means forward to partition 0
     */
    public RecordWriter(ResultPartition[] partitions, IPartitioner<T> partitioner) {
        this(partitions, partitioner, null);
    }

    /**
     * Creates a RecordWriter with multiple partitions, an optional partitioner, and edge configuration.
     *
     * @param partitions  the downstream partitions (must not be null or empty)
     * @param partitioner optional partitioner for record routing; null means forward to partition 0
     * @param edgeConfig  optional edge configuration for flow control (nullable)
     */
    public RecordWriter(ResultPartition[] partitions, IPartitioner<T> partitioner, EdgeConfig edgeConfig) {
        this(partitions, partitioner, edgeConfig, null);
    }

    /**
     * Creates a RecordWriter with multiple partitions, an optional partitioner, edge configuration,
     * and an explicit {@link PartitionRouter} for advanced partition routing.
     *
     * <p>When a PartitionRouter is provided, it takes precedence over the partitioner for
     * channel selection. This enables HASH/FORWARD/REBALANCE routing strategies independent
     * of the IPartitioner interface.
     *
     * @param partitions      the downstream partitions (must not be null or empty)
     * @param partitioner     optional partitioner for record routing (nullable)
     * @param edgeConfig      optional edge configuration for flow control (nullable)
     * @param partitionRouter explicit partition router (nullable; falls back to partitioner)
     */
    public RecordWriter(ResultPartition[] partitions, IPartitioner<T> partitioner,
                        EdgeConfig edgeConfig, PartitionRouter partitionRouter) {
        if (partitions == null || partitions.length == 0) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "partitions");
        }
        this.partitions = partitions;
        this.partitioner = partitioner;
        this.edgeConfig = edgeConfig;
        this.partitionRouter = partitionRouter;
        this.isBroadcast = partitionRouter instanceof BroadcastPartitionRouter;
        validateFlowControlPolicy();
    }

    /**
     * Validates that the flow control policy is the supported in-process policy.
     *
     * <p>Stage 28 (G27): {@code BLOCKING_QUEUE} is the only in-process policy.
     * The Flink Netty credit-based policies were permanently removed from the
     * enum (never needed — in-process backpressure is provided by
     * {@code BLOCKING_QUEUE} +
     * {@link io.nop.stream.core.execution.buffer.IBufferPool}, cross-JVM by
     * {@code IMessageService} in Stage 40). This validation is retained as a
     * fail-fast guard so that any future unknown policy value is caught here
     * rather than silently accepted.
     */
    private void validateFlowControlPolicy() {
        if (edgeConfig != null) {
            FlowControlPolicy policy = edgeConfig.getFlowControlPolicy();
            if (policy != FlowControlPolicy.BLOCKING_QUEUE) {
                throw new StreamException(ERR_STREAM_UNSUPPORTED).param(ARG_OPERATION, "Flow control policy " + policy + " is not supported. "
                                + "Only BLOCKING_QUEUE is supported in-process "
                                + "(Flink Netty policies were permanently removed, G27).");
            }
        }
    }

    /**
     * Emits a stream record to the appropriate downstream partition.
     *
     * @param record the record to emit
     */
    @SuppressWarnings("unchecked")
    public void emit(StreamRecord<T> record) {
        if (isBroadcast) {
            int delivered = 0;
            for (ResultPartition partition : partitions) {
                try {
                    partition.write(record);
                    delivered++;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    LOG.error("Interrupted during broadcast emit: {}/{} partitions delivered",
                            delivered, partitions.length);
                    throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, e).param(ARG_DETAIL, "record");
                }
            }
        } else {
            int targetChannel = selectChannel(record);
            try {
                partitions[targetChannel].write(record);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, e).param(ARG_DETAIL, "record");
            }
        }
    }

    /**
     * Broadcasts a watermark to all downstream partitions.
     *
     * @param watermark the watermark to emit
     */
    public void emitWatermark(Watermark watermark) {
        for (ResultPartition partition : partitions) {
            try {
                partition.write(watermark);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, e).param(ARG_DETAIL, "watermark");
            }
        }
    }

    /**
     * Broadcasts a checkpoint barrier to all downstream partitions.
     *
     * @param barrier the barrier to emit
     */
    public void emitBarrier(CheckpointBarrier barrier) {
        for (ResultPartition partition : partitions) {
            try {
                partition.write(barrier);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, e).param(ARG_DETAIL, "barrier");
            }
        }
    }

    /**
     * Broadcasts a watermark status (idle/active) to all downstream partitions.
     *
     * <p>AR-9 (plan 1326-2 Phase 4): watermark status must cross task boundaries —
     * an idle upstream subtask's status is the only signal that lets downstream
     * InputGates stop pinning the merged watermark at the idle channel's last value.
     */
    public void emitWatermarkStatus(io.nop.stream.core.streamrecord.watermark.WatermarkStatus status) {
        emitElement(status);
    }

    /**
     * Writes an arbitrary StreamElement to the selected partition.
     * Used for watermark status and other element types.
     *
     * @param element the element to write
     */
    public void emitElement(StreamElement element) {
        try {
            for (ResultPartition partition : partitions) {
                partition.write(element);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, e).param(ARG_DETAIL, "element");
        }
    }

    /**
     * Closes all downstream partitions to signal end-of-stream.
     *
     * <p>P1-10: each partition's {@code close()} now uses a blocking
     * {@code queue.put(END_OF_STREAM)} so the producer thread naturally
     * backpressures until the consumer drains enough room — no in-flight
     * records are discarded. An {@link InterruptedException} here is
     * propagated to the caller so cancel/abort can still tear down the
     * producer; remaining partitions are still attempted (suppressed on the
     * first failure) to mirror {@link OperatorChain#close()} semantics.
     */
    public void close() {
        Exception firstException = null;
        for (ResultPartition partition : partitions) {
            try {
                partition.close();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                if (firstException == null) {
                    firstException = new StreamException(ERR_STREAM_INTERRUPTED_WRITE, ie)
                            .param(ARG_DETAIL, "close");
                } else {
                    firstException.addSuppressed(ie);
                }
            } catch (Exception e) {
                if (firstException == null) {
                    firstException = e;
                } else {
                    firstException.addSuppressed(e);
                }
            }
        }
        if (firstException != null) {
            if (firstException instanceof StreamException) {
                throw (StreamException) firstException;
            }
            if (firstException instanceof RuntimeException) {
                throw (RuntimeException) firstException;
            }
            throw new StreamException(ERR_STREAM_INTERRUPTED_WRITE, firstException)
                    .param(ARG_DETAIL, "close");
        }
    }

    /**
     * Returns the write status for the first (or only) downstream partition.
     */
    public IWriteStatus getOutputStatus() {
        return partitions[0];
    }

    /**
     * Returns the number of downstream partitions.
     */
    public int getNumberOfPartitions() {
        return partitions.length;
    }

    /**
     * Returns the downstream partitions (for inspection / wiring verification).
     * Package-private; the returned array is the internal reference, callers must
     * not mutate it.
     */
    ResultPartition[] getPartitions() {
        return partitions;
    }

    private int selectChannel(StreamRecord<T> record) {
        // Priority 1: Explicit PartitionRouter (HASH/FORWARD/REBALANCE strategies)
        if (partitionRouter != null) {
            return partitionRouter.selectChannel(record);
        }
        // Priority 2: Legacy IPartitioner
        if (partitioner != null) {
            int channel = partitioner.partition(record.getValue(), partitions.length);
            return Math.floorMod(channel, partitions.length);
        }
        return 0;
    }
}
