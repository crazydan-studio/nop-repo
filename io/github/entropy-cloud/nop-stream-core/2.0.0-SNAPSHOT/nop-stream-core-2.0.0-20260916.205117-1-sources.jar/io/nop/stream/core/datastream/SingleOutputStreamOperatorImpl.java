/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.datastream;

import io.nop.stream.core.environment.StreamExecutionEnvironment;
import io.nop.stream.core.transformation.Transformation;

/**
 * Implementation of {@link SingleOutputStreamOperator} which represents a user defined
 * transformation applied on a {@link DataStream} with one predefined output type.
 * 
 * <p>This class extends {@link DataStreamImpl} and adds the ability to force non-parallel
 * execution, which is useful for operations that require global ordering or single-threaded
 * execution.
 * 
 * @param <T> The type of the elements in this stream
 */
public class SingleOutputStreamOperatorImpl<T> extends DataStreamImpl<T> implements SingleOutputStreamOperator<T> {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Creates a new SingleOutputStreamOperatorImpl with the specified environment and transformation.
     * 
     * @param environment the execution environment
     * @param transformation the transformation that produces this stream
     */
    public SingleOutputStreamOperatorImpl(StreamExecutionEnvironment environment, Transformation<T> transformation) {
        super(environment, transformation);
    }
    
    /**
     * Item 29: per-operator parallelism entry (covariant override — chaining a
     * {@code setParallelism} call keeps the {@code SingleOutputStreamOperator}
     * static type).
     */
    @Override
    public SingleOutputStreamOperator<T> setParallelism(int parallelism) {
        super.setParallelism(parallelism);
        return this;
    }

    /**
     * Sets the parallelism and maximum parallelism of this operator to one. And marks this
     * operator as non-parallelizable.
     * 
     * <p>This is useful for operations that require global ordering or single-threaded execution,
     * such as global aggregation or output to a single external system, and for CEP's non-keyed
     * entry point which requires a single global NFA.
     *
     * <p>Implementation: sets {@link Transformation#lockParallelismToOne()} so the lock flag
     * propagates through {@code Transformation → StreamNode → JobVertex → GraphExecutionPlan}.
     * Each downstream consumer forces the vertex to parallelism = 1 and rejects any override
     * (PartitionedPlan, DeploymentPlan, or runtime).
     * 
     * @return The operator with only one parallelism
     */
    @Override
    public SingleOutputStreamOperator<T> forceNonParallel() {
        if (transformation != null) {
            transformation.lockParallelismToOne();
        }
        return this;
    }
}
