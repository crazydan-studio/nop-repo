/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.core.windowing.triggers;

import java.time.Duration;

import io.nop.api.core.annotations.core.Internal;

import io.nop.stream.core.common.accumulators.SimpleAccumulator;
import io.nop.stream.core.windowing.windows.Window;

/**
 * A {@link Trigger} that continuously fires based on a given time interval as measured by the clock
 * of the machine on which the job is running.
 *
 * @param <W> The type of {@link Window Windows} on which this trigger can operate.
 *
 * <p>API 预留，当前未被使用
 */
@Internal
public class ContinuousProcessingTimeTrigger<W extends Window> extends ContinuousIntervalTrigger<W> {
    private static final long serialVersionUID = 1L;

    private ContinuousProcessingTimeTrigger(long interval) {
        super(interval);
    }

    @Override
    public TriggerResult onElement(Object element, long timestampIgnore, W window, TriggerContext ctx)
            throws Exception {
        ctx.registerProcessingTimeTimer(window.maxTimestamp());

        SimpleAccumulator<Long> fireTimestampState = ctx.getSimpleAccumulator(stateDesc);

        long timestamp = ctx.getCurrentProcessingTime();

        if (fireTimestampState.get() == null || fireTimestampState.get().equals(Long.MAX_VALUE)) {
            registerNextFireTimestamp(
                    timestamp - (timestamp % interval), window, ctx, fireTimestampState);
        }
        return TriggerResult.CONTINUE;
    }

    @Override
    public TriggerResult onEventTime(long time, W window, TriggerContext ctx) {
        return TriggerResult.CONTINUE;
    }

    @Override
    public TriggerResult onProcessingTime(long time, W window, TriggerContext ctx) {
        if (time == window.maxTimestamp()) {
            return TriggerResult.FIRE;
        }

        SimpleAccumulator<Long> fireTimestampState = ctx.getSimpleAccumulator(stateDesc);

        Long fireTimestamp = fireTimestampState.get();
        if (fireTimestamp != null && fireTimestamp.equals(time)) {
            fireTimestampState.clear();
            registerNextFireTimestamp(time, window, ctx, fireTimestampState);
            return TriggerResult.FIRE;
        }
        return TriggerResult.CONTINUE;
    }

    @Override
    public void clear(W window, TriggerContext ctx) {
        SimpleAccumulator<Long> fireTimestamp = ctx.getSimpleAccumulator(stateDesc);
        Long timestamp = fireTimestamp.get();
        if (timestamp != null) {
            ctx.deleteProcessingTimeTimer(timestamp);
            fireTimestamp.clear();
        }
        ctx.deleteProcessingTimeTimer(window.maxTimestamp());
    }

    @Override
    public boolean canMerge() {
        return true;
    }

    @Override
    public void onMerge(W window, OnMergeContext ctx) {
        Long nextFireTimestamp = ctx.getSimpleAccumulator(stateDesc).get();
        if (nextFireTimestamp != null && !nextFireTimestamp.equals(Long.MAX_VALUE)) {
            ctx.registerProcessingTimeTimer(nextFireTimestamp);
        }
    }

    public long getInterval() {
        return interval;
    }

    @Override
    public String toString() {
        return "ContinuousProcessingTimeTrigger(" + interval + ")";
    }

    /**
     * Creates a trigger that continuously fires based on the given interval.
     *
     * @param interval The time interval at which to fire.
     * @param <W>      The type of {@link Window Windows} on which this trigger can operate.
     */
    public static <W extends Window> ContinuousProcessingTimeTrigger<W> of(Duration interval) {
        return new ContinuousProcessingTimeTrigger<>(
                ContinuousIntervalTrigger.validatedIntervalMillis(interval, "ContinuousProcessingTimeTrigger"));
    }

    private void registerNextFireTimestamp(
            long time, W window, TriggerContext ctx, SimpleAccumulator<Long> fireTimestampState) {
        long nextFireTimestamp = nextFireTimestamp(time, window);
        fireTimestampState.add(nextFireTimestamp);
        ctx.registerProcessingTimeTimer(nextFireTimestamp);
    }
}
