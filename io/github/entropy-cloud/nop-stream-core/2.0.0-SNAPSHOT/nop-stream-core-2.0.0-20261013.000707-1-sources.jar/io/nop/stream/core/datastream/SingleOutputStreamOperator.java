/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.core.datastream;

import io.nop.stream.core.util.OutputTag;

/**
 * {@code SingleOutputStreamOperator} represents a user defined transformation applied on a {@link
 * DataStream} with one predefined output type.
 *
 * @param <T> The type of the elements in this stream.
 */
public interface SingleOutputStreamOperator<T> extends DataStream<T> {
    /**
     * Sets the parallelism of the operator producing this stream (item 29:
     * the {@code transforms/@parallelism} DSL declaration consumes this entry
     * through the flow builder).
     *
     * @param parallelism the per-operator parallelism, at least 1
     * @return this operator, for chaining
     */
    @Override
    SingleOutputStreamOperator<T> setParallelism(int parallelism);

    /**
     * Sets the parallelism and maximum parallelism of this operator to one. And mark this operator
     * cannot set a non-1 degree of parallelism.
     *
     * @return The operator with only one parallelism.
     */
    SingleOutputStreamOperator<T> forceNonParallel();

    /**
     * G-2+09e① (plan 369 Phase 2, Flink-shaped retrieval API): gets the {@link DataStream}
     * that contains the elements emitted to the side output identified by the given
     * {@link OutputTag} (e.g. late data routed via
     * {@code WindowedStream#sideOutputLateData(OutputTag)}).
     *
     * <p>The returned stream is a live side-output view: consumption goes through
     * {@code sink(...)} / {@code print()} / {@code collect(...)}, which register a
     * consumer for the tag in the {@link SideOutputRegistry} consulted by the
     * runtime output protocol ({@code ChainingOutput} and the cross-task
     * {@code StreamTaskInvokable} routing). Graph-level downstream transformations
     * (map/filter/keyBy/...) on a side-output view are not deployable yet and fail
     * fast with {@code ERR_STREAM_UNSUPPORTED}.
     *
     * @param outputTag the tag identifying the side output
     * @param <X> the type of the elements in the side output
     * @return the side-output stream view for the given tag
     */
    <X> DataStream<X> getSideOutput(OutputTag<X> outputTag);
}
