/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.environment;

import io.nop.api.core.time.CoreMetrics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.nop.stream.core.checkpoint.CheckpointConfig;
import io.nop.stream.core.checkpoint.ProcessingGuarantee;
import io.nop.stream.core.common.functions.source.SourceFunction;
import io.nop.stream.core.common.state.backend.IStateBackend;
import io.nop.stream.core.common.typeinfo.TypeInformation;
import io.nop.stream.core.datastream.DataStreamSource;
import io.nop.stream.core.datastream.SingleOutputStreamOperatorImpl;
import io.nop.stream.core.execution.DeploymentMode;
import io.nop.stream.core.execution.GraphExecutionPlan;
import io.nop.stream.core.execution.ICheckpointExecutorFactory;
import io.nop.stream.core.execution.IDeploymentPlanProvider;
import io.nop.stream.core.execution.IStreamExecutionDispatcher;
import io.nop.stream.core.execution.plan.DeploymentPlan;
import io.nop.stream.core.execution.plan.PartitionedPlan;
import io.nop.stream.core.execution.task.Subtask;
import io.nop.stream.core.execution.task.SubtaskTask;
import io.nop.stream.core.execution.task.TaskExecutor;
import io.nop.stream.core.graph.PartitionedPlanGenerator;
import io.nop.stream.core.graph.StreamGraph;
import io.nop.stream.core.graph.StreamGraphGenerator;
import io.nop.stream.core.jobgraph.JobGraph;
import io.nop.stream.core.jobgraph.JobGraphGenerator;
import io.nop.stream.core.jobgraph.JobVertex;
import io.nop.stream.core.model.StreamBackendCapability;
import io.nop.stream.core.model.StreamComponents;
import io.nop.stream.core.model.StreamComponentEntry;
import io.nop.stream.core.model.StreamModel;
import io.nop.stream.core.model.StreamRequirement;
import io.nop.stream.core.model.StreamModelFingerprint;
import io.nop.stream.core.model.StreamRequirementValidator;
import io.nop.stream.core.source.Source;
import io.nop.stream.core.source.SourceSplit;
import io.nop.stream.core.transformation.SinkTransformation;
import io.nop.stream.core.transformation.SourceApiTransformation;
import io.nop.stream.core.transformation.SourceTransformation;
import io.nop.commons.partition.IPartitioner;
import io.nop.stream.core.common.state.shard.KeyGroup;
import io.nop.stream.core.datastream.DataStreamImpl;
import io.nop.stream.core.transformation.PartitionTransformation;
import io.nop.stream.core.transformation.Transformation;
import io.nop.stream.core.exceptions.StreamException;

import io.nop.stream.core.exceptions.NopStreamErrors;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_JOB_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_JOB_EXECUTE_FAILED;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_TASK_FAILED;

public class StreamExecutionEnvironment {

    private final List<Transformation<?>> transformations = new ArrayList<>();

    private int parallelism = 1;

    private long watermarkInterval = 200L;

    private boolean executed = false;

    private final CheckpointConfig checkpointConfig = new CheckpointConfig();

    private static volatile ICheckpointExecutorFactory defaultCheckpointExecutorFactory;

    /**
     * F-06 (Plan 2026-09-04-1326-1 Phase 2, adjudication D2=(a)+(b)): ServiceLoader-
     * discovered factory, reviving the previously dead
     * {@code META-INF/services/io.nop.stream.core.execution.ICheckpointExecutorFactory}
     * configuration (the services file existed in nop-stream-runtime but was never
     * consumed). Cached after the first successful single-hit discovery; a static
     * setter value always takes precedence.
     */
    private static volatile ICheckpointExecutorFactory serviceLoaderFactory;

    private ICheckpointExecutorFactory checkpointExecutorFactory;

    /**
     * F-06: whether the user explicitly declared checkpointing via
     * {@link #enableCheckpointing(long)} (the Java API and the DSL builder both funnel
     * through it). {@code CheckpointConfig.isCheckpointEnabled()} defaults to
     * {@code true}, so it alone cannot distinguish a declared job from a plain one —
     * the fail-fast gate below keys on THIS flag: a declared job must never silently
     * fall through to non-checkpointed LOCAL execution, while an undeclared plain job
     * keeps the pre-fix LOCAL fallback.
     */
    private boolean checkpointingDeclared;

    /**
     * WI21 (§八 11): declarative registry entries declared by the DSL builder
     * (aggregators / joins / schemas, normalized into flow-free carriers) —
     * merged into every StreamModel this environment materializes.
     */
    private final Map<String, Map<String, StreamComponentEntry>> declaredRegistries = new LinkedHashMap<>();

    /**
     * WI21: registers one registry's entries (§八 11 — the DSL declarations must
     * reach the core {@link StreamComponents} of every materialized model).
     */
    public void declareRegistry(String registry, Map<String, StreamComponentEntry> entries) {
        if (registry == null || entries == null || entries.isEmpty()) {
            return;
        }
        declaredRegistries.computeIfAbsent(registry, k -> new LinkedHashMap<>()).putAll(entries);
    }

    private void mergeDeclaredRegistries(StreamComponents components) {
        if (components != null) {
            components.mergeDeclarativeRegistries(declaredRegistries);
        }
    }

    private DeploymentMode deploymentMode = DeploymentMode.LOCAL;

    private IStreamExecutionDispatcher executionDispatcher;

    public static StreamExecutionEnvironment getExecutionEnvironment() {
        return new StreamExecutionEnvironment();
    }

    /**
     * Creates a test environment with AT_LEAST_ONCE processing guarantee,
     * suitable for in-memory pipelines that use BEST_EFFORT/AT_LEAST_ONCE connectors.
     */
    public static StreamExecutionEnvironment createTestEnvironment() {
        StreamExecutionEnvironment env = new StreamExecutionEnvironment();
        env.getCheckpointConfig().setProcessingGuarantee(ProcessingGuarantee.AT_LEAST_ONCE);
        return env;
    }

    public static StreamExecutionEnvironment createLocalEnvironment(int parallelism) {
        StreamExecutionEnvironment env = new StreamExecutionEnvironment();
        env.setParallelism(parallelism);
        return env;
    }

    public StreamExecutionEnvironment() {
        this.checkpointExecutorFactory = defaultCheckpointExecutorFactory;
    }

    public StreamExecutionEnvironment setParallelism(int parallelism) {
        if (parallelism < 1) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "parallelism").param(ARG_DETAIL, "must be at least 1");
        }
        this.parallelism = parallelism;
        return this;
    }

    public int getParallelism() {
        return parallelism;
    }

    public StreamExecutionEnvironment setWatermarkInterval(long watermarkInterval) {
        if (watermarkInterval < 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "watermarkInterval").param(ARG_DETAIL, "must be >= 0");
        }
        this.watermarkInterval = watermarkInterval;
        return this;
    }

    public long getWatermarkInterval() {
        return watermarkInterval;
    }

    public CheckpointConfig getCheckpointConfig() {
        return checkpointConfig;
    }

    public StreamExecutionEnvironment enableCheckpointing(long interval) {
        checkpointingDeclared = true;
        checkpointConfig.setCheckpointEnabled(true);
        checkpointConfig.setCheckpointInterval(interval);
        return this;
    }

    public StreamExecutionEnvironment setStateBackend(IStateBackend stateBackend) {
        checkpointConfig.setStateBackend(stateBackend);
        return this;
    }

    public static void setCheckpointExecutorFactory(ICheckpointExecutorFactory factory) {
        defaultCheckpointExecutorFactory = factory;
    }

    /**
     * F-06 (D2 adjudication (a)): discovers an {@link ICheckpointExecutorFactory} via the
     * JDK {@link java.util.ServiceLoader} SPI ({@code META-INF/services} entry shipped by
     * nop-stream-runtime). Returns the single discovered implementation (cached), throws
     * typed on ambiguity (multiple implementations must be disambiguated by the explicit
     * static setter — never a silent arbitrary pick), and returns {@code null} when none
     * is on the classpath (callers then fail fast at the checkpoint gate).
     */
    private static synchronized ICheckpointExecutorFactory discoverCheckpointExecutorFactory() {
        if (serviceLoaderFactory != null) {
            return serviceLoaderFactory;
        }
        java.util.List<String> found = new ArrayList<>();
        ICheckpointExecutorFactory single = null;
        for (ICheckpointExecutorFactory factory : java.util.ServiceLoader.load(
                ICheckpointExecutorFactory.class, StreamExecutionEnvironment.class.getClassLoader())) {
            found.add(factory.getClass().getName());
            single = factory;
        }
        if (found.size() > 1) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "Multiple ICheckpointExecutorFactory implementations found via"
                            + " META-INF/services: " + found + ". Disambiguate by calling"
                            + " StreamExecutionEnvironment.setCheckpointExecutorFactory(...)"
                            + " explicitly (no silent arbitrary pick).");
        }
        if (single != null) {
            serviceLoaderFactory = single;
        }
        return single;
    }

    /**
     * F-06 (D2 adjudication (b) backstop): the factory required for checkpointed
     * execution — explicit setter value, else ServiceLoader discovery, else a typed
     * fail-fast. There is no path from a declared {@code enableCheckpointing} into a
     * silently non-checkpointed LOCAL execution.
     */
    private ICheckpointExecutorFactory requireCheckpointExecutorFactory() {
        ICheckpointExecutorFactory factory = checkpointExecutorFactory != null
                ? checkpointExecutorFactory
                : discoverCheckpointExecutorFactory();
        if (factory == null) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "enableCheckpointing() was declared but no ICheckpointExecutorFactory is"
                            + " available: the static setter was not used and the ServiceLoader"
                            + " found no META-INF/services/io.nop.stream.core.execution."
                            + "ICheckpointExecutorFactory entry. Ensure the nop-stream-runtime"
                            + " module is on the classpath (it ships the services entry), or"
                            + " register a factory via StreamExecutionEnvironment."
                            + "setCheckpointExecutorFactory(...). Refusing to silently fall"
                            + " back to non-checkpointed LOCAL execution (F-06).");
        }
        return factory;
    }

    public ICheckpointExecutorFactory getCheckpointExecutorFactory() {
        return checkpointExecutorFactory;
    }

    public StreamExecutionEnvironment setDeploymentMode(DeploymentMode deploymentMode) {
        if (deploymentMode == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "deploymentMode");
        }
        this.deploymentMode = deploymentMode;
        return this;
    }

    public DeploymentMode getDeploymentMode() {
        return deploymentMode;
    }

    public StreamExecutionEnvironment setExecutionDispatcher(IStreamExecutionDispatcher dispatcher) {
        this.executionDispatcher = dispatcher;
        return this;
    }

    public IStreamExecutionDispatcher getExecutionDispatcher() {
        return executionDispatcher;
    }

    @SafeVarargs
    public final <T> DataStreamSource<T> fromElements(T... data) {
        if (data == null || data.length == 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "data").param(ARG_DETAIL, "needs at least one element");
        }
        return fromCollection(Arrays.asList(data));
    }

    public <T> DataStreamSource<T> fromCollection(Collection<T> data) {
        if (data == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "data");
        }
        if (data.isEmpty()) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_ARG_NAME, "data").param(ARG_DETAIL, "must not be empty");
        }
        SourceFunction<T> sourceFunction = new CollectionSourceFunction<>(data);
        return addSource(sourceFunction, "Collection Source");
    }

    public <T> DataStreamSource<T> fromCollection(Collection<T> data, TypeInformation<T> typeInfo) {
        if (data == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "data");
        }
        if (typeInfo == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "typeInfo");
        }
        SourceFunction<T> sourceFunction = new CollectionSourceFunction<>(data);
        return addSource(sourceFunction, "Collection Source", typeInfo);
    }

    public <T> DataStreamSource<T> addSource(SourceFunction<T> function, String sourceName) {
        SourceTransformation<T> sourceTransform = new SourceTransformation<>(
                sourceName, function, null, parallelism);
        transformations.add(sourceTransform);
        return new SourceDataStream<>(this, sourceTransform);
    }

    public <T> DataStreamSource<T> addSource(SourceFunction<T> function, String sourceName,
                                               TypeInformation<T> typeInfo) {
        SourceTransformation<T> sourceTransform = new SourceTransformation<>(
                sourceName, function, typeInfo, parallelism);
        transformations.add(sourceTransform);
        return new SourceDataStream<>(this, sourceTransform);
    }

    /**
     * Stage 49 D5: adds a FLIP-27 style split-based {@link Source} to the streaming DAG.
     * Routes through a separate {@link SourceApiTransformation} so that the legacy
     * {@code SourceFunction} path and the new {@code Source} path do not share runtime
     * operator classes.
     *
     * @param source     the FLIP-27 style source descriptor; non-null
     * @param sourceName the name of the source transformation; non-null
     * @param <T>        the element type produced by the source
     */
    public <T> DataStreamSource<T> addSource(Source<T, ? extends SourceSplit, ?> source, String sourceName) {
        if (source == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "source");
        }
        SourceApiTransformation<T> sourceTransform = new SourceApiTransformation<>(
                sourceName, source, null, parallelism);
        transformations.add(sourceTransform);
        return new SourceDataStream<>(this, sourceTransform);
    }

    /**
     * Stage 49 D5: adds a FLIP-27 style split-based {@link Source} with explicit output type.
     */
    public <T> DataStreamSource<T> addSource(Source<T, ? extends SourceSplit, ?> source, String sourceName,
                                             TypeInformation<T> typeInfo) {
        if (source == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "source");
        }
        SourceApiTransformation<T> sourceTransform = new SourceApiTransformation<>(
                sourceName, source, typeInfo, parallelism);
        transformations.add(sourceTransform);
        return new SourceDataStream<>(this, sourceTransform);
    }

    public StreamExecutionResult execute() throws Exception {
        return execute("Streaming Job");
    }

    public StreamExecutionResult execute(String jobName) throws Exception {
        if (executed) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "A streaming job can only be executed once");
        }

        long startTime = CoreMetrics.currentTimeMillis();

        try {
            List<SinkTransformation<?>> sinks = requireSinkTransformations();
            StreamModel streamModel = buildStreamModel(sinks);
            StreamRequirementValidator.validate(streamModel, StreamBackendCapability.localRuntime());
            StreamRequirementValidator.validateConnectorConsistency(
                    checkpointConfig.getProcessingGuarantee(),
                    streamModel.getSourceCapabilities(),
                    streamModel.getSinkCapabilities()
            );

            JobGraph jobGraph = compilePlans(jobName, sinks);
            // WI21 (§八 11): the graph-attached model carries the derived
            // requirements — merge the declared registries into it too so both
            // materialized models agree
            mergeDeclaredRegistries(jobGraph.getStreamModel() == null
                    ? null : jobGraph.getStreamModel().getComponents());
            // WI21 gate A (§八 12): a TwoPhaseCommitSinkFunction only prepare/commits
            // on the checkpoint path — running it with no checkpointing configured
            // would silently never commit. Fail fast instead (the runtime checkpoint
            // path is the only sanctioned way to execute a 2PC sink).
            if (jobGraph.getStreamModel() != null
                    && jobGraph.getStreamModel().getRequirements().contains(StreamRequirement.TWO_PHASE_COMMIT_SINK)
                    && !checkpointingDeclared && checkpointExecutorFactory == null) {
                throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                        "job declares a TwoPhaseCommitSinkFunction sink but no checkpointing is "
                                + "configured — 2PC prepare/commit only runs on the checkpoint path, so the "
                                + "sink would silently never commit. Declare <checkpoint> / call "
                                + "enableCheckpointing() (or configure a checkpoint executor factory).");
            }
            PartitionedPlan partitionedPlan = buildPartitionedPlan(jobGraph, streamModel);
            DeploymentPlan deploymentPlan = generateDeploymentPlan(partitionedPlan);

            if (checkpointConfig.isCheckpointEnabled()
                    && (checkpointingDeclared || checkpointExecutorFactory != null)) {
                return executeWithCheckpointEngine(streamModel, partitionedPlan, deploymentPlan);
            }

            if (deploymentMode == DeploymentMode.DISTRIBUTED && executionDispatcher != null) {
                return executeDistributed(jobGraph, partitionedPlan, deploymentPlan);
            }

            if (deploymentMode == DeploymentMode.DISTRIBUTED && executionDispatcher == null) {
                throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "DISTRIBUTED mode requires an IStreamExecutionDispatcher. "
                  + "Ensure the runtime module is on the classpath and the dispatcher has been configured.");
            }

            return runLocal(jobName, jobGraph, deploymentPlan, startTime);
        } catch (Exception e) {
            throw new StreamException(ERR_STREAM_JOB_EXECUTE_FAILED, e).param(ARG_JOB_NAME, jobName);
        }
    }

    /**
     * Returns the sink transformations of this environment, failing fast when the
     * job declares none.
     */
    private List<SinkTransformation<?>> requireSinkTransformations() {
        List<SinkTransformation<?>> sinks = findSinkTransformations();
        if (sinks.isEmpty()) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "No sinks found in the streaming job");
        }
        return sinks;
    }

    /**
     * Compiles the sink-reachable transformation DAG into the executable JobGraph.
     *
     * <p>AR-1: threads the real job name into the JobGraph — it becomes the
     * checkpoint storage jobId (via PartitionedPlanGenerator) so distinct
     * jobs get distinct storage namespaces.
     */
    /**
     * R5 KR-3a/REG-7: deployment-time guard for the AR-01 parity contract.
     * Every keyBy partitioner freezes maxParallelism at graph time; this check
     * re-derives the bound from the CURRENTLY configured backend and fails
     * loudly on drift (e.g. setStateBackend called after keyBy, or a backend
     * swapped between graph build and execute) and on parallelism exceeding
     * the bound (previously a first-record data-plane failure).
     */
    private void validateKeyedRoutingParity() {
        CheckpointConfig checkpointConfig = getCheckpointConfig();
        IStateBackend backend = checkpointConfig != null ? checkpointConfig.getStateBackend() : null;
        int configuredMaxParallelism = backend != null ? backend.getMaxParallelism() : KeyGroup.DEFAULT_MAX_PARALLELISM;
        for (Transformation<?> t : getTransformations()) {
            if (t instanceof PartitionTransformation) {
                IPartitioner<?> partitioner = ((PartitionTransformation<?>) t).getPartitioner();
                if (partitioner instanceof DataStreamImpl.KeySelectorPartitioner) {
                    int graphMaxParallelism = ((DataStreamImpl.KeySelectorPartitioner<?>) partitioner).getMaxParallelism();
                    if (graphMaxParallelism != configuredMaxParallelism) {
                        throw new StreamException(ERR_STREAM_INVALID_ARG)
                                .param(ARG_DETAIL, "keyBy maxParallelism drift: graph-frozen "
                                        + graphMaxParallelism + " != configured backend " + configuredMaxParallelism
                                        + " (R5 KR-3: configure the state backend before keyBy,"
                                        + " or rebuild the graph)");
                    }
                    if (t.getParallelism() > graphMaxParallelism) {
                        throw new StreamException(ERR_STREAM_INVALID_ARG)
                                .param(ARG_DETAIL, "parallelism " + t.getParallelism()
                                        + " exceeds keyBy maxParallelism " + graphMaxParallelism
                                        + " (R5 REG-7)");
                    }
                }
            }
        }
    }

    private JobGraph compilePlans(String jobName, List<SinkTransformation<?>> sinks) {
        validateKeyedRoutingParity();
        StreamGraphGenerator graphGenerator = new StreamGraphGenerator();
        @SuppressWarnings("unchecked")
        List<Transformation<?>> sinkList = (List<Transformation<?>>) (List<?>) sinks;
        StreamGraph streamGraph = graphGenerator.generate(sinkList);

        JobGraphGenerator jobGraphGenerator = new JobGraphGenerator();
        return jobGraphGenerator.generate(streamGraph, jobName, null);
    }

    /**
     * Generates the PartitionedPlan for a compiled JobGraph. The model fingerprint
     * comes from the StreamModel populated onto the JobGraph when present, falling
     * back to the environment-built model.
     */
    private PartitionedPlan buildPartitionedPlan(JobGraph jobGraph, StreamModel streamModel) {
        PartitionedPlanGenerator partitionedPlanGenerator = new PartitionedPlanGenerator();
        StreamModel populatedModel = jobGraph.getStreamModel();
        StreamModelFingerprint fp = populatedModel != null
                ? populatedModel.computeFingerprint() : streamModel.computeFingerprint();
        return partitionedPlanGenerator.generate(jobGraph, fp);
    }

    /**
     * F-06: a DECLARED checkpointing job (or one with an explicitly wired
     * factory, matching the pre-fix behavior) MUST run checkpointed —
     * factory resolution is explicit setter &gt; ServiceLoader &gt; typed
     * fail-fast. There is no path from a declared enableCheckpointing()
     * into a silently non-checkpointed LOCAL execution. An UNDECLARED plain
     * job with no wired factory keeps the pre-fix LOCAL fallback (nothing
     * was declared, so nothing is silently skipped).
     */
    private StreamExecutionResult executeWithCheckpointEngine(StreamModel streamModel,
                                                              PartitionedPlan partitionedPlan,
                                                              DeploymentPlan deploymentPlan) throws Exception {
        ICheckpointExecutorFactory factory = requireCheckpointExecutorFactory();
        StreamExecutionResult result = factory.executeWithCheckpoint(
            streamModel, partitionedPlan, deploymentPlan, checkpointConfig);
        executed = true;
        return result;
    }

    private StreamExecutionResult executeDistributed(JobGraph jobGraph,
                                                     PartitionedPlan partitionedPlan,
                                                     DeploymentPlan deploymentPlan) throws Exception {
        StreamExecutionResult result = executionDispatcher.execute(
            jobGraph, partitionedPlan, deploymentPlan);
        executed = true;
        return result;
    }

    /**
     * Runs the compiled plan on the in-process {@link TaskExecutor} (LOCAL
     * deployment mode), then fails fast if any subtask ended in the FAILED state.
     */
    private StreamExecutionResult runLocal(String jobName, JobGraph jobGraph,
                                           DeploymentPlan deploymentPlan,
                                           long startTime) throws Exception {
        boolean barrierAlignment = checkpointConfig.getProcessingGuarantee().isBarrierAlignment();
        GraphExecutionPlan plan = GraphExecutionPlan.build(jobGraph, deploymentPlan, barrierAlignment);

        TaskExecutor executor = new TaskExecutor();
        try {
            List<SubtaskTask> subtaskTasks = new ArrayList<>();
            java.util.Set<Integer> sourceApiVertexIds = new java.util.LinkedHashSet<>();
            for (Transformation<?> t : transformations) {
                if (t instanceof SourceApiTransformation) {
                    sourceApiVertexIds.add(t.getId());
                }
            }

            for (String vertexId : plan.getSortedVertexIds()) {
                List<Subtask> vertexSubtasks = plan.getSubtasks(vertexId);
                int totalParallelism = vertexSubtasks.size();
                int parsedVertexId = parseVertexId(vertexId);
                boolean isSourceApiVertex = sourceApiVertexIds.contains(parsedVertexId);

                for (Subtask subtask : vertexSubtasks) {
                    SubtaskTask subtaskTask = new SubtaskTask(subtask, plan.getExecutionVertices().get(vertexId));
                    subtaskTasks.add(subtaskTask);

                    // Stage 49 D3: wire per-subtask identity on SourceReaderOperator
                    // before submission so its open() can locate the right coordinator
                    // channel and know its position among parallel source subtasks.
                    if (isSourceApiVertex) {
                        wireSourceReaderSubtaskIdentity(subtask, subtask.getTaskIndex(), totalParallelism);
                    }

                    executor.submitTask(subtaskTask);
                }
            }

            executor.awaitCompletion();

            for (SubtaskTask task : subtaskTasks) {
                if (task.getState() == SubtaskTask.State.FAILED) {
                    throw new StreamException(ERR_STREAM_TASK_FAILED, task.getError());
                }
            }

            executed = true;
            long executionTime = CoreMetrics.currentTimeMillis() - startTime;
            return new StreamExecutionResult(jobName, executionTime);
        } finally {
            shutdownLocalExecution(executor, plan);
        }
    }

    /**
     * Tears down one local execution: shuts the executor down, releases the per-job
     * buffer pool so any producer blocked on global exhaustion is woken and permits
     * do not leak across executions, and unregisters the source-api coordinators
     * registered for this job (Stage 49 D3) so subsequent executions of the same
     * vertex id start fresh.
     */
    private void shutdownLocalExecution(TaskExecutor executor, GraphExecutionPlan plan) {
        executor.shutdown();
        plan.closeBufferPool();
        for (Transformation<?> t : transformations) {
            if (t instanceof SourceApiTransformation) {
                io.nop.stream.core.source.coordinator.SourceCoordinatorRegistry.unregister(t.getId());
            }
        }
    }

    public String triggerSavepoint(String targetPath) throws Exception {
        // F-06: same resolution chain as the checkpoint gate (setter > ServiceLoader >
        // typed fail-fast) — the savepoint APIs already failed fast on a missing factory;
        // they now also benefit from ServiceLoader discovery.
        ICheckpointExecutorFactory factory = requireCheckpointExecutorFactory();

        JobGraph jobGraph = buildJobGraph("Savepoint Job");
        return factory.triggerSavepoint(jobGraph, checkpointConfig, targetPath);
    }

    public StreamExecutionResult executeWithSavepoint(String savepointPath) throws Exception {
        if (executed) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "A streaming job can only be executed once");
        }

        ICheckpointExecutorFactory factory = requireCheckpointExecutorFactory();

        if (savepointPath == null || savepointPath.isEmpty()) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "savepointPath");
        }

        JobGraph jobGraph = buildJobGraph("Streaming Job (Savepoint Recovery)");
        StreamExecutionResult result = factory.executeWithSavepoint(
                jobGraph, "Streaming Job (Savepoint Recovery)", checkpointConfig, savepointPath);
        executed = true;
        return result;
    }

    public StreamExecutionResult execute(String jobName, String savepointPath) throws Exception {
        if (savepointPath == null || savepointPath.isEmpty()) {
            return execute(jobName);
        }
        if (executed) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "A streaming job can only be executed once");
        }

        ICheckpointExecutorFactory factory = requireCheckpointExecutorFactory();

        JobGraph jobGraph = buildJobGraph(jobName);
        StreamExecutionResult result = factory.executeWithSavepoint(
                jobGraph, jobName, checkpointConfig, savepointPath);
        executed = true;
        return result;
    }

    public void addTransformation(Transformation<?> transformation) {
        transformations.add(transformation);
    }

    List<Transformation<?>> getTransformations() {
        return transformations;
    }

    /**
     * Stage 49 D3: parse the integer vertex id from the (possibly compound) string used by
     * the execution plan. {@code JobGraphGenerator} formats vertex ids as {@code "vertex-<id>"}
     * where {@code <id>} is the originating {@code Transformation.getId()} integer. Returns
     * -1 if parsing fails (the caller will skip source-api wiring for that vertex).
     */
    private static int parseVertexId(String vertexId) {
        if (vertexId == null || vertexId.isEmpty()) {
            return -1;
        }
        // Strip optional "vertex-" prefix used by JobGraphGenerator.
        String numPart = vertexId;
        if (numPart.startsWith("vertex-")) {
            numPart = numPart.substring("vertex-".length());
        }
        try {
            return Integer.parseInt(numPart);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Stage 49 D3: walks the subtask's operator chain and sets per-subtask identity
     * (subtaskIndex, totalParallelism) on every {@link io.nop.stream.core.operators.SourceReaderOperator}
     * found, so that the operator's {@code open()} can locate its coordinator channel.
     */
    private static void wireSourceReaderSubtaskIdentity(Subtask subtask, int subtaskIndex, int totalParallelism) {
        if (subtask.getInvokable() == null) {
            return;
        }
        for (io.nop.stream.core.operators.StreamOperator<?> op :
                subtask.getInvokable().getOperatorChain().getOperators()) {
            if (op instanceof io.nop.stream.core.operators.SourceReaderOperator) {
                io.nop.stream.core.operators.SourceReaderOperator<?> sro =
                        (io.nop.stream.core.operators.SourceReaderOperator<?>) op;
                sro.setSubtaskIdentity(subtaskIndex, totalParallelism);
            }
        }
    }

    private List<SinkTransformation<?>> findSinkTransformations() {
        List<SinkTransformation<?>> sinks = new ArrayList<>();
        for (Transformation<?> t : transformations) {
            if (t instanceof SinkTransformation) {
                sinks.add((SinkTransformation<?>) t);
            }
        }
        return sinks;
    }

    private StreamModel buildStreamModel(List<SinkTransformation<?>> sinks) {
        StreamComponents components = new StreamComponents();
        Map<String, Transformation<?>> transformMap = new LinkedHashMap<>();

        // Stable map keys and transformation ids across identical rebuilds: the
        // transformation id is a global static counter that drifts across
        // env.execute() calls, so id-based keys/ids would change the
        // stream-model fingerprint and the vertex ids — rejecting checkpoint
        // restore of an identically regenerated job (task-location vertex
        // matching + fingerprint validation). Both the model key and the id
        // are derived from the STABLE transformation name, disambiguated by
        // occurrence index (stable for identical user code); ids are
        // collision-probed against the per-build id set (deterministic for
        // the same key order).
        Map<String, Integer> nameCounts = new java.util.HashMap<>();
        java.util.Set<Integer> usedIds = new java.util.HashSet<>();
        for (Transformation<?> t : transformations) {
            int occurrence = nameCounts.merge(t.getName(), 1, Integer::sum) - 1;
            String stableKey = occurrence == 0 ? t.getName() : t.getName() + "#" + occurrence;
            transformMap.put(stableKey, t);

            int stableId = stableKey.hashCode() & Integer.MAX_VALUE;
            while (!usedIds.add(stableId)) {
                stableId = (stableId + 1) & Integer.MAX_VALUE;
            }
            t.assignStableId(stableId);
        }

        mergeDeclaredRegistries(components);

        return new StreamModel(components, transformMap);
    }

    /**
     * Generates a DeploymentPlan from a PartitionedPlan.
     *
     * <p>For LOCAL mode, uses {@link IDeploymentPlanProvider#generateLocal} which
     * produces a plan without physical node mapping (the runtime assigns at execution time).
     *
     * <p>For DISTRIBUTED mode, asks the {@link IStreamExecutionDispatcher} for the expected
     * node set and uses {@link IDeploymentPlanProvider#generateDistributed} to materialize
     * a round-robin subtask→node assignment into the plan.
     */
    private DeploymentPlan generateDeploymentPlan(PartitionedPlan partitionedPlan) {
        IDeploymentPlanProvider provider = IDeploymentPlanProvider.getProvider();

        if (deploymentMode == DeploymentMode.DISTRIBUTED && executionDispatcher != null) {
            List<String> nodeIds = executionDispatcher.getExpectedNodeIds(partitionedPlan);
            return provider.generateDistributed(partitionedPlan, nodeIds);
        }

        return provider.generateLocal(partitionedPlan);
    }

    /**
     * Builds the {@link JobGraph} for the transformations registered on this
     * environment WITHOUT executing them (item 14: the distributed launch path
     * — XDSL/model-declared topology assembled by
     * {@code StreamModelDslBuilder.build()}, then deployed by a standalone
     * coordinator instead of the in-process {@link #execute(String)}; design
     * D9 — declaration builds the graph, runtime orchestrates execution).
     *
     * <p>Applies the same stable-id assignment as {@code execute} so the graph's
     * StreamModel fingerprint is deterministic across identical rebuilds.
     *
     * @param jobName the job name used for the graph identity
     * @return the JobGraph (with the populated StreamModel attached)
     */
    public JobGraph buildJobGraph(String jobName) {
        validateKeyedRoutingParity();
        List<SinkTransformation<?>> sinks = findSinkTransformations();
        if (sinks.isEmpty()) {
            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "No sinks found in the streaming job");
        }

        if (!checkpointConfig.isCheckpointEnabled()) {
            checkpointConfig.setCheckpointEnabled(true);
        }

        // Stable-id assignment FIRST (same as execute()): transformation ids must
        // derive from stable names so two independent builds of the same
        // declaration (coordinator JVM + each TaskManager JVM in the distributed
        // launch path) produce IDENTICAL vertex ids and StreamModel fingerprints.
        // Without this the ids come from the global counter and drift per JVM.
        buildStreamModel(sinks);

        StreamGraphGenerator graphGenerator = new StreamGraphGenerator();
        @SuppressWarnings("unchecked")
        List<Transformation<?>> sinkList = (List<Transformation<?>>) (List<?>) sinks;
        StreamGraph streamGraph = graphGenerator.generate(sinkList);

        // WI21 (§八 11): the graph-attached model is the distributed launch path's
        // carrier — merge the declared registries into it as well
        mergeDeclaredRegistries(streamGraph.getStreamModel() == null
                ? null : streamGraph.getStreamModel().getComponents());

        JobGraphGenerator jobGraphGenerator = new JobGraphGenerator();
        // AR-1: same job-name threading as execute() — the distributed launch path's
        // storage identity must match the local path's for cross-run recovery.
        return jobGraphGenerator.generate(streamGraph, jobName, null);
    }

    private static class CollectionSourceFunction<T> implements SourceFunction<T> {
        private static final long serialVersionUID = 1L;

        private final Collection<T> data;
        private volatile boolean isRunning = true;

        CollectionSourceFunction(Collection<T> data) {
            this.data = data;
        }

        @Override
        public void run(SourceContext<T> ctx) throws Exception {
            for (T element : data) {
                if (!isRunning) {
                    break;
                }
                ctx.collect(element);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }

    private static class SourceDataStream<T> extends SingleOutputStreamOperatorImpl<T>
            implements DataStreamSource<T> {

        private static final long serialVersionUID = 1L;

        SourceDataStream(StreamExecutionEnvironment environment, Transformation<T> transformation) {
            super(environment, transformation);
        }
    }
}
