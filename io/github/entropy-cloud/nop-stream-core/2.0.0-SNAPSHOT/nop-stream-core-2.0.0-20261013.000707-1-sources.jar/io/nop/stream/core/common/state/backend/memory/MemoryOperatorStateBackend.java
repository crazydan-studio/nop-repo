/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.common.state.backend.memory;

import io.nop.stream.core.checkpoint.OperatorSnapshotResult;
import io.nop.stream.core.common.state.backend.IOperatorStateBackend;
import io.nop.stream.core.common.state.backend.RedistributionMode;
import io.nop.stream.core.exceptions.StreamException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATION;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED;

public class MemoryOperatorStateBackend implements IOperatorStateBackend {

    private static final long serialVersionUID = 1L;

    private final Map<String, Object> operatorStates = new HashMap<>();

    public MemoryOperatorStateBackend() {
    }

    @Override
    public OperatorSnapshotResult snapshotState(long checkpointId) throws Exception {
        // R6 plan 2323 (ST-01 family hardening): the raw-state channel (putRawState,
        // e.g. MemoryArrayListState) already copies the CONTAINER but shares the
        // ELEMENTS with the live list — post-barrier element mutations would leak
        // into the snapshot handed to the async persist thread. Freeze List-typed
        // raw values element-wise with the type-preserving copy so in-memory
        // restore keeps working. Non-List raw values pass through untouched: this
        // channel currently has no other producer, and blanket-copying unknown
        // shapes (e.g. accumulator maps) would flatten their typed entries into
        // JSON-native maps and break downstream type dispatch.
        Map<String, Object> frozen = new HashMap<>(operatorStates.size());
        for (Map.Entry<String, Object> e : operatorStates.entrySet()) {
            frozen.put(e.getKey(), freezeRawStateValue(e.getValue()));
        }
        return new OperatorSnapshotResult(
                frozen,
                Collections.emptyMap(),
                Collections.emptyMap());
    }

    private static Object freezeRawStateValue(Object value) {
        if (!(value instanceof List)) {
            return value;
        }
        List<?> list = (List<?>) value;
        List<Object> copy = new ArrayList<>(list.size());
        for (Object element : list) {
            copy.add(io.nop.stream.core.util.SnapshotCopyUtil.typedCopy(element));
        }
        return copy;
    }

    @Override
    public void restoreState(OperatorSnapshotResult snapshot) throws Exception {
        if (snapshot == null)
            return;
        operatorStates.clear();
        operatorStates.putAll(snapshot.getOperatorStates());
    }

    @Override
    public void restoreState(List<OperatorSnapshotResult> oldSnapshots, int oldParallelism,
                             RedistributionMode mode, int taskIndex, int newParallelism) throws Exception {
        if (mode == null)
            mode = RedistributionMode.NONE;

        switch (mode) {
            case NONE:
                if (oldSnapshots != null && !oldSnapshots.isEmpty()) {
                    restoreState(oldSnapshots.get(0));
                }
                break;
            case UNION:
                restoreUnion(oldSnapshots);
                break;
            case BROADCAST:
                restoreBroadcast(oldSnapshots);
                break;
            case SPLIT_DISTRIBUTE:
                restoreSplitDistribute(oldSnapshots, taskIndex, newParallelism);
                break;
            default:
                throw new StreamException(ERR_STREAM_UNSUPPORTED)
                        .param(ARG_OPERATION, "restoreState with mode=" + mode);
        }
    }

    private void restoreUnion(List<OperatorSnapshotResult> oldSnapshots) {
        Map<String, Object> merged = new HashMap<>();
        if (oldSnapshots != null) {
            for (OperatorSnapshotResult snap : oldSnapshots) {
                if (snap != null) {
                    for (Map.Entry<String, Object> entry : snap.getOperatorStates().entrySet()) {
                        merged.merge(entry.getKey(), entry.getValue(), (oldVal, newVal) -> {
                            if (oldVal instanceof List && newVal instanceof List) {
                                List<Object> combined = new ArrayList<>((List<?>) oldVal);
                                combined.addAll((List<?>) newVal);
                                return combined;
                            }
                            return newVal;
                        });
                    }
                }
            }
        }
        operatorStates.clear();
        operatorStates.putAll(merged);
    }

    /**
     * NEW-B (plan 369 Phase 3): union semantics, aligned with Flink's
     * {@code RoundRobinOperatorStateRepartitioner} UNION/BROADCAST path — every
     * non-empty old subtask snapshot contributes, and the union is restored into
     * ALL new instances (previously only the first non-empty snapshot was kept,
     * silently dropping divergent subtask states). Snapshot order (subtask
     * index) is the merge order, so the result is deterministic.
     *
     * <p>Same-name value merge: two lists concatenate; two maps merge entries
     * (later snapshot wins key conflicts); any other combination resolves to
     * the later value (scalars carry no merge function). Note: this path is a
     * backend-level semantic fix only — the 4-parameter {@code restoreState}
     * redistribution overload has no production caller yet (same non-wiring
     * adjudication as NEW-A), so production behavior is unchanged until
     * operator-state redistribution is wired.
     */
    private void restoreBroadcast(List<OperatorSnapshotResult> oldSnapshots) {
        Map<String, Object> union = new HashMap<>();
        if (oldSnapshots != null) {
            for (OperatorSnapshotResult snap : oldSnapshots) {
                if (snap == null || snap.getOperatorStates().isEmpty()) {
                    continue;
                }
                for (Map.Entry<String, Object> entry : snap.getOperatorStates().entrySet()) {
                    union.merge(entry.getKey(), entry.getValue(), MemoryOperatorStateBackend::unionBroadcastValues);
                }
            }
        }
        operatorStates.clear();
        operatorStates.putAll(union);
    }

    private static Object unionBroadcastValues(Object oldValue, Object newValue) {
        if (oldValue instanceof List && newValue instanceof List) {
            List<Object> combined = new ArrayList<>((List<?>) oldValue);
            combined.addAll((List<?>) newValue);
            return combined;
        }
        if (oldValue instanceof Map && newValue instanceof Map) {
            Map<Object, Object> merged = new HashMap<>((Map<?, ?>) oldValue);
            merged.putAll((Map<?, ?>) newValue);
            return merged;
        }
        return newValue;
    }

    private void restoreSplitDistribute(List<OperatorSnapshotResult> oldSnapshots,
                                        int taskIndex, int newParallelism) {
        Map<String, List<Object>> allNamedEntries = new HashMap<>();
        if (oldSnapshots != null) {
            for (OperatorSnapshotResult snap : oldSnapshots) {
                if (snap != null) {
                    for (Map.Entry<String, Object> entry : snap.getOperatorStates().entrySet()) {
                        String name = entry.getKey();
                        Object val = entry.getValue();
                        List<Object> entries = new ArrayList<>();
                        if (val instanceof List) {
                            entries.addAll((List<?>) val);
                        } else {
                            entries.add(val);
                        }
                        allNamedEntries.computeIfAbsent(name, k -> new ArrayList<>()).addAll(entries);
                    }
                }
            }
        }

        // S-9 (2026-09-01 core audit): fail fast on invalid redistribution inputs
        // instead of silently clamping. A taskIndex >= newParallelism would make
        // this subtask's stride overlap another subtask's (both restore the same
        // entries — e.g. taskIndex=5, parallelism=2 takes 5,7,9... which subtask 1
        // also receives as 1,3,5,7...), duplicating operator state with no error.
        if (newParallelism <= 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "newParallelism")
                    .param(ARG_DETAIL, "Operator state split-distribute requires newParallelism > 0, but was: "
                            + newParallelism);
        }
        if (taskIndex < 0 || taskIndex >= newParallelism) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "taskIndex")
                    .param(ARG_DETAIL, "Operator state split-distribute requires 0 <= taskIndex < newParallelism, but taskIndex="
                            + taskIndex + ", newParallelism=" + newParallelism);
        }

        Map<String, Object> redistributed = new HashMap<>();
        for (Map.Entry<String, List<Object>> namedEntry : allNamedEntries.entrySet()) {
            List<Object> pool = namedEntry.getValue();
            List<Object> myPortion = new ArrayList<>();
            for (int i = taskIndex; i < pool.size(); i += newParallelism) {
                myPortion.add(pool.get(i));
            }
            redistributed.put(namedEntry.getKey(), myPortion);
        }

        operatorStates.clear();
        operatorStates.putAll(redistributed);
    }

    @Override
    public Object getRawState(String key) {
        return operatorStates.get(key);
    }

    @Override
    public void putRawState(String key, Object value) {
        operatorStates.put(key, value);
    }

    public Map<String, Object> getOperatorStates() {
        return operatorStates;
    }
}
