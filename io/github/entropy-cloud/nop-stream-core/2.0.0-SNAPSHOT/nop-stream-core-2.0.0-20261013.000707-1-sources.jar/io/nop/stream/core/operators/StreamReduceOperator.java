/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.operators;

// D1=(a) SEMANTICS ANNOTATION (WI11): this operator implements LAST-VALUE-WINS
// final-value semantics for continuous (windowless) GROUP BY — every input element
// emits the current running reduction for its key. The output stream is therefore
// NOT append-only and NOT a retract stream: downstream consumers see intermediate
// reduction values and must treat the latest value per key as the current result.
// See sql-subset-and-semantics.md §1 for the adjudication.

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.core.lang.json.JsonTool;
import io.nop.stream.core.checkpoint.OperatorSnapshotResult;
import io.nop.stream.core.checkpoint.StateSnapshotContext;
import io.nop.stream.core.util.ClassNameValidator;
import io.nop.stream.core.util.SnapshotCopyUtil;
import io.nop.stream.core.common.functions.ReduceFunction;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.streamrecord.StreamRecord;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ACTUAL_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_EXPECTED_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATOR_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_OPERATOR_ERROR;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_TYPE_MISMATCH;

public class StreamReduceOperator<T>
        extends AbstractUdfStreamOperator<T, ReduceFunction<T>>
        implements OneInputStreamOperator<T, T> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(StreamReduceOperator.class);
    private static final String REDUCE_STATE_KEY = "reduce-state";

    private transient Object currentKey;
    private transient Map<Object, T> values;

    public StreamReduceOperator(ReduceFunction<T> reducer) {
        super(reducer);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Reduce operator: the user reduce function is shared across subtasks,
     * a fresh instance is created with empty {@code values} map (rebuilt in
     * {@link #open()}). Per-subtask reduction state is independent.
     */
    @Override
    public StreamReduceOperator<T> copyForSubtask() {
        return new StreamReduceOperator<>(userFunction);
    }

    @Override
    public void setCurrentKey(Object key) {
        this.currentKey = key;
        super.setCurrentKey(key);
    }

    @Override
    public Object getCurrentKey() {
        if (currentKey != null) {
            return currentKey;
        }
        return super.getCurrentKey();
    }

    @Override
    public void open() throws Exception {
        super.open();
        // Restore lifecycle: restoreState() runs BEFORE open()
        // (GraphModelCheckpointExecutor.restoreOperatorsFromState precedes
        // task submission, and operatorChain.open() runs at the top of the
        // invoke path). Only initialize the values map when restoreState()
        // has not already populated it, otherwise the restored keyed reduce
        // state would be silently discarded.
        if (values == null) {
            values = new HashMap<>();
        }
    }

    @Override
    public void processElement(StreamRecord<T> element) throws Exception {
        Object key = getCurrentKey();
        if (key == null) {
            throw new StreamException(ERR_STREAM_OPERATOR_ERROR)
                    .param(ARG_OPERATOR_NAME, "StreamReduceOperator")
                    .param(ARG_DETAIL, "requires key context. Ensure the stream is keyed via keyBy() before applying reduce.");
        }
        T value = element.getValue();
        T currentValue = values.get(key);

        if (currentValue == null) {
            values.put(key, value);
            output.collect(element);
        } else {
            T reduced = userFunction.reduce(currentValue, value);
            values.put(key, reduced);
            output.collect(new StreamRecord<>(reduced, element.getTimestamp()));
        }
    }

    @Override
    public OperatorSnapshotResult snapshotState(StateSnapshotContext context) throws Exception {
        OperatorSnapshotResult result = super.snapshotState(context);

        List<Map<String, Object>> entries = new ArrayList<>();
        for (Map.Entry<Object, T> e : values.entrySet()) {
            Map<String, Object> entry = new LinkedHashMap<>();
            Object key = e.getKey();
            // R5 ST-13: freeze the live entry so post-snapshot processing cannot
            // leak into the snapshot. typedCopy keeps the runtime class, so the
            // in-memory restore path (which matches concrete types) is unchanged.
            entry.put("key", SnapshotCopyUtil.typedCopy(key));
            if (key != null) {
                entry.put("keyTypeName", key.getClass().getName());
            }
            Object value = e.getValue();
            entry.put("value", SnapshotCopyUtil.typedCopy(value));
            if (value != null) {
                entry.put("valueTypeName", value.getClass().getName());
            }
            entries.add(entry);
        }
        result.putOperatorState(REDUCE_STATE_KEY, entries);

        return result;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void restoreState(OperatorSnapshotResult snapshotResult) throws Exception {
        super.restoreState(snapshotResult);

        Object stateObj = snapshotResult.getOperatorState(REDUCE_STATE_KEY);
        if (stateObj instanceof List) {
            values = new HashMap<>();
            List<?> entries = (List<?>) stateObj;
            for (Object item : entries) {
                if (item instanceof Map) {
                    Map<String, Object> entry = (Map<String, Object>) item;
                    Object key = entry.get("key");
                    Object value = entry.get("value");
                    // Defensive: skip entries where key or value is null after JSON round-trip
                    if (key == null || value == null) {
                        LOG.warn("Skipping restore entry with null key or value: key={}, value={}", key, value);
                        continue;
                    }
                    // R5 ST-13: after a JSON persist/restore round trip a frozen
                    // key arrives in its JSON-native shape; rebuild the recorded
                    // type so lookups against live keys keep matching.
                    key = rematerializeIfNeeded(key, (String) entry.get("keyTypeName"));
                    String expectedType = (String) entry.get("valueTypeName");
                    if (expectedType != null && !expectedType.equals(value.getClass().getName())) {
                        throw new StreamException(ERR_STREAM_TYPE_MISMATCH)
                                .param(ARG_EXPECTED_TYPE, expectedType)
                                .param(ARG_ACTUAL_TYPE, value.getClass().getName());
                    }
                    values.put(key, (T) value);
                }
            }
        }
    }

    /**
     * R5 ST-13: rebuild the recorded type when a restored entry's runtime class
     * no longer matches (JSON round trip degrades beans to maps). Same-class
     * values pass through unchanged.
     */
    private static Object rematerializeIfNeeded(Object value, String typeName) throws Exception {
        if (value == null || typeName == null || typeName.equals(value.getClass().getName())) {
            return value;
        }
        ClassNameValidator.validateClassName(typeName);
        Class<?> clazz = Class.forName(typeName);
        return JsonTool.parseBeanFromText(JsonTool.serialize(value, false), clazz);
    }
}
