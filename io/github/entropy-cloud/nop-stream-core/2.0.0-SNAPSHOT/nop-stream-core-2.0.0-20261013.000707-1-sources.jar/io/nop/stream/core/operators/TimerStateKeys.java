/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.operators;

/**
 * WI21 (§八 9): the operator-state keys under which timer-using operators
 * snapshot their timer state. Timer state is REQUIRED state for window and CEP
 * exactly-once — each consumer must snapshot under its declared key so the
 * checkpoint contract (and tests) can pin the wiring. Values are historical
 * literals preserved verbatim (compat with existing durable snapshots).
 */
public final class TimerStateKeys {

    /** WindowOperator's internal-timer snapshot key. */
    public static final String WINDOW_INTERNAL_TIMERS = "internal-timers";

    /** CepOperator's per-key event-time timer ledger key. */
    public static final String CEP_EVENT_TIME_TIMERS = "cep-event-time-timers";

    /** ProcessOperator's internal-timer snapshot key (R5 ST-11). */
    public static final String PROCESS_INTERNAL_TIMERS = "process-internal-timers";

    /** EquiJoinOperator's per-key working-buffer operator-state key (R6 plan 2324). */
    public static final String EQUI_JOIN_BUFFER = "equi-join-buffer";

    /** OverWindowOperator's per-key working-buffer operator-state key (R6 plan 2324). */
    public static final String OVER_WINDOW_BUFFER = "over-window-buffer";

    private TimerStateKeys() {
    }
}
