/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.datastream;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import io.nop.commons.partition.IPartitioner;

import io.nop.stream.core.checkpoint.CheckpointConfig;
import io.nop.stream.core.common.eventtime.WatermarkStrategy;
import io.nop.stream.core.common.functions.FilterFunction;
import io.nop.stream.core.common.functions.FlatMapFunction;
import io.nop.stream.core.common.functions.KeySelector;
import io.nop.stream.core.common.functions.MapFunction;
import io.nop.stream.core.common.functions.ProcessFunction;
import io.nop.stream.core.common.functions.SinkFunction;
import io.nop.stream.core.common.functions.sink.PrintSinkFunction;
import io.nop.stream.core.common.state.backend.IStateBackend;
import io.nop.stream.core.common.state.shard.KeyGroup;
import io.nop.stream.core.common.state.shard.KeyGroupAssignment;
import io.nop.stream.core.common.typeinfo.BasicTypeInfo;
import io.nop.stream.core.common.typeinfo.TypeInformation;
import io.nop.stream.core.common.typeinfo.UnknownTypeInformation;
import io.nop.stream.core.environment.StreamExecutionEnvironment;
import io.nop.stream.core.execution.plan.PartitionPolicy;
import io.nop.stream.core.execution.plan.PartitionPolicyAware;
import io.nop.stream.core.operators.OneInputStreamOperator;
import io.nop.stream.core.operators.ProcessOperator;
import io.nop.stream.core.operators.SimpleStreamOperatorFactory;
import io.nop.stream.core.operators.StreamFilter;
import io.nop.stream.core.operators.StreamFlatMap;
import io.nop.stream.core.operators.StreamMap;
import io.nop.stream.core.operators.StreamOperator;
import io.nop.stream.core.operators.StreamOperatorFactory;
import io.nop.stream.core.operators.TimestampsAndWatermarksOperator;
import io.nop.stream.core.transformation.OneInputTransformation;
import io.nop.stream.core.transformation.PartitionTransformation;
import io.nop.stream.core.transformation.SinkTransformation;
import io.nop.stream.core.transformation.TimestampsAndWatermarksTransformation;
import io.nop.stream.core.transformation.Transformation;
import io.nop.stream.core.transformation.UnionTransformation;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_PARTITION_KEY_FAILED;

/**
 * The implementation of the {@link DataStream} interface. This class represents a data stream
 * in the streaming program and provides methods to apply transformations to the stream.
 * 
 * <p>Each DataStreamImpl instance holds a reference to the execution environment and a
 * transformation that represents the current state of the stream. When operations are applied,
 * new transformations are created and registered with the environment.
 * 
 * <p>This class follows the builder pattern where each operation returns a new DataStream
 * instance, allowing for method chaining.
 * 
 * @param <T> The type of the elements in this stream
 */
public class DataStreamImpl<T> implements DataStream<T> {
    
    /**
     * The execution environment that this data stream belongs to
     */
    protected final StreamExecutionEnvironment environment;
    
    /**
     * The transformation that produces this data stream
     */
    protected final Transformation<T> transformation;
    
    /**
     * Creates a new DataStreamImpl with the specified environment and transformation.
     * 
     * @param environment the execution environment
     * @param transformation the transformation that produces this stream
     */
    public DataStreamImpl(StreamExecutionEnvironment environment, Transformation<T> transformation) {
        this.environment = environment;
        this.transformation = transformation;
    }
    
    /**
     * Gets the type information for the elements in this stream.
     *
     * @return the type information for the elements
     */
    @Override
    public TypeInformation<T> getType() {
        return transformation.getOutputType();
    }

    /**
     * Item 29: per-operator parallelism entry. Delegates to the wrapped
     * transformation (guarded setter: {@code >= 1}; rejected on a
     * {@code forceNonParallel()}-locked transformation for non-1 values).
     */
    @Override
    public DataStream<T> setParallelism(int parallelism) {
        this.transformation.setParallelism(parallelism);
        return this;
    }
    
    /**
     * Applies a transformation to the data stream. This is the low-level method for adding
     * operators to the stream. All higher-level operations (map, filter, flatMap) use this
     * method internally.
     * 
     * @param operatorName the name of the operator for logging and debugging
     * @param outTypeInfo the type information for the output elements
     * @param operator the operator to apply to the stream
     * @param <R> the type of the output elements
     * @return a new SingleOutputStreamOperator representing the transformed stream
     */
    @Override
    public <R> SingleOutputStreamOperator<R> transform(
            String operatorName,
            TypeInformation<R> outTypeInfo,
            OneInputStreamOperator<T, R> operator) {
        
        // Create the transformation
        StreamOperatorFactory<R> operatorFactory = new SimpleStreamOperatorFactory<R>(
            operator, operatorName, environment.getParallelism());
        OneInputTransformation<T, R> transform = new OneInputTransformation<>(
            this.transformation,
            operatorName,
            operatorFactory,
            outTypeInfo,
            environment.getParallelism()
        );
        
        // Register the transformation with the environment
        environment.addTransformation(transform);
        
        // Return a new DataStream wrapping the new transformation
        return new SingleOutputStreamOperatorImpl<>(environment, transform);
    }
    
    /**
     * {@inheritDoc}
     *
     * <p>WI6: builds a {@link UnionTransformation} over this stream's transformation and
     * every argument's transformation, registered with the environment so graph generation
     * picks it up. The union vertex's parallelism is the environment-level parallelism;
     * declare {@code setParallelism} on the returned stream to override.
     */
    @Override
    @SuppressWarnings("unchecked")
    public DataStream<T> union(DataStream<T>... streams) {
        if (streams == null || streams.length == 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "streams")
                    .param(ARG_DETAIL, "union requires at least one argument stream");
        }
        List<Transformation<T>> inputs = new ArrayList<>(streams.length + 1);
        inputs.add(this.transformation);
        for (DataStream<T> stream : streams) {
            if (stream == null) {
                throw new StreamException(ERR_STREAM_INVALID_ARG)
                        .param(ARG_ARG_NAME, "streams")
                        .param(ARG_DETAIL, "union argument stream must not be null");
            }
            inputs.add(((DataStreamImpl<T>) stream).transformation);
        }
        UnionTransformation<T> unionTransform = new UnionTransformation<>(
                "Union", inputs, environment.getParallelism());
        environment.addTransformation(unionTransform);
        return new DataStreamImpl<>(environment, unionTransform);
    }

    /**
     * Applies a map transformation to this data stream. The map function is called for each
     * element in the stream and produces exactly one output element for each input element.
     * 
     * @param mapper the map function to apply
     * @param <R> the type of the output elements
     * @return a new data stream with the mapped elements
     */
    @SuppressWarnings("unchecked")
    public <R> SingleOutputStreamOperator<R> map(MapFunction<T, R> mapper) {
        TypeInformation<R> inferredType = inferMapReturnType(mapper);
        return transform(
            "Map",
            inferredType != null ? inferredType : (TypeInformation<R>) UnknownTypeInformation.INSTANCE,
            new StreamMap<>(mapper)
        );
    }

    /**
     * Applies a map transformation to this data stream with explicit type information.
     *
     * @param mapper the map function to apply
     * @param typeInfo the type information for the output elements
     * @param <R> the type of the output elements
     * @return a new data stream with the mapped elements
     */
    public <R> SingleOutputStreamOperator<R> map(MapFunction<T, R> mapper, TypeInformation<R> typeInfo) {
        return transform("Map", typeInfo, new StreamMap<>(mapper));
    }
    
    /**
     * Applies a filter transformation to this data stream. The filter function is called for
     * each element and decides whether to keep or discard the element.
     * 
     * @param filter the filter function to apply
     * @return a new data stream with only the elements that passed the filter
     */
    public SingleOutputStreamOperator<T> filter(FilterFunction<T> filter) {
        return transform(
            "Filter",
            getType(),
            new StreamFilter<>(filter)
        );
    }
    
    /**
     * Applies a flat map transformation to this data stream. The flat map function is called
     * for each element and can produce zero, one, or more output elements for each input element.
     * 
     * @param flatMapper the flat map function to apply
     * @param <R> the type of the output elements
     * @return a new data stream with the flat mapped elements
     */
    public <R> SingleOutputStreamOperator<R> flatMap(FlatMapFunction<T, R> flatMapper) {
        return transform(
            "FlatMap",
            (TypeInformation<R>) UnknownTypeInformation.INSTANCE,
            new StreamFlatMap<>(flatMapper)
        );
    }

    /**
     * Applies a flat map transformation to this data stream with explicit type information.
     *
     * @param flatMapper the flat map function to apply
     * @param typeInfo the type information for the output elements
     * @param <R> the type of the output elements
     * @return a new data stream with the flat mapped elements
     */
    public <R> SingleOutputStreamOperator<R> flatMap(FlatMapFunction<T, R> flatMapper, TypeInformation<R> typeInfo) {
        return transform("FlatMap", typeInfo, new StreamFlatMap<>(flatMapper));
    }

    @Override
    public <R> SingleOutputStreamOperator<R> process(ProcessFunction<T, R> processFunction) {
        return transform(
                "Process",
                (TypeInformation<R>) UnknownTypeInformation.INSTANCE,
                new ProcessOperator<>(processFunction)
        );
    }

    @Override
    public SingleOutputStreamOperator<T> assignTimestampsAndWatermarks(WatermarkStrategy<T> strategy) {
        return assignTimestampsAndWatermarks(strategy, environment.getWatermarkInterval());
    }

    /**
     * F-04 (plan 1326-2 Phase 4): per-node watermark interval — the DSL's
     * {@code <timestampsAndWatermarks watermarkInterval="...">} declaration now
     * actually reaches the operator (previously the node-level value was parsed
     * and silently dropped; every job ran with the env-level interval).
     */
    @Override
    public SingleOutputStreamOperator<T> assignTimestampsAndWatermarks(
            WatermarkStrategy<T> strategy, long watermarkInterval) {
        TimestampsAndWatermarksTransformation<T> transformation = new TimestampsAndWatermarksTransformation<>(
            "Timestamps/Watermarks",
            getType(),
            environment.getParallelism(),
            this.transformation,
            strategy,
            watermarkInterval
        );
        environment.addTransformation(transformation);
        return new SingleOutputStreamOperatorImpl<>(environment, transformation);
    }
    
    /**
     * Creates a new {@link KeyedStream} that uses the provided key for partitioning its
     * operator states.
     * 
     * @param key the KeySelector to be used for extracting the key for partitioning
     * @param <K> the type of the key
     * @return the {@link KeyedStream} with partitioned state
     */
    @Override
    public <K> KeyedStream<T, K> keyBy(KeySelector<T, K> key) {
        // Create a partition transformation based on the key selector. Routing
        // must use the same key-group ownership formula as the keyed state
        // backends (AR-01), so records always land on the subtask that owns
        // (or will own, after a rescale restore) their keyed state.
        int keyByMaxParallelism = resolveKeyGroupMaxParallelism();
        // R5 KR-3b/REG-7: fail at graph time when the declared parallelism
        // already exceeds the key-group bound (the runtime would otherwise
        // fail on the first record, far from the misconfiguration).
        int declaredParallelism = environment.getParallelism();
        if (declaredParallelism > keyByMaxParallelism) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_DETAIL, "parallelism " + declaredParallelism
                            + " exceeds keyBy maxParallelism " + keyByMaxParallelism
                            + " (R5 KR-3/REG-7: raise maxParallelism on the state backend"
                            + " or lower the job parallelism)");
        }
        IPartitioner<T> partitioner = new KeySelectorPartitioner<>(key, keyByMaxParallelism);
        
        PartitionTransformation<T> partitionTransform = new PartitionTransformation<>(
            this.transformation,
            "KeyBy",
            partitioner,
            key,
            getType(),
            environment.getParallelism()
        );
        
        // Register the transformation
        environment.addTransformation(partitionTransform);
        
        // Return a new KeyedStream (simplified - would need KeyedStreamImpl)
        return new KeyedStreamImpl<>(environment, partitionTransform, key);
    }
    
    /**
     * Prints the elements of the DataStream to the standard output.
     */
    @Override
    public void print() {
        print(new PrintSinkFunction<>());
    }
    
    /**
     * Prints the elements of the DataStream to the standard output using a custom sink function.
     */
    @Override
    public void print(SinkFunction<T> sinkFunction) {
        sink(sinkFunction);
    }
    
    /**
     * Collects the elements of the DataStream using a collector function.
     */
    @Override
    public void collect(SinkFunction<T> collectorFunction) {
        sink(collectorFunction);
    }
    
    /**
     * Sends the elements of the DataStream to a sink function.
     */
    @Override
    public void sink(SinkFunction<T> sinkFunction) {
        sink(sinkFunction, environment.getParallelism());
    }

    /**
     * Item 29: sink registration with an explicit per-operator parallelism — the
     * sink transformation is terminal (no downstream stream object to call
     * {@link #setParallelism(int)} on), so the parallelism rides the registration.
     * Validation mirrors the guarded {@code Transformation.setParallelism}: the
     * value must be at least 1.
     */
    @Override
    public void sink(SinkFunction<T> sinkFunction, int parallelism) {
        if (parallelism < 1) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, "parallelism")
                    .param(ARG_DETAIL, "must be at least 1, got: " + parallelism);
        }
        SinkTransformation<T> sinkTransform = new SinkTransformation<>(
            this.transformation,
            "Sink",
            sinkFunction,
            null, // Void type for sinks
            parallelism
        );

        // Register the sink transformation
        environment.addTransformation(sinkTransform);
    }
    
    /**
     * Gets the execution environment for this data stream.
     * 
     * @return the execution environment
     */
    public StreamExecutionEnvironment getEnvironment() {
        return environment;
    }
    
    /**
     * Gets the transformation that produces this data stream.
     * 
     * @return the transformation
     */
    public Transformation<T> getTransformation() {
        return transformation;
    }
    
    @SuppressWarnings("unchecked")
    private static <R> TypeInformation<R> inferMapReturnType(MapFunction<?, R> mapper) {
        Class<?> clazz = mapper.getClass();
        java.lang.reflect.Type genericSuper = clazz.getGenericSuperclass();
        if (genericSuper instanceof java.lang.reflect.ParameterizedType) {
            java.lang.reflect.ParameterizedType paramType = (java.lang.reflect.ParameterizedType) genericSuper;
            if (MapFunction.class.equals(paramType.getRawType())) {
                java.lang.reflect.Type[] typeArgs = paramType.getActualTypeArguments();
                if (typeArgs.length >= 2 && typeArgs[1] instanceof Class) {
                    return BasicTypeInfo.of((Class<R>) typeArgs[1]);
                }
            }
        }
        for (java.lang.reflect.Type iface : clazz.getGenericInterfaces()) {
            if (iface instanceof java.lang.reflect.ParameterizedType) {
                java.lang.reflect.ParameterizedType paramType = (java.lang.reflect.ParameterizedType) iface;
                if (MapFunction.class.equals(paramType.getRawType())) {
                    java.lang.reflect.Type[] typeArgs = paramType.getActualTypeArguments();
                    if (typeArgs.length >= 2 && typeArgs[1] instanceof Class) {
                        return BasicTypeInfo.of((Class<R>) typeArgs[1]);
                    }
                }
            }
        }
        return null;
    }

    /**
     * A partitioner that uses a KeySelector to extract keys for partitioning.
     * 
     * @param <T> the type of elements being partitioned
     */
    /**
     * Resolves the job-global key-group upper bound used by keyBy routing: the
     * configured state backend's {@code maxParallelism}, or
     * {@link KeyGroup#DEFAULT_MAX_PARALLELISM} when no backend is configured
     * (matching the runtime wiring, which provisions a default backend then).
     */
    private int resolveKeyGroupMaxParallelism() {
        CheckpointConfig checkpointConfig = environment.getCheckpointConfig();
        IStateBackend backend = checkpointConfig != null ? checkpointConfig.getStateBackend() : null;
        int maxParallelism = backend != null ? backend.getMaxParallelism() : KeyGroup.DEFAULT_MAX_PARALLELISM;
        if (maxParallelism < 1) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_DETAIL, "maxParallelism must be at least 1: " + maxParallelism);
        }
        return maxParallelism;
    }

    /**
     * Production hash partitioner for {@code keyBy}: routes each record to the
     * subtask that owns its key's key-group (stableHash &#8594; key-group &#8594;
     * range owner), so record routing and keyed-state ownership share one
     * formula (AR-01) and a rescale restore never leaves a record on a subtask
     * that does not hold its state. Public so graph builders and tests can
     * attach the exact production partitioner to a JobEdge.
     */
    public static class KeySelectorPartitioner<T> implements IPartitioner<T>, PartitionPolicyAware, Serializable {
        private static final long serialVersionUID = 1L;

        private final KeySelector<T, ?> keySelector;

        /**
         * Job-global key-group upper bound, fixed at graph construction so the
         * routing mapping stays stable for the job lifetime (same contract as
         * the keyed state backend's {@code maxParallelism}).
         */
        private final int maxParallelism;

        public KeySelectorPartitioner(KeySelector<T, ?> keySelector, int maxParallelism) {
            this.keySelector = keySelector;
            this.maxParallelism = maxParallelism;
        }

        /** R5 KR-3/KR-1: the graph-frozen key-group bound, for deployment-time parity checks. */
        public int getMaxParallelism() {
            return maxParallelism;
        }

        @Override
        public int partition(T value, int numPartitions) {
            try {
                Object key = keySelector.getKey(value);
                if (key == null) {
                    return 0;
                }
                return KeyGroupAssignment.assignToSubtask(key, maxParallelism, numPartitions);
            } catch (StreamException e) {
                throw e;
            } catch (Exception e) {
                throw new StreamException(ERR_STREAM_PARTITION_KEY_FAILED, e);
            }
        }

        @Override
        public PartitionPolicy getPartitionPolicy() {
            return PartitionPolicy.HASH;
        }
    }
}
