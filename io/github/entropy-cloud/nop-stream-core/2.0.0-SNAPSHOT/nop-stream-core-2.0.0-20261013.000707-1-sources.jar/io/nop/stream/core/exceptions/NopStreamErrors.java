/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.exceptions;

import io.nop.api.core.exceptions.ErrorCode;

import static io.nop.api.core.exceptions.ErrorCode.define;

public interface NopStreamErrors {
    String ARG_ARG_NAME = "argName";
    String ARG_DETAIL = "detail";
    String ARG_OPERATOR_NAME = "operatorName";
    String ARG_STATE_NAME = "stateName";
    String ARG_CLASS_NAME = "className";
    String ARG_CONFIG_KEY = "configKey";
    String ARG_OPERATION = "operation";
    String ARG_VERTEX_ID = "vertexId";
    String ARG_TASK_INDEX = "taskIndex";
    String ARG_TASK_LOCATION = "taskLocation";
    String ARG_JOB_ID = "jobId";
    String ARG_CHECKPOINT_ID = "checkpointId";
    String ARG_EPOCH_ID = "epochId";
    String ARG_VALUE_TYPE = "valueType";
    String ARG_STATE_VERSION = "stateVersion";
    String ARG_STATE_TYPE = "stateType";
    String ARG_DESCRIPTOR_NAME = "descriptorName";
    String ARG_CURRENT_STATE = "currentState";
    String ARG_TARGET_STATE = "targetState";
    String ARG_ATTEMPT_NUMBER = "attemptNumber";
    String ARG_CAUSE = "cause";
    String ARG_NODE_ID = "nodeId";
    String ARG_POINT_ID = "pointId";
    String ARG_FROM_EPOCH = "fromEpoch";
    String ARG_OUTPUT_TAG = "outputTag";

    ErrorCode ERR_STREAM_JOB_ALREADY_HOSTED =
            define("nop.err.stream.job-already-hosted", "Job {jobId} is already hosted by this cluster", ARG_JOB_ID);

    ErrorCode ERR_STREAM_ILLEGAL_HEALTH_TRANSITION =
            define("nop.err.stream.illegal-health-transition", "Illegal health transition: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_NULL_ARG =
            define("nop.err.stream.null-arg", "Argument {argName} must not be null", ARG_ARG_NAME);

    ErrorCode ERR_STREAM_INVALID_STATE =
            define("nop.err.stream.invalid-state", "Invalid stream state: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CONFIG_ERROR =
            define("nop.err.stream.config-error", "Stream configuration error: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_UNSUPPORTED =
            define("nop.err.stream.unsupported", "Unsupported operation: {operation}", ARG_OPERATION);

    ErrorCode ERR_STREAM_SERIALIZATION =
            define("nop.err.stream.serialization", "Serialization failed: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_OPERATOR_ERROR =
            define("nop.err.stream.operator-error", "Operator {operatorName} execution error: {detail}",
                    ARG_OPERATOR_NAME, ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_ERROR =
            define("nop.err.stream.checkpoint-error", "Checkpoint error: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_STATE_ERROR =
            define("nop.err.stream.state-error", "State management error: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_INVALID_ARG =
            define("nop.err.stream.invalid-arg", "Invalid value for argument {argName}: {detail}",
                    ARG_ARG_NAME, ARG_DETAIL);

    ErrorCode ERR_STREAM_INIT_ERROR =
            define("nop.err.stream.init-error", "Initialization failed: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_EXECUTOR_FAILED =
            define("nop.err.stream.checkpoint-executor-failed", "Checkpoint executor failed: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_EXECUTOR_SAVEPOINT_FAILED =
            define("nop.err.stream.checkpoint-executor-savepoint-failed", "Failed to trigger terminal savepoint", ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_EXECUTOR_RESTORE_FAILED =
            define("nop.err.stream.checkpoint-executor-restore-failed", "Checkpoint restore failed: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_EXECUTOR_EXECUTE_FAILED =
            define("nop.err.stream.checkpoint-executor-execute-failed", "Task execution failed: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CHECKPOINT_EXECUTOR_JOB_GRAPH_INVALID =
            define("nop.err.stream.checkpoint-executor-job-graph-invalid", "Invalid job graph: no TaskLocation for vertex={vertexId} subtask={taskIndex}", ARG_VERTEX_ID, ARG_TASK_INDEX);

    ErrorCode ERR_STREAM_CHAINING_OUTPUT_EXCEPTION =
            define("nop.err.stream.chaining-output-exception", "Error in chaining output: {detail}", ARG_DETAIL);

    /**
     * Side output has no registered consumer in the chained execution — fail
     * fast instead of silently dropping (plan guide #24).
     */
    ErrorCode ERR_STREAM_SIDE_OUTPUT_NO_CONSUMER =
            define("nop.err.stream.side-output-no-consumer", "Side output {outputTag} has no registered consumer: {detail}",
                    ARG_OUTPUT_TAG, ARG_DETAIL);

    ErrorCode ERR_STREAM_CHAINING_OUTPUT_CLOSE_FAILED =
            define("nop.err.stream.chaining-output-close-failed", "Failed to close chaining output");

    ErrorCode ERR_STREAM_CHAINING_OUTPUT_FLUSH_FAILED =
            define("nop.err.stream.chaining-output-flush-failed", "Failed to flush chaining output");

    ErrorCode ERR_STREAM_CODEC_VALUE_TYPE_LOAD_FAILED =
            define("nop.err.stream.codec-value-type-load-failed", "Failed to load valueType class: {className}", ARG_CLASS_NAME);

    ErrorCode ERR_STREAM_WINDOW_TRIGGER_STATE_ACCUMULATOR_FAILED =
            define("nop.err.stream.window-trigger-state-accumulator-failed", "Failed to create trigger state accumulator: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_CLASS_NOT_ALLOWED =
            define("nop.err.stream.class-not-allowed", "Class not allowed: {className}", ARG_CLASS_NAME);

    ErrorCode ERR_STREAM_INVALID_TIMESTAMP =
            define("nop.err.stream.invalid-timestamp", "Invalid timestamp for argument {argName}: {detail}",
                    ARG_ARG_NAME, ARG_DETAIL);

    String ARG_EXPECTED = "expected";
    String ARG_JOB_NAME = "jobName";
    String ARG_REASON = "reason";

    ErrorCode ERR_STREAM_NULL_NAME =
            define("nop.err.stream.null-name", "Name must not be null");

    ErrorCode ERR_STREAM_SKIP_NO_MATCH =
            define("nop.err.stream.skip-no-match", "Could not skip to first element of a match");

    ErrorCode ERR_STREAM_PARTITION_KEY_FAILED =
            define("nop.err.stream.partition-key-failed", "Failed to extract key for partitioning");

    ErrorCode ERR_STREAM_BARRIER_INJECTION_FAILED =
            define("nop.err.stream.barrier-injection-failed", "Failed to inject barrier: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_ACCUMULATOR_CREATE_FAILED =
            define("nop.err.stream.accumulator-create-failed", "Failed to create accumulator: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_INTERRUPTED_WRITE =
            define("nop.err.stream.interrupted-write", "Interrupted while writing {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_HASH_NOT_AVAILABLE =
            define("nop.err.stream.hash-not-available", "SHA-256 algorithm not available");

    ErrorCode ERR_STREAM_TASK_FAILED =
            define("nop.err.stream.task-failed", "Task failed");

    ErrorCode ERR_STREAM_JOB_EXECUTE_FAILED =
            define("nop.err.stream.job-execute-failed", "Failed to execute job: {jobName}", ARG_JOB_NAME);

    ErrorCode ERR_STREAM_CHECKPOINT_ABORTED =
            define("nop.err.stream.checkpoint-aborted", "Checkpoint aborted: {reason}", ARG_REASON);

    ErrorCode ERR_STREAM_CHECKPOINT_FAILED =
            define("nop.err.stream.checkpoint-failed", "Checkpoint failed: {reason}", ARG_REASON);

    String ARG_TIMEOUT_MS = "timeoutMs";

    ErrorCode ERR_STREAM_BARRIER_ALIGNMENT_TIMEOUT =
            define("nop.err.stream.barrier-alignment-timeout",
                    "Barrier alignment timed out after {timeoutMs}ms: not all input channels delivered barriers within the configured timeout",
                    ARG_TIMEOUT_MS);

    /**
     * A {@code RemoteInputChannel} detected producer failure via its
     * liveness (inactivity) timeout — no accepted message (data, barrier,
     * watermark, or control) arrived within {@code channelTimeout}. This is
     * faster than waiting for the coarse lease timeout (~15-20s) and indicates
     * producer death or network partition.
     */
    ErrorCode ERR_STREAM_CHANNEL_TIMEOUT =
            define("nop.err.stream.channel-timeout",
                    "RemoteInputChannel timed out after {timeoutMs}ms with no accepted message or end-of-stream: producer is presumed dead or partitioned",
                    ARG_TIMEOUT_MS);

    String ARG_TOPIC = "topic";

    /**
     * Queue-full semantics: a {@code RemoteInputChannel}'s local
     * element queue stayed full with ZERO consumer progress for a whole bounded
     * enqueue window — the downstream task is stalled (or has no reader). The
     * channel fails typed instead of blocking the message-backend dispatch
     * thread forever; recovery re-subscribes (JDBC cursor-0 replay + new-epoch
     * fencing + producer re-send from checkpoint) so no data is silently lost.
     */
    ErrorCode ERR_STREAM_CHANNEL_OVERFLOW =
            define("nop.err.stream.channel-overflow",
                    "RemoteInputChannel queue full with no consumer progress for {timeoutMs}ms on topic={topic}: downstream task is stalled (typed channel failure, recoverable via re-subscription/replay)",
                    ARG_TIMEOUT_MS, ARG_TOPIC);

    String ARG_EXPECTED_TYPE = "expectedType";
    String ARG_ACTUAL_TYPE = "actualType";

    ErrorCode ERR_STREAM_TYPE_MISMATCH =
            define("nop.err.stream.type-mismatch", "Type mismatch: expected {expectedType} but got {actualType}",
                    ARG_EXPECTED_TYPE, ARG_ACTUAL_TYPE);

    String ARG_EXPECTED_CHECKSUM = "expectedChecksum";
    String ARG_ACTUAL_CHECKSUM = "actualChecksum";

    /**
     * The epoch manifest carries a checksum
     * (SHA-256 over the canonical serialization with the checksum key removed) and the
     * restore path recomputed a different value. The persisted bytes do not match their
     * recorded integrity checksum — corruption or tampering. Fails fast rather than
     * restoring from unverifiable state (No-Silent-No-Op).
     */
    ErrorCode ERR_STREAM_CHECKPOINT_CHECKSUM_MISMATCH =
            define("nop.err.stream.checkpoint-checksum-mismatch",
                    "Epoch manifest checksum mismatch for job={jobId} epoch={epochId}: "
                            + "stored={expectedChecksum}, recomputed={actualChecksum}",
                    ARG_JOB_ID, ARG_EPOCH_ID, ARG_EXPECTED_CHECKSUM, ARG_ACTUAL_CHECKSUM);

    String ARG_SEGMENT_ID = "segmentId";
    String ARG_FILE_NAME = "fileName";

    /**
     * A shared SST segment in the
     * content-addressed store failed restore-time integrity re-verification — the
     * recomputed SHA-256 differs from the content hash the segment is addressed by
     * (truncated write, bit rot, or tampering). Fails fast instead of feeding corrupt
     * bytes into a reopened RocksDB (silent wrong data).
     */
    ErrorCode ERR_STREAM_CHECKPOINT_SEGMENT_CORRUPT =
            define("nop.err.stream.checkpoint-segment-corrupt",
                    "Shared SST segment corrupted for segment={segmentId} file={fileName}: "
                            + "expected={expectedChecksum}, recomputed={actualChecksum}",
                    ARG_SEGMENT_ID, ARG_FILE_NAME, ARG_EXPECTED_CHECKSUM, ARG_ACTUAL_CHECKSUM);

    String ARG_FORMAT_VERSION = "formatVersion";
    String ARG_STATE_FORMAT_VERSION = "stateFormatVersion";
    String ARG_CURRENT_FORMAT_VERSION = "currentFormatVersion";

    /**
     * The manifest's self-describing version face is unreadable by this
     * runtime — either the envelope {@code formatVersion} or the {@code stateFormatVersion}
     * field is greater than the current supported version (a future format whose
     * semantics are unknown), or the two version faces are mutually inconsistent
     * (e.g. envelope=2 but stateFormatVersion=3, which no writer ever produces).
     * A lower/equal version with the field absent is the tolerated legacy path.
     */
    ErrorCode ERR_STREAM_CHECKPOINT_FORMAT_VERSION_UNSUPPORTED =
            define("nop.err.stream.checkpoint-format-version-unsupported",
                    "Checkpoint format version unsupported for job={jobId} epoch={epochId}: "
                            + "envelope formatVersion={formatVersion}, stateFormatVersion={stateFormatVersion}, "
                            + "current supported={currentFormatVersion}",
                    ARG_JOB_ID, ARG_EPOCH_ID, ARG_FORMAT_VERSION, ARG_STATE_FORMAT_VERSION,
                    ARG_CURRENT_FORMAT_VERSION);

    String ARG_MISSING_FIELDS = "missingFields";

    /**
     * A persisted checkpoint record exists but is unreadable — required identity
     * fields ({@code jobId}/{@code pipelineId}/{@code checkpointId}/
     * {@code triggerTimestamp}/{@code completedTimestamp}) are missing from the
     * stored JSON (truncated write, legacy row, or hand edit). Fails fast with
     * the record's identity context instead of being folded into "no checkpoint
     * found", which would silently cold-start a stateful job (R5-ST-06).
     */
    ErrorCode ERR_STREAM_CHECKPOINT_DATA_CORRUPT =
            define("nop.err.stream.checkpoint-data-corrupt",
                    "Checkpoint record corrupted for job={jobId} checkpoint={epochId}: "
                            + "missing required fields [{missingFields}]",
                    ARG_JOB_ID, ARG_EPOCH_ID, ARG_MISSING_FIELDS);

    /**
     * State schema fingerprint mismatch detected at {@code getState()} time.
     * The current descriptor's schema checksum differs from the restored state's
     * descriptor checksum. Fails fast when no {@code StateMigrationFunction} is
     * registered; with a registered migration the restore path consults the
     * migration registry before failing.
     */
    ErrorCode ERR_STREAM_STATE_SCHEMA_MISMATCH =
            define("nop.err.stream.state-schema-mismatch",
                    "State schema mismatch for state '{stateName}': restored schema checksum differs from current descriptor. "
                            + "expected={expectedChecksum}, actual={actualChecksum}",
                    ARG_STATE_NAME, ARG_EXPECTED_CHECKSUM, ARG_ACTUAL_CHECKSUM);

    ErrorCode ERR_STREAM_CYCLIC_JOB_GRAPH =
            define("nop.err.stream.cyclic-job-graph", "Cyclic job graph detected: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_WINDOW_NON_ACCUMULATOR_MERGE_CONFLICT =
            define("nop.err.stream.window-non-accumulator-merge-conflict",
                    "Cannot merge multiple non-accumulator window values; conflicting values detected", ARG_DETAIL);

    String ARG_ELEMENT_TYPE = "elementType";

    ErrorCode ERR_STREAM_UNSUPPORTED_ELEMENT_TYPE =
            define("nop.err.stream.unsupported-element-type", "Unsupported StreamElement type: {elementType}", ARG_ELEMENT_TYPE);

    String ARG_WATERMARK = "watermark";
    String ARG_WINDOW = "window";

    ErrorCode ERR_STREAM_WINDOW_MERGE_INVALID_WATERMARK =
            define("nop.err.stream.window-merge-invalid-watermark",
                    "Event-time window end timestamp cannot become earlier than current watermark by merging. Current watermark: {watermark}, window: {window}",
                    ARG_WATERMARK, ARG_WINDOW);

    String ARG_PROCESSING_TIME = "processingTime";

    ErrorCode ERR_STREAM_WINDOW_MERGE_INVALID_PROCESSING_TIME =
            define("nop.err.stream.window-merge-invalid-processing-time",
                    "Processing-time window end timestamp cannot become earlier than current processing time by merging. Current processing time: {processingTime}, window: {window}",
                    ARG_PROCESSING_TIME, ARG_WINDOW);

    String ARG_FIELD = "field";

    ErrorCode ERR_STREAM_TUPLE_FIELD_REQUIRED =
            define("nop.err.stream.tuple-field-required", "Aggregation with field index {field} != 0 requires Tuple types", ARG_FIELD);

    ErrorCode ERR_STREAM_NUMBER_REQUIRED =
            define("nop.err.stream.number-required", "Aggregation requires Number elements");

    ErrorCode ERR_STREAM_COMPARABLE_REQUIRED =
            define("nop.err.stream.comparable-required", "Aggregation requires Comparable elements");

    String ARG_EXPECTED_TOKEN = "expectedToken";
    String ARG_ACTUAL_TOKEN = "actualToken";

    /**
     * A stale fencing token was presented to a TaskManager RPC entry
     * point. The contract documented on {@code TaskManager} is that any
     * operation carrying an old fencing token is rejected with this typed
     * error rather than warned-and-ignored.
     */
    ErrorCode ERR_STREAM_FENCING_TOKEN_MISMATCH =
            define("nop.err.stream.fencing-token-mismatch",
                    "Fencing token mismatch: expected={expectedToken}, actual={actualToken}",
                    ARG_EXPECTED_TOKEN, ARG_ACTUAL_TOKEN);

    String ARG_ATTEMPTS = "attempts";

    /**
     * Plan 369 Phase 4 (R5-CC-15): the JDBC leader elector failed to allocate a
     * monotonic leader epoch from the persistent epoch-counter row after the
     * bounded optimistic-concurrency retry budget was exhausted. The elector
     * surfaces this loudly instead of falling back to a constant epoch, which
     * would roll fencing back after a lease-row loss.
     */
    ErrorCode ERR_STREAM_LEADER_EPOCH_ALLOC_FAILED =
            define("nop.err.stream.leader-epoch-alloc-failed",
                    "Failed to allocate a monotonic leader epoch after {attempts} attempts "
                            + "(concurrent takeovers keep racing the epoch counter): {detail}",
                    ARG_ATTEMPTS, ARG_DETAIL);

    String ARG_CHECKPOINT_VERTEX_IDS = "checkpointVertexIds";
    String ARG_CURRENT_VERTEX_IDS = "currentVertexIds";
    String ARG_MISSING_VERTEX_IDS = "missingVertexIds";

    /**
     * Reverse-direction savepoint vertex differential. The checkpoint
     * contains vertices that are not present in the current graph — i.e. a
     * stateful vertex was removed. Per {@code checkpoint-design.md} §8.6 the
     * safe default is to reject such a restore rather than silently dropping
     * the orphan state.
     */
    ErrorCode ERR_STREAM_SAVEPOINT_VERTEX_DIFFERENTIAL =
            define("nop.err.stream.savepoint-vertex-differential",
                    "Checkpoint contains stateful vertices absent from the current graph (likely deleted): "
                            + "missing={missingVertexIds}; checkpoint-vertices={checkpointVertexIds}; current-vertices={currentVertexIds}",
                    ARG_MISSING_VERTEX_IDS, ARG_CHECKPOINT_VERTEX_IDS, ARG_CURRENT_VERTEX_IDS);

    String ARG_DISCOVERY_ONLY = "discoveryOnly";
    String ARG_REGISTRY_ONLY = "registryOnly";

    String ARG_OLD_PARALLELISM = "oldParallelism";
    String ARG_NEW_PARALLELISM = "newParallelism";

    /**
     * Unaligned checkpoint + rescale interaction: a rescale restore
     * (parallelism change) detected that the source checkpoint carries non-empty
     * channel state (in-flight data captured during an unaligned checkpoint).
     * Channel state cannot be redistributed across a new parallelism in the first
     * version (no {@code InflightDataRescalingDescriptor}); silently dropping it
     * would break exactly-once. The restore path therefore fails fast and asks
     * the user to recover from an aligned checkpoint instead. See
     * {@code checkpoint-design.md} §2.11.8.
     */
    ErrorCode ERR_STREAM_CHANNEL_STATE_RESCALE_UNSUPPORTED =
            define("nop.err.stream.channel-state-rescale-unsupported",
                    "Cannot rescale (parallelism change) from a checkpoint that carries unaligned channel state: "
                            + "in-flight data cannot be redistributed across the new parallelism. "
                            + "vertex={vertexId}, oldParallelism={oldParallelism}, newParallelism={newParallelism}. "
                            + "Recover from an aligned checkpoint instead.",
                    ARG_VERTEX_ID, ARG_OLD_PARALLELISM, ARG_NEW_PARALLELISM);

    /**
     * Operator-state rescale interaction (plan 369 NEW-A): a scale-up rescale
     * restore (newParallelism &gt; oldParallelism) detected that at least one old
     * subtask carries a non-empty operator (non-keyed) state. Operator state has
     * no cross-parallelism redistribution wiring in the execution path (explicit
     * adjudication — see {@code state-management-design.md} §10.4), so the prior
     * behavior silently left every added subtask's operator state empty (e.g. a
     * source would lose its split-assignment table). The restore fails fast
     * instead, symmetric with the AR-03 scale-down guard in
     * {@code MaxParallelismReshardMigration}. Same-parallelism recovery (P
     * unchanged) restores 1:1 and is unaffected.
     */
    ErrorCode ERR_STREAM_OPERATOR_STATE_SCALE_UP_UNSUPPORTED =
            define("nop.err.stream.operator-state-scale-up-unsupported",
                    "Cannot scale up (increase parallelism) from a checkpoint whose subtasks carry "
                            + "non-empty operator state: operator state has no cross-parallelism "
                            + "redistribution wiring, so the added subtasks would silently start with "
                            + "empty state. vertex={vertexId}, oldParallelism={oldParallelism}, "
                            + "newParallelism={newParallelism}. Restart with the checkpoint's parallelism "
                            + "or run the maxParallelism reshard migration (which redistributes keyed "
                            + "state and refuses lossy operator-state migrations).",
                    ARG_VERTEX_ID, ARG_OLD_PARALLELISM, ARG_NEW_PARALLELISM);

    /**
     * The optional discovery-read cross-check
     * detected divergence between the platform discovery view and the
     * {@code ClusterRegistry} runtime source of truth. The two views are
     * eventually consistent (same DB, different tables, non-transactional), but
     * persistent divergence indicates a missed registration or a stale lease. The
     * checker fails loud rather than silently swallowing the drift (No-Silent-No-Op).
     */
    ErrorCode ERR_STREAM_DISCOVERY_DRIFT =
            define("nop.err.stream.discovery-drift",
                    "Discovery/registry drift detected: instances only in discovery={discoveryOnly}, "
                            + "nodes only in registry={registryOnly}",
                    ARG_DISCOVERY_ONLY, ARG_REGISTRY_ONLY);

    /**
     * A write
     * was attempted on a sealed {@code IMaterializationPoint}. Sealed points are
     * immutable; the producer must not continue dual-writing after seal. Fails
     * fast rather than silently dropping the element (No-Silent-No-Op).
     */
    ErrorCode ERR_STREAM_MATERIALIZE_POINT_SEALED =
            define("nop.err.stream.materialize-point-sealed",
                    "Materialization point {pointId} is sealed: {detail}", ARG_POINT_ID, ARG_DETAIL);

    /**
     * The
     * consumer-side replay path was invoked on a channel whose underlying
     * {@code ResultPartition} has no materialization point attached (i.e. the
     * {@code JobEdge} materialization marker is off). Fails fast rather than
     * silently returning an empty replay (No-Silent-No-Op): a replay request on
     * a non-materialized edge is a programming error in the recovery path.
     */
    ErrorCode ERR_STREAM_MATERIALIZE_POINT_NOT_ATTACHED =
            define("nop.err.stream.materialize-point-not-attached",
                    "No materialization point attached to this channel/partition: cannot replay. {detail}",
                    ARG_DETAIL);

    /**
     * Dual-write bypass was enabled (a materialization
     * point is attached) but the bypass write to the materialization store
     * failed. The producer fails fast rather than continuing with a divergent
     * main-queue/materialization-store pair (which would break recovery).
     */
    ErrorCode ERR_STREAM_MATERIALIZE_WRITE_FAILED =
            define("nop.err.stream.materialize-write-failed",
                    "Materialization bypass write failed for point {pointId}: {detail}",
                    ARG_POINT_ID, ARG_DETAIL);

    String ARG_REGION_ID = "regionId";
    String ARG_MAX_RESTARTS = "maxRestarts";

    /**
     * A task failed mid-execution and
     * the supervision loop detected it. This error surfaces the failure for the
     * single-region case (where scoped restart is not applicable — there is no
     * materialization boundary to contain the blast radius) and for the
     * global-recovery fallback path.
     */
    ErrorCode ERR_STREAM_SUPERVISION_TASK_FAILED =
            define("nop.err.stream.supervision-task-failed",
                    "Supervision loop detected task failure for vertex={vertexId} taskIndex={taskIndex} region={regionId}: {detail}",
                    ARG_VERTEX_ID, ARG_TASK_INDEX, ARG_REGION_ID, ARG_DETAIL);

    /**
     * The per-region restart budget
     * was exhausted. The supervision loop attempted to restart the failing
     * region {regionId} but it exceeded the configured maxRestarts={maxRestarts}.
     * Falls back to global recovery (whole-job) — the caller (typically
     * GraphModelCheckpointExecutor) surfaces this as a hard failure so the
     * existing recovery path can take over.
     */
    ErrorCode ERR_STREAM_SUPERVISION_RESTART_EXHAUSTED =
            define("nop.err.stream.supervision-restart-exhausted",
                    "Region restart budget exhausted for region={regionId}: attempts exceeded maxRestarts={maxRestarts}. Falling back to global recovery.",
                    ARG_REGION_ID, ARG_MAX_RESTARTS);

    String ARG_TASK_KEY = "taskKey";

    /**
     * A task did not reach a terminal state within the
     * cooperative-cancel budget during a region-scoped restart. Rebuilding a
     * second task instance would create a zombie (two producers writing the same
     * {@code ResultPartition}, racing on {@code currentMaterializationEpoch},
     * breaking exactly-once), so this error fails loud and the caller surfaces
     * the failure for recovery (local/embedded path via {@code env.execute()};
     * distributed path via FAILED report + {@code autoRecoverOnFailedReport}).
     *
     * <p>Distinct from {@link #ERR_STREAM_SUPERVISION_RESTART_EXHAUSTED} (the
     * region-restart budget exhaustion surfaced by {@code SupervisionLoop}) so the
     * two conditions remain distinguishable on an ops dashboard.
     */
    ErrorCode ERR_STREAM_SUPERVISION_ZOMBIE_TASK_TIMEOUT =
            define("nop.err.stream.supervision-zombie-task-timeout",
                    "Task {taskKey} did not reach a terminal state within the cancel budget "
                            + "during region restart (vertex={vertexId} taskIndex={taskIndex} region={regionId}). "
                            + "Refusing to rebuild a second task instance (would create a zombie). Failing loud for recovery.",
                    ARG_TASK_KEY, ARG_VERTEX_ID, ARG_TASK_INDEX, ARG_REGION_ID);

    /**
     * A region-scoped restart was
     * attempted but the region contains producer vertices that cannot be safely
     * restarted without the drain/reconnect protocol. The
     * supervision loop falls back to global recovery rather than silently
     * producing an inconsistent state (No-Silent-No-Op).
     */
    ErrorCode ERR_STREAM_REGION_RESTART_UNSUPPORTED =
            define("nop.err.stream.region-restart-unsupported",
                    "Region {regionId} cannot be safely restarted: it contains producer vertices requiring drain/reconnect (successor plan 4). Falling back to global recovery.",
                    ARG_REGION_ID);

    /**
     * R5-REG-01 (plan 368 Phase 5): a region
     * restart combined an internal NON-materialized edge whose producer already
     * COMPLETED with a consumer that must be rebuilt from a completed checkpoint.
     * The restart loop skips COMPLETED producer tasks (their finished partition
     * cannot be written again), so there is no re-emission source, and a
     * non-materialized edge has no store-backed replay — while the rebuilt
     * consumer's operator state is rolled back to the checkpoint epoch. The
     * record window between the checkpoint epoch and the failure would therefore
     * be silently truncated (undetectable wrong output). The restart fails loud
     * instead, naming the edge, the producer/consumer subtasks and the
     * checkpoint epoch. Restarts WITHOUT a completed checkpoint keep the
     * documented residual + end-of-stream delivery (inherent in-flight loss of a
     * non-materialized edge without a checkpoint — unchanged contract).
     */
    ErrorCode ERR_STREAM_RESTART_UNREPLAYABLE_INTERNAL_EDGE =
            define("nop.err.stream.restart-unreplayable-internal-edge",
                    "Region {regionId} restart would silently lose records: rebuilt consumer "
                            + "vertex={vertexId} taskIndex={taskIndex} reads a FINISHED "
                            + "non-materialized (internal) edge partition, its operator state was "
                            + "about to be rolled back to checkpoint epoch {checkpointId}, and the "
                            + "COMPLETED producer is skipped on restart (no replay source exists for "
                            + "the post-checkpoint window). Failing loud instead of truncating output: {detail}",
                    ARG_REGION_ID, ARG_VERTEX_ID, ARG_TASK_INDEX, ARG_CHECKPOINT_ID, ARG_DETAIL);

    /**
     * Per {@code checkpoint-design.md} §8.5.2: a checkpoint restore detected a
     * two-phase-commit sink vertex whose checkpoint parallelism differs from the current
     * execution parallelism. Cross-parallelism redistribution of 2PC pending commits has no
     * supported path — operator state restores strictly 1:1 by subtask index, so a scale-down
     * would silently drop durable-uncommitted pending commits (exactly-once violation) and a
     * non-keyed scale-up has no state-lookup path. The restore is therefore rejected with the
     * parallelism mismatch made explicit (typed, params vertexId/oldParallelism/newParallelism).
     * Same-parallelism recovery (kill/recover, P unchanged) is the supported restore path;
     * changing a 2PC sink's parallelism requires a fresh job.
     */
    ErrorCode ERR_STREAM_2PC_SINK_PARALLELISM_CHANGE_UNSUPPORTED =
            define("nop.err.stream.2pc-sink-parallelism-change-unsupported",
                    "Two-phase-commit sink vertex '{vertexId}' cannot restore across a parallelism change: "
                            + "checkpoint parallelism={oldParallelism}, current parallelism={newParallelism}. "
                            + "2PC pending commits cannot be redistributed across subtasks (they restore 1:1 by "
                            + "subtask index; a scale-down would silently drop durable-uncommitted commits). "
                            + "Restart with the same parallelism or start a fresh job "
                            + "(checkpoint-design.md 8.5.2).",
                    ARG_VERTEX_ID, ARG_OLD_PARALLELISM, ARG_NEW_PARALLELISM);

    // ------------------------------------------------------------------
    // nop-stream-flow DSL contract error codes
    // ------------------------------------------------------------------

    String ARG_ID = "id";
    String ARG_ELEMENT = "element";
    String ARG_ATTR_NAME = "attrName";
    String ARG_ATTR_VALUE = "attrValue";
    String ARG_EDGE_ID = "edgeId";
    String ARG_TRANSFORM_ID = "transformId";
    String ARG_REF_TYPE = "refType";
    String ARG_REF_NAME = "refName";
    String ARG_PARTITION = "partition";
    String ARG_BEAN_NAME = "beanName";
    String ARG_EXPECTED_STREAM_TYPE = "expectedStreamType";
    String ARG_ACTUAL_STREAM_TYPE = "actualStreamType";

    ErrorCode ERR_STREAM_DUPLICATE_ID =
            define("nop.err.stream.duplicate-id",
                    "Duplicate Stream DSL {element} id: {id}", ARG_ELEMENT, ARG_ID);

    ErrorCode ERR_STREAM_REQUIRED_ATTR =
            define("nop.err.stream.required-attr",
                    "Stream DSL {element} requires attribute {attrName}", ARG_ELEMENT, ARG_ATTR_NAME);

    ErrorCode ERR_STREAM_REQUIRED_BODY =
            define("nop.err.stream.required-body",
                    "Stream DSL {element} must declare either bean=\"...\" or inline <source>xpl</source>",
                    ARG_ELEMENT);

    ErrorCode ERR_STREAM_REF_UNKNOWN =
            define("nop.err.stream.ref-unknown",
                    "Stream DSL {element} references unknown {refType} '{refName}'",
                    ARG_ELEMENT, ARG_REF_TYPE, ARG_REF_NAME);

    ErrorCode ERR_STREAM_NOT_IMPLEMENTED =
            define("nop.err.stream.not-implemented", "not yet implemented: {detail}", ARG_DETAIL);

    ErrorCode ERR_STREAM_UPSTREAM_TYPE =
            define("nop.err.stream.upstream-type",
                    "Stream DSL {element} requires a {expectedStreamType} upstream, got {actualStreamType}",
                    ARG_ELEMENT, ARG_EXPECTED_STREAM_TYPE, ARG_ACTUAL_STREAM_TYPE);

    ErrorCode ERR_STREAM_UPSTREAM_NULL =
            define("nop.err.stream.upstream-null",
                    "Stream DSL {element} upstream is null", ARG_ELEMENT);

    ErrorCode ERR_STREAM_UPSTREAM_NOT_STREAM =
            define("nop.err.stream.upstream-not-stream",
                    "Stream DSL {element} upstream is not a recognized stream type: {actualStreamType}",
                    ARG_ELEMENT, ARG_ACTUAL_STREAM_TYPE);

    ErrorCode ERR_STREAM_EDGE_HASH_KEY_EXPR_REQUIRED =
            define("nop.err.stream.edge-hash-key-expr-required",
                    "Stream DSL edge {edgeId} declares partition=\"HASH\" without keyExpr; "
                            + "declare keyExpr=\"...\" or use FORWARD", ARG_EDGE_ID);

    ErrorCode ERR_STREAM_EDGE_HASH_REDUNDANT =
            define("nop.err.stream.edge-hash-redundant",
                    "Stream DSL edge {edgeId} declares partition=\"HASH\" but its target transform "
                            + "{transformId} is already a keyBy transform; use FORWARD",
                    ARG_EDGE_ID, ARG_TRANSFORM_ID);

    ErrorCode ERR_STREAM_EDGE_KEY_EXPR_WITHOUT_HASH =
            define("nop.err.stream.edge-key-expr-without-hash",
                    "Stream DSL edge {edgeId} declares keyExpr but partition is not HASH; "
                            + "keyExpr is only consumed with partition=\"HASH\"", ARG_EDGE_ID);

    ErrorCode ERR_STREAM_EDGE_PARTITION_UNSUPPORTED =
            define("nop.err.stream.edge-partition-unsupported",
                    "Stream DSL edge {edgeId} declares partition={partition} which is not yet "
                            + "implemented in nop-stream-core; use FORWARD or a <keyBy> transform",
                    ARG_EDGE_ID, ARG_PARTITION);

    ErrorCode ERR_STREAM_EDGE_ATTR_UNSUPPORTED =
            define("nop.err.stream.edge-attr-unsupported",
                    "Stream DSL edge {edgeId} declares {attrName} which is not yet implemented "
                            + "in nop-stream-core; remove the attribute",
                    ARG_EDGE_ID, ARG_ATTR_NAME);

    ErrorCode ERR_STREAM_WINDOW_ATTR_UNSUPPORTED =
            define("nop.err.stream.window-attr-unsupported",
                    "Stream DSL {element} declares {attrName}={attrValue} which is not yet "
                            + "implemented in nop-stream-core windowing; remove the declaration "
                            + "or use the default value",
                    ARG_ELEMENT, ARG_ATTR_NAME, ARG_ATTR_VALUE);

    ErrorCode ERR_STREAM_BEAN_NOT_FOUND =
            define("nop.err.stream.bean-not-found",
                    "Stream DSL bean reference not found: bean='{beanName}'", ARG_BEAN_NAME);

    ErrorCode ERR_STREAM_BEAN_TYPE_MISMATCH =
            define("nop.err.stream.bean-type-mismatch",
                    "Stream DSL bean '{beanName}' is not a {expectedType}: actual={actualType}",
                    ARG_BEAN_NAME, ARG_EXPECTED_TYPE, ARG_ACTUAL_TYPE);

    // ------------------------------------------------------------------
    // Connector SPI registry error codes
    // ------------------------------------------------------------------

    String ARG_TYPE_NAME = "typeName";
    String ARG_DIRECTION = "direction";
    String ARG_REGISTERED_TYPES = "registeredTypes";
    String ARG_EXPECTED_DIRECTION = "expectedDirection";
    String ARG_ACTUAL_DIRECTION = "actualDirection";
    String ARG_FACTORY_CLASS = "factoryClass";
    String ARG_EXISTING_FACTORY_CLASS = "existingFactoryClass";
    String ARG_PARAM_NAME = "paramName";
    String ARG_PARAM_KIND = "paramKind";
    String ARG_DECLARED_VALUE = "declaredValue";
    String ARG_ACTUAL_VALUE = "actualValue";

    ErrorCode ERR_STREAM_CONNECTOR_TYPE_NOT_FOUND =
            define("nop.err.stream.connector-type-not-found",
                    "Stream connector type '{typeName}' ({direction}) is not registered. "
                            + "Registered {direction} types: {registeredTypes}",
                    ARG_TYPE_NAME, ARG_DIRECTION, ARG_REGISTERED_TYPES);

    ErrorCode ERR_STREAM_CONNECTOR_DIRECTION_MISMATCH =
            define("nop.err.stream.connector-direction-mismatch",
                    "Stream connector type '{typeName}' is registered as {actualDirection}, "
                            + "not {expectedDirection}",
                    ARG_TYPE_NAME, ARG_ACTUAL_DIRECTION, ARG_EXPECTED_DIRECTION);

    ErrorCode ERR_STREAM_CONNECTOR_DUPLICATE_TYPE =
            define("nop.err.stream.connector-duplicate-type",
                    "Duplicate stream connector registration: {direction} type name '{typeName}' "
                            + "(or alias) is registered by both '{existingFactoryClass}' and '{factoryClass}'",
                    ARG_DIRECTION, ARG_TYPE_NAME, ARG_EXISTING_FACTORY_CLASS, ARG_FACTORY_CLASS);

    ErrorCode ERR_STREAM_CONNECTOR_DESCRIPTOR_INVALID =
            define("nop.err.stream.connector-descriptor-invalid",
                    "Stream connector factory '{factoryClass}' declares an invalid capability descriptor: {detail}",
                    ARG_FACTORY_CLASS, ARG_DETAIL);

    ErrorCode ERR_STREAM_CONNECTOR_PARAM_REQUIRED =
            define("nop.err.stream.connector-param-required",
                    "Stream connector '{typeName}' requires config param '{paramName}' of kind {paramKind}",
                    ARG_TYPE_NAME, ARG_PARAM_NAME, ARG_PARAM_KIND);

    ErrorCode ERR_STREAM_CONNECTOR_CAPABILITY_MISMATCH =
            define("nop.err.stream.connector-capability-mismatch",
                    "Stream connector '{typeName}' descriptor declares {declaredValue} but the constructed "
                            + "endpoint reports {actualValue}",
                    ARG_TYPE_NAME, ARG_DECLARED_VALUE, ARG_ACTUAL_VALUE);

    // ------------------------------------------------------------------
    // Pre-submit validation error codes
    // ------------------------------------------------------------------

    String ARG_DECLARED_PARAMS = "declaredParams";
    String ARG_FIELD_NAME = "fieldName";
    String ARG_FIELD_VALUE = "fieldValue";
    String ARG_CREDENTIAL_ID = "credentialId";
    String ARG_CONNECTOR_ENDPOINT = "connectorEndpoint";
    String ARG_LAYER = "layer";

    ErrorCode ERR_STREAM_CONNECTOR_PARAM_UNKNOWN =
            define("nop.err.stream.connector-param-unknown",
                    "Stream connector '{typeName}' does not declare config param '{paramName}'. "
                            + "Declared params: {declaredParams}",
                    ARG_TYPE_NAME, ARG_PARAM_NAME, ARG_DECLARED_PARAMS);

    ErrorCode ERR_STREAM_CREDENTIAL_REF_INVALID =
            define("nop.err.stream.credential-ref-invalid",
                    "Invalid credential reference '{fieldValue}' on field '{fieldName}': expected syntax "
                            + "credential:{credentialId}#{field}",
                    ARG_FIELD_NAME, ARG_FIELD_VALUE, ARG_CREDENTIAL_ID);

    ErrorCode ERR_STREAM_CREDENTIAL_PROVIDER_MISSING =
            define("nop.err.stream.credential-provider-missing",
                    "Credential reference '{fieldValue}' on field '{fieldName}' cannot be resolved: no "
                            + "ICredentialProvider is available (fail-closed). Inject the provider before "
                            + "starting or validating the connector.",
                    ARG_FIELD_NAME, ARG_FIELD_VALUE);

    ErrorCode ERR_STREAM_CREDENTIAL_UNRESOLVED =
            define("nop.err.stream.credential-unresolved",
                    "Credential '{credentialId}' (referenced by field '{fieldName}') could not be resolved: "
                            + "it does not exist or has been soft-deleted (fail-closed). "
                            + "Original failure: {detail}",
                    ARG_CREDENTIAL_ID, ARG_FIELD_NAME, ARG_FIELD_VALUE, ARG_DETAIL);

    ErrorCode ERR_STREAM_CONNECTIVITY_CHECK_FAILED =
            define("nop.err.stream.connectivity-check-failed",
                    "Connectivity check failed for connector endpoint '{connectorEndpoint}': {detail}",
                    ARG_CONNECTOR_ENDPOINT, ARG_DETAIL);

    ErrorCode ERR_STREAM_CONNECTIVITY_NOT_SUPPORTED =
            define("nop.err.stream.connectivity-not-supported",
                    "Connector endpoint '{connectorEndpoint}' implements no probe contract: dry-run cannot "
                            + "determine its connectivity ({detail})",
                    ARG_CONNECTOR_ENDPOINT, ARG_DETAIL);
}
