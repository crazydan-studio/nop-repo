/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.core.operators;

import java.io.Serializable;

import io.nop.stream.core.checkpoint.OperatorSnapshotResult;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.common.state.CheckpointListener;
import io.nop.stream.core.streamrecord.StreamRecord;

/**
 * Basic interface for stream operators. Implementers would implement {@link
 * OneInputStreamOperator} to create operators that process elements.
 *
 * <p>The class {@link io.nop.stream.core.operators.StreamingRuntimeContext} offers
 * default implementation for the lifecycle and properties methods.
 *
 * <p>Methods of {@code StreamOperator} are guaranteed not to be called concurrently. Also, if using
 * the timer service, timer callbacks are also guaranteed not to be called concurrently with methods
 * on {@code StreamOperator}.
 *
 * @param <OUT> The output type of the operator
 */
public interface StreamOperator<OUT> extends CheckpointListener, KeyContext, Serializable {

    // ------------------------------------------------------------------------
    //  life cycle
    // ------------------------------------------------------------------------

    /**
     * This method is called immediately before any elements are processed, it should contain the
     * operator's initialization logic.
     *
     * @throws java.lang.Exception An exception in this method causes the operator to fail.
     * @implSpec In case of recovery, this method needs to ensure that all recovered data is
     * processed before passing back control, so that the order of elements is ensured during
     * the recovery of an operator chain (operators are opened from the tail operator to the
     * head operator).
     */
    void open() throws Exception;

    /**
     * This method is called at the end of data processing.
     *
     * <p>The method is expected to flush all remaining buffered data. Exceptions during this
     * flushing of buffered data should be propagated, in order to cause the operation to be
     * recognized as failed, because the last data items are not processed properly.
     *
     * <p><b>After this method is called, no more records can be produced for the downstream
     * operators.</b>
     *
     * <p><b>WARNING:</b> It is not safe to use this method to commit any transactions or other side
     * effects! You can use this method to flush any buffered data that can later on be committed
     * e.g. in a {@link StreamOperator#notifyCheckpointComplete(long)}.
     *
     * <p><b>NOTE:</b>This method does not need to close any resources. You should release external
     * resources in the {@link #close()} method.
     *
     * @throws java.lang.Exception An exception in this method causes the operator to fail.
     */
    void finish() throws Exception;

    /**
     * This method is called at the very end of the operator's life, both in the case of a
     * successful completion of the operation, and in the case of a failure and canceling.
     *
     * <p>This method is expected to make a thorough effort to release all resources that the
     * operator has acquired.
     *
     * <p><b>NOTE:</b>It can not emit any records! If you need to emit records at the end of
     * processing, do so in the {@link #finish()} method.
     */
    void close() throws Exception;

    // ------------------------------------------------------------------------
    //  state snapshots
    // ------------------------------------------------------------------------

    /**
     * This method is called when the operator should do a snapshot, before it emits its own
     * checkpoint barrier.
     *
     * <p>This method is intended not for any actual state persistence, but only for emitting some
     * data before emitting the checkpoint barrier. Operators that maintain some small transient
     * state that is inefficient to checkpoint (especially when it would need to be checkpointed in
     * a re-scalable way) but can simply be sent downstream before the checkpoint. An example are
     * opportunistic pre-aggregation operators, which have small the pre-aggregation state that is
     * frequently flushed downstream.
     *
     * <p><b>Important:</b> This method should not be used for any actual state snapshot logic,
     * because it will inherently be within the synchronous part of the operator's checkpoint. If
     * heavy work is done within this method, it will affect latency and downstream checkpoint
     * alignments.
     *
     * @param checkpointId The ID of the checkpoint.
     * @throws Exception Throwing an exception here causes the operator to fail and go into
     *                   recovery.
     */
    void prepareSnapshotPreBarrier(long checkpointId) throws Exception;

    /**
     * Takes a state snapshot of the operator.
     *
     * @param checkpointId checkpoint ID
     * @return state snapshot result
     * @throws Exception exception during snapshotting
     */
    default OperatorSnapshotResult snapshotState(long checkpointId) throws Exception {
        // 默认实现：返回空快照
        return OperatorSnapshotResult.empty();
    }

    /**
     * Restores operator state from a snapshot.
     *
     * @param taskStateSnapshot the state data to restore
     * @throws Exception exception during restoration
     */
    default void initializeState(TaskStateSnapshot taskStateSnapshot) throws Exception {
        // 默认实现：无操作
    }

    // ------------------------------------------------------------------------
    //  parallelism / subtask isolation
    // ------------------------------------------------------------------------

    /**
     * Produces an independent copy of this operator suitable for execution as a
     * distinct parallel subtask.
     *
     * <p>When {@code parallelism > 1}, each subtask must hold its own operator
     * instance so that mutable operator state (output wiring, watermark tracking,
     * NFA, collectors, timer services, etc.) is not silently shared across
     * subtasks. User functions (closures, sink/map functions) and immutable
     * configuration are typically shared across subtask copies to preserve
     * captured external references — see the contract documented on
     * {@link io.nop.stream.core.jobgraph.OperatorChain#deepCopy()}.
     *
     * <p><strong>Default behavior:</strong> throws {@link UnsupportedOperationException}
     * so that operators which forget to declare copy semantics fail loudly rather
     * than silently share mutable state across subtasks (No-Silent-No-Op).
     *
     * <p>Concrete operators extending {@link AbstractStreamOperator} inherit a
     * serialization-based default; operators that must share user-function
     * references override with an efficient constructor-based copy. Operators
     * that are explicitly safe to share across subtasks (stateless markers)
     * may return {@code this} and should be annotated {@link Shareable}.
     *
     * @return a new operator instance with fresh mutable state (transient fields
     *         left empty — they are re-initialized by {@link #open()})
     * @throws UnsupportedOperationException if this operator does not declare
     *         copy semantics and is not marked {@link Shareable}
     */
    /**
     * Returns {@code true} if this operator is safe to share across parallel
     * subtasks without copying.
     *
     * <p>The default implementation checks for the {@link Shareable} annotation.
     * Operators that need dynamic shareability may override this method.
     */
    default boolean isShareable() {
        return getClass().isAnnotationPresent(Shareable.class);
    }

    default StreamOperator<?> copyForSubtask() {
        if (isShareable()) {
            return this;
        }
        throw new UnsupportedOperationException(
                "Operator " + getClass().getName() + " does not implement copyForSubtask(). "
                        + "Parallel subtasks would silently share mutable state. "
                        + "Either override copyForSubtask() to return an independent instance, "
                        + "or annotate the class with @Shareable if cross-subtask sharing is safe.");
    }

    // ------------------------------------------------------------------------
    //  miscellaneous
    // ------------------------------------------------------------------------

    void setKeyContextElement1(StreamRecord<?> record) throws Exception;

    void setKeyContextElement2(StreamRecord<?> record) throws Exception;

//    OperatorMetricGroup getMetricGroup();
//
//    OperatorID getOperatorID();
}
