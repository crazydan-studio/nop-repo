/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.core.operators;

import io.nop.stream.core.checkpoint.CheckpointBarrier;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.streamrecord.LatencyMarker;
import io.nop.stream.core.streamrecord.StreamElement;
import io.nop.stream.core.streamrecord.StreamRecord;
import io.nop.stream.core.streamrecord.watermark.Watermark;
import io.nop.stream.core.streamrecord.watermark.WatermarkStatus;
import io.nop.stream.core.util.Collector;
import io.nop.stream.core.util.OutputTag;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ELEMENT_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED_ELEMENT_TYPE;

/**
 * A {@link io.nop.stream.core.operators.StreamOperator} is supplied with an object of
 * this interface that can be used to emit elements and other messages, such as barriers and
 * watermarks, from an operator.
 *
 * @param <T> The type of the elements that can be emitted.
 */
public interface Output<T> extends Collector<T> {

    /**
     * Emits a {@link Watermark} from an operator. This watermark is broadcast to all downstream
     * operators.
     *
     * <p>A watermark specifies that no element with a timestamp lower or equal to the watermark
     * timestamp will be emitted in the future.
     */
    void emitWatermark(Watermark mark);

    void emitWatermarkStatus(WatermarkStatus watermarkStatus);

    /**
     * Emits a record to the side output identified by the given {@link OutputTag}.
     *
     * @param record The record to collect.
     */
    <X> void collect(OutputTag<X> outputTag, StreamRecord<X> record);

    void emitLatencyMarker(LatencyMarker latencyMarker);

    void emitBarrier(CheckpointBarrier barrier);

    @SuppressWarnings("unchecked")
    default void collectElement(StreamElement element) {
        if (element.isRecord()) {
            collect((T) element);
        } else if (element.isWatermark()) {
            emitWatermark((Watermark) element);
        } else if (element.isCheckpointBarrier()) {
            emitBarrier((CheckpointBarrier) element);
        } else if (element.isWatermarkStatus()) {
            emitWatermarkStatus((WatermarkStatus) element);
        } else if (element.isLatencyMarker()) {
            emitLatencyMarker((LatencyMarker) element);
        } else {
            throw new StreamException(ERR_STREAM_UNSUPPORTED_ELEMENT_TYPE)
                    .param(ARG_ELEMENT_TYPE, element.getClass().getName());
        }
    }
}
