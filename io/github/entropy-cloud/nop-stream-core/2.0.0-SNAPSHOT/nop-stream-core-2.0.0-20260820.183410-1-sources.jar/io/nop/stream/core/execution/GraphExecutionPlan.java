/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.execution;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.annotations.core.Internal;
import io.nop.commons.partition.IPartitioner;

import io.nop.stream.core.checkpoint.TaskLocation;
import io.nop.stream.core.execution.buffer.BufferPool;
import io.nop.stream.core.execution.buffer.IBufferPool;
import io.nop.stream.core.execution.flow.EdgeConfig;
import io.nop.stream.core.execution.materialization.InMemoryMaterializationPoint;
import io.nop.stream.core.execution.plan.DeploymentPlan;
import io.nop.stream.core.execution.plan.PartitionedPlan;
import io.nop.stream.core.execution.plan.PartitionPolicy;
import io.nop.stream.core.execution.plan.PartitionPolicyAware;
import io.nop.stream.core.jobgraph.JobEdge;
import io.nop.stream.core.jobgraph.JobGraph;
import io.nop.stream.core.jobgraph.JobVertex;
import io.nop.stream.core.jobgraph.OperatorChain;
import io.nop.stream.core.jobgraph.region.RegionDecomposition;
import io.nop.stream.core.jobgraph.region.RegionId;

import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CYCLIC_JOB_GRAPH;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;

/**
 * Builds an execution plan from a JobGraph, creating data exchange channels
 * (ResultPartition, InputChannel) for inter-task communication.
 *
 * <p>For each vertex with parallelism N, N {@link Subtask} instances are created.
 * For each JobEdge, a matrix of ResultPartitions is created:
 * sourceParallelism × targetParallelition partitions. Each source subtask's
 * RecordWriter holds the targetParallelism partitions for that edge. Each target
 * subtask's InputGate receives from all sourceParallelism partitions.
 *
 * <p>Partition routing is determined by the edge's {@link PartitionPolicy}:
 * <ul>
 *   <li>FORWARD: 1:1 mapping, source subtask i → target subtask i (modulo target parallelism)</li>
 *   <li>HASH: key-based routing via {@link io.nop.stream.core.common.state.shard.StateShard#stableHash}</li>
 *   <li>REBALANCE: round-robin across all target subtasks</li>
 * </ul>
 *
 * <p>Vertices are sorted in topological order (sources first, sinks last)
 * so that tasks can be submitted in dependency order.
 *
 * <p>This class is used by both the non-checkpoint execution path
 * ({@code StreamExecutionEnvironment}) and the checkpoint execution path
 * ({@code GraphModelCheckpointExecutor}).
 */
@Internal
public class GraphExecutionPlan {

    private static final Logger LOG = LoggerFactory.getLogger(GraphExecutionPlan.class);

    /**
     * Default global (cross-partition aggregate) element capacity used when a caller
     * invokes a {@code build(...)} overload that does not pass an explicit pool.
     *
     * <p>This is intentionally generous so that existing tests and small jobs are
     * unaffected by the global bound; production deployments should pass an explicit
     * {@link IBufferPool} sized to the real memory budget. The constant exists so the
     * global bound is observable (and testable) rather than unbounded.
     */
    public static final int DEFAULT_GLOBAL_BUFFER_CAPACITY = 65536;

    private final List<String> sortedVertexIds;
    private final Map<String, JobVertex> executionVertices;
    private final Map<String, StreamTaskInvokable> invokables;

    /**
     * Subtasks indexed by vertexId then taskIndex.
     * When parallelism=1 (legacy mode), each vertex has exactly one subtask at index 0.
     */
    private final Map<String, List<Subtask>> subtasks;

    /**
     * The per-job buffer pool shared by all local {@code ResultPartition} instances in
     * this plan. May be {@code null} for plans built via {@link #create(...)} (runtime
     * builders that supply their own, possibly remote, partitions).
     */
    private final IBufferPool bufferPool;

    /**
     * The region decomposition of the source {@link JobGraph} (Stage 44
     * successor plan 2). Populated by {@link #build}; {@code null} for plans
     * built via {@link #create} (runtime builders that do not have a JobGraph
     * to decompose).
     */
    private final RegionDecomposition regionDecomposition;

    private GraphExecutionPlan(List<String> sortedVertexIds,
                                Map<String, JobVertex> executionVertices,
                                Map<String, StreamTaskInvokable> invokables,
                                Map<String, List<Subtask>> subtasks,
                                IBufferPool bufferPool) {
        this(sortedVertexIds, executionVertices, invokables, subtasks, bufferPool, null);
    }

    private GraphExecutionPlan(List<String> sortedVertexIds,
                                Map<String, JobVertex> executionVertices,
                                Map<String, StreamTaskInvokable> invokables,
                                Map<String, List<Subtask>> subtasks,
                                IBufferPool bufferPool,
                                RegionDecomposition regionDecomposition) {
        this.sortedVertexIds = sortedVertexIds;
        this.executionVertices = executionVertices;
        this.invokables = invokables;
        this.subtasks = subtasks;
        this.bufferPool = bufferPool;
        this.regionDecomposition = regionDecomposition;
    }

    /**
     * Creates a GraphExecutionPlan from pre-built components.
     * Used by runtime-level builders that create custom partition types.
     *
     * @param sortedVertexIds  topologically sorted vertex IDs
     * @param executionVertices map of vertexId to JobVertex
     * @param invokables       map of vertexId to StreamTaskInvokable
     * @param subtasks         map of vertexId to list of subtasks
     * @return a new GraphExecutionPlan
     */
    public static GraphExecutionPlan create(List<String> sortedVertexIds,
                                            Map<String, JobVertex> executionVertices,
                                            Map<String, StreamTaskInvokable> invokables,
                                            Map<String, List<Subtask>> subtasks) {
        // create() is used by runtime-level builders that supply their own partitions
        // (e.g. RemoteResultPartition). Such partitions intentionally bypass the pool,
        // so no pool is attached to a create()-built plan.
        return new GraphExecutionPlan(sortedVertexIds, executionVertices, invokables, subtasks, null);
    }

    /**
     * Builds an execution plan from the given JobGraph.
     *
     * <p>For each edge, ResultPartitions are created and wired into the
     * upstream RecordWriter and downstream InputGate. Vertices with no
     * edges use SELF_CONTAINED mode (identical to single-chain behavior).
     * Uses default barrier alignment (true = STRICT_EXACTLY_ONCE).
     *
     * @param jobGraph the job graph to plan execution for
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph) {
        return build(jobGraph, null, true);
    }

    /**
     * Builds an execution plan from the given JobGraph with an optional DeploymentPlan.
     *
     * <p>When a DeploymentPlan is provided, its edge configuration and memory budget
     * can influence the execution plan construction. When null, default behavior applies.
     * Uses default barrier alignment (true = STRICT_EXACTLY_ONCE).
     *
     * @param jobGraph       the job graph to plan execution for
     * @param deploymentPlan optional deployment plan (null uses default behavior)
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan) {
        return build(jobGraph, deploymentPlan, true);
    }

    /**
     * Builds an execution plan from the given JobGraph with full configuration.
     *
     * <p>Supports parallelism > 1: for each vertex with parallelism N, N subtasks are created.
     * For each edge, a matrix of sourceParallelism × targetParallelism ResultPartitions
     * is allocated. The partition routing strategy is determined by the edge's
     * {@link PartitionPolicy} (resolved from the DeploymentPlan or defaulting to FORWARD).
     *
     * @param jobGraph         the job graph to plan execution for
     * @param deploymentPlan   optional deployment plan (null uses default behavior)
     * @param barrierAlignment if true, InputGates use barrier alignment (STRICT_EXACTLY_ONCE);
     *                         if false, they allow records to flow through during barriers (AT_LEAST_ONCE)
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                           boolean barrierAlignment) {
        return build(jobGraph, deploymentPlan, barrierAlignment, InputGate.DEFAULT_ALIGNMENT_TIMEOUT_MS);
    }

    /**
     * Builds an execution plan from the given JobGraph with full configuration including
     * barrier alignment timeout.
     *
     * <p>A per-job {@link IBufferPool} with {@link #DEFAULT_GLOBAL_BUFFER_CAPACITY} is
     * created internally (one pool shared by all partitions in the returned plan). Use
     * {@link #build(JobGraph, DeploymentPlan, boolean, long, IBufferPool)} to pass an
     * explicit pool (e.g. sized to a real memory budget).
     *
     * @param jobGraph                the job graph to plan execution for
     * @param deploymentPlan          optional deployment plan (null uses default behavior)
     * @param barrierAlignment        if true, InputGates use barrier alignment
     * @param barrierAlignmentTimeout maximum time in ms for barrier alignment before timeout
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                           boolean barrierAlignment, long barrierAlignmentTimeout) {
        return build(jobGraph, deploymentPlan, barrierAlignment, barrierAlignmentTimeout,
                false, InputGate.DEFAULT_ALIGNMENT_TIMEOUT_MS);
    }

    /**
     * Stage 43 (unaligned checkpoint): builds an execution plan with full
     * barrier-alignment AND aligned→unaligned fallback configuration. The
     * unaligned flags are threaded into every multi-input {@link InputGate} so
     * that, under sustained backpressure, a checkpoint switches to unaligned mode
     * after {@code unalignedThreshold} ms instead of waiting until
     * {@code barrierAlignmentTimeout} and failing the task.
     *
     * <p>Callers MUST have validated (e.g. via
     * {@code CheckpointConfig.validateUnalignedConfig()}) that when
     * {@code unalignedCheckpointEnabled=true},
     * {@code unalignedThreshold < barrierAlignmentTimeout}.
     *
     * @param jobGraph                 the job graph to plan execution for
     * @param deploymentPlan           optional deployment plan (null uses default behavior)
     * @param barrierAlignment         if true, InputGates use barrier alignment
     * @param barrierAlignmentTimeout  maximum ms for barrier alignment before timeout
     * @param unalignedCheckpointEnabled whether aligned→unaligned fallback is enabled
     * @param unalignedThreshold       aligned→unaligned mode-switch threshold in ms
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                           boolean barrierAlignment, long barrierAlignmentTimeout,
                                           boolean unalignedCheckpointEnabled, long unalignedThreshold) {
        return build(jobGraph, deploymentPlan, barrierAlignment, barrierAlignmentTimeout,
                new BufferPool(DEFAULT_GLOBAL_BUFFER_CAPACITY),
                unalignedCheckpointEnabled, unalignedThreshold);
    }

    /**
     * Builds an execution plan from the given JobGraph with an explicit per-job
     * {@link IBufferPool}.
     *
     * <p>The supplied pool is shared by all local {@code ResultPartition} instances in
     * the returned plan, giving a single observable cross-partition global aggregate
     * bound for one execution. Each partition's per-partition capacity is resolved from
     * {@link EdgeConfig#getQueueCapacity()} (falling back to
     * {@link ResultPartition#DEFAULT_CAPACITY} when no {@code EdgeConfig} is available).
     *
     * <p>Pool ownership: the returned plan holds the pool reference via
     * {@link #getBufferPool()}; callers should {@link IBufferPool#close()} it (directly
     * or via {@link #closeBufferPool()}) when execution ends or the plan is abandoned on
     * recovery, so any producer blocked on global exhaustion is woken.
     *
     * @param jobGraph                the job graph to plan execution for
     * @param deploymentPlan          optional deployment plan (null uses default behavior)
     * @param barrierAlignment        if true, InputGates use barrier alignment
     * @param barrierAlignmentTimeout maximum time in ms for barrier alignment before timeout
     * @param bufferPool              the per-job buffer pool (must not be null)
     * @return the execution plan
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                           boolean barrierAlignment, long barrierAlignmentTimeout,
                                           IBufferPool bufferPool) {
        return build(jobGraph, deploymentPlan, barrierAlignment, barrierAlignmentTimeout, bufferPool,
                false, InputGate.DEFAULT_ALIGNMENT_TIMEOUT_MS);
    }

    /**
     * Stage 43: full build with explicit per-job {@link IBufferPool} AND aligned→
     * unaligned fallback configuration. This is the production entry point threaded
     * from {@code GraphModelCheckpointExecutor} via {@code CheckpointConfig}.
     */
    public static GraphExecutionPlan build(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                           boolean barrierAlignment, long barrierAlignmentTimeout,
                                           IBufferPool bufferPool,
                                           boolean unalignedCheckpointEnabled, long unalignedThreshold) {
        if (bufferPool == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "bufferPool");
        }

        // --- 0. Decompose the JobGraph into regions (Stage 44 successor 2) ---
        // Materialization-enabled edges are region cut points; non-materialization
        // edges connect vertices inside the same region. The resulting vertex→regionId
        // map is propagated into every Subtask so successor 3 (supervision loop) can
        // query a failing task's region. A graph with no materialization markers
        // decomposes into a single region (zero regression). An empty graph (zero
        // vertices, a valid edge case for GraphExecutionPlan.build) produces a null
        // decomposition — there is nothing to assign regions to.
        RegionDecomposition regionDecomposition = jobGraph.getNumberOfVertices() > 0
                ? jobGraph.decomposeRegions()
                : null;

        // --- 1. Build adjacency maps ---
        Map<String, List<JobEdge>> outgoingEdges = new HashMap<>();
        Map<String, List<JobEdge>> incomingEdges = new HashMap<>();
        for (JobEdge edge : jobGraph.getEdges()) {
            outgoingEdges.computeIfAbsent(edge.getSourceVertex(), k -> new ArrayList<>()).add(edge);
            incomingEdges.computeIfAbsent(edge.getTargetVertex(), k -> new ArrayList<>()).add(edge);
        }

        // --- 2. Resolve parallelism for each vertex ---
        Map<String, Integer> parallelismMap = resolveParallelism(jobGraph, deploymentPlan);

        // --- 3. Allocate partition matrix per edge ---
        // Key: edge -> [sourceSubtaskIndex][targetSubtaskIndex] = ResultPartition
        // Each partition is bound to the per-job pool so the cross-partition global
        // aggregate in-flight element count is bounded. Per-partition capacity comes
        // from EdgeConfig.queueCapacity (wired here), defaulting to DEFAULT_CAPACITY.
        //
        // Stage 44 successor 1 (materialization point mechanism, option B): when an
        // edge is explicitly marked materializationEnabled, an independently
        // addressable IMaterializationPoint is attached to every ResultPartition in
        // the matrix so the producer dual-writes (main queue + bypass store) and the
        // consumer can replay. Default-off → zero regression for existing jobs.
        Map<JobEdge, ResultPartition[][]> edgePartitionMatrix = new LinkedHashMap<>();
        for (JobEdge edge : jobGraph.getEdges()) {
            int srcP = parallelismMap.getOrDefault(edge.getSourceVertex(), 1);
            int tgtP = parallelismMap.getOrDefault(edge.getTargetVertex(), 1);
            EdgeConfig edgeConfig = resolveEdgeConfig(edge, deploymentPlan);
            int partitionCapacity = resolvePartitionCapacity(edgeConfig);
            boolean materialize = edge.isMaterializationEnabled();
            ResultPartition[][] matrix = new ResultPartition[srcP][tgtP];
            for (int s = 0; s < srcP; s++) {
                for (int t = 0; t < tgtP; t++) {
                    ResultPartition partition = new ResultPartition(partitionCapacity, bufferPool);
                    if (materialize) {
                        String pointId = edge.getSourceVertex() + "->" + edge.getTargetVertex()
                                + "[s=" + s + "][t=" + t + "]";
                        partition.setMaterializationPoint(
                                new InMemoryMaterializationPoint(pointId));
                    }
                    matrix[s][t] = partition;
                }
            }
            edgePartitionMatrix.put(edge, matrix);
        }

        // --- 4. Legacy single-task structures (for backward compat) ---
        Map<String, JobVertex> executionVertices = new LinkedHashMap<>();
        Map<String, StreamTaskInvokable> invokables = new LinkedHashMap<>();

        // --- 5. New subtask structures ---
        Map<String, List<Subtask>> subtasksMap = new LinkedHashMap<>();

        // --- 6. Build subtasks for each vertex ---
        for (Map.Entry<String, JobVertex> entry : jobGraph.getVertices().entrySet()) {
            String vertexId = entry.getKey();
            JobVertex original = entry.getValue();
            int parallelism = parallelismMap.getOrDefault(vertexId, 1);

            List<JobEdge> outEdges = outgoingEdges.getOrDefault(vertexId, Collections.emptyList());
            List<JobEdge> inEdges = incomingEdges.getOrDefault(vertexId, Collections.emptyList());

            List<Subtask> vertexSubtasks = new ArrayList<>(parallelism);

            for (int taskIndex = 0; taskIndex < parallelism; taskIndex++) {
                boolean needsCopy = parallelism > 1 || !outEdges.isEmpty() || !inEdges.isEmpty();
                OperatorChain chain = needsCopy
                        ? original.getOperatorChains().get(0).deepCopy()
                        : original.getOperatorChains().get(0);

                RecordWriter<Object> recordWriter = null;
                InputGate inputGate = null;
                List<RecordWriter<Object>> fanOutWriters = null;

                // Build RecordWriter: for each outgoing edge, collect the partitions
                // that this source subtask writes to (one per target subtask per edge)
                if (!outEdges.isEmpty()) {
                    if (outEdges.size() == 1) {
                        List<ResultPartition> writerPartitions = new ArrayList<>();
                        JobEdge edge = outEdges.get(0);
                        ResultPartition[][] matrix = edgePartitionMatrix.get(edge);
                        if (matrix != null) {
                            for (int t = 0; t < matrix[taskIndex].length; t++) {
                                writerPartitions.add(matrix[taskIndex][t]);
                            }
                        }

                        if (!writerPartitions.isEmpty()) {
                            PartitionPolicy policy = resolvePartitionPolicy(edge, deploymentPlan);
                            IPartitioner<?> partitioner = edge.getPartitioner();
                            EdgeConfig writerConfig = resolveEdgeConfig(edge, deploymentPlan);
                            PartitionRouter router = PartitionRouter.create(
                                    policy, writerPartitions.size(), partitioner, taskIndex);
                            recordWriter = new RecordWriter<Object>(
                                    writerPartitions.toArray(new ResultPartition[0]),
                                    (IPartitioner<Object>) partitioner, writerConfig, router);
                        }
                    } else {
                        fanOutWriters = new ArrayList<>();
                        for (JobEdge edge : outEdges) {
                            List<ResultPartition> edgePartitions = new ArrayList<>();
                            ResultPartition[][] matrix = edgePartitionMatrix.get(edge);
                            if (matrix != null) {
                                for (int t = 0; t < matrix[taskIndex].length; t++) {
                                    edgePartitions.add(matrix[taskIndex][t]);
                                }
                            }
                            if (!edgePartitions.isEmpty()) {
                                PartitionPolicy policy = resolvePartitionPolicy(edge, deploymentPlan);
                                IPartitioner<?> partitioner = edge.getPartitioner();
                                EdgeConfig writerConfig = resolveEdgeConfig(edge, deploymentPlan);
                                PartitionRouter router = PartitionRouter.create(
                                        policy, edgePartitions.size(), partitioner, taskIndex);
                                fanOutWriters.add(new RecordWriter<Object>(
                                        edgePartitions.toArray(new ResultPartition[0]),
                                        (IPartitioner<Object>) partitioner, writerConfig, router));
                            }
                        }
                    }
                }

                // Build InputGate: for each incoming edge, collect the partitions
                // from all source subtasks that feed into this target subtask
                if (!inEdges.isEmpty()) {
                    List<InputChannel> channels = new ArrayList<>();
                    for (JobEdge edge : inEdges) {
                        ResultPartition[][] matrix = edgePartitionMatrix.get(edge);
                        if (matrix != null) {
                            for (int s = 0; s < matrix.length; s++) {
                                channels.add(new InputChannel(matrix[s][taskIndex]));
                            }
                        }
                    }

                    if (!channels.isEmpty()) {
                        EdgeConfig gateConfig = resolveEdgeConfig(inEdges.get(0), deploymentPlan);
                        // Stage 43: thread aligned→unaligned fallback config into every
                        // multi-input InputGate so backpressure triggers unaligned mode.
                        inputGate = new InputGate(channels, gateConfig, barrierAlignment,
                                barrierAlignmentTimeout, unalignedCheckpointEnabled, unalignedThreshold);
                    }
                }

                StreamTaskInvokable invokable;
                if (fanOutWriters != null && !fanOutWriters.isEmpty()) {
                    if (inputGate != null) {
                        invokable = new StreamTaskInvokable(chain, fanOutWriters, inputGate);
                    } else {
                        invokable = new StreamTaskInvokable(chain, fanOutWriters);
                    }
                } else if (recordWriter != null || inputGate != null) {
                    invokable = new StreamTaskInvokable(chain, recordWriter, inputGate);
                } else {
                    invokable = new StreamTaskInvokable(chain);
                }

                TaskLocation taskLocation = new TaskLocation(
                        jobGraph.getJobName(), "pipeline-0", vertexId, taskIndex);

                // Stage 44 successor 2: propagate the vertex's region ID into the
                // subtask so the full chain JobGraph → GraphExecutionPlan → Subtask
                // → SubtaskTask is observable end-to-end.
                RegionId regionId = regionDecomposition.getRegionId(vertexId);
                Subtask subtask = new Subtask(vertexId, taskIndex, taskLocation, invokable, regionId);
                vertexSubtasks.add(subtask);

                // For backward compat: store the first subtask's invokable in the legacy map
                if (taskIndex == 0) {
                    invokables.put(vertexId, invokable);

                    JobVertex execVertex = new JobVertex(
                            original.getId(), original.getName(), original.getParallelism(),
                            original.getOperatorChains(), invokable);
                    executionVertices.put(vertexId, execVertex);
                }
            }

            subtasksMap.put(vertexId, vertexSubtasks);
        }

        List<String> sorted = topologicalSort(jobGraph);

        return new GraphExecutionPlan(sorted, executionVertices, invokables, subtasksMap,
                bufferPool, regionDecomposition);
    }

    /**
     * Resolves parallelism for each vertex. Checks the DeploymentPlan's PartitionedPlan first,
     * then falls back to the JobVertex's parallelism.
     */
    private static Map<String, Integer> resolveParallelism(JobGraph jobGraph,
                                                            DeploymentPlan deploymentPlan) {
        Map<String, Integer> result = new LinkedHashMap<>();
        Map<String, Integer> planParallelism = null;

        if (deploymentPlan != null && deploymentPlan.getPartitionedPlan() != null) {
            planParallelism = new HashMap<>();
            for (Map.Entry<String, PartitionedPlan.VertexPlan> entry :
                    deploymentPlan.getPartitionedPlan().getVertexPlans().entrySet()) {
                planParallelism.put(entry.getKey(), entry.getValue().getParallelism());
            }
        }

        for (Map.Entry<String, JobVertex> entry : jobGraph.getVertices().entrySet()) {
            String vertexId = entry.getKey();
            JobVertex vertex = entry.getValue();
            int parallelism = vertex.getParallelism();
            if (planParallelism != null && planParallelism.containsKey(vertexId)) {
                parallelism = planParallelism.get(vertexId);
            }
            // Honor the parallelism lock: a vertex marked parallelismLocked by
            // forceNonParallel() (e.g. CEP non-keyed entry) is forced to 1 regardless
            // of any DeploymentPlan/PartitionedPlan override.
            if (vertex.isParallelismLocked()) {
                parallelism = 1;
            }
            result.put(vertexId, Math.max(1, parallelism));
        }
        return result;
    }

    /**
     * Resolves the PartitionPolicy for a given JobEdge.
     *
     * <p>Checks the DeploymentPlan's PartitionedPlan edge plans first, then
     * resolves from the edge's partitioner via {@link PartitionPolicyAware}.
     * Falls back to FORWARD only when the partitioner is null. A non-null
     * partitioner that does not implement {@link PartitionPolicyAware} fails
     * fast — class-name substring matching was removed (silent mis-routing
     * bug AR-3).
     */
    private static PartitionPolicy resolvePartitionPolicy(JobEdge edge, DeploymentPlan deploymentPlan) {
        if (deploymentPlan != null && deploymentPlan.getPartitionedPlan() != null) {
            for (PartitionedPlan.EdgePlan edgePlan :
                    deploymentPlan.getPartitionedPlan().getEdgePlans()) {
                if (edgePlan.getSourceVertexId().equals(edge.getSourceVertex())
                        && edgePlan.getTargetVertexId().equals(edge.getTargetVertex())) {
                    return edgePlan.getPartitionPolicy();
                }
            }
        }
        if (edge.getPartitioner() == null) {
            return PartitionPolicy.FORWARD;
        }
        if (edge.getPartitioner() instanceof PartitionPolicyAware) {
            return ((PartitionPolicyAware) edge.getPartitioner()).getPartitionPolicy();
        }
        // Fail-fast: do not silently classify by class-name substring matching
        // (removed: silent mis-routing bug AR-3). Partitioner must implement
        // PartitionPolicyAware to declare its policy.
        throw new StreamException(ERR_STREAM_INVALID_STATE)
                .param(ARG_DETAIL,
                        "Partitioner on edge " + edge.getSourceVertex() + "->"
                                + edge.getTargetVertex()
                                + " does not implement PartitionPolicyAware. "
                                + "Partition policy cannot be inferred by class-name matching "
                                + "(removed: silent mis-routing bug AR-3). Have the partitioner "
                                + "implement PartitionPolicyAware#getPartitionPolicy() to declare "
                                + "its policy.");
    }

    /**
     * Resolves the EdgeConfig for a given JobEdge.
     *
     * <p>First checks if the JobEdge already has an EdgeConfig set (e.g., from JobGraphGenerator).
     * If not, looks up the edge key in the DeploymentPlan's edgeConfigs map.
     * The edge key is formatted as "sourceVertex->targetVertex".
     *
     * @param edge           the JobEdge to resolve config for
     * @param deploymentPlan optional deployment plan containing edge configurations
     * @return the resolved EdgeConfig, or null if none available
     */
    private static EdgeConfig resolveEdgeConfig(JobEdge edge, DeploymentPlan deploymentPlan) {
        // Priority 1: EdgeConfig already set on the JobEdge itself
        if (edge.getEdgeConfig() != null) {
            return edge.getEdgeConfig();
        }
        // Priority 2: Look up in DeploymentPlan's edgeConfigs map
        if (deploymentPlan != null) {
            String edgeKey = edge.getSourceVertex() + "->" + edge.getTargetVertex();
            return deploymentPlan.getEdgeConfigs().get(edgeKey);
        }
        return null;
    }

    /**
     * Resolves the per-partition queue capacity (in element count) from the
     * {@link EdgeConfig}. Falls back to {@link ResultPartition#DEFAULT_CAPACITY} when
     * no {@code EdgeConfig} is available or {@code queueCapacity} is not positive.
     *
     * <p>This is the wiring point for the previously-unconnected
     * {@code EdgeConfig.queueCapacity} declaration.
     */
    private static int resolvePartitionCapacity(EdgeConfig edgeConfig) {
        if (edgeConfig != null && edgeConfig.getQueueCapacity() > 0) {
            return edgeConfig.getQueueCapacity();
        }
        return ResultPartition.DEFAULT_CAPACITY;
    }

    /**
     * Topological sort using Kahn's algorithm. Sources (no incoming edges)
     * come first, sinks (no outgoing edges) come last.
     */
    private static List<String> topologicalSort(JobGraph jobGraph) {
        Map<String, List<String>> adjacency = new HashMap<>();
        Map<String, Integer> inDegree = new HashMap<>();

        for (String vertexId : jobGraph.getVertices().keySet()) {
            adjacency.put(vertexId, new ArrayList<>());
            inDegree.put(vertexId, 0);
        }

        for (JobEdge edge : jobGraph.getEdges()) {
            adjacency.get(edge.getSourceVertex()).add(edge.getTargetVertex());
            inDegree.merge(edge.getTargetVertex(), 1, Integer::sum);
        }

        Queue<String> queue = new LinkedList<>();
        for (Map.Entry<String, Integer> entry : inDegree.entrySet()) {
            if (entry.getValue() == 0) {
                queue.add(entry.getKey());
            }
        }

        List<String> sorted = new ArrayList<>();
        while (!queue.isEmpty()) {
            String vertexId = queue.poll();
            sorted.add(vertexId);
            for (String neighbor : adjacency.get(vertexId)) {
                int newDegree = inDegree.get(neighbor) - 1;
                inDegree.put(neighbor, newDegree);
                if (newDegree == 0) {
                    queue.add(neighbor);
                }
            }
        }

        if (sorted.size() != jobGraph.getVertices().size()) {
            Set<String> allVertexIds = jobGraph.getVertices().keySet();
            Set<String> sortedSet = new HashSet<>(sorted);
            Set<String> missing = new HashSet<>(allVertexIds);
            missing.removeAll(sortedSet);
            throw new StreamException(ERR_STREAM_CYCLIC_JOB_GRAPH)
                    .param(ARG_DETAIL, "Cycle detected involving: " + missing);
        }

        return sorted;
    }

    public List<String> getSortedVertexIds() {
        return sortedVertexIds;
    }

    public Map<String, JobVertex> getExecutionVertices() {
        return executionVertices;
    }

    public Map<String, StreamTaskInvokable> getInvokables() {
        return invokables;
    }

    /**
     * Returns all subtasks indexed by vertexId.
     * Each vertex maps to a list of Subtask instances, one per parallelism unit.
     *
     * @return unmodifiable map of vertexId to list of subtasks
     */
    public Map<String, List<Subtask>> getSubtasks() {
        return Collections.unmodifiableMap(subtasks);
    }

    /**
     * Returns the subtasks for a specific vertex.
     *
     * @param vertexId the vertex ID
     * @return list of subtasks for the vertex, or empty list if vertex not found
     */
    public List<Subtask> getSubtasks(String vertexId) {
        return subtasks.getOrDefault(vertexId, Collections.emptyList());
    }

    /**
     * Returns the per-job buffer pool shared by all local {@code ResultPartition}
     * instances in this plan, or {@code null} for plans built via {@link #create(...)}
     * that intentionally do not use a pool (e.g. distributed runtime with remote
     * partitions).
     *
     * @return the per-job pool, or {@code null}
     */
    public IBufferPool getBufferPool() {
        return bufferPool;
    }

    /**
     * Closes the per-job buffer pool, waking any producer blocked on global exhaustion.
     * Safe to call when the pool is {@code null} (no-op) or already closed (idempotent).
     *
     * <p>Should be invoked when execution ends (normal or exceptional) or when the plan
     * is abandoned on checkpoint recovery so that blocked producers are released and a
     * fresh pool is created for the recovery attempt.
     */
    public void closeBufferPool() {
        if (bufferPool != null) {
            bufferPool.close();
        }
    }

    /**
     * Returns the region decomposition of the source {@link JobGraph} (Stage 44
     * successor plan 2: region identification).
     *
     * <p>For plans built via {@link #build}, this is the full decomposition
     * (every vertex is mapped to a region; materialization-enabled edges are
     * region cut points). For plans built via {@link #create} (runtime builders
     * without a JobGraph), this returns {@code null}.
     *
     * @return the region decomposition, or {@code null} if the plan was not
     *         built from a JobGraph
     * @see io.nop.stream.core.jobgraph.region.RegionDecomposition
     */
    public RegionDecomposition getRegionDecomposition() {
        return regionDecomposition;
    }

    /**
     * Returns the region ID of the specified vertex (Stage 44 successor plan 2).
     *
     * <p>This is a convenience accessor equivalent to
     * {@code getRegionDecomposition().getRegionId(vertexId)} when the
     * decomposition is non-null.
     *
     * @param vertexId the vertex ID to look up
     * @return the region ID, or {@code null} if the plan has no decomposition
     *         or the vertex is unknown
     */
    public RegionId getRegionId(String vertexId) {
        return regionDecomposition != null ? regionDecomposition.getRegionId(vertexId) : null;
    }
}
