/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.graph;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.nop.api.core.annotations.core.Internal;

import io.nop.stream.core.checkpoint.participant.CheckpointParticipant;
import io.nop.stream.core.common.functions.KeySelector;
import io.nop.stream.core.common.functions.SinkFunction;
import io.nop.stream.core.common.functions.sink.TwoPhaseCommitSinkFunction;
import io.nop.stream.core.common.functions.source.SourceFunction;
import io.nop.stream.core.common.typeinfo.TypeInformation;
import io.nop.stream.core.model.StreamComponents;
import io.nop.stream.core.model.StreamModel;
import io.nop.stream.core.model.StreamRequirement;
import io.nop.stream.core.operators.SimpleStreamOperatorFactory;
import io.nop.stream.core.operators.SourceReaderOperator;
import io.nop.stream.core.operators.StreamOperator;
import io.nop.stream.core.operators.StreamOperatorFactory;
import io.nop.stream.core.operators.StreamSinkOperator;
import io.nop.stream.core.operators.StreamSourceOperator;
import io.nop.stream.core.operators.TimestampsAndWatermarksOperator;
import io.nop.stream.core.source.Source;
import io.nop.stream.core.transformation.OneInputTransformation;
import io.nop.stream.core.transformation.PartitionTransformation;
import io.nop.stream.core.transformation.SinkTransformation;
import io.nop.stream.core.transformation.SourceApiTransformation;
import io.nop.stream.core.transformation.SourceTransformation;
import io.nop.stream.core.transformation.TimestampsAndWatermarksTransformation;
import io.nop.stream.core.transformation.Transformation;
import io.nop.stream.core.exceptions.StreamException;

import io.nop.stream.core.exceptions.NopStreamErrors;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATION;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_PARALLELISM;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_SINK_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_2PC_SINK_PARALLELISM_NOT_SUPPORTED;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED;

/**
 * Converts a chain of Transformation objects into a StreamGraph representation.
 * 
 * <p>The StreamGraphGenerator traverses the transformation DAG and creates the corresponding
 * StreamNode and StreamEdge objects that form the executable streaming topology. This class
 * implements a visitor pattern using instanceof checks to dispatch to the appropriate
 * transformation handler methods.
 * 
 * <p>The generator processes transformations recursively, ensuring that input transformations
 * are processed before their dependents, building the graph from sources to sinks.
 * 
 * <p>Supported transformation types:
 * <ul>
 *   <li>{@link SourceTransformation}: Creates source nodes with no inputs</li>
 *   <li>{@link OneInputTransformation}: Creates operator nodes with one input edge</li>
 *   <li>{@link SinkTransformation}: Creates sink nodes with one input edge</li>
 *   <li>{@link PartitionTransformation}: Creates partitioning nodes with partitioner edges</li>
 * </ul>
 * 
 * <p>The generator tracks which transformations have already been processed to avoid
 * duplicating nodes in the graph when the same transformation is referenced multiple times.
 * 
 * @see StreamGraph
 * @see StreamNode
 * @see StreamEdge
 * @see Transformation
 *
 * <p>Graph Path 编译管线第一阶段：Transformation DAG → StreamGraph
 */
@Internal
public class StreamGraphGenerator {
    
    /**
     * The stream graph being constructed.
     */
    private final StreamGraph streamGraph;
    
    private final Set<Integer> processedTransformations;
    
    private final Map<Integer, KeySelector<?, ?>> partitionKeySelectors = new HashMap<>();
    
    /**
     * Creates a new StreamGraphGenerator with an empty graph.
     */
    public StreamGraphGenerator() {
        this.streamGraph = new StreamGraph();
        this.processedTransformations = new HashSet<>();
    }
    
    /**
     * Generates a StreamGraph from a list of sink transformations.
     * 
     * <p>This method processes each transformation in the list, which typically represents
     * the sink nodes of a streaming topology. The processing is recursive, so all upstream
     * transformations will be processed as well.
     * 
     * @param transformations the list of transformations to process (typically sink transformations)
     * @return the constructed StreamGraph
     * @throws IllegalArgumentException if transformations is null
     */
    public StreamGraph generate(List<Transformation<?>> transformations) {
        if (transformations == null) {
            throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "transformations");
        }

        for (Transformation<?> transformation : transformations) {
            transform(transformation);
        }

        propagateKeySelectors();

        populateStreamModel(transformations);

        return streamGraph;
    }

    private void populateStreamModel(List<Transformation<?>> transformations) {
        StreamComponents components = new StreamComponents();
        Map<String, Transformation<?>> transformMap = new HashMap<>();
        for (Transformation<?> t : transformations) {
            collectTransforms(t, transformMap);
        }
        populateComponents(components, transformMap);
        registerStreams(components);
        detectWindowingStrategies(components, transformMap);
        StreamModel model = new StreamModel(components, transformMap);
        streamGraph.setStreamModel(model);
    }

    private void collectTransforms(Transformation<?> t, Map<String, Transformation<?>> map) {
        if (t == null || map.containsKey(String.valueOf(t.getId()))) return;
        map.put(String.valueOf(t.getId()), t);
        if (t.getInputs() != null) {
            for (Transformation<?> input : t.getInputs()) {
                collectTransforms(input, map);
            }
        }
    }

    private void populateComponents(StreamComponents components, Map<String, Transformation<?>> transformMap) {
        for (Map.Entry<String, Transformation<?>> entry : transformMap.entrySet()) {
            String id = entry.getKey();
            Transformation<?> t = entry.getValue();
            components.registerTransform(id, t);
            if (t instanceof SinkTransformation) {
                SinkFunction<?> sinkFn = ((SinkTransformation<?>) t).getSinkFunction();
                if (sinkFn instanceof CheckpointParticipant) {
                    components.addCheckpointParticipant(id);
                }
            }
        }
        detectRequirements(components, transformMap);
    }

    private void registerStreams(StreamComponents components) {
        for (Map.Entry<Integer, List<StreamEdge>> entry : streamGraph.getAllStreamEdges().entrySet()) {
            int sourceId = entry.getKey();
            for (StreamEdge edge : entry.getValue()) {
                String streamId = sourceId + "->" + edge.getTargetId();
                components.registerStream(streamId, edge);
            }
        }
    }

    private void detectWindowingStrategies(StreamComponents components, Map<String, Transformation<?>> transformMap) {
        // P1-1: Previously this method stored StreamOperatorFactory<?> into the
        // windowingStrategies registry, which was a type mismatch — the registry is
        // typed Map<String, WindowingStrategy> and WindowingStrategy is a serializable
        // config bean, not a factory. No code path reads this registry at runtime
        // (WindowedStreamImpl.getBean is never called in production), so the writes
        // were dead and type-unsafe. WindowingStrategy objects should be registered
        // explicitly via registerWindowingStrategy when they exist; factory detection
        // belongs to the graph/jobgraph layers, not the components registry.
    }

    private void detectRequirements(StreamComponents components, Map<String, Transformation<?>> transformMap) {
        for (Transformation<?> t : transformMap.values()) {
            if (t instanceof SinkTransformation) {
                SinkFunction<?> sinkFn = ((SinkTransformation<?>) t).getSinkFunction();
                if (sinkFn instanceof io.nop.stream.core.common.functions.sink.TwoPhaseCommitSinkFunction) {
                    components.addRequirement(StreamRequirement.TWO_PHASE_COMMIT_SINK);
                }
            }
        }
        components.addRequirement(StreamRequirement.DISTRIBUTED_EXECUTION);
    }
    
    /**
     * Transforms a single transformation into its graph representation.
     * 
     * <p>This method dispatches to the appropriate handler based on the transformation type.
     * It also ensures that each transformation is only processed once by tracking processed IDs.
     * 
     * @param transformation the transformation to process
     */
    private void transform(Transformation<?> transformation) {
        if (transformation == null) {
            return;
        }
        
        // Skip if already processed
        if (processedTransformations.contains(transformation.getId())) {
            return;
        }
        processedTransformations.add(transformation.getId());
        
        // Dispatch to appropriate handler based on transformation type
        if (transformation instanceof SourceTransformation) {
            transformSource((SourceTransformation<?>) transformation);
        } else if (transformation instanceof SourceApiTransformation) {
            transformSourceApi((SourceApiTransformation<?>) transformation);
        } else if (transformation instanceof OneInputTransformation) {
            transformOneInput((OneInputTransformation<?, ?>) transformation);
        } else if (transformation instanceof SinkTransformation) {
            transformSink((SinkTransformation<?>) transformation);
        } else if (transformation instanceof PartitionTransformation) {
            transformPartition((PartitionTransformation<?>) transformation);
        } else if (transformation instanceof TimestampsAndWatermarksTransformation) {
            transformTimestampsAndWatermarks((TimestampsAndWatermarksTransformation<?>) transformation);
        } else {
            throw new StreamException(ERR_STREAM_UNSUPPORTED).param(ARG_OPERATION, "transform " + transformation.getClass().getName());
        }
    }
    
    /**
     * Transforms a SourceTransformation into a StreamNode.
     * 
     * <p>Source transformations are leaf nodes in the DAG with no inputs. They represent
     * data sources like Kafka topics, files, or socket connections. The created node
     * uses a SourceOperatorFactory to wrap the SourceFunction.
     * 
     * @param transformation the source transformation to process
     * @param <OUT> the output type of the source
     */
    private <OUT> void transformSource(SourceTransformation<OUT> transformation) {
        // Create operator factory wrapper for the source function
        StreamOperatorFactory<OUT> operatorFactory = 
            new SourceOperatorFactory<>(transformation.getSourceFunction());
        
        // Create the stream node for this source
        StreamNode node = new StreamNode(
            transformation.getId(),
            transformation.getName(),
            operatorFactory,
            transformation.getOutputType(),
            resolveParallelism(transformation)
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(operatorFactory.getChainingStrategy());
        
        // Add node to graph and mark as source
        streamGraph.addStreamNode(node);
        streamGraph.addSourceID(node.getId());
    }

    /**
     * Stage 49 D5: transforms a {@link SourceApiTransformation} into a StreamNode driven by
     * a {@link SourceReaderOperatorFactory}. Sources are leaf nodes (no inputs) and use
     * the FLIP-27 style pull-based {@code SourceReader.pollNext()} execution model.
     *
     * @param transformation the source-api transformation
     * @param <OUT> the output type of the source
     */
    private <OUT> void transformSourceApi(SourceApiTransformation<OUT> transformation) {
        StreamOperatorFactory<OUT> operatorFactory =
                new SourceReaderOperatorFactory<>(transformation.getSource(), transformation.getId());

        StreamNode node = new StreamNode(
                transformation.getId(),
                transformation.getName(),
                operatorFactory,
                transformation.getOutputType(),
                resolveParallelism(transformation)
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(operatorFactory.getChainingStrategy());

        streamGraph.addStreamNode(node);
        streamGraph.addSourceID(node.getId());
    }
    
    /**
     * Transforms a OneInputTransformation into a StreamNode and StreamEdge.
     * 
     * <p>One-input transformations represent operations like map, filter, flatMap, etc.
     * They have exactly one input transformation and produce one output stream.
     * 
     * <p>The method:
     * <ol>
     *   <li>Recursively processes the input transformation</li>
     *   <li>Creates a StreamNode for this transformation</li>
     *   <li>Creates a StreamEdge connecting the input to this node</li>
     * </ol>
     * 
     * @param transformation the one-input transformation to process
     * @param <IN> the input type
     * @param <OUT> the output type
     */
    private <IN, OUT> void transformOneInput(OneInputTransformation<IN, OUT> transformation) {
        // 1. Recursively process the input transformation
        transform(transformation.getInput());
        
        // 2. Create the StreamNode for this transformation
        StreamNode node = new StreamNode(
            transformation.getId(),
            transformation.getName(),
            transformation.getOperatorFactory(),
            transformation.getOutputType(),
            resolveParallelism(transformation)
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(transformation.getOperatorFactory().getChainingStrategy());
        
        // Set key selector if present
        if (transformation.getKeySelector() != null) {
            node.setKeySelector(transformation.getKeySelector());
        }
        
        // Add node to graph
        streamGraph.addStreamNode(node);
        
        // 3. Create the StreamEdge connecting input to this node
        StreamEdge edge = new StreamEdge(
            transformation.getInput().getId(),
            node.getId()
        );
        // Use null partitioner for forward partitioning (same parallel instance)
        
        streamGraph.addStreamEdge(edge);
    }
    
    /**
     * Transforms a SinkTransformation into a StreamNode and StreamEdge.
     * 
     * <p>Sink transformations are terminal operations that consume elements from a stream
     * and send them to an external system. They have one input and no outputs.
     * 
     * <p>The method:
     * <ol>
     *   <li>Recursively processes the input transformation</li>
     *   <li>Creates a StreamNode for this sink using a SinkOperatorFactory</li>
     *   <li>Creates a StreamEdge connecting the input to this sink node</li>
     *   <li>Registers the node as a sink in the graph</li>
     * </ol>
     * 
     * @param transformation the sink transformation to process
     * @param <T> the input type consumed by the sink
     */
    private <T> void transformSink(SinkTransformation<T> transformation) {
        // 1. Recursively process the input transformation
        transform(transformation.getInput());

        // 2. Create operator factory wrapper for the sink function
        SinkFunction<T> sinkFunction = transformation.getSinkFunction();
        int effectiveParallelism = resolveParallelism(transformation);

        // Fail-fast gate (CONN-01 P1): reject a 2PC sink at effective parallelism > 1.
        // The built-in 2PC sinks silently lose data at parallelism > 1 because the
        // idempotency guard keys on epochId only and the UDF is shared across subtasks.
        // See checkpoint-design.md §6.4.1 for the deferral rationale and successor.
        if (sinkFunction instanceof TwoPhaseCommitSinkFunction && effectiveParallelism > 1) {
            throw new StreamException(ERR_STREAM_2PC_SINK_PARALLELISM_NOT_SUPPORTED)
                    .param(ARG_SINK_NAME, transformation.getName())
                    .param(ARG_PARALLELISM, effectiveParallelism);
        }

        StreamOperatorFactory<Void> operatorFactory =
            new SinkOperatorFactory<>(sinkFunction);
        
        // Create the stream node for this sink
        StreamNode node = new StreamNode(
            transformation.getId(),
            transformation.getName(),
            operatorFactory,
            transformation.getOutputType(),
            effectiveParallelism
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(operatorFactory.getChainingStrategy());
        
        // Add node to graph
        streamGraph.addStreamNode(node);
        
        // 3. Create the StreamEdge connecting input to this sink
        StreamEdge edge = new StreamEdge(
            transformation.getInput().getId(),
            node.getId()
        );
        
        streamGraph.addStreamEdge(edge);
        
        // 4. Register as sink
        streamGraph.addSinkID(node.getId());
    }
    
    /**
     * Transforms a PartitionTransformation into a StreamNode and StreamEdge with partitioner.
     * 
     * <p>Partition transformations are logical transformations that define how data should
     * be distributed across parallel instances. They are typically created by operations
     * like keyBy, rebalance, or rescale.
     * 
     * <p>The method:
     * <ol>
     *   <li>Recursively processes the input transformation</li>
     *   <li>Creates a StreamNode for this partition transformation</li>
     *   <li>Creates a StreamEdge with the partitioner from the transformation</li>
     * </ol>
     * 
     * @param transformation the partition transformation to process
     * @param <T> the element type
     */
    private <T> void transformPartition(PartitionTransformation<T> transformation) {
        transform(transformation.getInput());
        
        StreamOperatorFactory<T> partitionFactory = new PartitionOperatorFactory<>();
        StreamNode node = new StreamNode(
            transformation.getId(),
            transformation.getName(),
            partitionFactory,
            transformation.getOutputType(),
            resolveParallelism(transformation)
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(partitionFactory.getChainingStrategy());
        
        streamGraph.addStreamNode(node);
        
        if (transformation.getKeySelector() != null) {
            partitionKeySelectors.put(node.getId(), transformation.getKeySelector());
        }
        
        StreamEdge edge = new StreamEdge(
            transformation.getInput().getId(),
            node.getId()
        );
        edge.setPartitioner(transformation.getPartitioner());
        
        streamGraph.addStreamEdge(edge);
    }

    private <T> void transformTimestampsAndWatermarks(TimestampsAndWatermarksTransformation<T> transformation) {
        transform(transformation.getInput());

        TimestampsAndWatermarksOperator<T> operator =
            new TimestampsAndWatermarksOperator<>(transformation.getWatermarkStrategy(), transformation.getWatermarkInterval());
        StreamOperatorFactory<T> operatorFactory =
            new SimpleStreamOperatorFactory<>(operator, transformation.getName(), resolveParallelism(transformation));

        StreamNode node = new StreamNode(
            transformation.getId(),
            transformation.getName(),
            operatorFactory,
            transformation.getOutputType(),
            resolveParallelism(transformation)
        );
        applyParallelismLock(node, transformation);
        node.setChainingStrategy(operatorFactory.getChainingStrategy());

        streamGraph.addStreamNode(node);

        StreamEdge edge = new StreamEdge(
            transformation.getInput().getId(),
            node.getId()
        );

        streamGraph.addStreamEdge(edge);
    }

    /**
     * Resolves the effective parallelism for a StreamNode created from the
     * given Transformation. When the Transformation has been locked to
     * parallel-1 via {@code forceNonParallel()}, the node is forced to 1
     * regardless of the Transformation's configured parallelism.
     */
    private static int resolveParallelism(Transformation<?> transformation) {
        if (transformation.isParallelismLocked()) {
            return 1;
        }
        return transformation.getParallelism();
    }

    /**
     * Propagates the parallelism lock from Transformation to StreamNode when
     * the transformation has been locked via {@code forceNonParallel()}.
     */
    private static void applyParallelismLock(StreamNode node, Transformation<?> transformation) {
        if (transformation.isParallelismLocked()) {
            node.setParallelismLocked(true);
        }
    }

    private void propagateKeySelectors() {
        if (partitionKeySelectors.isEmpty()) {
            return;
        }
        for (Map.Entry<Integer, List<StreamEdge>> entry : streamGraph.getAllStreamEdges().entrySet()) {
            int sourceId = entry.getKey();
            if (!partitionKeySelectors.containsKey(sourceId)) {
                continue;
            }
            KeySelector<?, ?> keySelector = partitionKeySelectors.get(sourceId);
            for (StreamEdge edge : entry.getValue()) {
                StreamNode target = streamGraph.getStreamNode(edge.getTargetId());
                if (target != null && target.getKeySelector() == null) {
                    target.setKeySelector(keySelector);
                }
            }
        }
    }

    // ===== Inner classes for operator factory wrappers =====
    
    /**
     * Operator factory wrapper for SourceFunction.
     * 
     * <p>This factory creates operators that wrap source functions for execution.
     * The actual execution logic is handled by the streaming runtime.
     * 
     * @param <OUT> the output type of the source
     */
    private static class SourceOperatorFactory<OUT> implements StreamOperatorFactory<OUT>, Serializable {
        
        private static final long serialVersionUID = 1L;
        
        private final SourceFunction<OUT> sourceFunction;
        
        public SourceOperatorFactory(SourceFunction<OUT> sourceFunction) {
            this.sourceFunction = sourceFunction;
        }
        
        public SourceFunction<OUT> getSourceFunction() {
            return sourceFunction;
        }
        
        @Override
        public StreamOperator<OUT> createStreamOperator(TypeInformation<OUT> outputType) {
            return new StreamSourceOperator<>(sourceFunction);
        }
        
        @Override
        public int getParallelism() {
            return 1;
        }
        
        @Override
        public String getName() {
            return "Source";
        }
    }

    /**
     * Stage 49 D5: factory for {@link SourceReaderOperator} (FLIP-27 style source).
     *
     * <p>The factory carries the {@link io.nop.stream.core.source.Source} descriptor. The
     * live reader + coordinator channel (assignment proxy) are wired by the runtime that
     * owns the target subtask — for LOCAL mode this is the in-process
     * {@code LocalSourceCoordinator} registered by {@code StreamExecutionEnvironment}.
     */
    private static class SourceReaderOperatorFactory<OUT> implements StreamOperatorFactory<OUT>, Serializable {

        private static final long serialVersionUID = 1L;

        private final Source<OUT, ? extends io.nop.stream.core.source.SourceSplit, ?> source;
        private final int vertexId;

        public SourceReaderOperatorFactory(Source<OUT, ? extends io.nop.stream.core.source.SourceSplit, ?> source,
                                           int vertexId) {
            this.source = source;
            this.vertexId = vertexId;
        }

        public Source<OUT, ? extends io.nop.stream.core.source.SourceSplit, ?> getSource() {
            return source;
        }

        public int getVertexId() {
            return vertexId;
        }

        @Override
        public StreamOperator<OUT> createStreamOperator(TypeInformation<OUT> outputType) {
            // The LOCAL execution path overrides per-subtask identity
            // (subtaskIndex, totalParallelism) before run() via setSubtaskIdentity().
            return new SourceReaderOperator<>(source, vertexId);
        }

        @Override
        public int getParallelism() {
            return 1;
        }

        @Override
        public String getName() {
            return "SourceReader";
        }
    }
    
    /**
     * Operator factory wrapper for SinkFunction.
     * 
     * <p>This factory creates operators that wrap sink functions for execution.
     * The actual sink execution is handled by the streaming runtime.
     * 
     * @param <T> the input type consumed by the sink
     */
    private static class SinkOperatorFactory<T> implements StreamOperatorFactory<Void>, Serializable {
        
        private static final long serialVersionUID = 1L;
        
        private final SinkFunction<T> sinkFunction;
        
        public SinkOperatorFactory(SinkFunction<T> sinkFunction) {
            this.sinkFunction = sinkFunction;
        }
        
        public SinkFunction<T> getSinkFunction() {
            return sinkFunction;
        }
        
        @Override
        public StreamOperator<Void> createStreamOperator(TypeInformation<Void> outputType) {
            return new StreamSinkOperator<>(sinkFunction);
        }
        
        @Override
        public int getParallelism() {
            return 1;
        }
        
        @Override
        public String getName() {
            return "Sink";
        }
    }
    
    /**
     * Placeholder operator factory for partition transformations.
     * 
     * <p>Partition transformations are logical and don't execute any operator.
     * They only affect how data is distributed between nodes.
     * 
     * @param <T> the element type
     */
    private static class PartitionOperatorFactory<T> implements StreamOperatorFactory<T>, Serializable {
        
        private static final long serialVersionUID = 1L;
        
        @Override
        public StreamOperator<T> createStreamOperator(TypeInformation<T> outputType) {
            // Partition transformations are logical - no actual operator
            return null;
        }
        
        @Override
        public int getParallelism() {
            return 1;
        }
        
        @Override
        public String getName() {
            return "Partition";
        }
    }
}
