/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.common.functions;

import io.nop.stream.core.common.functions.sink.SinkConsistencyCapability;

/**
 * A sink function that consumes elements from the stream.
 *
 * @param <T> The type of elements consumed by the sink
 */
public interface SinkFunction<T> extends StreamFunction {
    
    /**
     * Consumes the given element.
     *
     * @param value The element to consume
     * @throws Exception This method may throw exceptions
     */
    void consume(T value) throws Exception;

    /**
     * Returns the consistency capability of this sink.
     * Default is {@link SinkConsistencyCapability#AT_LEAST_ONCE}.
     * Connectors should override this to declare their actual capability.
     *
     * @return the sink consistency capability
     */
    default SinkConsistencyCapability getSinkConsistency() {
        return SinkConsistencyCapability.AT_LEAST_ONCE;
    }

    /**
     * Called when all data has been consumed and the sink should flush any buffered data.
     * Default implementation does nothing. Override to provide finish behavior.
     *
     * @throws Exception if finishing fails
     */
    default void finish() throws Exception {
    }
}
