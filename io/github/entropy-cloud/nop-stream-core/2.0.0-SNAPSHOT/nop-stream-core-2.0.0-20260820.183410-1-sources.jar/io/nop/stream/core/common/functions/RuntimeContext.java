/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.core.common.functions;

import io.nop.api.core.annotations.core.Internal;
import io.nop.stream.core.common.state.KeyedStateStore;
import io.nop.stream.core.time.TimerService;

/**
 * @Internal
 */
@Internal
public interface RuntimeContext {

    int getIndexOfThisSubtask();

    int getNumberOfParallelSubtasks();

    String getTaskName();

    default KeyedStateStore getKeyedStateStore() {
        throw new UnsupportedOperationException("Keyed state is only available on a keyed stream.");
    }

    default TimerService getTimerService() {
        throw new UnsupportedOperationException("Timers are only available on a keyed stream.");
    }
}
