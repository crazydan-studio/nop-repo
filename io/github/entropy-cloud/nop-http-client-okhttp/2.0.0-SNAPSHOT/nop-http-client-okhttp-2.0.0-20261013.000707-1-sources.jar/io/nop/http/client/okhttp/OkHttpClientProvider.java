/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.http.client.okhttp;

import io.nop.api.core.util.LogLevel;
import io.nop.commons.service.LifeCycleSupport;
import io.nop.http.api.client.HttpClientConfig;
import io.nop.http.api.client.IHttpClient;
import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OkHttpClientProvider extends LifeCycleSupport {
    static final Logger LOG = LoggerFactory.getLogger(OkHttpClientProvider.class);

    private HttpClientConfig config;
    private List<Interceptor> interceptors;

    private OkHttpClientImpl client;

    private HostnameVerifier hostnameVerifier;
    private X509TrustManager trustManager;

    public HostnameVerifier getHostnameVerifier() {
        return hostnameVerifier;
    }

    public void setHostnameVerifier(HostnameVerifier hostnameVerifier) {
        this.hostnameVerifier = hostnameVerifier;
    }

    public X509TrustManager getTrustManager() {
        return trustManager;
    }

    public void setTrustManager(X509TrustManager trustManager) {
        this.trustManager = trustManager;
    }

    public void setConfig(HttpClientConfig config) {
        this.config = config;
    }

    public HttpClientConfig getConfig() {
        return config;
    }

    public void setInterceptors(List<Interceptor> interceptors) {
        this.interceptors = interceptors;
    }

    public IHttpClient getClient() {
        return client;
    }

    @Override
    protected void doStart() {
        OkHttpClient okHttpClient = newBuilder().build();
        this.client = new OkHttpClientImpl(okHttpClient, config);
    }

    protected OkHttpClient.Builder newBuilder() {
        ConnectionPool pool = null;

        if (config.getMaxIdleTime() != null && config.getMaxIdleCount() > 0) {
            pool = new ConnectionPool(config.getMaxIdleCount(), config.getMaxIdleTime().toMillis(), TimeUnit.MILLISECONDS);
        }

        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        Dispatcher dispatcher = new Dispatcher();

        if (config.getMaxRequestsPerHost() > 0) {
            dispatcher.setMaxRequestsPerHost(config.getMaxRequestsPerHost());
        }

        if (config.getMaxConnTotal() > 0) {
            dispatcher.setMaxRequests(config.getMaxConnTotal());
        }

        builder.dispatcher(dispatcher);
        addSSLConfig(builder);


        if (config.getConnectTimeout() != null) {
            builder.connectTimeout(config.getConnectTimeout());
        }
        builder.retryOnConnectionFailure(config.isRetryOnConnectionFailure())
                .followRedirects(config.isFollowRedirects());
        if (pool != null) {
            builder.connectionPool(pool);
        }
        if (config.getReadTimeout() != null) {
            builder.readTimeout(config.getReadTimeout());
        }

        if (config.getWriteTimeout() != null) {
            builder.writeTimeout(config.getWriteTimeout());
        }

        if (config.getLogLevel() != null) {
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(String message) {
                    LogLevel.log(LOG, config.getLogLevel(), message);
                }
            });

            if (config.isLogBody()) {
                interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            } else {
                interceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);
            }
            builder.addInterceptor(interceptor);
        }

        builder.addInterceptor(new OkHttpTimeoutInterceptor());

        if (interceptors != null) {
            for (Interceptor interceptor : interceptors) {
                builder.addInterceptor(interceptor);
            }
        }

        return builder;
    }

    protected void addSSLConfig(OkHttpClient.Builder builder) {
        if (config.isUseSsl()) {
            try {
                X509TrustManager trustManager = this.trustManager != null ? this.trustManager
                        : new DisableValidationTrustManager(); //NOSONAR
                if (this.trustManager == null) {
                    // G12-13-01：trust-all 组件被“静默默认”安装曾是零告警路径——对齐
                    // CompositeX509TrustManager 的 F-N1-3 告警基线，安装点输出显著 WARN。
                    // 默认行为不变（plan 2283 Deferred 裁定：useSsl 默认语义统一为显式
                    // opt-in 留待本模块实际接线时处理，见 plan 2283 Deferred But Adjudicated）。
                    LOG.warn("nop.http.okhttp.trust-all-trust-manager-enabled: TLS certificate validation "
                            + "is DISABLED for this OkHttp client (use-ssl=true with no explicit X509TrustManager "
                            + "injected; the default DisableValidationTrustManager accepts ALL certificates). "
                            + "All outbound HTTPS traffic is exposed to man-in-the-middle attacks. Inject an "
                            + "explicit trust manager via OkHttpClientProvider.setTrustManager() to enable "
                            + "real certificate validation.");
                }
                TrustManager[] trustManagers = new TrustManager[]{trustManager};
                SSLContext sslContext = SSLContext.getInstance(config.getSslVersion());
                sslContext.init((KeyManager[]) null, trustManagers, new SecureRandom());
                SSLSocketFactory socketFactory = sslContext.getSocketFactory();
                builder.sslSocketFactory(socketFactory, trustManager);

                HostnameVerifier verifier = this.hostnameVerifier != null ? this.hostnameVerifier
                        : new TrustAllHostnames(); //NOSONAR
                if (this.hostnameVerifier == null) {
                    LOG.warn("nop.http.okhttp.trust-all-hostname-verifier-enabled: HTTPS hostname verification "
                            + "is DISABLED for this OkHttp client (use-ssl=true with no explicit HostnameVerifier "
                            + "injected; the default TrustAllHostnames accepts ANY hostname). Connections to "
                            + "spoofed endpoints are exposed to man-in-the-middle attacks. Inject an explicit "
                            + "verifier via OkHttpClientProvider.setHostnameVerifier() to enable real "
                            + "hostname validation.");
                }
                builder.hostnameVerifier(verifier);
            } catch (Exception e) {
                LOG.warn("nop.err.okhttp.setSocketFactory-fail", e);
            }
        }
    }

    @Override
    protected void doStop() {
        if (client != null) {
            client.stop();
        }
    }

    @SuppressWarnings("java:S5527")
    public static class TrustAllHostnames implements HostnameVerifier {
        public TrustAllHostnames() {
        }

        public boolean verify(String s, SSLSession sslSession) {
            return true;
        }
    }

    @SuppressWarnings({"java:S5527","java:S4830"})
    public static class DisableValidationTrustManager implements X509TrustManager {
        public DisableValidationTrustManager() {
        }

        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}
