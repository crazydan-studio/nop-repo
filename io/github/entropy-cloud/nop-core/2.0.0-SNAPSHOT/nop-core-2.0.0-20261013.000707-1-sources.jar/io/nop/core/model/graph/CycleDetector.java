/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.nop.core.model.graph;

import java.util.Set;

/**
 * Detects cycles in directed graphs.
 *
 * @param <V> Vertex type
 */
public class CycleDetector<V> {
    private final ITargetVertexView<V> graph;

    public CycleDetector(ITargetVertexView<V> graph) {
        this.graph = graph;
    }

    // 这个Set可能包含多余的节点，并不是最简化的循环链
    public Set<V> findCycles() {
        return new TopologicalOrderIterator(graph.vertexSet(), graph, false).findCycles();
    }
}