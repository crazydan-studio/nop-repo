package io.nop.ai.dao.entity;

import io.nop.api.core.annotations.biz.BizObjName;
import io.nop.ai.dao.entity._gen._NopAiRequirement;


@BizObjName("NopAiRequirement")
public class NopAiRequirement extends _NopAiRequirement{


}
