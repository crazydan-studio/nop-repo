package io.nop.ai.agent.security;

import io.nop.ai.agent.engine.AgentExecutionContext;

import java.io.File;
import java.util.Map;

/**
 * Layer 2 policy-extension contract: security-level resolution (design §5.1).
 * Given an action kind (a tool name / operation category such as
 * {@code fs.read}, {@code shell.exec}, {@code network.fetch}) and the auditable
 * {@link LevelHints}, the resolver returns the {@link SecurityLevel} for the
 * action.
 *
 * <p><b>Deterministic rule table</b> (design §5.1, no AI decision):
 *
 * <table>
 *   <tr><th>action_kind</th><th>Default level</th><th>Upgrade condition</th></tr>
 *   <tr><td>{@code fs.read}, {@code fs.list}, {@code fs.grep}</td><td>STANDARD</td><td>&mdash;</td></tr>
 *   <tr><td>{@code fs.write}, {@code fs.edit}, {@code patch.apply}</td><td>STANDARD</td><td>{@code writesOutsideWorkspace} &rarr; ELEVATED</td></tr>
 *   <tr><td>{@code shell.exec}, {@code code.exec}</td><td>STANDARD</td><td>{@code !trustedSource} &rarr; ELEVATED; {@code highImpact} &rarr; RESTRICTED</td></tr>
 *   <tr><td>{@code network.fetch}, {@code web.fetch}</td><td>STANDARD</td><td>{@code !trustedSource} &rarr; RESTRICTED</td></tr>
 *   <tr><td>other</td><td>STANDARD</td><td>{@code !trustedSource} &rarr; ELEVATED; {@code highImpact} &rarr; RESTRICTED</td></tr>
 * </table>
 *
 * <p><b>Default</b>: {@link DefaultSecurityLevelResolver} &mdash; a
 * trusted-by-default variant of the design §5.1 rule table (plan 200).
 * {@link NoOpSecurityLevelResolver} is retained as a public opt-in for
 * integrators who need the "all STANDARD" behavior.
 *
 * <p><b>Dispatch-path consultation</b>: this contract surface is landed now;
 * the actual consultation call in the ReAct / tool-dispatch path is deferred to
 * a successor plan (requires {@code AgentExecutionContext} channelKind/principal
 * fields + a {@link LevelHints} runtime-production chain). The NoOp default
 * makes the wiring transparent to runtime behaviour.
 *
 * <p>The {@link SecurityLevel} enum is reused from L2-14 (plan 172), where it
 * was defined because the {@link IPermissionMatrix} contract requires it as an
 * input parameter. This resolver is the producer of that value.
 *
 * <p>This interface also incorporates the {@code produce} method formerly on
 * {@code ILevelHintsProducer} (merged per plan 304 Phase 6). A single
 * implementation handles both hint production and level resolution, removing
 * the need for a separate producer interface.
 */
public interface ISecurityLevelResolver {

    /**
     * Resolve the security level for the given action kind and hints.
     *
     * @param actionKind the tool name / operation category (e.g. {@code fs.read},
     *                   {@code shell.exec}); may be {@code null} or unknown —
     *                   implementations should treat unknown kinds per the
     *                   design §5.1 "other" row
     * @param hints      the auditable boolean hints about the action; may be
     *                   {@code null} — implementations should treat a null hints
     *                   as {@link LevelHints#defaults()} (no risk signals)
     * @return the resolved security level; never {@code null}
     */
    SecurityLevel resolve(String actionKind, LevelHints hints);

    /**
     * Produce the {@link LevelHints} for a tool call. Given the tool name, the
     * tool-call arguments, the agent's working directory, and the execution
     * context, derives the auditable boolean hints consumed by
     * {@link #resolve(String, LevelHints)}.
     *
     * @param toolName  the tool name / operation category; may be {@code null} or unknown
     * @param arguments the tool-call arguments; may be {@code null} or empty
     * @param workDir   the agent's working directory, or {@code null} (JVM CWD is used as the base)
     * @param ctx       the execution context; may be {@code null}
     * @return the produced hints; never {@code null}
     */
    LevelHints produce(String toolName, Map<String, Object> arguments, File workDir, AgentExecutionContext ctx);
}
