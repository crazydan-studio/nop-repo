package io.nop.ai.agent.plan.model._gen;

import io.nop.commons.collections.KeyedList; //NOPMD NOSONAR - suppressed UnusedImports - Used for List Prop
import io.nop.core.lang.json.IJsonHandler;
import io.nop.ai.agent.plan.model.AgentPlanPhase;
import io.nop.commons.util.ClassHelper;



// tell cpd to start ignoring code - CPD-OFF
/**
 * generate from /nop/schema/ai/agent-plan.xdef <p>
 * 每个阶段包含多个任务，任务支持递归子任务
 */
@SuppressWarnings({"PMD.UselessOverridingMethod","PMD.UnusedLocalVariable",
    "PMD.UnnecessaryFullyQualifiedName","PMD.EmptyControlStatement","java:S116","java:S101","java:S1128","java:S1161"})
public abstract class _AgentPlanPhase extends io.nop.core.resource.component.AbstractComponentModel {
    
    /**
     *  
     * xml name: completedAt
     * 
     */
    private java.time.LocalDateTime _completedAt ;
    
    /**
     *  
     * xml name: description
     * 阶段描述（大文本）
     */
    private java.lang.String _description ;
    
    /**
     *  
     * xml name: exitCriteria
     * 
     */
    private KeyedList<io.nop.ai.agent.plan.model.AgentPlanCriterion> _exitCriteria = KeyedList.emptyList();
    
    /**
     *  
     * xml name: gate
     * 阶段验收门控（design §14.1）：不满足时按 on-fail 动作处理
     */
    private io.nop.ai.agent.plan.model.AgentPlanGate _gate ;
    
    /**
     *  
     * xml name: kind
     * 
     */
    private java.lang.String _kind ;
    
    /**
     *  
     * xml name: name
     * 
     */
    private java.lang.String _name ;
    
    /**
     *  
     * xml name: startedAt
     * 
     */
    private java.time.LocalDateTime _startedAt ;
    
    /**
     *  
     * xml name: status
     * 
     */
    private io.nop.ai.agent.model.AgentExecStatus _status ;
    
    /**
     *  
     * xml name: targets
     * 
     */
    private KeyedList<io.nop.ai.agent.plan.model.AgentPlanTarget> _targets = KeyedList.emptyList();
    
    /**
     *  
     * xml name: tasks
     * 阶段任务列表：支持递归子任务
     */
    private KeyedList<io.nop.ai.agent.plan.model.AgentPlanTaskModel> _tasks = KeyedList.emptyList();
    
    /**
     * 
     * xml name: completedAt
     *  
     */
    
    public java.time.LocalDateTime getCompletedAt(){
      return _completedAt;
    }

    
    public void setCompletedAt(java.time.LocalDateTime value){
        checkAllowChange();
        
        this._completedAt = value;
           
    }

    
    /**
     * 
     * xml name: description
     *  阶段描述（大文本）
     */
    
    public java.lang.String getDescription(){
      return _description;
    }

    
    public void setDescription(java.lang.String value){
        checkAllowChange();
        
        this._description = value;
           
    }

    
    /**
     * 
     * xml name: exitCriteria
     *  
     */
    
    public java.util.List<io.nop.ai.agent.plan.model.AgentPlanCriterion> getExitCriteria(){
      return _exitCriteria;
    }

    
    public void setExitCriteria(java.util.List<io.nop.ai.agent.plan.model.AgentPlanCriterion> value){
        checkAllowChange();
        
        this._exitCriteria = KeyedList.fromList(value, io.nop.ai.agent.plan.model.AgentPlanCriterion::getId);
           
    }

    
    public io.nop.ai.agent.plan.model.AgentPlanCriterion getCriterion(String name){
        return this._exitCriteria.getByKey(name);
    }

    public boolean hasCriterion(String name){
        return this._exitCriteria.containsKey(name);
    }

    public void addCriterion(io.nop.ai.agent.plan.model.AgentPlanCriterion item) {
        checkAllowChange();
        java.util.List<io.nop.ai.agent.plan.model.AgentPlanCriterion> list = this.getExitCriteria();
        if (list == null || list.isEmpty()) {
            list = new KeyedList<>(io.nop.ai.agent.plan.model.AgentPlanCriterion::getId);
            setExitCriteria(list);
        }
        list.add(item);
    }
    
    public java.util.Set<String> keySet_exitCriteria(){
        return this._exitCriteria.keySet();
    }

    public boolean hasExitCriteria(){
        return !this._exitCriteria.isEmpty();
    }
    
    /**
     * 
     * xml name: gate
     *  阶段验收门控（design §14.1）：不满足时按 on-fail 动作处理
     */
    
    public io.nop.ai.agent.plan.model.AgentPlanGate getGate(){
      return _gate;
    }

    
    public void setGate(io.nop.ai.agent.plan.model.AgentPlanGate value){
        checkAllowChange();
        
        this._gate = value;
           
    }

    
    /**
     * 
     * xml name: kind
     *  
     */
    
    public java.lang.String getKind(){
      return _kind;
    }

    
    public void setKind(java.lang.String value){
        checkAllowChange();
        
        this._kind = value;
           
    }

    
    /**
     * 
     * xml name: name
     *  
     */
    
    public java.lang.String getName(){
      return _name;
    }

    
    public void setName(java.lang.String value){
        checkAllowChange();
        
        this._name = value;
           
    }

    
    /**
     * 
     * xml name: startedAt
     *  
     */
    
    public java.time.LocalDateTime getStartedAt(){
      return _startedAt;
    }

    
    public void setStartedAt(java.time.LocalDateTime value){
        checkAllowChange();
        
        this._startedAt = value;
           
    }

    
    /**
     * 
     * xml name: status
     *  
     */
    
    public io.nop.ai.agent.model.AgentExecStatus getStatus(){
      return _status;
    }

    
    public void setStatus(io.nop.ai.agent.model.AgentExecStatus value){
        checkAllowChange();
        
        this._status = value;
           
    }

    
    /**
     * 
     * xml name: targets
     *  
     */
    
    public java.util.List<io.nop.ai.agent.plan.model.AgentPlanTarget> getTargets(){
      return _targets;
    }

    
    public void setTargets(java.util.List<io.nop.ai.agent.plan.model.AgentPlanTarget> value){
        checkAllowChange();
        
        this._targets = KeyedList.fromList(value, io.nop.ai.agent.plan.model.AgentPlanTarget::getId);
           
    }

    
    public io.nop.ai.agent.plan.model.AgentPlanTarget getTarget(String name){
        return this._targets.getByKey(name);
    }

    public boolean hasTarget(String name){
        return this._targets.containsKey(name);
    }

    public void addTarget(io.nop.ai.agent.plan.model.AgentPlanTarget item) {
        checkAllowChange();
        java.util.List<io.nop.ai.agent.plan.model.AgentPlanTarget> list = this.getTargets();
        if (list == null || list.isEmpty()) {
            list = new KeyedList<>(io.nop.ai.agent.plan.model.AgentPlanTarget::getId);
            setTargets(list);
        }
        list.add(item);
    }
    
    public java.util.Set<String> keySet_targets(){
        return this._targets.keySet();
    }

    public boolean hasTargets(){
        return !this._targets.isEmpty();
    }
    
    /**
     * 
     * xml name: tasks
     *  阶段任务列表：支持递归子任务
     */
    
    public java.util.List<io.nop.ai.agent.plan.model.AgentPlanTaskModel> getTasks(){
      return _tasks;
    }

    
    public void setTasks(java.util.List<io.nop.ai.agent.plan.model.AgentPlanTaskModel> value){
        checkAllowChange();
        
        this._tasks = KeyedList.fromList(value, io.nop.ai.agent.plan.model.AgentPlanTaskModel::getTaskNo);
           
    }

    
    public io.nop.ai.agent.plan.model.AgentPlanTaskModel getTask(String name){
        return this._tasks.getByKey(name);
    }

    public boolean hasTask(String name){
        return this._tasks.containsKey(name);
    }

    public void addTask(io.nop.ai.agent.plan.model.AgentPlanTaskModel item) {
        checkAllowChange();
        java.util.List<io.nop.ai.agent.plan.model.AgentPlanTaskModel> list = this.getTasks();
        if (list == null || list.isEmpty()) {
            list = new KeyedList<>(io.nop.ai.agent.plan.model.AgentPlanTaskModel::getTaskNo);
            setTasks(list);
        }
        list.add(item);
    }
    
    public java.util.Set<String> keySet_tasks(){
        return this._tasks.keySet();
    }

    public boolean hasTasks(){
        return !this._tasks.isEmpty();
    }
    

    @Override
    public void freeze(boolean cascade){
        if(frozen()) return;
        super.freeze(cascade);

        if(cascade){ //NOPMD - suppressed EmptyControlStatement - Auto Gen Code
        
           this._exitCriteria = io.nop.api.core.util.FreezeHelper.deepFreeze(this._exitCriteria);
            
           this._gate = io.nop.api.core.util.FreezeHelper.deepFreeze(this._gate);
            
           this._targets = io.nop.api.core.util.FreezeHelper.deepFreeze(this._targets);
            
           this._tasks = io.nop.api.core.util.FreezeHelper.deepFreeze(this._tasks);
            
        }
    }

    @Override
    protected void outputJson(IJsonHandler out){
        super.outputJson(out);
        
        out.putNotNull("completedAt",this.getCompletedAt());
        out.putNotNull("description",this.getDescription());
        out.putNotNull("exitCriteria",this.getExitCriteria());
        out.putNotNull("gate",this.getGate());
        out.putNotNull("kind",this.getKind());
        out.putNotNull("name",this.getName());
        out.putNotNull("startedAt",this.getStartedAt());
        out.putNotNull("status",this.getStatus());
        out.putNotNull("targets",this.getTargets());
        out.putNotNull("tasks",this.getTasks());
    }

    public AgentPlanPhase cloneInstance(){
        AgentPlanPhase instance = newInstance();
        this.copyTo(instance);
        return instance;
    }

    protected void copyTo(AgentPlanPhase instance){
        super.copyTo(instance);
        
        instance.setCompletedAt(this.getCompletedAt());
        instance.setDescription(this.getDescription());
        instance.setExitCriteria(this.getExitCriteria());
        instance.setGate(this.getGate());
        instance.setKind(this.getKind());
        instance.setName(this.getName());
        instance.setStartedAt(this.getStartedAt());
        instance.setStatus(this.getStatus());
        instance.setTargets(this.getTargets());
        instance.setTasks(this.getTasks());
    }

    protected AgentPlanPhase newInstance(){
        return (AgentPlanPhase) ClassHelper.newInstance(getClass());
    }
}
 // resume CPD analysis - CPD-ON
