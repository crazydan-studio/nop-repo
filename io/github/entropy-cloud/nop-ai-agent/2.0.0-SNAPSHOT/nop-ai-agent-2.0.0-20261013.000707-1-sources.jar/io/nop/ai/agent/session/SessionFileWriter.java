package io.nop.ai.agent.session;

import static io.nop.ai.agent.NopAiAgentErrors.ERR_AGENT_INTERNAL_DETAIL;
import static io.nop.ai.agent.NopAiAgentErrors.ARG_DETAIL;
import io.nop.ai.agent.engine.NopAiAgentException;
import io.nop.ai.api.chat.messages.ChatMessage;
import io.nop.core.lang.json.JsonTool;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Serializes an {@link AgentSession} to a per-session {@code session.json}
 * file (design §1.1 recovery model + plan 183 crash/restart restore protocol).
 * The session file is the source of truth for crash/restart recovery: the full
 * message history ({@code List<ChatMessage>} including tool-call / tool-result
 * messages) is persisted so the restore path can rebuild the
 * {@code AgentExecutionContext} without re-executing completed tools.
 *
 * <p><b>Full-rewrite semantics</b>: the session file is overwritten on each
 * write — it always represents the latest aggregate session state. Unlike the
 * checkpoint journal (append-only, derived from per-tool-execution events),
 * the session is a mutable aggregate state; the per-session file is small, so
 * full-rewrite is simple and consistent.
 *
 * <p><b>Polymorphic message serialization</b>: the {@link ChatMessage} base
 * class is annotated with Jackson {@code @JsonTypeInfo(property="role")} +
 * {@code @JsonSubTypes}. {@link JsonTool#stringify} and
 * {@link JsonTool#parseBeanFromText} honour these annotations and dispatch
 * each message map to the correct subclass on read-back, so user/assistant/
 * system/tool/custom roles round-trip correctly (validated by
 * {@code TestFileBackedSessionStore}).
 *
 * <p><b>Thread safety</b>: writes are serialized on a per-instance lock.
 */
public final class SessionFileWriter {

    static final String FIELD_SESSION_ID = "sessionId";
    static final String FIELD_AGENT_NAME = "agentName";
    static final String FIELD_MESSAGES = "messages";
    static final String FIELD_TOTAL_TOKENS_USED = "totalTokensUsed";
    static final String FIELD_TOTAL_ITERATIONS = "totalIterations";
    static final String FIELD_CREATED_AT = "createdAt";
    static final String FIELD_UPDATED_AT = "updatedAt";
    static final String FIELD_STATUS = "status";
    static final String FIELD_METADATA = "metadata";
    static final String FIELD_PARENT_SESSION_ID = "parentSessionId";
    static final String FIELD_PLAN_ID = "planId";
    static final String FIELD_COMPACTED_AT = "compactedAt";
    static final String FIELD_TENANT_ID = "tenantId";
    static final String FIELD_SEEN_INPUT_KEYS = "seenInputKeys";
    static final String FIELD_PENDING_INJECTIONS = "pendingInjections";

    /**
     * Plan 2295 (WI14): monotonically increasing version of the base snapshot.
     * Journal entries record the snapshot version they extend
     * ({@code baseVersion}); a mismatch on replay means the journal is stale
     * (fold crash window) and it is self-healed away. Absent field in legacy
     * session files → version 0.
     */
    static final String FIELD_SNAPSHOT_VERSION = "snapshotVersion";

    private final Object ioLock = new Object();

    /**
     * Write (or overwrite) the session file with snapshot version 0 (legacy
     * shape — used by callers that do not participate in the incremental
     * journal protocol).
     *
     * @param sessionFile the per-session session.json path; never null
     * @param session     the session to serialize; never null
     * @throws NopAiAgentException if serialization or I/O fails
     */
    public void write(Path sessionFile, AgentSession session) {
        write(sessionFile, session, 0L);
    }

    /**
     * Write (or overwrite) the session file, stamping the given
     * {@code snapshotVersion} into the persisted JSON (plan 2295 / WI14).
     * Called by the incremental write path on every fold; the version is
     * what journal entries validate their {@code baseVersion} against.
     *
     * @param sessionFile     the per-session session.json path; never null
     * @param session         the session to serialize; never null
     * @param snapshotVersion the new base-snapshot version; fold increments it
     * @throws NopAiAgentException if serialization or I/O fails
     */
    public void write(Path sessionFile, AgentSession session, long snapshotVersion) {
        if (sessionFile == null) {
            throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL).param(ARG_DETAIL, "SessionFileWriter.write: sessionFile must not be null");
        }
        if (session == null) {
            throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL).param(ARG_DETAIL, "SessionFileWriter.write: session must not be null");
        }

        String json = serialize(session, snapshotVersion);

        synchronized (ioLock) {
            // Crash-safe write (plan 195): write to a sibling .tmp file, then
            // atomically replace the target via Files.move(ATOMIC_MOVE,
            // REPLACE_EXISTING). POSIX rename(2) guarantees the target file
            // is at all times either the complete previous content or the
            // complete new content — never truncated or partially written.
            // The .tmp file is a sibling of the target so both reside on the
            // same filesystem/mount point (required for ATOMIC_MOVE).
            Path tmp = sessionFile.resolveSibling(sessionFile.getFileName() + ".tmp");
            try {
                Path parent = sessionFile.getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
                Files.write(tmp, json.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.WRITE,
                        StandardOpenOption.TRUNCATE_EXISTING);
                Files.move(tmp, sessionFile, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL, e).param(ARG_DETAIL, "SessionFileWriter.write: failed to write " + sessionFile
                                + ": " + e.getMessage());
            } finally {
                try {
                    Files.deleteIfExists(tmp);
                } catch (IOException deleteErr) {
                    // Best-effort cleanup of a stale tmp — must not mask the
                    // primary exception (already thrown above if write/move
                    // failed). Only logged.
                }
            }
        }
    }

    static String serialize(AgentSession session) {
        return serialize(session, 0L);
    }

    /**
     * Serialize the full session state with the given {@code snapshotVersion}
     * stamped in (plan 2295 / WI14).
     */
    static String serialize(AgentSession session, long snapshotVersion) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(FIELD_SESSION_ID, session.getSessionId());
        map.put(FIELD_AGENT_NAME, session.getAgentName());
        // messages serialize via ChatMessage polymorphism — each map carries
        // a "role" discriminator that the reader uses to pick the subclass.
        map.put(FIELD_MESSAGES, session.getMessages());
        map.put(FIELD_TOTAL_TOKENS_USED, session.getTotalTokensUsed());
        map.put(FIELD_TOTAL_ITERATIONS, session.getTotalIterations());
        map.put(FIELD_CREATED_AT, session.getCreatedAt());
        map.put(FIELD_UPDATED_AT, session.getUpdatedAt());
        map.put(FIELD_STATUS, session.getStatus() != null ? session.getStatus().name() : null);
        map.put(FIELD_METADATA, session.getMetadata());
        map.put(FIELD_PARENT_SESSION_ID, session.getParentSessionId());
        map.put(FIELD_PLAN_ID, session.getPlanId());
        map.put(FIELD_COMPACTED_AT, session.getCompactedAt());
        map.put(FIELD_TENANT_ID, session.getTenantId());
        map.put(FIELD_SEEN_INPUT_KEYS, session.getSeenInputKeys());
        map.put(FIELD_PENDING_INJECTIONS, session.getPendingInjections());
        map.put(FIELD_SNAPSHOT_VERSION, snapshotVersion);
        try {
            return JsonTool.stringify(map);
        } catch (Exception e) {
            throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL, e).param(ARG_DETAIL, "SessionFileWriter.serialize: failed to serialize session: " + e.getMessage());
        }
    }

    /**
     * Serialize only the mutable scalar state (everything except identity,
     * createdAt, and messages) — the {@code state} block of a journal entry
     * (plan 2295 / WI14). Absolute-value semantics: the block carries the
     * whole scalar state at capture time, and replay overwrites (not
     * accumulates) each field.
     */
    static Map<String, Object> serializeState(AgentSession session) {
        Map<String, Object> state = new LinkedHashMap<>();
        state.put(FIELD_TOTAL_TOKENS_USED, session.getTotalTokensUsed());
        state.put(FIELD_TOTAL_ITERATIONS, session.getTotalIterations());
        state.put(FIELD_UPDATED_AT, session.getUpdatedAt());
        state.put(FIELD_STATUS, session.getStatus() != null ? session.getStatus().name() : null);
        state.put(FIELD_METADATA, session.getMetadata());
        state.put(FIELD_PARENT_SESSION_ID, session.getParentSessionId());
        state.put(FIELD_PLAN_ID, session.getPlanId());
        state.put(FIELD_COMPACTED_AT, session.getCompactedAt());
        state.put(FIELD_TENANT_ID, session.getTenantId());
        state.put(FIELD_SEEN_INPUT_KEYS, session.getSeenInputKeys());
        state.put(FIELD_PENDING_INJECTIONS, session.getPendingInjections());
        return state;
    }
}
