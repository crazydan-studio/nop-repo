package io.nop.ai.agent.session;

import io.nop.api.core.time.CoreMetrics;
import io.nop.ai.agent.compact.InMemorySpillStore;
import io.nop.ai.agent.compact.InSessionCompactionArchive;
import io.nop.ai.agent.compact.ISpillStore;
import io.nop.ai.agent.model.AgentExecStatus;
import io.nop.ai.agent.model.AgentModel;
import io.nop.ai.api.chat.messages.ChatMessage;
import io.nop.ai.toolkit.api.ICompactionArchive;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AgentSession {

    private final String sessionId;
    private final String agentName;
    private final List<ChatMessage> messages;
    private long totalTokensUsed;
    private int totalIterations;
    private final long createdAt;
    private long updatedAt;
    private AgentExecStatus status;
    private Map<String, Object> metadata;
    private String parentSessionId;
    private String planId;
    private Long compactedAt;
    /**
     * Multi-tenant identifier captured from the request's
     * {@code Principal.tenantId} at execution time (plan 270 finding 13-12).
     * Persisted so recovery paths ({@code resumeSession} /
     * {@code restoreSession} — which have no request/Principal source) can
     * re-establish the tenant context before any tenant-scoped DB operation
     * (e.g. {@code DBDenialLedger.reset}). {@code null} means "no tenant
     * context" (single-tenant / legacy — all data visible, backward
     * compatible).
     */
    private String tenantId;

    /**
     * Plan 296 (WS2): runtime override for the agent's active tool-visibility
     * tags. When non-null, this takes precedence over the agent model's
     * declared {@code activeTags}. Set by the {@code set-active-tags}
     * meta-tool to dynamically switch which tagged tools are exposed to the
     * LLM within this session. {@code null} means "use the agent model's
     * default activeTags". Only affects the current session — not persisted
     * across restarts.
     */
    private Set<String> activeTags;

    /**
     * Per-session compaction archive (design §8.2 Decision G). Lazily
     * initialised on first access — the write side (reference-style compaction
     * strategy via {@code AgentCompactionCoordinator}) and the read side
     * ({@code read-ref} tool via {@code AgentToolExecuteContext}) both reach
     * this same instance through the session, so the full compact→archive→
     * read-back wiring shares one host. {@code null} until the first
     * reference-style compaction runs; the session holds the only reference
     * so the archive is reclaimed when the session ends.
     */
    private ICompactionArchive compactionArchive;

    /**
     * Per-session compaction snapshot archive (design §8.3 Decision B).
     * Lazily initialised on first access by the
     * {@code AgentCompactionCoordinator} write side — before each compaction
     * the complete pre-compaction message list is archived here under a fresh
     * {@code snapshotId} so the original history is retrievable for audit /
     * debugging and a failed compaction leaves the original verifiably intact.
     * {@code null} until the first real compaction runs; the session holds the
     * only reference so the archive is reclaimed (session-scoped lifecycle)
     * when the session ends. Independent from the §8.2 content-addressed
     * {@link #compactionArchive} (per-event addressing vs per-content hash).
     */
    private ICompactionSnapshotArchive compactionSnapshotArchive;

    /**
     * Per-session spill store for oversized tool results (design §3.3).
     * Lazily initialised on first access — the write side
     * ({@code AgentToolDispatcher} via {@code sessionStore.get(sessionId)})
     * and the read side ({@code read-spill} tool via
     * {@code AgentToolExecuteContext.getSession()}) both reach this same
     * instance through the session, so spill→preview→read-back shares one
     * host. Default-assembled with {@link InMemorySpillStore} (there is no
     * null-store branch). {@code null} until the first spill; the session
     * holds the only reference so the store is reclaimed when the session
     * ends.
     */
    private ISpillStore spillStore;

    private AgentSession(String sessionId, String agentName, long createdAt) {
        this.sessionId = sessionId;
        this.agentName = agentName;
        this.messages = new ArrayList<>();
        this.totalTokensUsed = 0;
        this.totalIterations = 0;
        this.createdAt = createdAt;
        this.updatedAt = this.createdAt;
        this.status = AgentExecStatus.pending;
        this.metadata = new HashMap<>();
    }

    private AgentSession(String sessionId, String agentName) {
        this(sessionId, agentName, CoreMetrics.currentTimeMillis());
    }

    public static AgentSession create(String sessionId, String agentName) {
        return new AgentSession(sessionId, agentName);
    }

    /**
     * Package-private restore factory used by the persistence reader
     * ({@link SessionFileReader}) to reconstruct a session from its persisted
     * state with the original {@code createdAt} / {@code updatedAt} timestamps
     * preserved. The public API continues to use {@link #create} for new
     * sessions; this factory is only for crash/restart recovery (plan 183
     * Phase 1).
     *
     * @param sessionId  the session id; never null
     * @param agentName  the agent name; never null
     * @param createdAt  the original creation timestamp (epoch millis)
     * @param updatedAt  the original last-update timestamp (epoch millis)
     * @return a new session with the supplied identity + timestamps
     */
    static AgentSession restore(String sessionId, String agentName, long createdAt, long updatedAt) {
        AgentSession session = new AgentSession(sessionId, agentName, createdAt);
        session.updatedAt = updatedAt;
        return session;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getAgentName() {
        return agentName;
    }

    public List<ChatMessage> getMessages() {
        return Collections.unmodifiableList(new ArrayList<>(messages));
    }

    public void appendMessages(List<ChatMessage> newMessages) {
        if (newMessages != null) {
            this.messages.addAll(newMessages);
        }
        this.updatedAt = CoreMetrics.currentTimeMillis();
    }

    /**
     * Full-sync replace: clear the current message list and write the supplied
     * list in its place. Idempotent — repeated calls with the same input leave
     * the session in the same terminal state.
     * <p>
     * Used by {@code DefaultAgentEngine.doExecute}/{@code resumeSession}/
     * {@code restoreSession} post-execution sync and by the
     * {@code ReActAgentExecutor} intra-execution persistence path so that both
     * sync paths produce the same terminal state
     * ({@code session.messages == ctx.getMessages()}) without duplicate
     * appends. With the old append-delta sync, intra-execution and
     * post-execution sync would each append the same batch and produce
     * duplicates; the replace-semantic unifies them (plan 183 Phase 1
     * coordination decision).
     *
     * @param newMessages the complete message list to set; null is treated as
     *                    an empty list (clears all messages). The messages are
     *                    copied into the session's internal list, so subsequent
     *                    mutations to the input list do not affect the session.
     */
    public void replaceMessages(List<ChatMessage> newMessages) {
        this.messages.clear();
        if (newMessages != null) {
            this.messages.addAll(newMessages);
        }
        this.updatedAt = CoreMetrics.currentTimeMillis();
    }

    public long getTotalTokensUsed() {
        return totalTokensUsed;
    }

    public void addTokensUsed(long tokens) {
        this.totalTokensUsed += tokens;
    }

    public int getTotalIterations() {
        return totalIterations;
    }

    public void addIterations(int iterations) {
        this.totalIterations += iterations;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public AgentExecStatus getStatus() {
        return status;
    }

    public void setStatus(AgentExecStatus status) {
        this.status = status;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata != null ? new HashMap<>(metadata) : new HashMap<>();
    }

    public int getMessageCount() {
        return messages.size();
    }

    public void touch() {
        this.updatedAt = CoreMetrics.currentTimeMillis();
    }

    /**
     * Package-private: restore the {@code updatedAt} timestamp from the
     * persisted value. Used by the persistence reader ({@link SessionFileReader})
     * after mutations (e.g. {@code appendMessages}) that touch
     * {@code updatedAt} to the current time, so the persisted timestamp
     * survives the round-trip.
     */
    void restoreUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getParentSessionId() {
        return parentSessionId;
    }

    public void setParentSessionId(String parentSessionId) {
        this.parentSessionId = parentSessionId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public Long getCompactedAt() {
        return compactedAt;
    }

    public void setCompactedAt(Long compactedAt) {
        this.compactedAt = compactedAt;
    }

    public void markCompacted() {
        this.compactedAt = CoreMetrics.currentTimeMillis();
        this.touch();
    }

    /**
     * @return the tenantId captured from the request's
     *         {@code Principal.tenantId} at execution time, or {@code null}
     *         when the session has no tenant context (single-tenant / legacy).
     *         Recovery paths read this to re-establish the tenant context
     *         before tenant-scoped DB operations (plan 270 finding 13-12).
     */
    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    /**
     * Plan 296 (WS2): return the runtime active-tags override, or {@code null}
     * when no runtime override has been set (meaning "use the agent model's
     * default").
     */
    public Set<String> getActiveTags() {
        return activeTags;
    }

    public void setActiveTags(Set<String> activeTags) {
        this.activeTags = activeTags;
    }

    /**
     * Plan 296 (WS2): resolve the effective active-tags for tool visibility
     * filtering. Precedence: runtime session override ({@link #activeTags})
     * → agent model's declared {@code activeTags} → empty set (full
     * visibility, no tag restriction).
     *
     * <p>An empty return set means "no tag filtering" — all tools (subject to
     * other filters) are visible. This is NOT a silent no-op: it is the
     * explicitly-resolved "no restriction" state that the filter caller
     * checks before applying tag intersection logic.
     *
     * @param model the agent model whose declared activeTags are the fallback
     * @return the effective active tag set (never null; empty = no filter)
     */
    public Set<String> resolveActiveTags(AgentModel model) {
        if (activeTags != null) {
            return activeTags;
        }
        if (model != null && model.getActiveTags() != null) {
            return model.getActiveTags();
        }
        return Collections.emptySet();
    }

    /**
     * Return the per-session compaction archive, lazily initialising it on
     * first access. Both the reference-style compaction strategy (write side)
     * and the {@code read-ref} tool (read side) reach the same instance
     * through this host (design §8.2 Decision G). The laziness means sessions
     * that never use reference-style compaction pay no allocation cost and
     * no archive leaks into persistence (the field is transient by nature —
     * it is an in-memory cache of content already present in the message
     * history).
     *
     * @return the per-session archive; never null after this call
     */
    public ICompactionArchive getOrCreateCompactionArchive() {
        if (compactionArchive == null) {
            compactionArchive = new InSessionCompactionArchive();
        }
        return compactionArchive;
    }

    /**
     * Return the existing per-session compaction archive, or {@code null} when
     * no reference-style compaction has run yet (no archive materialised).
     * Used by the read side ({@code AgentToolExecuteContext}) to expose the
     * read-only view to {@code read-ref} without forcing materialisation —
     * when null, {@code read-ref} fails fast with "reference invalid" since
     * there is nothing to read back.
     *
     * @return the per-session archive, or {@code null} if none materialised
     */
    public ICompactionArchive getCompactionArchive() {
        return compactionArchive;
    }

    /**
     * Test/diagnostics hook for directly inspecting the archive. Production
     * code should prefer {@link #getOrCreateCompactionArchive()} (write side)
     * or {@link #getCompactionArchive()} (read side).
     */
    public void setCompactionArchive(ICompactionArchive compactionArchive) {
        this.compactionArchive = compactionArchive;
    }

    /**
     * Return the per-session spill store, lazily initialising it on first
     * access (design §3.3). The write side ({@code AgentToolDispatcher})
     * reaches this instance to PUT oversized tool results; the read side
     * ({@code read-spill} tool) reads them back through the same instance.
     * Default-assembled with {@link InMemorySpillStore} — always present.
     *
     * @return the per-session spill store; never null after this call
     */
    public ISpillStore getOrCreateSpillStore() {
        if (spillStore == null) {
            spillStore = new InMemorySpillStore(sessionId);
        }
        return spillStore;
    }

    /**
     * Return the existing per-session spill store, or {@code null} when no
     * spill has occurred yet (no store materialised). Used by read-only paths
     * that must not force materialisation.
     *
     * @return the per-session spill store, or {@code null} if none materialised
     */
    public ISpillStore getSpillStore() {
        return spillStore;
    }

    /**
     * Test/diagnostics hook for directly inspecting the spill store.
     * Production code should prefer {@link #getOrCreateSpillStore()} (write
     * side) or {@link #getSpillStore()} (read side).
     */
    public void setSpillStore(ISpillStore spillStore) {
        this.spillStore = spillStore;
    }

    /**
     * Return the per-session compaction snapshot archive, lazily initialising
     * it on first access (design §8.3 Decision B). The
     * {@code AgentCompactionCoordinator} write side reaches this instance to
     * archive the pre-compaction message list before handing it to the
     * compaction pipeline; the snapshot is then retrievable via
     * {@link ICompactionSnapshotArchive#get(String)} for audit / debugging.
     * The laziness means sessions that never compact pay no allocation cost.
     *
     * @return the per-session snapshot archive; never null after this call
     */
    public ICompactionSnapshotArchive getOrCreateCompactionSnapshotArchive() {
        if (compactionSnapshotArchive == null) {
            compactionSnapshotArchive = new InSessionCompactionSnapshotArchive(sessionId);
        }
        return compactionSnapshotArchive;
    }

    /**
     * Return the existing per-session compaction snapshot archive, or
     * {@code null} when no compaction has run yet (no archive materialised).
     * Used by read-back / audit paths that must not force materialisation —
     * when null there is no archived snapshot to retrieve.
     *
     * @return the per-session snapshot archive, or {@code null} if none materialised
     */
    public ICompactionSnapshotArchive getCompactionSnapshotArchive() {
        return compactionSnapshotArchive;
    }
}
