package io.nop.ai.agent.engine;

import io.nop.ai.agent.engine.NopAiAgentException;
import static io.nop.ai.agent.NopAiAgentErrors.ERR_AGENT_INTERNAL_DETAIL;
import static io.nop.ai.agent.NopAiAgentErrors.ARG_DETAIL;
import io.nop.ai.agent.hook.AgentLifecyclePoint;
import io.nop.ai.agent.hook.HookContext;
import io.nop.ai.agent.hook.HookResult;
import io.nop.ai.agent.hook.IAgentLifecycleHook;
import io.nop.ai.agent.hook.IHookRegistry;
import io.nop.ai.agent.middleware.AttemptContext;
import io.nop.ai.agent.middleware.ExecutionPoint;
import io.nop.ai.agent.middleware.IAgentMiddleware;
import io.nop.ai.agent.middleware.MiddlewareChain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * Lifecycle-hook invocation and agent-event publication (extracted from
 * {@link ReActAgentExecutor}, MA4.2-05). Wraps the hook observer loop
 * ({@link #invokeHooks}) in the middleware onion chain
 * ({@link #executeWithMiddleware}) for the 9 chain-enabled lifecycle points,
 * and publishes {@link AgentEvent}s (including error events) to the wired
 * {@link IAgentEventPublisher}.
 *
 * <p>W3-1 adds {@link #executeExecutionMiddleware} for execution-level
 * (per-attempt) middleware, which fires at {@link ExecutionPoint}s inside the
 * LLM retry loop and the tool dispatch loop. Session-level behaviour is
 * unchanged.
 */
public class AgentHookInvoker {
    private static final Logger LOG = LoggerFactory.getLogger(AgentHookInvoker.class);

    private final IHookRegistry hookRegistry;
    private final IAgentEventPublisher eventPublisher;

    public AgentHookInvoker(IHookRegistry hookRegistry, IAgentEventPublisher eventPublisher) {
        this.hookRegistry = hookRegistry;
        this.eventPublisher = eventPublisher;
    }

    // ---- moved verbatim from ReActAgentExecutor (MA4.2-05 split) ----
    /**
     * Plan 296 (Workstream 1): invoke lifecycle hooks with optional middleware
     * wrapping. When middlewares are registered at {@code point}, they form an
     * onion chain whose core is {@link #invokeHooks} (the existing hook
     * observer loop). When no middlewares are registered, this delegates
     * directly to {@link #invokeHooks} — zero overhead, identical to the
     * pre-middleware path.
     *
     * <p>The 9 chain-enabled points are: PRE_CALL, PRE_REASONING,
     * POST_REASONING, PRE_ACTING, POST_ACTING, POST_CALL, PRE_COMPACT,
     * BEFORE_TOOL_RESULT_PROCESSED, AFTER_TOOL_RESULT_PROCESSED. The
     * non-chain points (ON_ERROR, POST_COMPACT) continue to call
     * {@link #invokeHooks} directly.
     */
    public HookResult executeWithMiddleware(AgentLifecyclePoint point, AgentExecutionContext ctx,
                                              String agentName, String toolName, String toolCallId) {
        List<IAgentMiddleware> mws = hookRegistry.getMiddlewares(point, agentName);
        if (mws.isEmpty()) {
            return invokeHooks(point, ctx, agentName, toolName, toolCallId);
        }
        HookContext mwCtx = new HookContext(point, ctx);
        mwCtx.setToolName(toolName);
        mwCtx.setToolCallId(toolCallId);
        java.util.function.Function<HookContext, HookResult> core = hookCtx ->
                invokeHooks(point, hookCtx.getExecutionContext(), agentName,
                        hookCtx.getToolName(), hookCtx.getToolCallId());
        MiddlewareChain chain = new MiddlewareChain(mws, 0, core);
        HookResult result = chain.proceed(mwCtx);
        // W5-3 (BAIL): BailResult is only valid at POST_REASONING / POST_CALL.
        // A middleware short-circuiting the chain at a non-POST point (not
        // calling next.proceed) bypasses invokeHooks' validation, so this is
        // the choke point for middleware-returned BAIL. Fail-loud, no silent
        // ignore (Minimum Rules #24).
        validateBailPoint(result, point);
        return result;
    }

    /**
     * W3-1 (dual-layer middleware, decision D1): invoke execution-level
     * (per-attempt) middleware at the given {@link ExecutionPoint}. Unlike
     * session-level middleware (which wraps the hook observer loop),
     * execution-level middleware has a pass-through core — PRE_* and POST_*
     * are standalone trigger points invoked immediately before/after each LLM
     * or tool attempt; they do not wrap the attempt itself (the attempt
     * outcome is consumed by the caller, e.g. {@code LlmCallCoordinator} /
     * {@code AgentToolDispatcher}, which map a Veto to the retry/tool-error
     * control flow per design §5.1).
     *
     * <p>When no execution middlewares are registered at {@code point}, this
     * returns {@link HookResult.PassResult} directly — zero overhead, no
     * allocation beyond the fast {@code isEmpty()} check (no silent skip: the
     * caller always receives a definitive Pass it can forward).
     *
     * @param point        the execution-level trigger point
     * @param ctx          the agent execution context (shared with the retry/dispatch loop)
     * @param attemptCtx   the per-attempt context (attempt number, retry flag,
     *                     last attempt's error classification); may be
     *                     {@code null} when the caller has no attempt info
     *                     (e.g. first attempt with no prior classification)
     * @param agentName    the agent name (for agent-scoped registry lookup)
     * @param toolName     the tool name (non-null only for tool-side points)
     * @param toolCallId   the tool call id (non-null only for tool-side points)
     * @return the aggregated hook result (Pass/Veto); never Reenter for
     *         execution-level points (Reenter is a session-level re-entrant
     *         concept only)
     */
    public HookResult executeExecutionMiddleware(ExecutionPoint point, AgentExecutionContext ctx,
                                                   AttemptContext attemptCtx, String agentName,
                                                   String toolName, String toolCallId) {
        List<IAgentMiddleware> mws = hookRegistry.getExecutionMiddlewares(point, agentName);
        if (mws.isEmpty()) {
            return HookResult.PassResult.instance();
        }
        HookContext mwCtx = new HookContext(AgentLifecyclePoint.PRE_REASONING, ctx);
        mwCtx.setAttemptContext(attemptCtx);
        mwCtx.setToolName(toolName);
        mwCtx.setToolCallId(toolCallId);
        // Execution middleware core is a pass-through: PRE_* and POST_* do not
        // wrap the actual attempt (the attempt is driven by the caller). The
        // onion chain here only composes multiple execution middlewares at the
        // same point, so each can veto / observe around the (empty) core.
        java.util.function.Function<HookContext, HookResult> core = hookCtx -> HookResult.PassResult.instance();
        MiddlewareChain chain = new MiddlewareChain(mws, 0, core);
        HookResult result = chain.proceed(mwCtx);
        // W5-3 (BAIL): BailResult is session-level only (POST_REASONING /
        // POST_CALL). Execution-level scope returning BailResult is a
        // misconfiguration — fail-loud rather than silently treating it as
        // Pass (the caller only checks isVeto, so a Bail would be a silent
        // skip). Minimum Rules #24.
        if (result.isBail()) {
            throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL).param(ARG_DETAIL, "BailResult is not valid at execution-level points (ExecutionPoint=" + point
                            + "); BAIL is session-level (POST_REASONING/POST_CALL) only");
        }
        return result;
    }
    public HookResult invokeHooks(AgentLifecyclePoint point, AgentExecutionContext ctx,
                                   String agentName, String toolName, String toolCallId) {
        List<IAgentLifecycleHook> hooks = hookRegistry.getHooks(point, agentName);
        if (hooks.isEmpty()) {
            return HookResult.PassResult.instance();
        }

        for (IAgentLifecycleHook hook : hooks) {
            HookResult result;
            try {
                HookContext hookCtx = new HookContext(point, ctx);
                hookCtx.setToolName(toolName);
                hookCtx.setToolCallId(toolCallId);
                result = hook.onEvent(hookCtx);
            } catch (Exception e) {
                if (point == AgentLifecyclePoint.ON_ERROR) {
                    LOG.warn("on_error hook failed, using engine default error handling", e);
                    continue;
                } else if (point.name().startsWith("PRE_") || point.name().startsWith("BEFORE_")) {
                    LOG.error("before_* hook at {} failed", point, e);
                    throw e;
                } else {
                    LOG.warn("after_* hook at {} failed, continuing", point, e);
                    continue;
                }
            }

            // Contract validation stays OUTSIDE the degradation try/catch: a
            // hook business exception at after_* points keeps its warn-and-
            // continue semantics, but a contract violation (ReenterResult at a
            // non-reentrant point, BailResult at a non-POST point) must fail
            // loud at EVERY lifecycle point — including the direct-call
            // non-chain points ON_ERROR/POST_COMPACT that previously swallowed
            // it via the after_* warn branch (W5-3 fail-loud was only honored
            // for PRE_/BEFORE_ points). Minimum Rules #24.
            if (result instanceof HookResult.ReenterResult) {
                if (point != AgentLifecyclePoint.BEFORE_TOOL_RESULT_PROCESSED
                        && point != AgentLifecyclePoint.AFTER_TOOL_RESULT_PROCESSED) {
                    throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL).param(ARG_DETAIL, "ReenterResult is only valid at re-entrant hook points (BEFORE_TOOL_RESULT_PROCESSED, AFTER_TOOL_RESULT_PROCESSED), got: " + point);
                }
                return result;
            }

            // W5-3 (BAIL): validate BailResult is only returned at POST
            // points. This covers hooks (including the 2 non-chain points
            // ON_ERROR/POST_COMPACT that call invokeHooks directly).
            // Middlewares returning BailResult are validated at
            // executeWithMiddleware's choke point. Fail-loud (Minimum
            // Rules #24).
            validateBailPoint(result, point);

            if (result.isBail()) {
                return result;
            }

            if (result.isVeto()) {
                return result;
            }
        }
        return HookResult.PassResult.instance();
    }
    public void invokeOnError(AgentExecutionContext ctx, String agentName) {
        try {
            invokeHooks(AgentLifecyclePoint.ON_ERROR, ctx, agentName, null, null);
        } catch (Exception e) {
            LOG.warn("ON_ERROR hook invocation failed", e);
        }
    }

    public String vetoReason(HookResult result) {
        if (result instanceof HookResult.VetoResult) {
            return ((HookResult.VetoResult) result).getReason();
        }
        return "vetoed";
    }

    /**
     * W5-3 (BAIL): validate that BailResult is only returned at POST_REASONING
     * or POST_CALL. BailResult at any other lifecycle point indicates a
     * misconfigured middleware/hook — fail-loud rather than silently ignoring
     * the result (Minimum Rules #24). No-op for non-Bail results.
     */
    private static void validateBailPoint(HookResult result, AgentLifecyclePoint point) {
        if (result.isBail()
                && point != AgentLifecyclePoint.POST_REASONING
                && point != AgentLifecyclePoint.POST_CALL) {
            throw new NopAiAgentException(ERR_AGENT_INTERNAL_DETAIL).param(ARG_DETAIL, "BailResult is only valid at POST lifecycle points (POST_REASONING, POST_CALL), got: " + point);
        }
    }
    public void publishEvent(AgentEventType type, String sessionId, String agentName,
                              Map<String, Object> payload) {
        if (eventPublisher != null) {
            eventPublisher.publish(AgentEvent.create(type, sessionId, agentName, payload));
        }
    }

    public void publishErrorEvent(AgentEventType type, String sessionId, String agentName,
                                   String error) {
        if (eventPublisher != null) {
            eventPublisher.publish(AgentEvent.createError(type, sessionId, agentName, error));
        }
    }
}

