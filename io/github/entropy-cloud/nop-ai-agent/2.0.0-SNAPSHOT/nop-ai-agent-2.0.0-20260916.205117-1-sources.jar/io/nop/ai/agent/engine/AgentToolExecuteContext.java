package io.nop.ai.agent.engine;

import io.nop.ai.agent.memory.IAiMemoryStore;
import io.nop.ai.agent.message.IAgentMessenger;
import io.nop.ai.agent.model.PathRuleModel;
import io.nop.ai.agent.session.AgentSession;
import io.nop.ai.agent.team.ITeamAclChecker;
import io.nop.ai.agent.team.ITeamManager;
import io.nop.ai.agent.team.ITeamTaskStore;
import io.nop.ai.agent.team.NoOpTeamAclChecker;
import io.nop.ai.toolkit.api.ICompactionArchiveReader;
import io.nop.ai.toolkit.api.IToolExecuteContext;
import io.nop.ai.toolkit.fs.IToolFileSystem;
import io.nop.api.core.util.ICancelToken;
import io.nop.commons.concurrent.executor.IThreadPoolExecutor;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Agent-domain {@link IToolExecuteContext} that additionally exposes the
 * {@link IAgentEngine}, {@link IAgentMessenger}, and current session metadata
 * (sessionId, agentName) to engine-aware tools such as {@code call-agent} and
 * {@code send-message}.
 *
 * <p>Legacy tools that only depend on the {@link IToolExecuteContext} interface
 * (workDir, envs, expireAt, cancelToken, fileSystem, executor) are unaffected —
 * they never access the extra fields.
 *
 * <p>Engine-aware tools access the extra fields via casting the context or via
 * direct field access. If the engine or messenger is null (e.g. the executor
 * was constructed outside the engine for testing), engine-aware tools must
 * fail fast with a descriptive error rather than silently no-op.
 */
public class AgentToolExecuteContext implements IToolExecuteContext {

    private final File workDir;
    private final Map<String, String> envs;
    private final long expireAt;
    private final ICancelToken cancelToken;
    private final IToolFileSystem fileSystem;
    private final IThreadPoolExecutor executor;
    private final IAgentEngine engine;
    private final IAgentMessenger messenger;
    private final String sessionId;
    private final String agentName;
    private final Set<String> allowedTools;
    private final Set<String> allowedPathRoots;
    private final List<PathRuleModel> allowedPathRules;
    private final IAiMemoryStore memoryStore;
    private final ITeamManager teamManager;
    private final ITeamTaskStore teamTaskStore;
    private final ITeamAclChecker teamAclChecker;
    // call-agent chain. Set by ReActAgentExecutor from AgentExecutionContext
    // before the dispatch loop so CallAgentExecutor can read it and enforce
    // MAX_DELEGATION_DEPTH. Defaults to 0 (top-level) when not explicitly set.
    private int delegationDepth;
    // from sessionStore.get(sessionId). Meta-tools (e.g. set-active-tags)
    // read this to mutate session-scoped state. Null when the executor was
    // constructed outside the engine for testing or no sessionStore is wired.
    private AgentSession session;

    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName) {
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, null);
    }

    /**
     * Extended constructor that additionally carries the current agent's
     * <b>effective (clamped)</b> allowed tool set, used by engine-aware tools
     * (e.g. {@code call-agent}) to propagate a parent permission constraint to
     * sub-agents (design §4.4).
     *
     * @param allowedTools the current agent's effective (clamped) allowed tool
     *                     names; {@code null} means "no constraint information
     *                     available" — engine-aware tools do not propagate a
     *                     parent constraint (backward-compatible top-level
     *                     behavior). A non-null set (including an empty set) is
     *                     propagated verbatim as the parent's effective tool set
     *                     to sub-agents.
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools) {
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, allowedTools, null);
    }

    /**
     * Full constructor carrying both the current agent's effective (clamped)
     * allowed tool set AND its effective (clamped) allowed path roots, used by
     * engine-aware tools (e.g. {@code call-agent}) to propagate a parent
     * permission constraint to sub-agents (design §4.4:
     * 工具权限 = 父权限 ∩ 子配置, 文件权限 = 父权限 ∩ 子配置).
     *
     * @param allowedTools     the current agent's effective (clamped) allowed
     *                         tool names; {@code null} means "no constraint
     *                         information available" (backward-compatible
     *                         top-level behavior). A non-null set (including
     *                         empty) is propagated as the parent's effective
     *                         tool set.
     * @param allowedPathRoots the current agent's effective (clamped) allowed
     *                         path roots (normalized absolute directory roots);
     *                         {@code null} means ABSENT (no declared path scope
     *                         → no path confinement, backward compatible). A
     *                         non-null set (including empty) is propagated as
     *                         the parent's effective path roots. PRESENT({}) =
     *                         deny all paths (maximum restriction).
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools,
                                   Set<String> allowedPathRoots) {
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, allowedTools, allowedPathRoots, null);
    }

    /**
     * Full constructor carrying the current agent's effective (clamped) allowed
     * tool set, effective (clamped) allowed path roots, AND effective (clamped)
     * allowed path rules, used by engine-aware tools (e.g. {@code call-agent})
     * to propagate a parent permission constraint to sub-agents (design §4.4:
     * 文件权限 = 父权限 ∩ 子配置).
     *
     * @param allowedPathRules the current agent's effective (clamped) accumulated
     *                         path-rule chain; {@code null} means ABSENT (no
     *                         declared path-rules → no rule confinement). A
     *                         non-null List (including empty) is propagated as
     *                         the parent's effective path rules.
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools,
                                   Set<String> allowedPathRoots,
                                   List<PathRuleModel> allowedPathRules) {
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, allowedTools, allowedPathRoots,
                allowedPathRules, null);
    }

    /**
     * Full constructor additionally carrying the per-session
     * {@link IAiMemoryStore} resolved by the dispatch loop from the
     * engine's {@link io.nop.ai.agent.memory.IMemoryStoreProvider}. Working-memory
     * tools (read-memory / write-memory / search-memory) read the store from
     * here.
     *
     * <p>When {@code memoryStore} is {@code null} (the engine has not been
     * wired with a provider, or the caller is testing the executor outside the
     * engine), memory tools fail fast at execution time with a descriptive
     * error rather than silently no-op.
     *
     * @param memoryStore the per-session memory store; {@code null} is a
     *                    legitimate value (memory tools fail fast when null)
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools,
                                   Set<String> allowedPathRoots,
                                   List<PathRuleModel> allowedPathRules,
                                   IAiMemoryStore memoryStore) {
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, allowedTools, allowedPathRoots,
                allowedPathRules, memoryStore, null, null);
    }

    /**
     * Full constructor additionally carrying the per-session
     * {@link IAiMemoryStore} resolved by the dispatch loop from the
     * engine's {@link io.nop.ai.agent.memory.IMemoryStoreProvider}, AND the
     * engine's {@link ITeamManager} + {@link ITeamTaskStore} for team-aware
     * tools (team-send-message / team-status / team-task-create). Working-memory
     * tools read the store from here; team tools read the teamManager /
     * teamTaskStore from here.
     *
     * <p>When {@code memoryStore} is {@code null} (the engine has not been
     * wired with a provider, or the caller is testing the executor outside the
     * engine), memory tools fail fast at execution time with a descriptive
     * error rather than silently no-op. When {@code teamManager} /
     * {@code teamTaskStore} is {@code null} (team functionality not enabled),
     * team tools honestly report that the operation was not executed.
     *
     * @param memoryStore   the per-session memory store; {@code null} is a
     *                      legitimate value (memory tools fail fast when null)
     * @param teamManager   the engine's team manager; {@code null} means team
     *                      functionality is not enabled (team tools honestly
     *                      report)
     * @param teamTaskStore the engine's team task store; {@code null} means
     *                      team task functionality is not enabled
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools,
                                   Set<String> allowedPathRoots,
                                   List<PathRuleModel> allowedPathRules,
                                   IAiMemoryStore memoryStore,
                                   ITeamManager teamManager,
                                   ITeamTaskStore teamTaskStore) {
        // delegates to the 17-param endpoint, defaulting teamAclChecker to
        // NoOp so the 5 existing test callers (TestTeamSendMessageExecutor
        // / TestTeamStatusExecutor / TestTeamTaskCreateExecutor /
        // TestTeamTaskUpdateExecutor / TestTeamTaskUpdateEndToEnd) compile
        // and behave unchanged (NoOp allow → zero regression).
        this(workDir, envs, expireAt, cancelToken, fileSystem, executor,
                engine, messenger, sessionId, agentName, allowedTools, allowedPathRoots,
                allowedPathRules, memoryStore, teamManager, teamTaskStore,
                NoOpTeamAclChecker.noOp());
    }

    /**
     * Plan 228 (L4-team-acl-enforcement): full constructor additionally
     * carrying the engine's {@link ITeamAclChecker} for team-aware tools.
     * The 4 team tool executors consult this checker after resolving the
     * caller's team and before performing the actual store / messenger
     * operation.
     *
     * <p>When {@code teamAclChecker} is the shipped {@link NoOpTeamAclChecker}
     * (the engine default), all team-tool operations are permitted with no
     * extra authorisation overhead — zero behaviour regression. When a
     * functional {@link io.nop.ai.agent.team.DefaultTeamAclChecker} is
     * wired, the §5.1 default role-permission matrix is enforced.
     *
     * @param teamAclChecker the engine's team ACL checker; the engine always
     *                      passes a non-null value (NoOp by default). A null
     *                      value is treated as NoOp for defensive backward
     *                      compatibility.
     */
    public AgentToolExecuteContext(File workDir,
                                   Map<String, String> envs,
                                   long expireAt,
                                   ICancelToken cancelToken,
                                   IToolFileSystem fileSystem,
                                   IThreadPoolExecutor executor,
                                   IAgentEngine engine,
                                   IAgentMessenger messenger,
                                   String sessionId,
                                   String agentName,
                                   Set<String> allowedTools,
                                   Set<String> allowedPathRoots,
                                   List<PathRuleModel> allowedPathRules,
                                   IAiMemoryStore memoryStore,
                                   ITeamManager teamManager,
                                   ITeamTaskStore teamTaskStore,
                                   ITeamAclChecker teamAclChecker) {
        this.workDir = workDir;
        this.envs = envs != null ? envs : Collections.emptyMap();
        this.expireAt = expireAt;
        this.cancelToken = cancelToken;
        this.fileSystem = fileSystem;
        this.executor = executor;
        this.engine = engine;
        this.messenger = messenger;
        this.sessionId = sessionId;
        this.agentName = agentName;
        this.allowedTools = allowedTools;
        this.allowedPathRoots = allowedPathRoots;
        this.allowedPathRules = allowedPathRules;
        this.memoryStore = memoryStore;
        this.teamManager = teamManager;
        this.teamTaskStore = teamTaskStore;
        this.teamAclChecker = teamAclChecker != null ? teamAclChecker : NoOpTeamAclChecker.noOp();
    }

    @Override
    public File getWorkDir() {
        return workDir;
    }

    @Override
    public Map<String, String> getEnvs() {
        return envs;
    }

    @Override
    public long getExpireAt() {
        return expireAt;
    }

    @Override
    public ICancelToken getCancelToken() {
        return cancelToken;
    }

    @Override
    public IToolFileSystem getFileSystem() {
        return fileSystem;
    }

    @Override
    public IThreadPoolExecutor getExecutor() {
        return executor;
    }

    public IAgentEngine getEngine() {
        return engine;
    }

    public IAgentMessenger getMessenger() {
        return messenger;
    }

    @Override
    public String getSessionId() {
        return sessionId;
    }

    public String getAgentName() {
        return agentName;
    }

    /**
     * Return the current agent's effective (clamped) allowed tool set, or
     * {@code null} when no constraint information is available (top-level agent
     * whose context was constructed by a caller that did not opt into the
     * constraint field). {@code call-agent} reads this set to build and
     * propagate a {@link io.nop.ai.agent.security.ParentPermissionConstraint}
     * to sub-agents.
     */
    public Set<String> getAllowedTools() {
        return allowedTools;
    }

    /**
     * Return the current agent's effective (clamped) allowed path roots
     * (normalized absolute directory roots), or {@code null} when no path-scope
     * information is available (ABSENT — no declared path scope, backward
     * compatible). {@code call-agent} reads this set to include the parent's
     * path roots in the propagated
     * {@link io.nop.ai.agent.security.ParentPermissionConstraint}.
     *
     * @return {@code null} (ABSENT) or a non-null Set (PRESENT, possibly empty)
     */
    public Set<String> getAllowedPathRoots() {
        return allowedPathRoots;
    }

    /**
     * Return the current agent's effective (clamped) accumulated path-rule
     * chain, or {@code null} when no path-rule information is available
     * (ABSENT — no declared path-rules, backward compatible).
     * {@code call-agent} reads this list to include the parent's effective
     * path rules in the propagated
     * {@link io.nop.ai.agent.security.ParentPermissionConstraint}.
     *
     * @return {@code null} (ABSENT) or a non-null List (PRESENT)
     */
    public List<PathRuleModel> getAllowedPathRules() {
        return allowedPathRules;
    }

    /**
     * Return the per-session {@link IAiMemoryStore} resolved from the
     * engine's {@link io.nop.ai.agent.memory.IMemoryStoreProvider}, or
     * {@code null} when no provider is wired (memory tools fail fast at
     * execution time with a descriptive error). Working-memory tools
     * (read-memory / write-memory / search-memory) read the store from here.
     *
     * @return {@code null} (no provider wired) or a non-null per-session store
     */
    public IAiMemoryStore getMemoryStore() {
        return memoryStore;
    }

    /**
     * Return the engine's {@link ITeamManager} for team-aware tools
     * (team-send-message / team-status / team-task-create), or {@code null}
     * when team functionality is not enabled (team tools honestly report).
     *
     * @return {@code null} (not enabled) or a non-null team manager
     */
    public ITeamManager getTeamManager() {
        return teamManager;
    }

    /**
     * Return the engine's {@link ITeamTaskStore} for team task tools
     * (team-task-create / team-status task count), or {@code null} when team
     * task functionality is not enabled.
     *
     * @return {@code null} (not enabled) or a non-null team task store
     */
    public ITeamTaskStore getTeamTaskStore() {
        return teamTaskStore;
    }

    /**
     * Plan 228 (L4-team-acl-enforcement): return the engine's
     * {@link ITeamAclChecker} for team-aware tools (team-send-message /
     * team-status / team-task-create / team-task-update). Always non-null —
     * the shipped default is {@link NoOpTeamAclChecker} (allow(null)), and
     * the engine guarantees a non-null value via
     * {@code DefaultAgentEngine.setTeamAclChecker} null-safe fallback.
     *
     * @return the team ACL checker (never null; NoOp allow by default)
     */
    public ITeamAclChecker getTeamAclChecker() {
        return teamAclChecker;
    }

    /**
     * Plan 278 (AR-05): the delegation depth of the current execution within
     * a call-agent chain. 0 = top-level agent. CallAgentExecutor reads this
     * to enforce MAX_DELEGATION_DEPTH and compute the child's depth.
     */
    public int getDelegationDepth() {
        return delegationDepth;
    }

    public void setDelegationDepth(int delegationDepth) {
        this.delegationDepth = delegationDepth;
    }

    /**
     * Plan 296 (WS2): return the current {@link AgentSession}, or {@code null}
     * when no session is available (executor constructed outside the engine,
     * or no sessionStore wired). Meta-tools (e.g. {@code set-active-tags})
     * read this to mutate session-scoped state; they fail fast with a
     * descriptive error when null.
     */
    public AgentSession getSession() {
        return session;
    }

    public void setSession(AgentSession session) {
        this.session = session;
    }

    /**
     * Read side of the per-session compaction archive (design §8.2
     * Decision C + G). Overrides the {@code IToolExecuteContext} default UOE
     * bridge to return the {@code AgentSession}'s archive read-only view,
     * so the {@code read-ref} tool can read back original content that was
     * replaced by a {@code shortRef} pointer during reference-style
     * compaction.
     * <p>
     * Returns {@code null} when no session is available or no archive has
     * been materialised (no reference-style compaction has run). The
     * {@code read-ref} tool treats null as "reference invalid / not
     * available" and surfaces an explicit error rather than silently
     * returning empty content (Minimum Rules #24). This is NOT a UOE: a null
     * return is a legitimate "nothing to read back yet" state that the tool
     * handles explicitly.
     */
    @Override
    public ICompactionArchiveReader getCompactionArchiveReader() {
        if (session == null) {
            return null;
        }
        return session.getCompactionArchive();
    }
}
