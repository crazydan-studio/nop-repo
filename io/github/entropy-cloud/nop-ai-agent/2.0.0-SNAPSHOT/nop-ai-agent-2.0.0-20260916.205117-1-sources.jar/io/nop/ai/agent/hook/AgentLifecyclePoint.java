package io.nop.ai.agent.hook;

public enum AgentLifecyclePoint {
    PRE_CALL,
    PRE_REASONING,
    POST_REASONING,
    PRE_ACTING,
    POST_ACTING,
    ON_ERROR,
    POST_CALL,
    PRE_COMPACT,
    POST_COMPACT,
    BEFORE_TOOL_RESULT_PROCESSED,
    AFTER_TOOL_RESULT_PROCESSED
}
