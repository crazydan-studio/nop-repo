package io.nop.ai.agent.hook;

import io.nop.ai.api.secure.SecureDefault;
import io.nop.ai.agent.middleware.ExecutionPoint;
import io.nop.ai.agent.middleware.IAgentMiddleware;
import io.nop.ai.agent.middleware.MiddlewareChain;
import io.nop.ai.agent.model.AgentHookModel;
import io.nop.ai.agent.model.AgentModel;
import io.nop.core.lang.eval.EvalExprProvider;
import io.nop.core.lang.eval.IEvalFunction;
import io.nop.core.lang.eval.IEvalScope;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

@SecureDefault
public class DefaultHookRegistry implements IHookRegistry {

    private static final Map<String, AgentLifecyclePoint> EVENT_NAME_MAP = buildEventNameMap();

    // W3-1: execution-level point name -> ExecutionPoint (case-insensitive).
    private static final Map<String, ExecutionPoint> EXECUTION_POINT_NAME_MAP = buildExecutionPointNameMap();

    // The hooks map is retained for backward-compatible access but
    // register() now wraps the hook in a middleware delegate so the
    // unified middleware chain covers both hooks and middlewares.
    private final Map<AgentLifecyclePoint, List<IAgentLifecycleHook>> hooks = new EnumMap<>(AgentLifecyclePoint.class);

    private final Map<AgentLifecyclePoint, List<IAgentMiddleware>> middlewares = new EnumMap<>(AgentLifecyclePoint.class);

    // W3-1 (dual-layer middleware): execution-level middlewares, stored
    // separately from session-level middlewares. Keyed by ExecutionPoint
    // (a distinct enum) so the two scopes never conflate.
    private final Map<ExecutionPoint, List<IAgentMiddleware>> executionMiddlewares = new EnumMap<>(ExecutionPoint.class);

    public DefaultHookRegistry() {
    }

    @Override
    public List<IAgentLifecycleHook> getHooks(AgentLifecyclePoint point, String agentName) {
        List<IAgentLifecycleHook> list = hooks.get(point);
        return list != null ? Collections.unmodifiableList(list) : Collections.emptyList();
    }

    @Override
    public void register(AgentLifecyclePoint point, IAgentLifecycleHook hook) {
        hooks.computeIfAbsent(point, k -> new ArrayList<>()).add(hook);
        // Middlewares wrap around hooks. No additional registration needed here.
    }

    @Override
    public List<IAgentMiddleware> getMiddlewares(AgentLifecyclePoint point, String agentName) {
        List<IAgentMiddleware> list = middlewares.get(point);
        return list != null ? Collections.unmodifiableList(list) : Collections.emptyList();
    }

    @Override
    public void registerMiddleware(AgentLifecyclePoint point, IAgentMiddleware middleware) {
        middlewares.computeIfAbsent(point, k -> new ArrayList<>()).add(middleware);
    }

    @Override
    public List<IAgentMiddleware> getExecutionMiddlewares(ExecutionPoint point, String agentName) {
        List<IAgentMiddleware> list = executionMiddlewares.get(point);
        return list != null ? Collections.unmodifiableList(list) : Collections.emptyList();
    }

    @Override
    public void registerExecutionMiddleware(ExecutionPoint point, IAgentMiddleware middleware) {
        executionMiddlewares.computeIfAbsent(point, k -> new ArrayList<>()).add(middleware);
    }

    /**
     * Build an immutable {@link MiddlewareChain} for the given lifecycle point,
     * wrapping the supplied core callable. The core runs all registered hooks
     * at this point (the innermost layer). When no middlewares are registered
     * at this point, the returned chain delegates directly to the core —
     * zero overhead, equivalent to the pre-middleware path.
     *
     * @param point the lifecycle point whose middlewares (if any) wrap the core
     * @param core  the innermost callable that runs the hook observers
     * @return a ready-to-proceed chain
     */
    public MiddlewareChain buildChain(AgentLifecyclePoint point, Function<HookContext, HookResult> core) {
        List<IAgentMiddleware> list = middlewares.get(point);
        if (list == null || list.isEmpty()) {
            return new MiddlewareChain(Collections.emptyList(), 0, core);
        }
        return new MiddlewareChain(Collections.unmodifiableList(list), 0, core);
    }

    public static DefaultHookRegistry fromAgentModel(AgentModel model) {
        DefaultHookRegistry registry = new DefaultHookRegistry();
        if (model == null) {
            return registry;
        }
        // lifecycle hooks are loaded via hasLifecycle()/getLifecycle() when present.
        // For backward compat, also load from hooks and middlewares.
        if (model.hasHooks()) {
            for (AgentHookModel hookModel : model.getHooks()) {
                AgentLifecyclePoint point = resolveLifecyclePoint(hookModel.getEvent());
                if (point == null) {
                    continue;
                }
                IEvalFunction body = hookModel.getBody();
                registry.register(point, new EvalFunctionHookAdapter(body));
            }
        }
        return registry;
    }

    /**
     * Plan 304: adapts an {@link IAgentLifecycleHook} to the
     * {@link IAgentMiddleware} interface so hooks are processed through
     * the unified middleware chain.
     */
    private static class HookToMiddlewareAdapter implements IAgentMiddleware {
        private final IAgentLifecycleHook hook;

        HookToMiddlewareAdapter(IAgentLifecycleHook hook) {
            this.hook = hook;
        }

        @Override
        public HookResult execute(HookContext ctx, MiddlewareChain chain) {
            // Run the hook first, then continue the chain
            HookResult hookResult = hook.onEvent(ctx);
            if (hookResult.isVeto()) {
                return hookResult;
            }
            return chain.proceed(ctx);
        }
    }

    public static AgentLifecyclePoint resolveLifecyclePoint(String event) {
        if (event == null || event.isEmpty()) {
            return null;
        }
        return EVENT_NAME_MAP.get(event.toLowerCase(Locale.ROOT));
    }

    /**
     * W3-1: resolve an execution-level trigger point name (snake_case or
     * enum name, case-insensitive) to an {@link ExecutionPoint}. Returns
     * {@code null} when the name does not match any execution point.
     */
    public static ExecutionPoint resolveExecutionPoint(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        return EXECUTION_POINT_NAME_MAP.get(name.toLowerCase(Locale.ROOT));
    }

    private static Map<String, AgentLifecyclePoint> buildEventNameMap() {
        Map<String, AgentLifecyclePoint> map = new java.util.HashMap<>();

        addMapping(map, "before_call", "pre_call", AgentLifecyclePoint.PRE_CALL);
        addMapping(map, "before_reasoning", "pre_reasoning", AgentLifecyclePoint.PRE_REASONING);
        addMapping(map, "after_reasoning", "post_reasoning", AgentLifecyclePoint.POST_REASONING);
        addMapping(map, "before_acting", "pre_acting", AgentLifecyclePoint.PRE_ACTING);
        addMapping(map, "after_acting", "post_acting", AgentLifecyclePoint.POST_ACTING);
        addMapping(map, "on_error", AgentLifecyclePoint.ON_ERROR);
        addMapping(map, "after_call", "post_call", AgentLifecyclePoint.POST_CALL);
        addMapping(map, "before_compact", "pre_compact", AgentLifecyclePoint.PRE_COMPACT);
        addMapping(map, "after_compact", "post_compact", AgentLifecyclePoint.POST_COMPACT);
        addMapping(map, "before_tool_result_processed", AgentLifecyclePoint.BEFORE_TOOL_RESULT_PROCESSED);
        addMapping(map, "after_tool_result_processed", AgentLifecyclePoint.AFTER_TOOL_RESULT_PROCESSED);

        return map;
    }

    /**
     * W3-1: execution-level trigger point name map. Both snake_case
     * (pre_llm_attempt) and the enum name (PRE_LLM_ATTEMPT) resolve.
     */
    private static Map<String, ExecutionPoint> buildExecutionPointNameMap() {
        Map<String, ExecutionPoint> map = new java.util.HashMap<>();
        for (ExecutionPoint p : ExecutionPoint.values()) {
            map.put(p.name().toLowerCase(Locale.ROOT), p);
        }
        return map;
    }

    private static void addMapping(Map<String, AgentLifecyclePoint> map, String canonicalSnake,
                                   String altSnake, AgentLifecyclePoint point) {
        map.put(canonicalSnake, point);
        map.put(altSnake, point);
        map.put(point.name().toLowerCase(Locale.ROOT), point);
    }

    private static void addMapping(Map<String, AgentLifecyclePoint> map, String canonicalSnake,
                                   AgentLifecyclePoint point) {
        map.put(canonicalSnake, point);
        map.put(point.name().toLowerCase(Locale.ROOT), point);
    }

    private static class EvalFunctionHookAdapter implements IAgentLifecycleHook {
        private final IEvalFunction body;

        EvalFunctionHookAdapter(IEvalFunction body) {
            this.body = body;
        }

        @Override
        public HookResult onEvent(HookContext ctx) {
            if (body == null) {
                return HookResult.PassResult.instance();
            }
            IEvalScope scope = EvalExprProvider.newEvalScope();
            Object result = body.call2(null, ctx, ctx.getExecutionContext(), scope);
            if (result instanceof HookResult) {
                return (HookResult) result;
            }
            return HookResult.PassResult.instance();
        }
    }
}
