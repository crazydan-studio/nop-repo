package io.nop.metadata.service.search;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.exceptions.NopException;
import io.nop.core.context.IServiceContext;
import io.nop.metadata.api.dto.IndexResult;
import io.nop.metadata.api.dto.SearchHitDTO;
import io.nop.metadata.api.dto.SearchResultDTO;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.search.api.ISearchEngine;
import io.nop.search.api.SearchHit;
import io.nop.search.api.SearchRequest;
import io.nop.search.api.SearchResponse;
import io.nop.metadata.service.NopMetadataException;
import jakarta.annotation.Nullable;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pseudo-BizModel for cross-cutting search operations across multiple entity types.
 * This BizModel has no single corresponding entity because search indexes span
 * NopMetaTable, NopMetaEntity, NopMetaEntityField, NopMetaGlossaryTerm, etc.
 * The xmeta at {@code _vfs/nop/metadata/model/NopMetaSearch/NopMetaSearch.xmeta} provides
 * GraphQL schema definition（R2.10：已移至 model/ 扫描根可达路径，MA3.1-10）。
 */
@BizModel("NopMetaSearch")
public class NopMetaSearchBizModel {

    private static final Logger LOG = LoggerFactory.getLogger(NopMetaSearchBizModel.class);

    @Inject
    protected NopMetaIndexBuilder indexBuilder;

    @Inject
    protected NopMetaSearchProcessor searchService;

    @Inject
    @Nullable
    @Named("nopSearchEngine")
    protected ISearchEngine searchEngine;

    @BizMutation
    public List<IndexResult> rebuildSearchIndex(@Name("entityTypes") List<String> entityTypes,
                                                IServiceContext context) {
        if (searchEngine == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_SEARCH_ENGINE_UNAVAILABLE)
                    .param(NopMetadataErrors.ARG_ERROR, "searchEngine not available");
        }
        return indexBuilder.buildFullIndex(entityTypes);
    }

    @BizQuery
    public SearchResultDTO searchMetadata(@Name("query") String query,
                                          @Name("entityType") String entityType,
                                          @Name("limit") Integer limit,
                                          IServiceContext context) {
        if (limit == null) {
            limit = 20;
        } else if (limit < 0) {
            // AR-23④（R8.2）：负 limit 显式拒绝（沿 AR-09 ERR_PAGINATION_LIMIT_INVALID 先例——
            // 不做静默钳制、不直通引擎），在设置 request 之前拒绝
            throw new NopMetadataException(NopMetadataErrors.ERR_SEARCH_LIMIT_INVALID)
                    .param(NopMetadataErrors.ARG_LIMIT, limit);
        } else if (limit > 100) {
            limit = 100;
        }

        SearchRequest request = new SearchRequest();
        request.setTopic(NopMetaSearchProcessor.TOPIC);
        request.setTags(entityType != null ? Collections.singleton(entityType) : null);
        request.setQuery(query);
        request.setLimit(limit);

        if (searchEngine == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_SEARCH_ENGINE_UNAVAILABLE)
                    .param(NopMetadataErrors.ARG_ERROR, "searchEngine not available");
        }
        SearchResponse response = searchEngine.search(request);

        SearchResultDTO result = new SearchResultDTO();
        if (response.getItems() != null) {
            List<SearchHitDTO> items = new ArrayList<>();
            for (SearchHit hit : response.getItems()) {
                SearchHitDTO dto = new SearchHitDTO();
                dto.setId(hit.getId());
                if (hit.getTags() != null && !hit.getTags().isEmpty()) {
                    dto.setEntityType(hit.getTags().iterator().next());
                }
                dto.setName(hit.getName());
                dto.setTitle(hit.getTitle());
                dto.setSummary(hit.getSummary());
                dto.setScore((double) hit.getScore());
                items.add(dto);
            }
            result.setItems(items);
        }
        result.setTotal(response.getTotal());
        result.setLimit(limit);

        return result;
    }
}
