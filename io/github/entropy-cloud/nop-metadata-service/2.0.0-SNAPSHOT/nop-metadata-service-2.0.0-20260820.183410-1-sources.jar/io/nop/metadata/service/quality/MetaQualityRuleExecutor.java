
package io.nop.metadata.service.quality;


import io.nop.api.core.time.CoreMetrics;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.exceptions.ErrorCode;
import io.nop.commons.util.StringHelper;
import io.nop.core.lang.json.JsonTool;
import io.nop.metadata.service.connection.MetaDataSourceConnectionProcessor;
import io.nop.metadata.service.tableref.TableReference;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 质量规则执行器（无状态，参考 {@code MetaCatalogCollector} 收集器模式）。按架构基线 §2.7.1 D3 判定语义，
 * 根据 ruleType 生成并执行检测 SQL，返回结构化判定结果（{@link QualityRuleJudgment}），
 * 由 {@code NopMetaQualityRuleBizModel} 据此写入 NopMetaQualityResult 时序行。
 *
 * <p>本类不自建连接，由调用方在 P2-1 {@code withConnection} callback 内传入已打开的 {@link Connection}。
 * 物理解析（entityId → NopMetaTable → querySpace → NopMetaDataSource）在 BizModel 层完成，本类仅消费解析结果。
 *
 * <p>标识符注入防护（§2.7.1 D3）：列名 / 表名 / schema 名为 SQL 标识符，拼接前必须通过
 * {@link #IDENTIFIER_PATTERN} 白名单校验；比较值（range min/max、regex pattern）使用 PreparedStatement 参数绑定。
 * custom_sql 的 sqlExpression/params.sql 为用户显式提供（已知显式风险），直接执行不解析不改写。
 *
 * <p>不支持的方言（regex REGEXP 不可用）→ SKIP + details 标记（不静默跳过、不伪造值）。
 */
public class MetaQualityRuleExecutor {

    private static final Logger LOG = LoggerFactory.getLogger(MetaQualityRuleExecutor.class);

    /** SQL 标识符白名单：字母/下划线开头，后跟字母/数字/下划线。用于校验列名/表名/schema，防注入。 */
    static final Pattern IDENTIFIER_PATTERN = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*$");

    /** inline ErrorCode：标识符（列名/表名/schema）不符合白名单，拒绝拼接防注入。 */

    /**
     * 维度13-03：custom_sql 规则的 SQL 内容含危险关键字（多语句、UNION、文件读写等），拒绝执行。
     * PreparedStatement 不解决 custom_sql 注入（SQL 文本本身是用户配置），所以白名单是核心防御。
     */

    /**
     * 维度13-03：custom_sql 危险关键字黑名单（MA7.1-02 修复后为 token 级匹配，R6.1 补全 PG 文件族/脚本导出族
     * 6 缺项，AR-04/AR-05 补 DML/TCL 族与 H2 文件读写族，F9 补 PG 脚本执行/系统目录族）。
     * <ul>
     *   <li>单 token 条目：分词后按 token 精确匹配（不做子串匹配，避免字符串字面量误伤也避免
     *       {@code UNION} 拼接变体绕过——token 化使空白/注释/反引号变体全部归一）。</li>
     *   <li>DML 族（INSERT/UPDATE/DELETE/MERGE/REPLACE）与 TCL 族（COMMIT/ROLLBACK/SAVEPOINT/SET/TRANSACTION）
     *       以及 RENAME/LOCK/UNLOCK 逐项对齐模块内兄弟校验器 {@code ExpressionMeasureValidator.KEYWORD_BLACKLIST}
     *       ——custom_sql 规则在外部数据源账户上执行（MySQL/PG 驱动"先执行后报错"语义使篡改生效），DML/TCL
     *       全部拒绝。</li>
     *   <li>文件访问族全覆盖：PostgreSQL 文件/目录访问族（PG_READ_FILE/PG_READ_BINARY_FILE/PG_LS_DIR/
     *       PG_LS_LOGDIR/PG_LS_WALDIR/PG_STAT_FILE/COPY）、脚本导出族（H2 RUNSCRIPT/SCRIPT、SYS_EXEC）、
     *       H2 文件读写族（FILE_READ/FILE_WRITE/BACKUP/CSVWRITE/CSVREAD）。</li>
     *   <li>F9（plan 2026-08-14-1133-1）补 PG 脚本执行/系统目录/时序攻击族：
     *       {@code DO}（PG 执行匿名 PL/pgSQL 代码块）、{@code PG_SLEEP}（时序盲注/DoS）、
     *       {@code PG_CATALOG}（PG 系统目录 schema）、{@code PG_STAT_USER_TABLES}（PG 系统统计视图，
     *       信息泄漏面）。{@code WITH}（CTE 递归）见下方 tradeoff 裁定。</li>
     *   <li>多 token 条目（{@link #CUSTOM_SQL_FORBIDDEN_SEQUENCES}）：按连续 token 序列匹配，
     *       {@code INTO\tOUTFILE} / 注释分隔的 {@code INTO} 与 {@code OUTFILE} / 多空白分隔一律命中；
     *       {@code LOAD XML} 序列覆盖 H2 的 {@code LOAD XML INFILE} 文件读。</li>
     *   <li>{@code ;} 与 MySQL 可执行注释（{@code /*!} 开头）在归一化前显式拒绝。</li>
     * </ul>
     *
     * <p><b>F9 DRY 裁定（与 {@code ExpressionMeasureValidator.KEYWORD_BLACKLIST}/{@code FUNCTION_BLACKLIST} 的关系）</b>：
     * 保持分离（不抽取共享常量）。理由：(1) 语义域不同——custom_sql 管整条 SQL 文本（DDL/DML/文件读写/过程调用），
     * expression measure 管 SELECT 片段表达式（计算列，禁任何 DDL/DML）；(2) 分词与匹配机制不同——custom_sql
     * 用简单 token 化 + fail-closed（字符串字面量内关键字也被拒，{@code testUnionInsideStringLiteralBlockedFailClosed}
     * 钉死），expression validator 用 word-boundary + 字符串字面量先抽取（字符串内关键字不触发误拒）；(3) 演进路径不同
     * ——custom_sql 持续吸收外部源方言的副作用函数/系统目录（PG 族），expression validator 聚焦表达式语义安全。
     * 抽取共享常量会耦合两个不同匹配语义与演进节奏的组件。重叠项（DROP/CREATE/ALTER/... 等 22 项）的"恰好同名"
     * 是语义域交集的自然结果，非 DRY 缺陷。{@code PG_SLEEP} 同时存在于本表与 {@code FUNCTION_BLACKLIST}，
     * 但两者匹配形态不同（custom_sql 的 token 精确匹配 vs function-call 形态匹配），各自独立维护。
     *
     * <p><b>F9 {@code WITH} CTE false-positive tradeoff</b>：加入 {@code WITH} 会阻断合法分析型 CTE 查询
     * （{@code WITH t AS (SELECT ...) SELECT ... FROM t}）。这与既有 over-block 哲学一致——custom_sql 质量规则
     * 面向受限 SQL 场景（已知显式风险的 count/measure SQL），已含 {@code SET} 等常见关键字，宁可误拒不放过。
     * 合法 CTE 分析需求应改用子查询（{@code SELECT ... FROM (SELECT ...) t}）或评估改用专用 measure 表达式通道
     * （经 {@code ExpressionMeasureValidator} 校验的 expression 列）。CTE 包装的 DML（{@code WITH x AS (DELETE...) SELECT 1}）
     * 经 token 化后 DML 关键字亦暴露被拒，{@code WITH} 条目使其更早 fail-fast。
     */
    private static final Set<String> CUSTOM_SQL_FORBIDDEN_WORDS = unmodifiableSet(
            "UNION",
            "LOAD_FILE",
            "CALL", "EXEC", "EXECUTE",
            "SHUTDOWN",
            "DROP", "TRUNCATE", "ALTER", "CREATE", "GRANT", "REVOKE", "RENAME",
            "INSERT", "UPDATE", "DELETE", "MERGE", "REPLACE",
            "COMMIT", "ROLLBACK", "SAVEPOINT", "SET", "TRANSACTION",
            "LOCK", "UNLOCK",
            "INFORMATION_SCHEMA",
            "COPY", "PG_READ_FILE", "PG_READ_BINARY_FILE", "PG_LS_DIR", "PG_LS_LOGDIR", "PG_LS_WALDIR",
            "PG_STAT_FILE", "SYS_EXEC", "RUNSCRIPT", "SCRIPT",
            "FILE_READ", "FILE_WRITE", "BACKUP", "CSVWRITE", "CSVREAD",
            // F9（plan 2026-08-14-1133-1）：PG 脚本执行 / 时序攻击 / 系统目录族 + CTE（WITH tradeoff 见上）
            "DO", "PG_SLEEP", "PG_CATALOG", "PG_STAT_USER_TABLES",
            "WITH");

    /** 多 token 危险序列（归一化分词后的连续 token 序列）。 */
    private static final String[][] CUSTOM_SQL_FORBIDDEN_SEQUENCES = {
            {"INTO", "OUTFILE"},
            {"INTO", "DUMPFILE"},
            {"LOAD", "DATA"},
            {"LOAD", "XML"},
            {"MYSQL", "USER"},
            {"MYSQL", "SCHEMAS"}
    };

    /** 维度13-03：sqlHash 用的固定 salt（不防碰撞，只防明文反查，便于审计）。 */
    private static final String SQL_HASH_SALT = "nop.metadata.custom_sql.v1";

    private static Set<String> unmodifiableSet(String... items) {
        HashSet<String> s = new HashSet<>(Arrays.asList(items));
        return java.util.Collections.unmodifiableSet(s);
    }

    /**
     * 执行单条质量规则并返回判定结果（消费 {@link TableReference}，架构基线 §4.4.3 D3）。
     *
     * @param conn           已打开的连接（external/sql 由 withConnection 提供，entity 由平台 IJdbcTransaction 提供）
     * @param ref            table-reference（external/entity/sql 三态）
     * @param schemaPattern  schema 限定（null/空串表示依赖连接默认 schema；sql 子查询忽略此参数）
     * @param ruleType       规则类型（not_null/unique/range/regex/custom_sql/freshness/volume）
     * @param entityType     对象类型（field/table/database）
     * @param paramsJson     规则 params JSON 文本（可能为 null/空）
     * @param sqlExpression  规则 sqlExpression 列（custom_sql 优先使用，可能为 null）
     * @param threshold      规则阈值（可能为 null）
     * @param productName    DB 产品名（运行时取自 DatabaseMetaData，放入 details）
     * @return 判定结果（status/actualValue/expectedValue/message/details 全显式填充）
     */
    public QualityRuleJudgment judge(Connection conn, TableReference ref, String schemaPattern,
                                     String ruleType, String entityType,
                                     String paramsJson, String sqlExpression,
                                     Double threshold, String productName) {
        // 基础校验：external/entity 物理表名必须是合法标识符（防注入）；sql 子查询不校验（用户显式提供）
        if (!ref.isSubquery()) {
            validateIdentifier(ref.getPhysicalTableName());
        }

        String displayTable = ref.isSubquery()
                ? "(" + ref.getSourceSql() + ") _t" : ref.getPhysicalTableName();

        Map<String, Object> params = parseParams(paramsJson);
        QualityRuleJudgment j = new QualityRuleJudgment();
        j.getDetails().put("ruleType", ruleType);
        j.getDetails().put("entityType", entityType);
        j.getDetails().put("tableName", displayTable);
        j.getDetails().put("tableType", ref.getKind().name().toLowerCase(Locale.ROOT));
        if (threshold != null) {
            j.getDetails().put("threshold", threshold);
        }
        if (productName != null) {
            j.getDetails().put("databaseProductName", productName);
        }
        if (!ref.isSubquery() && schemaPattern != null && !schemaPattern.trim().isEmpty()) {
            j.getDetails().put("schema", schemaPattern);
        }

        // entityType=database 首版不支持（§2.7.1 D1）→ SKIP + details 标记
        if ("database".equals(entityType)) {
            j.setStatus("SKIP");
            j.setMessage("entityType=database not supported in first version (external-table-only execution)");
            j.getDetails().put("reason", "database-not-supported-first-version");
            return j;
        }

        switch (ruleType) {
            case "volume":
                return judgeVolume(conn, ref, schemaPattern, threshold, params, j);
            case "freshness":
                return judgeFreshness(conn, ref, schemaPattern, threshold, params, j);
            case "custom_sql":
                return judgeCustomSql(conn, sqlExpression, params, j);
            case "not_null":
                return judgeNotNull(conn, ref, schemaPattern, threshold, params, j);
            case "unique":
                return judgeUnique(conn, ref, schemaPattern, params, j);
            case "range":
                return judgeRange(conn, ref, schemaPattern, params, j);
            case "regex":
                return judgeRegex(conn, ref, schemaPattern, params, j);
            default:
                j.setStatus("ERROR");
                j.setMessage("Unsupported ruleType: " + ruleType);
                return j;
        }
    }

    // ===== table 级规则 =====

    /** volume：SELECT COUNT(*) → actualValue=行数；与 minRows/maxRows/threshold 比较。 */
    private QualityRuleJudgment judgeVolume(Connection conn, TableReference ref, String schemaPattern,
                                            Double threshold, Map<String, Object> params, QualityRuleJudgment j) {
        String qualified = buildFromClause(ref, schemaPattern);
        long rowCount = queryLong(conn, "SELECT COUNT(*) FROM " + qualified);
        j.setActualValue((double) rowCount);

        Double minRows = getDouble(params, "minRows");
        Double maxRows = getDouble(params, "maxRows");
        // 若 params 未给 min/max，回退用 threshold 作为 minRows（最小行数语义）
        if (minRows == null && maxRows == null && threshold != null) {
            minRows = threshold;
        }
        if (minRows != null) {
            j.setExpectedValue(minRows);
        }
        j.getDetails().put("minRows", minRows);
        j.getDetails().put("maxRows", maxRows);

        boolean pass = true;
        if (minRows != null && rowCount < minRows) {
            pass = false;
        }
        if (maxRows != null && rowCount > maxRows) {
            pass = false;
        }
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "volume ok: rowCount=" + rowCount
                : "volume fail: rowCount=" + rowCount + " outside [" + minRows + "," + maxRows + "]");
        return j;
    }

    /** freshness：SELECT MAX(tsCol) → age(now-maxTs) 分钟；与 maxAgeMinutes/threshold 比较。 */
    private QualityRuleJudgment judgeFreshness(Connection conn, TableReference ref, String schemaPattern,
                                               Double threshold, Map<String, Object> params, QualityRuleJudgment j) {
        String tsCol = getString(params, "timestampColumn");
        if (tsCol == null || tsCol.isEmpty()) {
            j.setStatus("ERROR");
            j.setMessage("freshness rule missing required param 'timestampColumn'");
            return j;
        }
        if (isDerivedColumnName(tsCol)) {
            return skipDerivedColumn(tsCol, j);
        }
        validateIdentifier(tsCol);
        j.getDetails().put("timestampColumn", tsCol);

        String qualified = buildFromClause(ref, schemaPattern);
        Timestamp maxTs = queryTimestamp(conn, "SELECT MAX(" + tsCol + ") FROM " + qualified);
        if (maxTs == null) {
            j.setStatus("ERROR");
            j.setMessage("freshness cannot be computed: no rows with timestamp value in column " + tsCol);
            return j;
        }
        j.getDetails().put("maxTimestamp", maxTs.toString());

        Double maxAgeMinutes = getDouble(params, "maxAgeMinutes");
        if (maxAgeMinutes == null && threshold != null) {
            maxAgeMinutes = threshold;
        }
        long ageMinutes = ageMinutesFromNow(maxTs);
        j.setActualValue((double) ageMinutes);
        if (maxAgeMinutes != null) {
            j.setExpectedValue(maxAgeMinutes);
        }
        j.getDetails().put("maxAgeMinutes", maxAgeMinutes);
        // AR-15（R8.1）：暴露原始差值（可为负——DB 时钟超前/未来时间戳），供判定与审计追溯
        j.getDetails().put("rawAgeMinutes", ageMinutes);

        boolean pass = true;
        String failReason = null;
        if (ageMinutes < 0) {
            // AR-15 fail-loud 语义裁定：负年龄（未来时间戳）不再恒 PASS——时钟偏移异常本身即新鲜度违约，
            // 钳制为 0 会继续掩盖违约。显式 FAIL + details 暴露原始差值。
            pass = false;
            failReason = "maxTimestamp is in the future (clock skew suspected)";
        } else if (maxAgeMinutes != null && ageMinutes > maxAgeMinutes) {
            pass = false;
            failReason = "ageMinutes=" + ageMinutes + " exceeds maxAgeMinutes=" + maxAgeMinutes;
        }
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "freshness ok: ageMinutes=" + ageMinutes + " (maxTs=" + maxTs + ")"
                : "freshness fail: " + failReason + " (maxTs=" + maxTs + ", ageMinutes=" + ageMinutes + ")");
        return j;
    }

    /**
     * custom_sql：执行 sqlExpression（优先）或 params.sql；期望返回单数值/单布尔；按 params.expectPassWhen 判定。
     *
     * <p>维度13-03 沙箱化（核心防御）：
     * <ul>
     *   <li><b>SQL 内容白名单</b>（关键，不依赖 PreparedStatement）：拒绝含分号（多语句）、UNION、
     *       INTO OUTFILE、LOAD DATA 等危险关键字。先 trim + 大写后匹配。</li>
     *   <li>在 details 写入 {@code sqlHash}（SHA-256 短摘要）用于审计，便于追溯哪条规则执行了什么 SQL。</li>
     *   <li>ErrorCode 描述明确"custom_sql 规则在外部数据源账户上执行"，强化运维认知。</li>
     *   <li>{@code querySingleValue} 改用 PreparedStatement（AR-12，纯风格统一，不解决注入）。</li>
     * </ul>
     */
    private QualityRuleJudgment judgeCustomSql(Connection conn, String sqlExpression,
                                               Map<String, Object> params, QualityRuleJudgment j) {
        String sql = sqlExpression;
        if (sql == null || sql.isEmpty()) {
            sql = getString(params, "sql");
        }
        if (sql == null || sql.isEmpty()) {
            j.setStatus("ERROR");
            j.setMessage("custom_sql rule missing both sqlExpression column and params.sql");
            return j;
        }
        // 维度13-03：(b) SQL 内容白名单——拒绝危险关键字（不依赖 PreparedStatement，因 SQL 文本是用户配置）
        String ruleKey = getString(params, "ruleKey");
        String sqlHash = sqlHashOf(sql);
        j.getDetails().put("sqlHash", sqlHash);
        // 沙箱校验在执行前；custom_sql 为用户显式提供（已知显式风险，§2.7.1 D3），白名单是其唯一防御
        validateCustomSqlSandbox(sql, ruleKey, sqlHash);
        // P2-07（plan 2026-08-16-0226-1）：QualityResult.details 不再持久化 SQL 全文——权威存储
        // 在规则本体（NopMetaQualityRule.sqlExpression 列优先 / params.sql JSON），details.sql 属
        // 每结果行重复落盘；details 只保留 sqlHash（:321 已写入）供审计追溯，与 AR-16 裁定的
        // 日志面"只记 sqlHash"语义对齐（持久化面/日志面同数据族同脱敏口径）

        Double value;
        try {
            value = querySingleValue(conn, sql);
        } catch (SQLException e) {
            LOG.error("custom_sql execution failed: errorCode={} sqlHash={}",
                    NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode(), sqlHash, e);
            j.setStatus("ERROR");
            j.setMessage("custom_sql execution failed (executes on external data source account): ["
                    + NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode() + "] " + messageOf(e));
            return j;
        }
        if (value == null) {
            j.setStatus("ERROR");
            j.setMessage("custom_sql did not return a single numeric/boolean value");
            return j;
        }
        j.setActualValue(value);

        String expectPassWhen = getString(params, "expectPassWhen");
        boolean pass;
        if (expectPassWhen == null || expectPassWhen.isEmpty()) {
            // 默认：返回 0 = pass
            pass = value == 0.0;
            j.getDetails().put("expectPassWhen", "default: eq 0");
        } else {
            // AR-13（R8.1）：调用点线程化传入真实 ruleKey（judgeCustomSql :285 已有 ruleKey 变量），
            // 错误上下文可归属（替换字面量 <evalExpectPassWhen>）
            pass = evalExpectPassWhen(expectPassWhen, value, ruleKey);
            j.getDetails().put("expectPassWhen", expectPassWhen);
        }
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "custom_sql ok: returned " + value + " satisfies " + expectPassWhen
                : "custom_sql fail: returned " + value + " does not satisfy " + (expectPassWhen == null ? "eq 0" : expectPassWhen));
        return j;
    }

    /**
     * 维度13-03：SQL 内容白名单校验（MA7.1-02 修复：token 级匹配替代子串匹配）。
     * <p><b>核心防御</b>：PreparedStatement 不解决 custom_sql 注入（SQL 文本本身是用户配置），
     * 因此白名单是唯一可控的注入面收口。失败时显式抛 ErrorCode（不静默跳过、不返回 0）。
     *
     * <p><b>匹配算法</b>：先拒绝 {@code ;}（多语句）与 MySQL 可执行注释（{@code /*!} 开头，剥离即绕过）；
     * 然后剥离普通注释（块注释、{@code --} 行注释、{@code #} 行注释）并归一化空白，再按非字母数字
     * 分词：单 token 黑名单条目做 token 集合精确匹配，多 token 条目做连续 token 序列匹配。
     * 归一化使空白/注释/反引号变体（{@code INTO\tOUTFILE}、注释分隔的 {@code INTO} 与 {@code OUTFILE}、
     * 反引号限定 {@code mysql}.{@code user}）全部命中。fail-closed：字符串字面量内含黑名单 token
     * （如 {@code SELECT 'UNION'}）同样被拒，属预期行为（宁可误拒不放过）。
     *
     * <p><b>安全边界</b>：黑名单覆盖截至 2026-08-06 已确认的已知危险关键字——DML 族
     * （INSERT/UPDATE/DELETE/MERGE/REPLACE）、TCL 族（COMMIT/ROLLBACK/SAVEPOINT/SET/TRANSACTION）、
     * RENAME/LOCK/UNLOCK、PostgreSQL 文件/目录访问族（PG_READ_BINARY_FILE/PG_LS_LOGDIR/PG_LS_WALDIR/
     * PG_STAT_FILE/COPY 等）、脚本导出族（H2 RUNSCRIPT/SCRIPT、SYS_EXEC）与 H2 文件读写族
     * （FILE_READ/FILE_WRITE/BACKUP/CSVWRITE/CSVREAD）；条目集合与 {@code ExpressionMeasureValidator.KEYWORD_BLACKLIST}
     * 逐项对齐（AR-04/AR-05 补齐）。future SQL 方言新增的同类关键字需阶段性审查更新。
     * 本校验不检查 SQL 语义——PreparedStatement 参数绑定通道由调用方保证。
     */
    static void validateCustomSqlSandbox(String sql, String ruleKey, String sqlHash) {
        if (sql == null) {
            return;
        }
        String upper = sql.trim().toUpperCase(Locale.ROOT);
        if (upper.contains(";")) {
            throw customSqlBlocked("forbidden keyword present: ;", ruleKey, sqlHash);
        }
        if (upper.contains("/*!")) {
            // MySQL 可执行注释 /*!...*/ 会被服务器执行，剥离后校验 = 绕过，故显式拒绝
            throw customSqlBlocked("executable comment present: /*!", ruleKey, sqlHash);
        }
        List<String> tokens = tokenizeSqlForSandbox(upper);
        for (String word : CUSTOM_SQL_FORBIDDEN_WORDS) {
            if (tokens.contains(word)) {
                throw customSqlBlocked("forbidden keyword present: " + word, ruleKey, sqlHash);
            }
        }
        for (String[] sequence : CUSTOM_SQL_FORBIDDEN_SEQUENCES) {
            if (containsTokenSequence(tokens, sequence)) {
                throw customSqlBlocked("forbidden keyword present: " + String.join(" ", sequence), ruleKey, sqlHash);
            }
        }
    }

    private static NopException customSqlBlocked(String reason, String ruleKey, String sqlHash) {
        return new NopMetadataException(NopMetadataErrors.ERR_QUALITY_CUSTOM_SQL_BLOCKED)
                .param("ruleKey", String.valueOf(ruleKey))
                .param("reason", reason)
                .param("sqlHash", sqlHash);
    }

    /** 归一化 SQL：剥离普通注释（块注释/行注释）并折叠空白，返回大写 token 流文本。 */
    private static List<String> tokenizeSqlForSandbox(String upperSql) {
        String s = upperSql.replaceAll("/\\*.*?\\*/", " ");
        s = s.replaceAll("--[^\\n]*", " ");
        s = s.replaceAll("#[^\\n]*", " ");
        s = s.replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) {
            return new ArrayList<>();
        }
        List<String> tokens = new ArrayList<>();
        for (String token : s.split("[^A-Za-z0-9_]+")) {
            if (!token.isEmpty()) {
                tokens.add(token);
            }
        }
        return tokens;
    }

    private static boolean containsTokenSequence(List<String> tokens, String[] sequence) {
        if (tokens.size() < sequence.length) {
            return false;
        }
        for (int i = 0; i <= tokens.size() - sequence.length; i++) {
            boolean match = true;
            for (int j = 0; j < sequence.length; j++) {
                if (!sequence[j].equals(tokens.get(i + j))) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return true;
            }
        }
        return false;
    }

    /** 维度13-03：SHA-256 短摘要（前 16 字符 hex）用于审计追溯，不防碰撞。null 返回 null。 */
    public static String sqlHashOf(String sql) {
        if (sql == null) {
            return null;
        }
        String full = StringHelper.sha256Hash(sql, SQL_HASH_SALT);
        return full == null ? null : full.substring(0, Math.min(16, full.length()));
    }

    // ===== field 级规则（external params.column 约定）=====

    /** not_null：SELECT COUNT(*) WHERE col IS NULL → actualValue=nullCount；expectedValue=threshold(默认0)。 */
    private QualityRuleJudgment judgeNotNull(Connection conn, TableReference ref, String schemaPattern,
                                             Double threshold, Map<String, Object> params, QualityRuleJudgment j) {
        String col = requireColumn(params, j);
        if (col == null) {
            return j;
        }
        String qualified = buildFromClause(ref, schemaPattern);
        long nullCount = queryLong(conn,
                "SELECT COUNT(*) FROM " + qualified + " WHERE " + col + " IS NULL");
        j.setActualValue((double) nullCount);
        double allowed = threshold != null ? threshold : 0.0;
        j.setExpectedValue(allowed);
        boolean pass = nullCount <= allowed;
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "not_null ok: nullCount=" + nullCount + " <= " + allowed
                : "not_null fail: nullCount=" + nullCount + " exceeds threshold " + allowed);
        return j;
    }

    /** unique：SELECT COUNT(*) FROM (SELECT col WHERE col IS NOT NULL GROUP BY col HAVING COUNT(*)>1) → 重复值组数。 */
    private QualityRuleJudgment judgeUnique(Connection conn, TableReference ref, String schemaPattern,
                                            Map<String, Object> params, QualityRuleJudgment j) {
        String col = requireColumn(params, j);
        if (col == null) {
            return j;
        }
        String qualified = buildFromClause(ref, schemaPattern);
        long dupGroups = queryLong(conn,
                "SELECT COUNT(*) FROM (SELECT " + col + " FROM " + qualified
                        + " WHERE " + col + " IS NOT NULL GROUP BY " + col + " HAVING COUNT(*)>1) d");
        j.setActualValue((double) dupGroups);
        j.setExpectedValue(0.0);
        boolean pass = dupGroups == 0;
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "unique ok: no duplicate value groups"
                : "unique fail: " + dupGroups + " duplicate value groups found");
        return j;
    }

    /** range：SELECT COUNT(*) WHERE col IS NOT NULL AND (col < :min OR col > :max) → 越界行数；expectedValue=0。 */
    private QualityRuleJudgment judgeRange(Connection conn, TableReference ref, String schemaPattern,
                                           Map<String, Object> params, QualityRuleJudgment j) {
        String col = requireColumn(params, j);
        if (col == null) {
            return j;
        }
        Double min = getDouble(params, "min");
        Double max = getDouble(params, "max");
        if (min == null && max == null) {
            j.setStatus("ERROR");
            j.setMessage("range rule requires at least one of params.min / params.max");
            return j;
        }
        j.getDetails().put("min", min);
        j.getDetails().put("max", max);

        String qualified = buildFromClause(ref, schemaPattern);
        // 边界缺失时用一个不触发的哨兵值占位（保证 SQL 语法合法且语义正确）
        boolean hasMin = min != null;
        boolean hasMax = max != null;
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM ").append(qualified)
                .append(" WHERE ").append(col).append(" IS NOT NULL AND (");
        if (hasMin) {
            sql.append(col).append(" < ?");
        }
        if (hasMin && hasMax) {
            sql.append(" OR ");
        }
        if (hasMax) {
            sql.append(col).append(" > ?");
        }
        sql.append(")");

        long outOfRange;
        try (PreparedStatement st = conn.prepareStatement(sql.toString())) {
            int idx = 1;
            if (hasMin) {
                st.setDouble(idx++, min);
            }
            if (hasMax) {
                st.setDouble(idx, max);
            }
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    // P2-13：COUNT(*) 无行是可预期业务分支（表空），非 SQL 故障——显式建模为 ERROR 判定，
                    // 不再以哨兵 SQLException 作方法内控制流信号（judgment 输出与原 catch 路径逐字段等价）。
                    LOG.error("range SQL execution failed: errorCode={}",
                            NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode());
                    j.setStatus("ERROR");
                    j.setMessage("range SQL execution failed: ["
                            + NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode()
                            + "] range COUNT(*) returned no row");
                    return j;
                }
                outOfRange = rs.getLong(1);
            }
        } catch (SQLException e) {
            LOG.error("range SQL execution failed: errorCode={}",
                    NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode(), e);
            j.setStatus("ERROR");
            j.setMessage("range SQL execution failed: ["
                    + NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode() + "] " + messageOf(e));
            return j;
        }
        j.setActualValue((double) outOfRange);
        j.setExpectedValue(0.0);
        boolean pass = outOfRange == 0;
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "range ok: no out-of-range rows"
                : "range fail: " + outOfRange + " rows outside [" + min + "," + max + "]");
        return j;
    }

    /** regex：SELECT COUNT(*) WHERE col IS NOT NULL AND col NOT REGEXP :pattern → 不匹配数；方言不支持 → SKIP。 */
    private QualityRuleJudgment judgeRegex(Connection conn, TableReference ref, String schemaPattern,
                                           Map<String, Object> params, QualityRuleJudgment j) {
        String col = requireColumn(params, j);
        if (col == null) {
            return j;
        }
        String pattern = getString(params, "pattern");
        if (pattern == null || pattern.isEmpty()) {
            j.setStatus("ERROR");
            j.setMessage("regex rule missing required param 'pattern'");
            return j;
        }
        j.getDetails().put("pattern", pattern);

        String qualified = buildFromClause(ref, schemaPattern);
        String sql = "SELECT COUNT(*) FROM " + qualified
                + " WHERE " + col + " IS NOT NULL AND " + col + " NOT REGEXP ?";
        long notMatching;
        try (PreparedStatement st = conn.prepareStatement(sql)) {
            st.setString(1, pattern);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    // P2-13：COUNT(*) 无行是可预期业务分支（表空），非 SQL 故障——显式建模为 ERROR 判定，
                    // 不再以哨兵 SQLException 作方法内控制流信号（judgment 输出与原 catch 路径逐字段等价）。
                    LOG.error("regex SQL execution failed: errorCode={}",
                            NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode());
                    j.setStatus("ERROR");
                    j.setMessage("regex SQL execution failed: ["
                            + NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode()
                            + "] regex COUNT(*) returned no row");
                    return j;
                }
                notMatching = rs.getLong(1);
            }
        } catch (SQLException e) {
            // 方言不支持 REGEXP → SKIP + details 标记（不静默跳过、不伪造值）
            if (isRegexpUnsupported(e)) {
                LOG.warn("regex skipped: dialect does not support REGEXP operator", e);
                j.setStatus("SKIP");
                j.setMessage("regex skipped: dialect does not support REGEXP operator (" + messageOf(e) + ")");
                j.getDetails().put("reason", "regexp-unsupported-dialect");
                return j;
            }
            LOG.error("regex SQL execution failed: errorCode={}",
                    NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode(), e);
            j.setStatus("ERROR");
            j.setMessage("regex SQL execution failed: ["
                    + NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode() + "] " + messageOf(e));
            return j;
        }
        j.setActualValue((double) notMatching);
        j.setExpectedValue(0.0);
        boolean pass = notMatching == 0;
        j.setStatus(pass ? "PASS" : "FAIL");
        j.setMessage(pass
                ? "regex ok: all non-null values match pattern"
                : "regex fail: " + notMatching + " non-null values do not match pattern " + pattern);
        return j;
    }

    // ===== helpers =====

    private String requireColumn(Map<String, Object> params, QualityRuleJudgment j) {
        String col = getString(params, "column");
        if (col == null || col.isEmpty()) {
            j.setStatus("ERROR");
            j.setMessage("field-level rule missing required param 'column'");
            return null;
        }
        // D5：sql 视图 <expr_N> 合成列通不过标识符白名单 → 显式 SKIP + details 标记（不整表失败、不静默跳过）
        if (isDerivedColumnName(col)) {
            skipDerivedColumn(col, j);
            return null;
        }
        validateIdentifier(col);
        j.getDetails().put("column", col);
        return col;
    }

    /** D5：检测 sql 视图合成列名（形如 {@code <expr_N>}，含 {@code <>} 非标识符字符）。 */
    static boolean isDerivedColumnName(String col) {
        return col != null && col.startsWith("<") && col.contains("expr");
    }

    /** D5：对合成列显式 SKIP + details 标记 {@code reason=derived-column-skipped}（不整表失败、不伪造）。 */
    private QualityRuleJudgment skipDerivedColumn(String col, QualityRuleJudgment j) {
        j.setStatus("SKIP");
        j.setMessage("field-level rule skipped: column '" + col + "' is a derived expression column "
                + "(sql view synthetic name, not a queryable identifier)");
        j.getDetails().put("reason", "derived-column-skipped");
        j.getDetails().put("column", col);
        return j;
    }

    /**
     * 构建 FROM 子句目标（架构基线 §4.4.3 D3）：
     * external/entity → {@code <schema>.<tableName>}；sql → {@code (<sourceSql>) _t}。
     */
    static String buildFromClause(TableReference ref, String schemaPattern) {
        if (ref.isSubquery()) {
            return "(" + ref.getSourceSql() + ") _t";
        }
        String tableName = ref.getPhysicalTableName();
        return qualifyTable(normalizeSchema(schemaPattern), tableName);
    }

    private static long queryLong(Connection conn, String sql) {
        // AR-16（R8.2）：完整 SQL 降 DEBUG 级；INFO 级只记 sqlHash（SQL 可内嵌敏感字面量——
        // sql 子查询引用 sourceSql / 比较值参数化前，日志面脱敏保持可追溯性）
        LOG.info("qualityRule SQL executed: sqlHash={}", sqlHashOf(sql));
        LOG.debug("qualityRule SQL: {}", sql);
        try (PreparedStatement st = conn.prepareStatement(sql); ResultSet rs = st.executeQuery()) {
            if (!rs.next()) {
                // AR-13（R8.1）：静态调用链无 ruleKey 上下文——ErrorCode 声明已改为 {sqlHash}；
                // 不设完整 SQL 参数（NopException.getMessage 会无条件拼入 params，完整 SQL 落日志
                // 与 R8.2 AR-16 脱敏目标冲突）
                throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_SQL_NO_ROW)
                        .param(NopMetadataErrors.ARG_SQL_HASH, sqlHashOf(sql));
            }
            return rs.getLong(1);
        } catch (SQLException e) {
            // AR-13: ErrorCode 描述含 {error} 占位符，throw 时同时设置 sqlHash + error 参数（原仅设置 sql）
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_SQL_FAILED, e)
                    .param(NopMetadataErrors.ARG_SQL_HASH, sqlHashOf(sql))
                    .param(NopMetadataErrors.ARG_ERROR, messageOf(e));
        }
    }

    private static Timestamp queryTimestamp(Connection conn, String sql) {
        // AR-16（R8.2）：完整 SQL 降 DEBUG 级；INFO 级只记 sqlHash（同 queryLong 脱敏语义）
        LOG.info("qualityRule SQL executed: sqlHash={}", sqlHashOf(sql));
        LOG.debug("qualityRule SQL: {}", sql);
        try (PreparedStatement st = conn.prepareStatement(sql); ResultSet rs = st.executeQuery()) {
            if (!rs.next()) {
                return null;
            }
            return rs.getTimestamp(1);
        } catch (SQLException e) {
            // AR-13: ErrorCode 描述含 {error} 占位符，throw 时同时设置 sqlHash + error 参数（原仅设置 sql）
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_SQL_FAILED, e)
                    .param(NopMetadataErrors.ARG_SQL_HASH, sqlHashOf(sql))
                    .param(NopMetadataErrors.ARG_ERROR, messageOf(e));
        }
    }

    /**
     * 执行 custom_sql，期望返回单数值或单布尔；否则返回 null（由调用方记 ERROR）。
     *
     * <p>AR-12：与 queryLong/queryTimestamp 一致改用 PreparedStatement（纯风格统一）。
     * 维度13-03：<b>PreparedStatement 不解决 custom_sql 注入</b>（SQL 文本本身是用户配置），
     * 因此调用方 {@link #judgeCustomSql} 在调用前已做 SQL 内容白名单校验（拒绝分号/UNION/INTO OUTFILE 等）。
     */
    private static Double querySingleValue(Connection conn, String sql) throws SQLException {
        // AR-16（R8.2）：custom_sql 文本可内嵌敏感字面量（姓名/卡号等）——完整 SQL 降 DEBUG 级，
        // INFO 级只记 sqlHash（judgeCustomSql :295 已写入 details 的同一摘要，保持可追溯性）
        LOG.info("qualityRule custom_sql executed: sqlHash={}", sqlHashOf(sql));
        LOG.debug("qualityRule custom_sql: {}", sql);
        try (PreparedStatement st = conn.prepareStatement(sql); ResultSet rs = st.executeQuery()) {
            if (!rs.next()) {
                return null;
            }
            // 优先按数值读
            try {
                double d = rs.getDouble(1);
                if (!rs.wasNull()) {
                    return d;
                }
            } catch (SQLException ignore) {
                // 非数值列，尝试按布尔读
                LOG.debug(NopMetadataErrors.ERR_QUALITY_RULE_TYPE_PROBE_FAILED.getErrorCode()
                        + ": numeric column probe failed, falling back to boolean read", ignore);
            }
            // 回退按布尔读（true=1, false=0）
            try {
                boolean b = rs.getBoolean(1);
                return b ? 1.0 : 0.0;
            } catch (SQLException ignore) {
                LOG.debug(NopMetadataErrors.ERR_QUALITY_RULE_TYPE_PROBE_FAILED.getErrorCode()
                        + ": boolean column probe failed, returning null", ignore);
                return null;
            }
        }
    }

    private static boolean evalExpectPassWhen(String expectPassWhen, double value, String ruleKey) {
        String s = expectPassWhen.trim().toLowerCase(Locale.ROOT);
        try {
            if ("true".equals(s) || "eq 1".equals(s) || "eq1".equals(s)) {
                return value == 1.0;
            }
            if (s.startsWith("eq ")) {
                return value == Double.parseDouble(s.substring(3).trim());
            }
            if (s.startsWith("gt ")) {
                return value > Double.parseDouble(s.substring(3).trim());
            }
            if (s.startsWith("lt ")) {
                return value < Double.parseDouble(s.substring(3).trim());
            }
            if (s.startsWith("ge ")) {
                return value >= Double.parseDouble(s.substring(3).trim());
            }
            if (s.startsWith("le ")) {
                return value <= Double.parseDouble(s.substring(3).trim());
            }
            // 默认 eq 0
            return value == 0.0;
        } catch (NumberFormatException e) {
            // plan 2026-07-19-1250-3 Phase 5 AR-11：显式抛 ErrorCode（与模块内其它 ErrorCode 路径一致）
            // expectPassWhen 配置错误属于规则定义问题，应快速失败（裁定为 ERR_QUALITY_EXPECT_PASS_WHEN_INVALID）。
            // AR-13（R8.1）：错误上下文从字面量 <evalExpectPassWhen> 改为真实 ruleKey（judgeCustomSql 内可归属）
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_EXPECT_PASS_WHEN_INVALID, e)
                    .param(NopMetadataErrors.ARG_QUALITY_RULE_ID, ruleKey)
                    .param(NopMetadataErrors.ARG_EXPR, expectPassWhen);
        }
    }

    /**
     * 方言不支持 REGEXP 的签名集合（AR-11/R8.1 收窄：子串启发式 → 签名匹配）。
     *
     * <ul>
     *   <li><b>"not supported"</b> —— 通用"不支持"声明（低版本/嵌入式方言）</li>
     *   <li><b>"unknown function"</b> —— REGEXP 未实现为内建函数时的声明</li>
     *   <li><b>"syntax error at or near"</b> —— PostgreSQL 真实签名：PG 不支持 REGEXP 运算符，
     *       报错即含此短语</li>
     * </ul>
     *
     * <p>显式<b>排除</b>裸 "regexp"/"syntax" 子串：MySQL（支持 REGEXP）非法 pattern 报错
     * "Got error ... from regexp" 含 "regexp"、H2 非法 pattern 消息可能含 "syntax"——这些是
     * <b>规则级正则错误</b>（方言支持 REGEXP），必须走 ERROR 而非 SKIP（AR-11：失败规则不得
     * 从 pass/fail 统计中静默消失）。
     */
    private static final String[] REGEXP_UNSUPPORTED_SIGNATURES = {
            "not supported",
            "unknown function",
            "syntax error at or near"
    };

    private static boolean isRegexpUnsupported(SQLException e) {
        String msg = e.getMessage();
        if (msg == null) {
            return false;
        }
        String lower = msg.toLowerCase(Locale.ROOT);
        for (String signature : REGEXP_UNSUPPORTED_SIGNATURES) {
            if (lower.contains(signature)) {
                return true;
            }
        }
        return false;
    }

    static long ageMinutesFromNow(Timestamp ts) {
        long nowMs = CoreMetrics.currentTimeMillis();
        long tsMs = ts.getTime();
        long diffMs = nowMs - tsMs;
        return diffMs / 60000L;
    }

    /** schema 限定：<schema>.<tableName>；schema 为空时用 <tableName>（依赖连接默认 schema）。与 Catalog 一致。 */
    static String qualifyTable(String schema, String tableName) {
        if (schema == null || schema.isEmpty()) {
            return tableName;
        }
        return schema + "." + tableName;
    }

    private static String normalizeSchema(String schemaPattern) {
        if (schemaPattern == null || schemaPattern.trim().isEmpty()) {
            return null;
        }
        String trimmed = schemaPattern.trim();
        // AR-01: schemaPattern 与 tableName/列名一致走标识符白名单（防 SQL 注入家族）
        validateIdentifier(trimmed);
        return trimmed;
    }

    static void validateIdentifier(String identifier) {
        if (identifier == null || !IDENTIFIER_PATTERN.matcher(identifier).matches()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_INVALID_IDENTIFIER)
                    .param("identifier", String.valueOf(identifier));
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> parseParams(String paramsJson) {
        if (paramsJson == null || paramsJson.trim().isEmpty()) {
            return java.util.Collections.emptyMap();
        }
        Object parsed = JsonTool.parse(paramsJson);
        if (parsed instanceof Map) {
            return (Map<String, Object>) parsed;
        }
        return java.util.Collections.emptyMap();
    }

    private static String getString(Map<String, Object> params, String key) {
        Object v = params.get(key);
        return v == null ? null : String.valueOf(v);
    }

    private static Double getDouble(Map<String, Object> params, String key) {
        Object v = params.get(key);
        if (v == null) {
            return null;
        }
        if (v instanceof Number) {
            return ((Number) v).doubleValue();
        }
        try {
            return Double.parseDouble(String.valueOf(v));
        } catch (NumberFormatException e) {
            LOG.debug(NopMetadataErrors.ERR_QUALITY_RULE_TYPE_PROBE_FAILED.getErrorCode()
                    + ": numeric parse failed for getDouble param, returning null", e);
            return null;
        }
    }

    /**
     * 提取异常消息（null 时回退类名）；集中调用避免 catch 块内直接 e.getMessage() 丢失堆栈。
     *
     * <p>P2-08（plan 2026-08-16-0226-1）：消息进 judgment message / error param 前统一经
     * jdbc: URL 脱敏过滤（{@link MetaDataSourceConnectionProcessor#redactJdbcUrlsInText}）——
     * 单点覆盖本文件全部 messageOf 面（judgeCustomSql ERROR / judgeRange ERROR /
     * judgeRegex SKIP+ERROR / queryLong / queryTimestamp）。驱动消息可回显 userinfo 形态
     * 含口令的 URL，未过滤会击穿 jdbcUrl 侧 redactJdbcUrl 脱敏；无 jdbc: 命中时原样返回
     * （诊断信息不丢）。query 形态口令与无 {@code ://} 的 Oracle thin 形态不在脱敏范围
     * （F6 既有裁定语义边界）。
     */
    private static String messageOf(Throwable t) {
        String m = t.getMessage();
        return m != null ? MetaDataSourceConnectionProcessor.redactJdbcUrlsInText(m)
                : t.getClass().getName();
    }
}
