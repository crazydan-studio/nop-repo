package io.nop.metadata.service.entity;

import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.dao.api.IEntityDao;
import io.nop.dao.api.IDaoProvider;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaLineageEdge;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.dao.entity.NopMetaTableMeasure;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.field.ExpressionMeasureValidator;
import io.nop.metadata.service.field.MetaTableFieldResolver;
import io.nop.metadata.service.lineage.ColumnLineageCandidate;
import io.nop.metadata.service.lineage.SqlColumnLineageExtractor;
import io.nop.metadata.service.lineage.SqlSourceTableExtractor;
import io.nop.metadata.service.lineage.SqlTableReference;
import io.nop.metadata.service.NopMetadataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class NopMetaLineageEdgeQueryAction {

    private static final Logger LOG = LoggerFactory.getLogger(NopMetaLineageEdgeQueryAction.class);

    private final SqlSourceTableExtractor sqlExtractor = new SqlSourceTableExtractor();
    private final SqlColumnLineageExtractor columnExtractor = new SqlColumnLineageExtractor();
    private final MetaTableFieldResolver fieldResolver = new MetaTableFieldResolver();

    private final int maxEdges;
    private final int maxTables;

    public NopMetaLineageEdgeQueryAction(int maxEdges, int maxTables) {
        this.maxEdges = maxEdges > 0 ? maxEdges : NopMetaLineageEdgeBizModel.DEFAULT_LINEAGE_MAX_EDGES;
        this.maxTables = maxTables > 0 ? maxTables : NopMetaLineageEdgeBizModel.DEFAULT_LINEAGE_MAX_TABLES;
    }

    public List<String> getUpstream(String metaTableId, IEntityDao<NopMetaLineageEdge> dao) {
        LineageGraph graph = buildLineageGraph(dao);
        Set<String> visited = new HashSet<>();
        visited.add(metaTableId);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(metaTableId);
        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String cur = queue.poll();
            List<String> sources = graph.reverse.get(cur);
            if (sources != null) {
                for (String src : sources) {
                    if (visited.add(src)) {
                        result.add(src);
                        queue.add(src);
                    }
                }
            }
        }
        return result;
    }

    public List<String> getDownstream(String metaTableId, IEntityDao<NopMetaLineageEdge> dao) {
        LineageGraph graph = buildLineageGraph(dao);
        Set<String> visited = new HashSet<>();
        visited.add(metaTableId);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(metaTableId);
        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String cur = queue.poll();
            List<String> targets = graph.forward.get(cur);
            if (targets != null) {
                for (String tgt : targets) {
                    if (visited.add(tgt)) {
                        result.add(tgt);
                        queue.add(tgt);
                    }
                }
            }
        }
        return result;
    }

    public List<String> getLineagePath(String sourceTableId, String targetTableId,
                                        IEntityDao<NopMetaLineageEdge> dao) {
        LineageGraph graph = buildLineageGraph(dao);
        if (sourceTableId.equals(targetTableId)) {
            return Collections.singletonList(sourceTableId);
        }
        Map<String, String> prev = new HashMap<>();
        Set<String> visited = new HashSet<>();
        visited.add(sourceTableId);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(sourceTableId);
        boolean found = false;
        while (!queue.isEmpty() && !found) {
            String cur = queue.poll();
            List<String> targets = graph.forward.get(cur);
            if (targets == null) continue;
            for (String tgt : targets) {
                if (visited.add(tgt)) {
                    prev.put(tgt, cur);
                    if (tgt.equals(targetTableId)) {
                        found = true;
                        break;
                    }
                    queue.add(tgt);
                }
            }
        }
        if (!found) return Collections.emptyList();
        List<String> path = new ArrayList<>();
        String node = targetTableId;
        while (node != null) {
            path.add(node);
            node = prev.get(node);
        }
        Collections.reverse(path);
        return path;
    }

    public List<String> getImpactAnalysis(String metaTableId, String columnName,
                                           IEntityDao<NopMetaLineageEdge> dao) {
        LineageGraph graph = buildLineageGraph(dao);
        List<String> tableLevel = bfsForward(graph.forward, metaTableId);
        if (columnName == null || columnName.isEmpty()) return tableLevel;
        List<String> columnFiltered = bfsForwardByColumn(graph.columnForward, metaTableId, columnName);
        return columnFiltered.isEmpty() ? tableLevel : columnFiltered;
    }

    public LineageExtractResult extractLineageFromSql(String metaTableId,
                                                       IDaoProvider daoProvider,
                                                       IEntityDao<NopMetaLineageEdge> dao) {
        IEntityDao<NopMetaTable> tableDao = daoProvider.daoFor(NopMetaTable.class);
        NopMetaTable targetTable = tableDao.getEntityById(metaTableId);
        if (targetTable == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_SQL_TABLE_NOT_FOUND).param("metaTableId", metaTableId);
        }
        if (!_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(targetTable.getTableType())) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_NOT_SQL_VIEW_TABLE)
                    .param("metaTableId", metaTableId)
                    .param("tableType", targetTable.getTableType());
        }
        String sourceSql = targetTable.getSourceSql();
        if (sourceSql == null || sourceSql.trim().isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_SQL_SOURCE_EMPTY).param("metaTableId", metaTableId);
        }
        List<Map<String, Object>> errors = new ArrayList<>();
        List<SqlTableReference> refs;
        try {
            refs = sqlExtractor.extract(sourceSql);
        } catch (NopException e) {
            LOG.error("extractLineageFromSql failed for metaTableId={}, errorCode={}",
                    metaTableId, NopMetadataErrors.ERR_LINEAGE_QUERY_ISOLATED.getErrorCode(), e);
            errors.add(errorMap("sql_parse", e));
            refs = Collections.emptyList();
        }
        Map<String, String> nameToId = buildTableNameIndex(daoProvider);
        String targetId = targetTable.getMetaTableId();
        List<String> unresolved = new ArrayList<>();
        List<String> candidateSourceIds = new ArrayList<>();
        for (SqlTableReference ref : refs) {
            String sourceId = nameToId.get(ref.getSimpleName().toLowerCase(Locale.ROOT));
            if (sourceId == null) {
                unresolved.add(ref.getFullName());
                continue;
            }
            candidateSourceIds.add(sourceId);
        }
        Set<String> existingSourceIds = batchLoadExistingSqlParseSourceIds(candidateSourceIds, targetId, dao);
        List<NopMetaLineageEdge> newEdges = new ArrayList<>();
        for (String sourceId : candidateSourceIds) {
            if (!existingSourceIds.contains(sourceId)) {
                NopMetaLineageEdge edge = dao.newEntity();
                edge.setSourceTableId(sourceId);
                edge.setTargetTableId(targetId);
                edge.setLineageSource(_NopMetadataCoreConstants.LINEAGE_SOURCE_SQL_PARSE);
                edge.setTransformType(_NopMetadataCoreConstants.LINEAGE_TRANSFORM_DIRECT);
                newEdges.add(edge);
            }
        }
        if (!newEdges.isEmpty()) {
            dao.batchSaveEntities(newEdges);
        }
        return new LineageExtractResult(candidateSourceIds.size(),
                dedupPreservingOrder(candidateSourceIds), unresolved, errors);
    }

    public LineageExtractResult extractColumnLineageFromSql(String metaTableId,
                                                             IDaoProvider daoProvider,
                                                             IEntityDao<NopMetaLineageEdge> dao) {
        IEntityDao<NopMetaTable> tableDao = daoProvider.daoFor(NopMetaTable.class);
        NopMetaTable targetTable = tableDao.getEntityById(metaTableId);
        if (targetTable == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_SQL_TABLE_NOT_FOUND).param("metaTableId", metaTableId);
        }
        if (!_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(targetTable.getTableType())) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_NOT_SQL_VIEW_TABLE)
                    .param("metaTableId", metaTableId)
                    .param("tableType", targetTable.getTableType());
        }
        String sourceSql = targetTable.getSourceSql();
        if (sourceSql == null || sourceSql.trim().isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_SQL_SOURCE_EMPTY).param("metaTableId", metaTableId);
        }
        List<Map<String, Object>> errors = new ArrayList<>();
        List<ColumnLineageCandidate> candidates;
        try {
            candidates = columnExtractor.extract(sourceSql);
        } catch (NopException e) {
            LOG.error("extractColumnLineageFromSql failed for metaTableId={}, errorCode={}",
                    metaTableId, NopMetadataErrors.ERR_LINEAGE_QUERY_ISOLATED.getErrorCode(), e);
            errors.add(errorMap("sql_parse_column", e));
            candidates = Collections.emptyList();
        }
        Map<String, String> nameToId = buildTableNameIndex(daoProvider);
        String targetId = targetTable.getMetaTableId();
        List<String> unresolved = new ArrayList<>();
        List<String> resolvedSourceIds = new ArrayList<>();
        List<ColumnLineageCandidate> resolvedCandidates = new ArrayList<>();
        for (ColumnLineageCandidate c : candidates) {
            if (c.isUnresolvable()) {
                unresolved.add(c.getTargetColumn() + " <- " + String.valueOf(c.getSourceColumn())
                        + " (" + c.getUnresolvedReason() + ")");
                continue;
            }
            String sourceId = nameToId.get(c.getSourceTableName().toLowerCase(Locale.ROOT));
            if (sourceId == null) {
                unresolved.add(c.getTargetColumn() + " <- " + c.getSourceTableName() + "."
                        + c.getSourceColumn() + " (source-table-not-in-catalog)");
                continue;
            }
            resolvedSourceIds.add(sourceId);
            resolvedCandidates.add(c);
        }
        Map<List<String>, NopMetaLineageEdge> existingEdgeMap = batchLoadExistingColumnParseEdgeMap(resolvedSourceIds, targetId, dao);
        List<NopMetaLineageEdge> toSave = new ArrayList<>();
        List<NopMetaLineageEdge> toUpdate = new ArrayList<>();
        // 同批去重：同一表达式内重复列引用（如 a.x + a.x）产生同键候选，toSave 内待插项不在
        // existingEdgeMap 中，第二条同键候选会重复 INSERT（MA7.4-02）——用已见键集合拦截。
        // D5（Cycle 2，adjudication-table-cycle2 §5）：键为结构性 List（值级 equals/hashCode），
        // 非 "|" 拼接 String——带引号 SQL 派生列名可含 "|"，拼接键碰撞会导致第二条边被静默吞掉
        // （沿 AR-03 结构性键先例）。
        Set<List<String>> seenKeys = new HashSet<>();
        int extracted = 0;
        for (int i = 0; i < resolvedCandidates.size(); i++) {
            ColumnLineageCandidate c = resolvedCandidates.get(i);
            String sourceId = resolvedSourceIds.get(i);
            List<String> key = Arrays.asList(sourceId, c.getSourceColumn(), c.getTargetColumn());
            NopMetaLineageEdge existing = existingEdgeMap.get(key);
            if (existing == null && seenKeys.add(key)) {
                NopMetaLineageEdge edge = dao.newEntity();
                edge.setSourceTableId(sourceId);
                edge.setTargetTableId(targetId);
                edge.setSourceColumn(c.getSourceColumn());
                edge.setTargetColumn(c.getTargetColumn());
                edge.setLineageSource(_NopMetadataCoreConstants.LINEAGE_SOURCE_SQL_PARSE);
                edge.setTransformType(c.getTransformType());
                toSave.add(edge);
            } else if (existing != null && !c.getTransformType().equals(existing.getTransformType())) {
                existing.setTransformType(c.getTransformType());
                toUpdate.add(existing);
            }
            extracted++;
        }
        if (!toSave.isEmpty()) {
            dao.batchSaveEntities(toSave);
        }
        if (!toUpdate.isEmpty()) {
            dao.batchUpdateEntities(toUpdate);
        }
        return new LineageExtractResult(extracted, dedupPreservingOrder(resolvedSourceIds), unresolved, errors);
    }

    public LineageExtractResult extractMeasureLineage(String metaTableId,
                                                       IDaoProvider daoProvider,
                                                       IEntityDao<NopMetaLineageEdge> dao) {
        IEntityDao<NopMetaTable> tableDao = daoProvider.daoFor(NopMetaTable.class);
        NopMetaTable targetTable = tableDao.getEntityById(metaTableId);
        if (targetTable == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_TABLE_NOT_FOUND).param("tableId", metaTableId);
        }
        IEntityDao<NopMetaEntityField> fieldDao = daoProvider.daoFor(NopMetaEntityField.class);
        Set<String> fieldNames = fieldResolver.resolveFieldNames(targetTable, fieldDao);
        Set<String> fieldNamesLower = new HashSet<>(fieldNames.size());
        for (String n : fieldNames) {
            if (n != null) fieldNamesLower.add(n.toLowerCase(Locale.ROOT));
        }
        String targetId = targetTable.getMetaTableId();
        deleteMeasureParseEdges(targetId, dao);
        IEntityDao<NopMetaTableMeasure> measureDao = daoProvider.daoFor(NopMetaTableMeasure.class);
        QueryBean mq = new QueryBean();
        mq.addFilter(FilterBeans.eq(NopMetaTableMeasure.PROP_NAME_metaTableId, metaTableId));
        List<NopMetaTableMeasure> measures = measureDao.findAllByQuery(mq);
        List<String> unresolved = new ArrayList<>();
        List<Map<String, Object>> errors = new ArrayList<>();
        int extracted = 0;
        List<NopMetaLineageEdge> toSave = new ArrayList<>();
        for (NopMetaTableMeasure measure : measures) {
            String expression = measure.getExpression();
            if (expression == null || expression.trim().isEmpty()) continue;
            String measureName = measure.getMeasureName();
            try {
                ExpressionMeasureValidator.ValidatedExpression validated =
                        ExpressionMeasureValidator.validateStatic(expression,
                                ExpressionMeasureValidator.ValidationOptions.saveTimeLoose(),
                                metaTableId, measureName);
                String transformType = measure.getAggFunc() != null && !measure.getAggFunc().isEmpty()
                        ? _NopMetadataCoreConstants.LINEAGE_TRANSFORM_AGGREGATED
                        : _NopMetadataCoreConstants.LINEAGE_TRANSFORM_DERIVED;
                for (String ident : validated.identifiers) {
                    if (ident == null || ident.isEmpty()) continue;
                    if (ident.indexOf('.') >= 0) {
                        unresolved.add(measureName + " <- " + ident + " (join-context-deferred)");
                        continue;
                    }
                    if (!fieldNamesLower.contains(ident.toLowerCase(Locale.ROOT))) {
                        unresolved.add(measureName + " <- " + ident + " (column-not-in-table-fields)");
                        continue;
                    }
                    NopMetaLineageEdge edge = dao.newEntity();
                    edge.setSourceTableId(targetId);
                    edge.setTargetTableId(targetId);
                    edge.setSourceColumn(ident);
                    edge.setTargetColumn(measureName);
                    edge.setLineageSource(_NopMetadataCoreConstants.LINEAGE_SOURCE_MEASURE_PARSE);
                    edge.setTransformType(transformType);
                    toSave.add(edge);
                    extracted++;
                }
            } catch (NopException e) {
                LOG.warn("extractMeasureLineage validator failed for metaTableId={}, measureName={}, errorCode={}",
                        metaTableId, measureName, NopMetadataErrors.ERR_LINEAGE_QUERY_ISOLATED.getErrorCode(), e);
                Map<String, Object> err = new LinkedHashMap<>();
                err.put("stage", "measure_parse");
                err.put("measureName", measureName);
                err.put("error", NopMetadataHelper.toErrorMessage(e));
                errors.add(err);
            }
        }
        if (!toSave.isEmpty()) {
            dao.batchSaveEntities(toSave);
        }
        // 指标级语义裁定（P1-3）：measure 边全部为自环（sourceTableId=targetId），无独立 resolved 计算——
        // sourceTables = 宿主表自身 [metaTableId]（与边语义一致）；产出 0 条边时为空列表（不伪造源）。
        List<String> measureSourceTables = extracted > 0
                ? Collections.singletonList(targetId)
                : Collections.emptyList();
        return new LineageExtractResult(extracted, measureSourceTables, unresolved, errors);
    }

    // ============================================================
    // shared helpers
    // ============================================================

    List<String> bfsForward(Map<String, List<String>> forward, String start) {
        Set<String> visited = new HashSet<>();
        visited.add(start);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(start);
        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String cur = queue.poll();
            List<String> targets = forward.get(cur);
            if (targets == null) continue;
            for (String tgt : targets) {
                if (visited.add(tgt)) {
                    result.add(tgt);
                    queue.add(tgt);
                }
            }
        }
        return result;
    }

    List<String> bfsForwardByColumn(Map<String, List<NopMetaLineageEdge>> columnForward,
                                     String start, String columnName) {
        Set<String> visited = new HashSet<>();
        visited.add(start);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(start);
        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String cur = queue.poll();
            List<NopMetaLineageEdge> edges = columnForward.get(cur);
            if (edges == null) continue;
            for (NopMetaLineageEdge edge : edges) {
                if (!matchesColumn(edge, columnName)) continue;
                String tgt = edge.getTargetTableId();
                if (visited.add(tgt)) {
                    result.add(tgt);
                    queue.add(tgt);
                }
            }
        }
        return result;
    }

    private LineageGraph buildLineageGraph(IEntityDao<NopMetaLineageEdge> dao) {
        QueryBean q = new QueryBean();
        q.setLimit(maxEdges + 1);
        List<NopMetaLineageEdge> allEdges = dao.findAllByQuery(q);
        if (allEdges.size() > maxEdges) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_GRAPH_TOO_LARGE)
                    .param("edges", allEdges.size()).param("limit", maxEdges);
        }
        Map<String, List<String>> forward = new HashMap<>();
        Map<String, List<String>> reverse = new HashMap<>();
        Map<String, List<NopMetaLineageEdge>> columnForward = new HashMap<>();
        for (NopMetaLineageEdge edge : allEdges) {
            String src = edge.getSourceTableId();
            String tgt = edge.getTargetTableId();
            forward.computeIfAbsent(src, k -> new ArrayList<>()).add(tgt);
            reverse.computeIfAbsent(tgt, k -> new ArrayList<>()).add(src);
            if (edge.getSourceColumn() != null || edge.getTargetColumn() != null) {
                columnForward.computeIfAbsent(src, k -> new ArrayList<>()).add(edge);
            }
        }
        return new LineageGraph(forward, reverse, columnForward);
    }

    Map<String, String> buildTableNameIndex(IDaoProvider daoProvider) {
        IEntityDao<NopMetaTable> tableDao = daoProvider.daoFor(NopMetaTable.class);
        QueryBean q = new QueryBean();
        q.setLimit(maxTables + 1);
        List<NopMetaTable> tables = tableDao.findAllByQuery(q);
        if (tables.size() > maxTables) {
            throw new NopMetadataException(NopMetadataErrors.ERR_LINEAGE_TABLE_INDEX_TOO_LARGE)
                    .param("tables", tables.size()).param("limit", maxTables);
        }
        Map<String, String> map = new LinkedHashMap<>();
        for (NopMetaTable t : tables) {
            if (t.getTableName() != null) {
                map.putIfAbsent(t.getTableName().toLowerCase(Locale.ROOT), t.getMetaTableId());
            }
        }
        return map;
    }

    Set<String> loadExistingTableIds(Set<String> ids, IDaoProvider daoProvider) {
        if (ids.isEmpty()) return Collections.emptySet();
        IEntityDao<NopMetaTable> tableDao = daoProvider.daoFor(NopMetaTable.class);
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.in(NopMetaTable.PROP_NAME_metaTableId, ids));
        List<NopMetaTable> tables = tableDao.findAllByQuery(q);
        Set<String> existing = new HashSet<>();
        for (NopMetaTable t : tables) {
            existing.add(t.getMetaTableId());
        }
        return existing;
    }

    Set<String> batchLoadExistingSqlParseSourceIds(List<String> sourceIds, String targetTableId,
                                                    IEntityDao<NopMetaLineageEdge> dao) {
        if (sourceIds.isEmpty()) return Collections.emptySet();
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.in(NopMetaLineageEdge.PROP_NAME_sourceTableId, new HashSet<>(sourceIds)));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_targetTableId, targetTableId));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_lineageSource,
                _NopMetadataCoreConstants.LINEAGE_SOURCE_SQL_PARSE));
        q.addFilter(FilterBeans.isNull(NopMetaLineageEdge.PROP_NAME_sourceColumn));
        List<NopMetaLineageEdge> edges = dao.findAllByQuery(q);
        Set<String> existing = new HashSet<>();
        for (NopMetaLineageEdge e : edges) {
            existing.add(e.getSourceTableId());
        }
        return existing;
    }

    Map<List<String>, NopMetaLineageEdge> batchLoadExistingColumnParseEdgeMap(Collection<String> sourceIds,
                                                                               String targetTableId,
                                                                               IEntityDao<NopMetaLineageEdge> dao) {
        if (sourceIds.isEmpty()) return Collections.emptyMap();
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.in(NopMetaLineageEdge.PROP_NAME_sourceTableId, new HashSet<>(sourceIds)));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_targetTableId, targetTableId));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_lineageSource,
                _NopMetadataCoreConstants.LINEAGE_SOURCE_SQL_PARSE));
        List<NopMetaLineageEdge> edges = dao.findAllByQuery(q);
        // D6（Cycle 2，adjudication-table-cycle2 §5）：existing-edge map 键为结构性 List（值级
        // equals/hashCode），非 "|" 拼接 String——SQL 派生列名（带引号标识符）可含 "|"，拼接键
        // 碰撞会使不同边在 map 中互相覆盖 → 错误 update/insert 路由（沿 AR-03 结构性键先例）。
        Map<List<String>, NopMetaLineageEdge> map = new HashMap<>();
        for (NopMetaLineageEdge e : edges) {
            if (e.getSourceColumn() != null) {
                map.put(Arrays.asList(e.getSourceTableId(), e.getSourceColumn(), e.getTargetColumn()), e);
            }
        }
        return map;
    }

    void deleteMeasureParseEdges(String tableId, IEntityDao<NopMetaLineageEdge> dao) {
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_sourceTableId, tableId));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_targetTableId, tableId));
        q.addFilter(FilterBeans.eq(NopMetaLineageEdge.PROP_NAME_lineageSource,
                _NopMetadataCoreConstants.LINEAGE_SOURCE_MEASURE_PARSE));
        List<NopMetaLineageEdge> stale = dao.findAllByQuery(q);
        for (NopMetaLineageEdge e : stale) {
            dao.deleteEntity(e);
        }
    }

    private static boolean matchesColumn(NopMetaLineageEdge edge, String columnName) {
        return columnName != null && (columnName.equals(edge.getSourceColumn())
                || columnName.equals(edge.getTargetColumn()));
    }

    private static Map<String, Object> errorMap(String stage, NopException e) {
        Map<String, Object> err = new LinkedHashMap<>();
        err.put("stage", stage);
        err.put("error", NopMetadataHelper.toErrorMessage(e));
        return err;
    }

    /** 去重保序（跨 schema 同 simpleName 可解析到同一 metaTable ID，sourceTables 语义为"源表集"）。 */
    private static List<String> dedupPreservingOrder(List<String> ids) {
        if (ids.isEmpty()) return Collections.emptyList();
        return new ArrayList<>(new LinkedHashSet<>(ids));
    }

    public static final class LineageGraph {
        public final Map<String, List<String>> forward;
        public final Map<String, List<String>> reverse;
        public final Map<String, List<NopMetaLineageEdge>> columnForward;

        public LineageGraph(Map<String, List<String>> forward,
                            Map<String, List<String>> reverse,
                            Map<String, List<NopMetaLineageEdge>> columnForward) {
            this.forward = forward;
            this.reverse = reverse;
            this.columnForward = columnForward;
        }
    }

    public static final class LineageExtractResult {
        public final int edgeCount;
        /**
         * 已解析源表标识（metaTable ID 集，去重保序）。
         * 表级 = nameToId 命中的 candidateSourceIds；列级 = 命中的 resolvedSourceIds；
         * 指标级 = 宿主表自身（自环边语义，仅当产出 ≥1 条边，否则空列表）。
         * 与 unresolved（完整名/诊断串）异质并存，语义见 owner doc。
         */
        public final List<String> resolvedSourceTables;
        public final List<String> unresolved;
        public final List<Map<String, Object>> errors;

        public LineageExtractResult(int edgeCount, List<String> resolvedSourceTables,
                                    List<String> unresolved, List<Map<String, Object>> errors) {
            this.edgeCount = edgeCount;
            this.resolvedSourceTables = resolvedSourceTables;
            this.unresolved = unresolved;
            this.errors = errors;
        }
    }
}
