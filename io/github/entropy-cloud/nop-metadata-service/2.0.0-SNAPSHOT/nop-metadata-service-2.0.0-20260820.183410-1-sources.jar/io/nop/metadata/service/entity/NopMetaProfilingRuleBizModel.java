
package io.nop.metadata.service.entity;


import io.nop.api.core.time.CoreMetrics;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.json.JsonTool;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.biz.INopMetaProfilingRuleBiz;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.api.dto.ErrorDTO;
import io.nop.metadata.api.dto.ProfileResultDTO;
import io.nop.metadata.dao.entity.NopMetaDataSource;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaProfilingResult;
import io.nop.metadata.dao.entity.NopMetaProfilingRule;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.service.connection.IMetaDataSourceConnectionProcessor;
import io.nop.metadata.service.datasource.MetaDataSourceResolver;
import io.nop.metadata.service.profiling.MetaTableProfiler;
import io.nop.metadata.service.profiling.ProfilingColumnStats;
import io.nop.metadata.service.profiling.ProfilingSnapshot;
import io.nop.metadata.service.tableref.MetaTableReferenceResolver;
import io.nop.metadata.service.tableref.TableReference;
import io.nop.metadata.service.tableref.TableReferenceExecutor;
import io.nop.metadata.service.NopMetadataException;
import jakarta.inject.Inject;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 数据剖析规则 BizModel：基线 CRUD（{@link CrudBizModel}）+ 按规则执行剖析（架构基线 §2.7.2 / 设计 06 §三 D3）。
 *
 * <p>剖析主入口是 {@code NopMetaTableBizModel.profileTable}（metaTableId 为键）。本类提供辅助入口
 * {@link #executeProfilingRule}：按 {@link NopMetaProfilingRule} 定义的 columns/stats 执行剖析，
 * 委托同一无状态剖析路径（{@link MetaTableProfiler}），使 ProfilingRule 实体可运行、非空壳。
 *
 * <p>物理解析 + 失败/不可执行路径显式化自包含（与 {@code NopMetaQualityRuleBizModel} 同模式）：
 * 表不存在/非 external/无数据源/DISABLED/非 jdbc 显式失败，不静默通过。
 */
@BizModel("NopMetaProfilingRule")
public class NopMetaProfilingRuleBizModel extends CrudBizModel<NopMetaProfilingRule> implements INopMetaProfilingRuleBiz {

    @Inject
    protected IMetaDataSourceConnectionProcessor connectionService;

    /** 共享 table-reference 解析器（架构基线 §4.4.3 D3）。 */
    private final MetaTableReferenceResolver tableRefResolver = new MetaTableReferenceResolver(
            new MetaDataSourceResolver(), new io.nop.metadata.service.field.MetaTableFieldResolver());

    /** 数据剖析器（无状态，与 profileTable 共用同一剖析路径）。 */
    private final MetaTableProfiler profiler = new MetaTableProfiler();

    /** 按 table-reference 形态分派 Connection 获取（§4.4.3 D1/D2）。延迟初始化（需 orm()）。 */
    private TableReferenceExecutor tableRefExecutor;

    public NopMetaProfilingRuleBizModel() {
        setEntityName(NopMetaProfilingRule.class.getName());
    }

    /**
     * 按剖析规则定义执行（架构基线 §2.7.2 D3 + §4.4.3 D1-D5）：加载规则 → 解析目标表（任意 tableType）→
     * table-reference 分派 Connection → 剖析器按规则 columns/stats 统计 → 追加一行 NopMetaProfilingResult。
     *
     * @param profilingRuleId 规则 ID
     * @param schemaPattern   可选 schema 限定（null/空串表示依赖连接默认 schema）
     * @param context         服务上下文
     * @return {@code ProfileResultDTO}
     */
    @BizMutation
    public ProfileResultDTO executeProfilingRule(@Name("profilingRuleId") String profilingRuleId,
                                                  @Optional @Name("schemaPattern") String schemaPattern,
                                                  IServiceContext context) {
        NopMetaProfilingRule rule = requireEntity(profilingRuleId, "executeProfilingRule", context);

        NopMetaTable table = resolveTargetTableOrThrow(rule);
        TableReference ref = tableRefResolver.resolve(table,
                daoFor(NopMetaDataSource.class), daoFor(NopMetaEntity.class),
                daoFor(NopMetaEntityField.class), orm());

        // 规则定义的 columns 作为列过滤（stats 指标首版全量收集，规则仅记录意图，不裁剪以保证剖析完整性）
        String columns = rule.getColumns();

        // plan 0852-3 Phase 3: 默认 schema 解析在 BizModel 层（持有 NopMetaTable）
        String effectiveSchema = resolveDefaultSchema(schemaPattern, table);

        ProfilingSnapshot snapshot = ensureTableRefExecutor().execute(ref,
                (conn, metaData, productName) -> profiler.profile(conn, metaData, ref, effectiveSchema,
                        columns, productName));

        NopMetaProfilingResult row = appendProfilingResult(
                rule.getProfilingRuleId(), table.getMetaTableId(), snapshot);
        return buildProfileResultDTO(row, snapshot);
    }

    // ============================================================
    // helpers（自包含，与 NopMetaQualityRuleBizModel 同模式）
    // ============================================================

    /** 解析规则目标表：rule.tableId → NopMetaTable；不存在显式失败（任意 tableType，§4.4.3 D4）。 */
    private NopMetaTable resolveTargetTableOrThrow(NopMetaProfilingRule rule) {
        IEntityDao<NopMetaTable> tableDao = daoFor(NopMetaTable.class);
        NopMetaTable table = tableDao.getEntityById(rule.getMetaTableId());
        if (table == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_PROFILING_TABLE_NOT_FOUND)
                    .param("metaTableId", rule.getMetaTableId());
        }
        return table;
    }

    /** 延迟初始化 TableReferenceExecutor（需 orm()，构造时 orm 不可用）。 */
    private TableReferenceExecutor ensureTableRefExecutor() {
        if (tableRefExecutor == null) {
            tableRefExecutor = new TableReferenceExecutor(connectionService, orm());
        }
        return tableRefExecutor;
    }

    /**
     * 默认 schema 解析（plan 0852-3 Phase 3）：未显式传 schemaPattern（null/空/纯空白）且
     * {@code table.schema} 非空 → 默认取 {@code table.schema}；否则维持入参（可能为 null=不过滤）。
     * 与 {@code NopMetaDataSourceBizModel.resolveDefaultSchema} 同语义。
     */
    private static String resolveDefaultSchema(String schemaPattern, NopMetaTable table) {
        if (schemaPattern != null && !schemaPattern.trim().isEmpty()) {
            return schemaPattern;
        }
        return table.getMetaSchema();
    }

    /** 追加一行 NopMetaProfilingResult（时序语义：snapshotTime=now，不覆盖）。 */
    private NopMetaProfilingResult appendProfilingResult(String profilingRuleId, String metaTableId,
                                                         ProfilingSnapshot snapshot) {
        IEntityDao<NopMetaProfilingResult> resultDao = daoFor(NopMetaProfilingResult.class);
        NopMetaProfilingResult row = resultDao.newEntity();
        row.setProfilingRuleId(profilingRuleId);
        row.setMetaTableId(metaTableId);
        row.setSnapshotTime(CoreMetrics.currentTimestamp());
        row.setTableStats(JsonTool.stringify(snapshot.toTableStatsMap()));
        row.setColumnStats(JsonTool.stringify(snapshot.toColumnStatsList()));
        resultDao.saveEntity(row);
        return row;
    }

    /** 构建 ProfileResultDTO（profilingResultId + 列统计 + 表级不可用 + 列级 errors）。 */
    private static ProfileResultDTO buildProfileResultDTO(NopMetaProfilingResult row, ProfilingSnapshot snapshot) {
        ProfileResultDTO dto = new ProfileResultDTO();
        dto.setProfilingResultId(row.getProfilingResultId());
        dto.setColumnCount(snapshot.getColumnStats().size());
        dto.setUnavailable(snapshot.getTableUnavailable());
        List<String> columnUnavailable = new ArrayList<>();
        for (ProfilingColumnStats cs : snapshot.getColumnStats()) {
            columnUnavailable.addAll(cs.getUnavailable());
        }
        dto.setColumnUnavailable(columnUnavailable);
        List<ErrorDTO> errorDTOs = new ArrayList<>(snapshot.getErrors().size());
        for (Map<String, Object> err : snapshot.getErrors()) {
            ErrorDTO errDTO = new ErrorDTO();
            Object colName = err.get("columnName");
            errDTO.setCode(colName != null ? colName.toString() : null);
            Object msg = err.get("error");
            errDTO.setMessage(msg != null ? msg.toString() : null);
            errorDTOs.add(errDTO);
        }
        dto.setErrors(errorDTOs);
        return dto;
    }

}
