package io.nop.metadata.service.query;

import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.TreeBean;
import io.nop.api.core.beans.query.OrderFieldBean;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.dao.api.IEntityDao;
import io.nop.dataset.IDataRow;
import io.nop.dataset.IDataSet;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.dao.entity.NopMetaDataSource;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.dao.entity.NopMetaTableDimension;
import io.nop.metadata.dao.entity.NopMetaTableJoin;
import io.nop.metadata.dao.entity.NopMetaTableMeasure;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.field.ExpressionMeasureValidator;
import io.nop.metadata.service.field.ResolvedTableField;
import io.nop.metadata.service.NopMetadataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class AggregationHelper {
    private static final Logger LOG = LoggerFactory.getLogger(AggregationHelper.class);

    public static String safeAlias(String name) {
        if (name == null) {
            return "v";
        }
        String s = name.replaceAll("[^A-Za-z0-9_]", "_");
        if (s.isEmpty() || !Character.isLetter(s.charAt(0)) && s.charAt(0) != '_') {
            s = "v_" + s;
        }
        return s.toUpperCase(Locale.ROOT);
    }

    public static Map<String, Object> buildResult(List<Map<String, Object>> items) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("items", items != null ? items : new ArrayList<>());
        return result;
    }

    public static String aggSqlOf(String aggFunc, String column, String measureName) {
        if (aggFunc == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_AGG_FUNC_UNSUPPORTED)
                    .param(NopMetadataErrors.ARG_AGG_FUNC, String.valueOf(aggFunc)).param(NopMetadataErrors.ARG_MEASURE_NAME, measureName);
        }
        switch (aggFunc) {
            case _NopMetadataCoreConstants.AGG_FUNC_SUM:
                return "SUM(" + column + ")";
            case _NopMetadataCoreConstants.AGG_FUNC_COUNT:
                return "COUNT(" + column + ")";
            case _NopMetadataCoreConstants.AGG_FUNC_AVG:
                return "AVG(" + column + ")";
            case _NopMetadataCoreConstants.AGG_FUNC_MIN:
                return "MIN(" + column + ")";
            case _NopMetadataCoreConstants.AGG_FUNC_MAX:
                return "MAX(" + column + ")";
            case _NopMetadataCoreConstants.AGG_FUNC_COUNT_DISTINCT:
                return "COUNT(DISTINCT " + column + ")";
            default:
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_AGG_FUNC_UNSUPPORTED)
                        .param(NopMetadataErrors.ARG_AGG_FUNC, aggFunc).param(NopMetadataErrors.ARG_MEASURE_NAME, measureName);
        }
    }

    public static List<Map<String, Object>> executeJdbcQuery(Connection conn, String sql, List<Object> filterParams,
                                                              Long limit, Long offset, String metaTableId) {
        List<Map<String, Object>> rows = new ArrayList<>();
        try (PreparedStatement st = conn.prepareStatement(sql)) {
            int idx = 1;
            for (Object p : filterParams) {
                st.setObject(idx++, p);
            }
            if (limit != null) {
                st.setObject(idx++, limit);
            }
            if (offset != null && offset > 0) {
                st.setObject(idx++, offset);
            }
            try (ResultSet rs = st.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int columnCount = meta.getColumnCount();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int c = 1; c <= columnCount; c++) {
                        String label = meta.getColumnLabel(c);
                        if (label == null || label.isEmpty()) {
                            label = meta.getColumnName(c);
                        }
                        row.put(label, rs.getObject(c));
                    }
                    rows.add(row);
                }
            }
            return rows;
        } catch (SQLException e) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXEC_FAILED, e)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, metaTableId)
                    .param(NopMetadataErrors.ARG_ERROR, messageOf(e));
        }
    }

    public static List<Map<String, Object>> collectRows(IDataSet ds) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (IDataRow row : ds) {
            Map<String, Object> map = new LinkedHashMap<>();
            for (int i = 0; i < row.getFieldCount(); i++) {
                map.put(row.getMeta().getFieldName(i), row.getObject(i));
            }
            rows.add(map);
        }
        return rows;
    }

    /**
     * 非空名称守卫（空/null 显式失败，非静默返回）。
     *
     * @param value       待检值
     * @param what        值语义描述（进错误消息 error 参数）
     * @param metaTableId 目标逻辑表 ID（P1-6 plan 2026-08-15-1913-3 轨 2 穿参：静态工具
     *                    方法无身份值，由调用方传入——{metaTableId} 占位符真实渲染）
     * @return 原值（非空非空白）
     */
    public static String requireName(String value, String what,
                                      final String metaTableId) {
        if (value == null || value.trim().isEmpty()) {
            throw new NopMetadataException(
                    NopMetadataErrors.ERR_AGGR_EXEC_FAILED)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, metaTableId)
                    .param(NopMetadataErrors.ARG_ERROR, what + " is empty");
        }
        return value;
    }

    public static Set<String> resolveTableColumnNames(NopMetaTable table, IEntityDao<NopMetaEntityField> fieldDao,
                                                       MetaQueryContext ctx) {
        List<ResolvedTableField> fields = ctx.fieldResolver().resolve(table, fieldDao);
        Set<String> names = new LinkedHashSet<>(fields.size());
        for (ResolvedTableField f : fields) {
            names.add(f.getName());
        }
        return names;
    }

    public static String resolveExternalFieldOrThrow(Set<String> columns, String field, NopMetaTable table,
                                                      String side, String joinId) {
        if (field == null || field.isEmpty() || !containsIgnoreCase(columns, field)) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_JOIN_FIELD_NOT_ON_SIDE)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "join-field")
                    .param(NopMetadataErrors.ARG_SIDE, side)
                    .param(NopMetadataErrors.ARG_ENDPOINT_TABLE_TYPE, String.valueOf(table.getTableType()))
                    .param(NopMetadataErrors.ARG_COLUMN, String.valueOf(field))
                    .param(NopMetadataErrors.ARG_JOIN_ID, joinId);
        }
        return field;
    }

    public static NopMetaDataSource resolveSharedDataSourceOrThrow(NopMetaTable table, MetaQueryContext ctx, String joinId) {
        IEntityDao<NopMetaDataSource> dsDao = ctx.daoProvider().daoFor(NopMetaDataSource.class);
        try {
            return ctx.dataSourceResolver().resolveActiveOrThrow(dsDao, table.getQuerySpace());
        } catch (NopException e) {
            if (e.getParam(NopMetadataErrors.ARG_JOIN_ID) == null) {
                e.param(NopMetadataErrors.ARG_JOIN_ID, joinId).param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId());
            }
            throw e;
        }
    }

    public static Map<String, String> resolveEntityColumns(NopMetaEntity entity, MetaQueryContext ctx) {
        IEntityDao<NopMetaEntityField> fieldDao = ctx.daoProvider().daoFor(NopMetaEntityField.class);
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.eq(NopMetaEntityField.PROP_NAME_metaEntityId, entity.getMetaEntityId()));
        List<NopMetaEntityField> fields = fieldDao.findAllByQuery(q);
        Map<String, String> propToCol = new LinkedHashMap<>();
        for (NopMetaEntityField f : fields) {
            if (f.getFieldName() != null && f.getColumnCode() != null) {
                propToCol.put(f.getFieldName(), f.getColumnCode());
            }
        }
        return propToCol;
    }

    public static TreeBean rewriteFilterToColumns(TreeBean filter, Map<String, String> propToCol) {
        if (filter == null) {
            return null;
        }
        TreeBean copy = new TreeBean(filter.getTagName());
        if (filter.getAttrs() != null) {
            copy.setAttrs(new LinkedHashMap<>(filter.getAttrs()));
        }
        Object name = copy.getAttr("name");
        if (name != null && propToCol.containsKey(name.toString())) {
            copy.setAttr("name", propToCol.get(name.toString()));
        }
        if (filter.getChildren() != null) {
            List<TreeBean> children = new ArrayList<>();
            for (TreeBean child : filter.getChildren()) {
                children.add(rewriteFilterToColumns(child, propToCol));
            }
            copy.setChildren(children);
        }
        return copy;
    }

    public static String resolveEntityFieldColumn(String entityFieldId, String name, NopMetaTable table,
                                                   MetaQueryContext ctx) {
        if (entityFieldId == null || entityFieldId.isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_FIELD_NOT_RESOLVED)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, name).param(NopMetadataErrors.ARG_ENTITY_FIELD_ID, String.valueOf(entityFieldId));
        }
        IEntityDao<NopMetaEntityField> fieldDao = ctx.daoProvider().daoFor(NopMetaEntityField.class);
        NopMetaEntityField field = fieldDao.getEntityById(entityFieldId);
        if (field == null || field.getColumnCode() == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_FIELD_NOT_RESOLVED)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, name).param(NopMetadataErrors.ARG_ENTITY_FIELD_ID, entityFieldId);
        }
        return field.getColumnCode();
    }

    public static Map<String, String> buildNameToExprTable(List<AggregationContext.MeasureSpec> measures,
                                                            List<AggregationContext.DimensionSpec> dims,
                                                            List<String> measureNames, List<String> dimensionNames,
                                                            NopMetaTable table) {
        Map<String, String> map = new LinkedHashMap<>();
        if (measures.size() != measureNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: measures/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < measures.size(); i++) {
            map.put(measureNames.get(i), measures.get(i).aggSql);
        }
        if (dims.size() != dimensionNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: dims/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < dims.size(); i++) {
            map.put(dimensionNames.get(i), dims.get(i).column);
        }
        return map;
    }

    public static Map<String, String> buildJoinNameToExprTable(List<AggregationContext.JoinMeasureSpec> measures,
                                                                List<AggregationContext.JoinDimensionSpec> dims,
                                                                List<String> measureNames,
                                                                List<String> dimensionNames, NopMetaTable table) {
        Map<String, String> map = new LinkedHashMap<>();
        if (measures.size() != measureNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: join measures/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < measures.size(); i++) {
            map.put(measureNames.get(i), measures.get(i).aggSql);
        }
        if (dims.size() != dimensionNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: join dims/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < dims.size(); i++) {
            map.put(dimensionNames.get(i), dims.get(i).qualifiedCol);
        }
        return map;
    }

    public static FilterToSqlTranslator.FieldResolver nameResolverFor(Map<String, String> nameToExpr,
                                                                        NopMetaTable table,
                                                                        List<String> measureNames,
                                                                        List<String> dimensionNames,
                                                                        String clause) {
        return (node, name) -> {
            String expr = nameToExpr.get(name);
            if (expr != null) {
                if (expr.indexOf('?') >= 0) {
                    throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXPRESSION_HAVING_ORDER_BY_UNSUPPORTED)
                            .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                            .param(NopMetadataErrors.ARG_MEASURE_NAME, name)
                            .param(NopMetadataErrors.ARG_CLAUSE, clause);
                }
                return expr;
            }
            // MA7.1-01：非白名单 name 一律禁止原样透传。唯一例外是 preprocessHavingArithmetic 已完成
            // token 级白名单替换并显式标记（HAVING_EXPR_RESOLVED_ATTR）的 expr 叶子。
            if (Boolean.TRUE.equals(node.getAttr(MetaAggregationExecutor.HAVING_EXPR_RESOLVED_ATTR))) {
                return name;
            }
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, name)
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        };
    }

    /**
     * 构造 ORDER BY 子句。
     *
     * @param dialect 方言名（H2/MySQL/PostgreSQL；null = ORM 路径方言不可得，保持 H2 语义拼接 NULLS FIRST/LAST）
     */
    public static String buildOrderByClause(List<OrderFieldBean> orderBy, Map<String, String> nameToExpr,
                                             NopMetaTable table, List<String> measureNames,
                                             List<String> dimensionNames, String clause, String dialect) {
        if (orderBy == null || orderBy.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < orderBy.size(); i++) {
            OrderFieldBean f = orderBy.get(i);
            String name = f.getName();
            String expr = nameToExpr.get(name);
            if (expr == null) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_ORDER_BY_UNKNOWN_NAME)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                        .param(NopMetadataErrors.ARG_NAME, String.valueOf(name))
                        .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                        .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
            }
            if (expr.indexOf('?') >= 0) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXPRESSION_HAVING_ORDER_BY_UNSUPPORTED)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                        .param(NopMetadataErrors.ARG_MEASURE_NAME, String.valueOf(name))
                        .param(NopMetadataErrors.ARG_CLAUSE, clause);
            }
            if (i > 0) {
                sb.append(",");
            }
            sb.append(expr).append(f.isDesc() ? " DESC" : " ASC");
            Boolean nullsFirst = f.getNullsFirst();
            if (nullsFirst != null) {
                if ("MySQL".equalsIgnoreCase(dialect)) {
                    // AR-20a：MySQL 无 NULLS FIRST/LAST 语法。MySQL 默认 NULL 在 ASC 中居前、DESC 中居后——
                    // 与默认一致时省略子句（语义不变）；MySQL 无法表达的组合（NULLS LAST in ASC /
                    // NULLS FIRST in DESC）显式 fail-fast（不做 CASE 表达式模拟，见 plan 2026-08-06-1228-1）。
                    boolean matchesMySqlDefault = (nullsFirst && !f.isDesc()) || (!nullsFirst && f.isDesc());
                    if (!matchesMySqlDefault) {
                        throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_ORDER_BY_NULLS_UNSUPPORTED)
                                .param(NopMetadataErrors.ARG_DATABASE_PRODUCT_NAME, dialect)
                                .param(NopMetadataErrors.ARG_NAME, String.valueOf(name))
                                .param(NopMetadataErrors.ARG_DESC, f.isDesc())
                                .param(NopMetadataErrors.ARG_NULLS_FIRST, nullsFirst);
                    }
                } else {
                    // H2/PostgreSQL 支持 NULLS FIRST/LAST；dialect==null（ORM 路径，EntityAggregationProcessor
                    // via-EQL / EntityEntityJoinAggregationProcessor 裁定）保持既有拼接行为。
                    sb.append(nullsFirst ? " NULLS FIRST" : " NULLS LAST");
                }
            }
        }
        return sb.toString();
    }

    public static List<NopMetaTableMeasure> loadMeasures(NopMetaTable table, List<String> names, MetaQueryContext ctx) {
        IEntityDao<NopMetaTableMeasure> dao = ctx.daoProvider().daoFor(NopMetaTableMeasure.class);
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.eq(NopMetaTableMeasure.PROP_NAME_metaTableId, table.getMetaTableId()));
        List<NopMetaTableMeasure> all = dao.findAllByQuery(q);
        Map<String, NopMetaTableMeasure> byName = new LinkedHashMap<>();
        for (NopMetaTableMeasure m : all) {
            byName.put(m.getMeasureName(), m);
        }
        List<NopMetaTableMeasure> result = new ArrayList<>();
        for (String name : names) {
            NopMetaTableMeasure m = byName.get(name);
            if (m == null) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_MEASURE_NOT_FOUND)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId()).param(NopMetadataErrors.ARG_MEASURE_NAME, name);
            }
            result.add(m);
        }
        return result;
    }

    public static List<NopMetaTableDimension> loadDimensions(NopMetaTable table, List<String> names, MetaQueryContext ctx) {
        IEntityDao<NopMetaTableDimension> dao = ctx.daoProvider().daoFor(NopMetaTableDimension.class);
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.eq(NopMetaTableDimension.PROP_NAME_metaTableId, table.getMetaTableId()));
        List<NopMetaTableDimension> all = dao.findAllByQuery(q);
        Map<String, NopMetaTableDimension> byName = new LinkedHashMap<>();
        for (NopMetaTableDimension d : all) {
            byName.put(d.getDimensionName(), d);
        }
        List<NopMetaTableDimension> result = new ArrayList<>();
        for (String name : names) {
            NopMetaTableDimension d = byName.get(name);
            if (d == null) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_DIMENSION_NOT_FOUND)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId()).param(NopMetadataErrors.ARG_DIMENSION_NAME, name);
            }
            result.add(d);
        }
        return result;
    }

    public static String endpointTypeOf(MetaJoinExecutor.Endpoint ep) {
        if (ep.isEntity) {
            return "entity";
        }
        return ep.table == null ? "unknown" : String.valueOf(ep.table.getTableType());
    }

    public static List<Map<String, Object>>[] newArrayHolder() {
        return ArrayHolderUtils.newArrayHolder();
    }

    public static boolean containsIgnoreCase(Set<String> cols, String name) {
        if (cols == null || name == null) {
            return false;
        }
        for (String c : cols) {
            if (c != null && c.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public static boolean equalsStr(String a, String b) {
        return (a == null) ? b == null : a.equals(b);
    }

    public static String crossDbAliasOf(NopMetaTableJoin join) {
        String a = join.getAlias();
        return (a != null && !a.trim().isEmpty()) ? a : "right";
    }

    public static Object getCaseInsensitiveObj(Map<String, Object> map, String key) {
        if (map == null || key == null) {
            return null;
        }
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (e.getKey().equalsIgnoreCase(key)) {
                return e.getValue();
            }
        }
        return null;
    }

    public static String findKeyIgnoreCase(Map<String, Object> map, String key) {
        if (map == null || key == null) {
            return null;
        }
        for (String k : map.keySet()) {
            if (k.equalsIgnoreCase(key)) {
                return k;
            }
        }
        return null;
    }

    public static String safeProductName(DatabaseMetaData metaData) {
        try {
            return metaData.getDatabaseProductName();
        } catch (SQLException e) {
            // AR-14a：SQLException 来自 getDatabaseProductName()，本质是连接/驱动/基础设施失败，
            // 非"方言不支持"。fail-loud：抛 infra 错误并传播 cause，不再 return null（否则被调用方
            // 误归因为 ERR_AGGR_UNSUPPORTED_DIALECT，掩盖真实故障）。
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_DB_PRODUCT_NAME_FAILED, e)
                    .param(NopMetadataErrors.ARG_ERROR, messageOf(e));
        }
    }

    public static String messageOf(Throwable t) {
        String m = t.getMessage();
        return m != null ? m : t.getClass().getName();
    }

    public static String externalTableFromForJoin(NopMetaTable table, String alias) {
        FilterToSqlTranslator.validateIdentifier(alias);
        if (_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(table.getTableType())) {
            String sourceSql = table.getSourceSql();
            if (sourceSql == null || sourceSql.trim().isEmpty()) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXEC_FAILED)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                        .param(NopMetadataErrors.ARG_ERROR, "sql table sourceSql is empty");
            }
            return "(" + sourceSql + ") " + alias;
        }
        String tableName = table.getTableName();
        FilterToSqlTranslator.validateIdentifier(tableName);
        return tableName + " " + alias;
    }

    public static String buildEntityFromClause(String physicalTable, String schema, String alias) {
        FilterToSqlTranslator.validateIdentifier(alias);
        if (schema != null && !schema.trim().isEmpty()) {
            FilterToSqlTranslator.validateIdentifier(schema);
            return schema + "." + physicalTable + " " + alias;
        }
        return physicalTable + " " + alias;
    }

    public static boolean isEntityTableVisible(DatabaseMetaData metaData, String schema, String tableName) {
        if (tableName == null || tableName.isEmpty()) {
            return false;
        }
        return checkTableExists(metaData, schema, tableName)
                || checkTableExists(metaData, schema, tableName.toUpperCase(Locale.ROOT))
                || checkTableExists(metaData, schema, tableName.toLowerCase(Locale.ROOT));
    }

    public static boolean checkTableExists(DatabaseMetaData metaData, String schema, String tableName) {
        try (ResultSet rs = metaData.getTables(null, schema, tableName, null)) {
            while (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            // P2-06：真实故障（权限缺失/元数据面异常）不得归类为"表不可见"——显式抛错保留原始异常链，
            // 由调用方决定回退或失败，避免 ERR_FIELD_RESOLVE_NO_FIELDS 语义漂移。
            LOG.warn("checkTableExists: getTables failed (metadata lookup error, not a missing table): schema={}, table={}",
                    schema, tableName, e);
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_TABLE_VISIBILITY_CHECK_FAILED, e)
                    .param(NopMetadataErrors.ARG_SCHEMA, schema)
                    .param(NopMetadataErrors.ARG_TABLE_NAME, tableName)
                    .param(NopMetadataErrors.ARG_ERROR, messageOf(e));
        }
        return false;
    }

    public static java.math.BigDecimal toBigDecimal(Object v) {
        if (v instanceof java.math.BigDecimal) {
            return (java.math.BigDecimal) v;
        }
        if (v instanceof java.math.BigInteger) {
            return new java.math.BigDecimal((java.math.BigInteger) v);
        }
        if (v instanceof Number) {
            Number n = (Number) v;
            // AR-10：整数类型用 longValue() 无损转换——Long > 2^53 经 doubleValue() 会丢低位；
            // AtomicLong/AtomicInteger 同为整数子类型（不继承 Long/Integer，需显式判断）
            if (n instanceof Long || n instanceof Integer || n instanceof Short || n instanceof Byte
                    || n instanceof java.util.concurrent.atomic.AtomicLong
                    || n instanceof java.util.concurrent.atomic.AtomicInteger) {
                return java.math.BigDecimal.valueOf(n.longValue());
            }
            // Float/Double 及其它 Number 子类型保持 doubleValue()（小数不截断）
            return java.math.BigDecimal.valueOf(n.doubleValue());
        }
        // AR-10：String 类型数值（部分 JDBC driver 交付方式）尝试解析，不再静默 return null
        if (v instanceof String) {
            String s = ((String) v).trim();
            if (s.isEmpty()) {
                return null;
            }
            try {
                return new java.math.BigDecimal(s);
            } catch (NumberFormatException e) {
                // INV-SILENT-SWALLOW（plan 2026-08-14-1448-2）：非数值字符串是
                // 预期的 coercion miss（返回 null 由调用方回退非数值处理，如
                // string stats）。DEBUG 日志携带 ErrorCode 上下文保留可见信号——
                // 与 probeNumeric（AR-06）同类 benign-miss 形式化，不静默吞。
                String code = NopMetadataErrors.ERR_AGGR_VALUE_NOT_NUMERIC
                        .getErrorCode();
                LOG.debug(code + ": toBigDecimal null (not numeric)", e);
                return null;
            }
        }
        return null;
    }

    public static String buildFromClause(NopMetaTable table) {
        if (_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(table.getTableType())) {
            String sourceSql = table.getSourceSql();
            if (sourceSql == null || sourceSql.trim().isEmpty()) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXEC_FAILED)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                        .param(NopMetadataErrors.ARG_ERROR, "sql table sourceSql is empty");
            }
            return "(" + sourceSql + ") _t";
        }
        String tableName = table.getTableName();
        FilterToSqlTranslator.validateIdentifier(tableName);
        return tableName;
    }

    public static String buildExternalAggregationSql(NopMetaTable table,
                                                      List<AggregationContext.MeasureSpec> measures,
                                                      List<AggregationContext.DimensionSpec> dims, TreeBean filter,
                                                      TreeBean having,
                                                      List<OrderFieldBean> orderBy, Map<String, String> nameToExpr,
                                                      List<String> measureNames, List<String> dimensionNames,
                                                      Long limit, Long offset,
                                                      String dialect, MetaQueryContext ctx) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> groupExprs = new ArrayList<>();
        for (int i = 0; i < dims.size(); i++) {
            AggregationContext.DimensionSpec d = dims.get(i);
            String expr;
            if (_NopMetadataCoreConstants.DIMENSION_TYPE_TEMPORAL.equals(d.dimensionType) && d.granularity != null) {
                expr = GranularityBucketing.translate(d.granularity, d.column, dialect, d.alias);
            } else {
                FilterToSqlTranslator.validateIdentifier(d.column);
                expr = d.column;
            }
            sql.append(i == 0 ? "" : ",").append(expr).append(" AS ").append(d.alias);
            groupExprs.add(expr);
        }
        for (AggregationContext.MeasureSpec m : measures) {
            sql.append(",").append(m.aggSql).append(" AS ").append(m.alias);
        }

        String fromClause = buildFromClause(table);
        sql.append(" FROM ").append(fromClause);

        if (filter != null) {
            FilterToSqlTranslator.TranslatedFilter tf = ctx.filterTranslator().translate(filter);
            if (tf.getSql() != null && !tf.getSql().isEmpty()) {
                sql.append(" WHERE ").append(tf.getSql());
            }
        }
        sql.append(" GROUP BY ").append(String.join(",", groupExprs));
        if (having != null) {
            MetaAggregationExecutor.preprocessHavingArithmetic(having, nameToExpr, table, measureNames, dimensionNames);
            FilterToSqlTranslator.TranslatedFilter hf = ctx.filterTranslator().translate(having,
                    nameResolverFor(nameToExpr, table, measureNames, dimensionNames, "HAVING"));
            if (hf.getSql() != null && !hf.getSql().isEmpty()) {
                sql.append(" HAVING ").append(hf.getSql());
            }
        }
        String orderByClause = buildOrderByClause(orderBy, nameToExpr, table, measureNames, dimensionNames, "ORDER_BY", dialect);
        if (!orderByClause.isEmpty()) {
            sql.append(" ORDER BY ").append(orderByClause);
        }
        SqlPagination.appendLimitOffset(sql, limit, offset, dialect);
        return sql.toString();
    }

    public static List<Object> collectBindParams(List<AggregationContext.MeasureSpec> measures,
                                                  List<AggregationContext.DimensionSpec> dims, TreeBean filter,
                                                  TreeBean having, Map<String, String> nameToExpr, MetaQueryContext ctx,
                                                  NopMetaTable table,
                                                  List<String> measureNames, List<String> dimensionNames) {
        List<Object> params = new ArrayList<>();
        for (AggregationContext.MeasureSpec m : measures) {
            if (m.expressionParams != null) {
                params.addAll(m.expressionParams);
            }
        }
        if (filter != null) {
            FilterToSqlTranslator.TranslatedFilter tf = ctx.filterTranslator().translate(filter);
            params.addAll(tf.getParams());
        }
        if (having != null) {
            FilterToSqlTranslator.TranslatedFilter hf = ctx.filterTranslator().translate(having,
                    nameResolverFor(nameToExpr, table, measureNames, dimensionNames, "HAVING"));
            params.addAll(hf.getParams());
        }
        return params;
    }

    public static StringBuilder buildExternalExternalJoinSql(
            List<AggregationContext.JoinMeasureSpec> measures,
            List<AggregationContext.JoinDimensionSpec> dims,
            String leftFrom, String rightFrom, String leftJoinCol,
            String rightJoinCol, NopMetaTableJoin join,
            FilterToSqlTranslator.TranslatedFilter filterTf,
            FilterToSqlTranslator.TranslatedFilter havingTf,
            String orderByClause,
            String dialect, Long limit, Long offset) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> groupExprs = new ArrayList<>();
        for (int i = 0; i < dims.size(); i++) {
            AggregationContext.JoinDimensionSpec d = dims.get(i);
            String expr;
            if (_NopMetadataCoreConstants.DIMENSION_TYPE_TEMPORAL.equals(d.dimensionType) && d.granularity != null) {
                expr = GranularityBucketing.translate(d.granularity, d.qualifiedCol, dialect, d.alias);
                FilterToSqlTranslator.validateIdentifier(d.column);
            } else {
                expr = d.qualifiedCol;
            }
            sql.append(i == 0 ? "" : ",").append(expr).append(" AS ").append(d.alias);
            groupExprs.add(expr);
        }
        for (AggregationContext.JoinMeasureSpec m : measures) {
            sql.append(",").append(m.aggSql).append(" AS ").append(m.alias);
        }
        sql.append(" FROM ").append(leftFrom);
        String joinKeyword = _NopMetadataCoreConstants.JOIN_TYPE_INNER.equals(join.getJoinType())
                ? " INNER JOIN " : " LEFT JOIN ";
        sql.append(joinKeyword).append(rightFrom)
                .append(" ON l.").append(leftJoinCol)
                .append(" = r.").append(rightJoinCol);

        if (filterTf != null && filterTf.getSql() != null && !filterTf.getSql().isEmpty()) {
            sql.append(" WHERE ").append(filterTf.getSql());
        }
        sql.append(" GROUP BY ").append(String.join(",", groupExprs));
        if (havingTf != null && havingTf.getSql() != null && !havingTf.getSql().isEmpty()) {
            sql.append(" HAVING ").append(havingTf.getSql());
        }
        if (!orderByClause.isEmpty()) {
            sql.append(" ORDER BY ").append(orderByClause);
        }
        SqlPagination.appendLimitOffset(sql, limit, offset, dialect);
        return sql;
    }

    public static StringBuilder buildMixedSameDbJoinSql(
            List<AggregationContext.JoinMeasureSpec> measures,
            List<AggregationContext.JoinDimensionSpec> dims,
            String entityFrom, String tableFrom,
            String entityAlias, String tableAlias,
            String entityJoinColumn, String tableJoinColumn,
            NopMetaTableJoin join,
            FilterToSqlTranslator.TranslatedFilter filterTf,
            FilterToSqlTranslator.TranslatedFilter havingTf,
            String orderByClause,
            String dialect, Long limit, Long offset) {
        StringBuilder sql = new StringBuilder("SELECT ");
        List<String> groupExprs = new ArrayList<>();
        for (int i = 0; i < dims.size(); i++) {
            AggregationContext.JoinDimensionSpec d = dims.get(i);
            String expr;
            if (_NopMetadataCoreConstants.DIMENSION_TYPE_TEMPORAL.equals(d.dimensionType) && d.granularity != null) {
                expr = GranularityBucketing.translate(d.granularity, d.qualifiedCol, dialect, d.alias);
                FilterToSqlTranslator.validateIdentifier(d.column);
            } else {
                expr = d.qualifiedCol;
            }
            sql.append(i == 0 ? "" : ",").append(expr).append(" AS ").append(d.alias);
            groupExprs.add(expr);
        }
        for (AggregationContext.JoinMeasureSpec m : measures) {
            sql.append(",").append(m.aggSql).append(" AS ").append(m.alias);
        }
        sql.append(" FROM ").append(entityFrom);
        String joinKeyword = _NopMetadataCoreConstants.JOIN_TYPE_INNER.equals(join.getJoinType())
                ? " INNER JOIN " : " LEFT JOIN ";
        sql.append(joinKeyword).append(tableFrom)
                .append(" ON ").append(entityAlias).append(".").append(entityJoinColumn)
                .append(" = ").append(tableAlias).append(".").append(tableJoinColumn);

        if (filterTf != null && filterTf.getSql() != null && !filterTf.getSql().isEmpty()) {
            sql.append(" WHERE ").append(filterTf.getSql());
        }
        sql.append(" GROUP BY ").append(String.join(",", groupExprs));
        if (havingTf != null && havingTf.getSql() != null && !havingTf.getSql().isEmpty()) {
            sql.append(" HAVING ").append(havingTf.getSql());
        }
        if (!orderByClause.isEmpty()) {
            sql.append(" ORDER BY ").append(orderByClause);
        }
        SqlPagination.appendLimitOffset(sql, limit, offset, dialect);
        return sql;
    }

    public static Map<String, String> buildCrossDbNameToAliasTable(
            List<AggregationContext.CrossDbMeasureSpec> measures,
            List<AggregationContext.CrossDbDimensionSpec> dims,
            List<String> measureNames,
            List<String> dimensionNames, NopMetaTable table) {
        Map<String, String> map = new LinkedHashMap<>();
        if (measures.size() != measureNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: cross-db measures/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < measures.size(); i++) {
            map.put(measureNames.get(i), measures.get(i).alias);
        }
        if (dims.size() != dimensionNames.size()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                    .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                    .param(NopMetadataErrors.ARG_NAME, "<internal>: cross-db dims/names length mismatch")
                    .param(NopMetadataErrors.ARG_SELECTED_MEASURES, String.valueOf(measureNames))
                    .param(NopMetadataErrors.ARG_SELECTED_DIMENSIONS, String.valueOf(dimensionNames));
        }
        for (int i = 0; i < dims.size(); i++) {
            map.put(dimensionNames.get(i), dims.get(i).alias);
        }
        return map;
    }

    public static void resolveAndValidateLookupKeys(List<? extends AggregationContext.CrossDbFieldSpec> specs,
                                                      String alias,
                                                      Map<String, Object> sampleRow, NopMetaTable table, String joinId,
                                                      String fieldKind) {
        for (AggregationContext.CrossDbFieldSpec spec : specs) {
            String rawKey = spec.rawKey;
            String lookupKey;
            if (_NopMetadataCoreConstants.JOIN_SIDE_RIGHT.equalsIgnoreCase(spec.side)) {
                String prefixed = alias + "_" + rawKey;
                String actualPrefixed = findKeyIgnoreCase(sampleRow, prefixed);
                lookupKey = actualPrefixed != null ? actualPrefixed : rawKey;
            } else {
                lookupKey = rawKey;
            }
            String actual = findKeyIgnoreCase(sampleRow, lookupKey);
            if (actual == null) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_CROSS_DB_FIELD_KEY_MISSING)
                        .param(NopMetadataErrors.ARG_META_TABLE_ID, table.getMetaTableId())
                        .param(NopMetadataErrors.ARG_NAME, spec.alias)
                        .param(NopMetadataErrors.ARG_FIELD_KIND, fieldKind)
                        .param(NopMetadataErrors.ARG_RAW_KEY, String.valueOf(rawKey))
                        .param(NopMetadataErrors.ARG_LOOKUP_KEY, String.valueOf(lookupKey))
                        .param(NopMetadataErrors.ARG_ROW_KEYS, sampleRow.keySet())
                        .param(NopMetadataErrors.ARG_JOIN_ID, joinId);
            }
            spec.lookupKey = actual;
        }
    }

    public static List<Map<String, Object>> memoryGroupBy(List<Map<String, Object>> rows,
                                                           List<AggregationContext.CrossDbMeasureSpec> measures,
                                                           List<AggregationContext.CrossDbDimensionSpec> dims) {
        // AR-03（plan 2026-08-14-0707-2）：用结构性 key（值级 equals/hashCode 的 List<Object>）替换分隔符
        // 拼接 String——消除 "\u0001" 连接符 / "\u0000" null 哨兵导致的碰撞：
        //   ("a","\u0001b") 与 ("a\u0001","b") 拼出相同 String key → 行被错误合并；
        //   null 与字面量 "\u0000" 碰撞。List 元素级 equals/hashCode 天然区分这些值。
        LinkedHashMap<List<Object>, Map<String, Object>> groupDims = new LinkedHashMap<>();
        LinkedHashMap<List<Object>, AggregationContext.MemAggAccumulator[]> groupAccs = new LinkedHashMap<>();

        for (Map<String, Object> row : rows) {
            Object[] dimValues = new Object[dims.size()];
            List<Object> groupKey = new ArrayList<>(dims.size());
            for (int i = 0; i < dims.size(); i++) {
                Object v = getCaseInsensitiveObj(row, dims.get(i).lookupKey);
                dimValues[i] = v;
                groupKey.add(v);
            }

            Map<String, Object> gRow = groupDims.get(groupKey);
            AggregationContext.MemAggAccumulator[] accs = groupAccs.get(groupKey);
            if (gRow == null) {
                gRow = new LinkedHashMap<>();
                for (int i = 0; i < dims.size(); i++) {
                    gRow.put(dims.get(i).alias, dimValues[i]);
                }
                groupDims.put(groupKey, gRow);
                accs = AggregationContext.MemAggAccumulator.newAccumulators(measures);
                groupAccs.put(groupKey, accs);
            }
            for (int i = 0; i < measures.size(); i++) {
                Object val = getCaseInsensitiveObj(row, measures.get(i).lookupKey);
                accs[i].accumulate(val);
            }
        }

        List<Map<String, Object>> items = new ArrayList<>(groupDims.size());
        for (Map.Entry<List<Object>, Map<String, Object>> e : groupDims.entrySet()) {
            Map<String, Object> item = new LinkedHashMap<>(e.getValue());
            AggregationContext.MemAggAccumulator[] accs = groupAccs.get(e.getKey());
            for (int i = 0; i < measures.size(); i++) {
                item.put(measures.get(i).alias, accs[i].result());
            }
            items.add(item);
        }
        return items;
    }

    public static List<Map<String, Object>> truncateCrossDb(List<Map<String, Object>> rows, Long limit, Long offset) {
        int from = 0;
        if (offset != null && offset > 0) {
            if (offset > Integer.MAX_VALUE) {
                throw new NopMetadataException(NopMetadataErrors.ERR_PAGINATION_OFFSET_TOO_LARGE).param(NopMetadataErrors.ARG_OFFSET, offset);
            }
            from = offset.intValue();
        }
        if (from > rows.size()) {
            from = rows.size();
        }
        int to = rows.size();
        if (limit != null) {
            // AR-09（plan 2026-08-06-0553-3 Phase 1）：负 limit 显式拒绝（defense-in-depth——
            // 入口归一化已拒绝，此处兜底直接调用本方法的路径）
            if (limit < 0) {
                throw new NopMetadataException(NopMetadataErrors.ERR_PAGINATION_LIMIT_INVALID)
                        .param(NopMetadataErrors.ARG_LIMIT, limit);
            }
            if (limit > Integer.MAX_VALUE) {
                throw new NopMetadataException(NopMetadataErrors.ERR_PAGINATION_LIMIT_TOO_LARGE).param(NopMetadataErrors.ARG_LIMIT, limit);
            }
            // AR-09：long 运算防 int 溢出（from + limit 溢出为负 → subList 裸 IllegalArgumentException）
            to = (int) Math.min(rows.size(), (long) from + limit);
        }
        return new ArrayList<>(rows.subList(from, to));
    }

    public static List<AggregationContext.JoinMeasureSpec> loadJoinMeasuresWithResolver(
            NopMetaTable table, List<String> names,
            MetaQueryContext ctx,
            AggregationContext.JoinFieldResolverFn resolver,
            Set<String> leftCols, Set<String> rightCols) {
        List<NopMetaTableMeasure> all = loadMeasures(table, names, ctx);
        List<AggregationContext.JoinMeasureSpec> specs = new ArrayList<>();
        for (NopMetaTableMeasure m : all) {
            if (m.getExpression() != null && !m.getExpression().trim().isEmpty()) {
                ExpressionMeasureValidator.ValidatedExpression ve =
                        ExpressionMeasureValidator.validateStatic(m.getExpression(),
                                ExpressionMeasureValidator.ValidationOptions.joinStrict(leftCols, rightCols),
                                table.getMetaTableId(), m.getMeasureName());
                specs.add(new AggregationContext.JoinMeasureSpec(safeAlias(m.getMeasureName()),
                        aggSqlOf(m.getAggFunc(), ve.sqlFragment, m.getMeasureName()),
                        "<expression>", ve.params, ve));
                continue;
            }
            AggregationContext.JoinField f = resolver.resolve(m.getEntityFieldId(), m.getMeasureName(), m.getSide());
            FilterToSqlTranslator.validateIdentifier(f.column);
            specs.add(new AggregationContext.JoinMeasureSpec(safeAlias(m.getMeasureName()),
                    aggSqlOf(m.getAggFunc(), f.qualifiedColumn, m.getMeasureName()), f.qualifiedColumn));
        }
        return specs;
    }

    public static List<AggregationContext.JoinDimensionSpec> loadJoinDimensionsWithResolver(
            NopMetaTable table, List<String> names,
            MetaQueryContext ctx,
            AggregationContext.JoinFieldResolverFn resolver) {
        List<NopMetaTableDimension> all = loadDimensions(table, names, ctx);
        List<AggregationContext.JoinDimensionSpec> specs = new ArrayList<>();
        for (NopMetaTableDimension d : all) {
            AggregationContext.JoinField f = resolver.resolve(d.getEntityFieldId(), d.getDimensionName(), d.getSide());
            FilterToSqlTranslator.validateIdentifier(f.column);
            specs.add(new AggregationContext.JoinDimensionSpec(safeAlias(d.getDimensionName()), f.qualifiedColumn, f.column,
                    d.getDimensionType(), d.getGranularity()));
        }
        return specs;
    }
}
