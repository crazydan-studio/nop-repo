package io.nop.metadata.service.entity;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.api.core.annotations.ioc.InjectValue;
import io.nop.api.core.beans.FieldSelectionBean;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.TreeBean;
import io.nop.api.core.beans.query.OrderFieldBean;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.commons.util.CollectionHelper;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.json.JsonTool;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.biz.INopMetaModuleBiz;
import io.nop.metadata.biz.INopMetaProfilingResultBiz;
import io.nop.metadata.biz.INopMetaTableBiz;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.api.dto.AggregationResultDTO;
import io.nop.metadata.api.dto.CreateSqlTableResultDTO;
import io.nop.metadata.api.dto.PreviewSqlFieldsResultDTO;
import io.nop.metadata.api.dto.ProfileResultDTO;
import io.nop.metadata.api.dto.QueryJoinDataResultDTO;
import io.nop.metadata.api.dto.QueryTableDataResultDTO;
import io.nop.metadata.api.dto.ResolveTableFieldsResultDTO;
import io.nop.metadata.api.dto.ResolvedTableFieldDTO;
import io.nop.metadata.api.dto.SqlViewFieldDTO;
import io.nop.metadata.dao.entity.NopMetaDataSource;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaModule;
import io.nop.metadata.dao.entity.NopMetaProfilingResult;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataArgs;
import io.nop.metadata.service.connection.IMetaDataSourceConnectionProcessor;
import io.nop.metadata.service.event.MetaModelChangedEventPublisher;
import io.nop.metadata.service.field.ResolvedTableField;
import io.nop.metadata.service.profiling.MetaTableProfiler;
import io.nop.metadata.service.profiling.ProfilingSnapshot;
import io.nop.metadata.service.query.MetaAggregationExecutor;
import io.nop.metadata.service.query.MetaJoinExecutor;
import io.nop.metadata.service.query.MetaQueryContext;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.metadata.service.search.NopMetaSearchProcessor;
import io.nop.metadata.service.sqlview.SqlViewField;
import io.nop.metadata.service.sqlview.SqlViewFieldTypeInferrer;
import io.nop.metadata.service.tableref.TableReference;
import io.nop.metadata.service.tableref.TableReferenceExecutor;
import io.nop.search.api.SearchableDoc;
import io.nop.metadata.service.NopMetadataException;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@BizModel("NopMetaTable")
public class NopMetaTableBizModel extends CrudBizModel<NopMetaTable> implements INopMetaTableBiz {

    /** MA7.4-03：queryTableData 缺省 limit（省略时避免全表拉入内存） */
    public static final int DEFAULT_QUERY_LIMIT = 1000;

    /** MA7.4-03：queryTableData limit 上限（防单次查询内存放大） */
    public static final int DEFAULT_MAX_QUERY_LIMIT = 10000;

    @InjectValue(value = "@cfg:nop.metadata.query.max-limit|0")
    protected int configuredMaxQueryLimit = 0;

    private static final Logger LOG = LoggerFactory.getLogger(NopMetaTableBizModel.class);

    @Inject
    protected IMetaDataSourceConnectionProcessor connectionService;

    @Inject
    protected MetaModelChangedEventPublisher eventPublisher;

    @Inject
    protected NopMetaSearchProcessor searchService;

    /** 跨聚合访问（plan 353 MD-1）：MetaModule 读取 / ProfilingResult 写入经 Biz 接口而非 dao 直连。 */
    @Inject
    protected INopMetaModuleBiz moduleBiz;

    @Inject
    protected INopMetaProfilingResultBiz profilingResultBiz;

    static final String EVENT_ENTITY_TYPE = "NopMetaTable";

    private final MetaTableProfiler profiler = new MetaTableProfiler();
    private final MetaJoinExecutor joinExecutor = new MetaJoinExecutor();
    private final MetaAggregationExecutor aggregationExecutor = new MetaAggregationExecutor(joinExecutor);
    private final NopMetaTableQueryAction queryAction = new NopMetaTableQueryAction();

    private TableReferenceExecutor tableRefExecutor;

    public NopMetaTableBizModel() {
        setEntityName(NopMetaTable.class.getName());
    }

    @Override
    public NopMetaTable save(@Name("data") Map<String, Object> data, IServiceContext context) {
        // P2-19（plan 2026-08-16-0226-3）：null/empty data 提前委托基类
        // （形态统一，此前三元形态只防 null），统一抛 ERR_BIZ_EMPTY_DATA_FOR_SAVE
        if (CollectionHelper.isEmptyMap(data)) {
            return super.save(data, context);
        }
        String id = NopMetadataHelper.stringOf(data, NopMetaTable.PROP_NAME_metaTableId);
        NopMetaTable before = id != null ? dao().getEntityById(id) : null;
        NopMetaTable saved = super.save(data, context);
        String eventType = before == null
                ? _NopMetadataCoreConstants.CHANGE_EVENT_TYPE_ENTITY_CREATED
                : _NopMetadataCoreConstants.CHANGE_EVENT_TYPE_ENTITY_UPDATED;
        String afterSnapshot = eventPublisher.buildSnapshot(saved, EVENT_ENTITY_TYPE, saved.getMetaTableId());
        String beforeSnapshot = before != null
                ? eventPublisher.buildSnapshot(before, EVENT_ENTITY_TYPE, saved.getMetaTableId()) : null;
        eventPublisher.publishEventWithSnapshots(eventType, EVENT_ENTITY_TYPE, saved.getMetaTableId(),
                saved.getTableName(), MetaModelChangedEventPublisher.CHANGE_SOURCE_API,
                beforeSnapshot, afterSnapshot,
                MetaModelChangedEventPublisher.newTransactionId(), context);
        searchService.addToIndex("MetaTable", saved.getMetaTableId(), toSearchableDoc(saved));
        return saved;
    }

    @Override
    public boolean delete(@Name("id") String id, IServiceContext context) {
        NopMetaTable before = requireEntity(id, "delete", context);
        boolean deleted = super.delete(id, context);
        String beforeSnapshot = eventPublisher.buildSnapshot(before, EVENT_ENTITY_TYPE, id);
        eventPublisher.publishEventWithSnapshots(
                _NopMetadataCoreConstants.CHANGE_EVENT_TYPE_ENTITY_DELETED,
                EVENT_ENTITY_TYPE, id, before.getTableName(),
                MetaModelChangedEventPublisher.CHANGE_SOURCE_API,
                beforeSnapshot, null,
                MetaModelChangedEventPublisher.newTransactionId(), context);
        // check2 P2-06（2026-08-23 审计）：主实体索引清理走 best-effort——removeFromIndex 在
        // BizMutation 事务内、提交前执行且不可回滚，fail-closed（默认）抛
        // ERR_SEARCH_INDEX_REMOVE_FAILED 会使事务回滚 → "DB 行留存、索引文档已删"的分裂
        // （实体存在却搜不到）。对齐 NopMetaModuleBizModel.safeRemoveFromIndex 先例（子实体
        // 清理 NopMetaEntityBizModel 已有同款防护，主实体级此前遗漏）。
        safeRemoveFromIndex("MetaTable", id);
        return deleted;
    }

    /** check2 P2-06：主实体索引清理 best-effort（失败 WARN 不掩盖删除结果，不回滚 DB 删除）。 */
    private void safeRemoveFromIndex(String entityType, String id) {
        try {
            searchService.removeFromIndex(entityType, id);
        } catch (RuntimeException e) {
            LOG.warn("delete index cleanup failed for entityType={} id={}, errorCode={}",
                    entityType, id, NopMetadataErrors.ERR_ENTITY_SYNC_ISOLATED.getErrorCode(), e);
        }
    }

    @BizMutation
    public ProfileResultDTO profileTable(@Name("metaTableId") String metaTableId,
                                          @Optional @Name("schemaPattern") String schemaPattern,
                                          @Optional @Name("columns") String columns,
                                          IServiceContext context) {
        NopMetaTable table = requireEntity(metaTableId, "profile", context);
        // resolver 边界：MetaTableReferenceResolver API 消费 IEntityDao（tableref/resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        TableReference ref = queryAction.tableRefResolver().resolve(table,
                daoFor(NopMetaDataSource.class), daoFor(NopMetaEntity.class),
                daoFor(NopMetaEntityField.class), orm());
        String effectiveSchema = resolveDefaultSchema(schemaPattern, table);
        ProfilingSnapshot snapshot = ensureTableRefExecutor().execute(ref,
                (conn, metaData, productName) -> profiler.profile(conn, metaData, ref, effectiveSchema, columns, productName));
        NopMetaProfilingResult row = appendProfilingResult(null, metaTableId, snapshot, context);
        return NopMetaTableQueryAction.buildProfileResultDTO(row, snapshot);
    }

    @BizMutation
    public CreateSqlTableResultDTO createSqlTable(@Name("sql") String sql,
                                                   @Name("tableName") String tableName,
                                                   @Name("metaModuleId") String metaModuleId,
                                                   @Optional @Name("querySpace") String querySpace,
                                                   @Optional @Name("displayName") String displayName,
                                                   IServiceContext context) {
        List<SqlViewField> fields = queryAction.sqlFieldExtractor().extract(sql);
        if (querySpace != null && !querySpace.trim().isEmpty()) {
            // inferrer 边界：SqlViewFieldTypeInferrer API 消费 IEntityDao（sqlview 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
            fields = queryAction.ensureSqlFieldTypeInferrer(connectionService).inferTypes(
                    fields, sql, querySpace, daoFor(NopMetaDataSource.class));
        }
        NopMetaModule module = moduleBiz.requireEntity(metaModuleId, null, context);
        IEntityDao<NopMetaTable> tableDao = dao();
        // R4.2（plan-2026-08-05-1625-1 D5）：4 列 UK 含可空 META_SCHEMA 后 SQL 表（恒 null-schema）
        // 第二次创建不再被 DB 层 UK 拦截——补 find-or-fail 守卫保持 fail-fast 语义。
        // R6.3（plan-2026-08-05-2157-3 Phase 2，AR-08）：守卫逐字对齐 4 列 UK
        // (metaModuleId, tableName, isDelta, metaSchema)——补 isDelta=0 + metaSchema IS NULL 过滤，
        // 使已导入 delta 行 / 异 schema 行存在时不误报 ERR_SQL_VIEW_TABLE_EXISTS；
        // 仅真重复（同模块同表名同 isDelta=0 同 null-schema）仍 fail-fast。
        // 不做「null 或空串归一」：'' 与 NULL 在 UK 中是两个不同键（DB 允许共存），
        // 空串归一会误伤外部 NULL-schema 行的 '' 哨兵形态（误报面复发）。
        QueryBean dupQuery = new QueryBean();
        dupQuery.addFilter(FilterBeans.eq(NopMetaTable.PROP_NAME_metaModuleId, metaModuleId));
        dupQuery.addFilter(FilterBeans.eq(NopMetaTable.PROP_NAME_tableName, tableName));
        dupQuery.addFilter(FilterBeans.eq(NopMetaTable.PROP_NAME_isDelta, (byte) 0));
        dupQuery.addFilter(FilterBeans.isNull(NopMetaTable.PROP_NAME_metaSchema));
        if (tableDao.findFirstByQuery(dupQuery) != null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_SQL_VIEW_TABLE_EXISTS)
                    .param(NopMetadataArgs.ARG_META_MODULE_ID, metaModuleId)
                    .param(NopMetadataArgs.ARG_TABLE_NAME, tableName);
        }
        NopMetaTable table = tableDao.newEntity();
        table.setMetaModuleId(metaModuleId);
        table.setIsDelta((byte) 0);
        table.setTableName(tableName);
        table.setDisplayName(displayName != null ? displayName : tableName);
        table.setTableType(_NopMetadataCoreConstants.TABLE_TYPE_SQL);
        if (querySpace != null) table.setQuerySpace(querySpace);
        table.setSourceSql(sql);
        tableDao.saveEntity(table);
        eventPublisher.publishEvent(
                _NopMetadataCoreConstants.CHANGE_EVENT_TYPE_ENTITY_CREATED,
                EVENT_ENTITY_TYPE, table.getMetaTableId(), table.getTableName(),
                MetaModelChangedEventPublisher.CHANGE_SOURCE_UI,
                null, table, MetaModelChangedEventPublisher.newTransactionId(), context);
        CreateSqlTableResultDTO result = new CreateSqlTableResultDTO();
        result.setMetaTableId(table.getMetaTableId());
        result.setTableName(table.getTableName());
        result.setTableType(table.getTableType());
        result.setFields(toSqlViewFieldDTOs(fields));
        return result;
    }

    @BizQuery
    public PreviewSqlFieldsResultDTO previewSqlFields(@Name("sql") String sql, IServiceContext context) {
        List<SqlViewField> fields = queryAction.sqlFieldExtractor().extract(sql);
        PreviewSqlFieldsResultDTO result = new PreviewSqlFieldsResultDTO();
        result.setFields(toSqlViewFieldDTOs(fields));
        return result;
    }

    @BizQuery
    public ResolveTableFieldsResultDTO resolveTableFields(@Name("metaTableId") String metaTableId,
                                                           IServiceContext context) {
        NopMetaTable table = requireEntity(metaTableId, "query", context);
        // resolver 边界：MetaTableFieldResolver API 消费 IEntityDao（resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        IEntityDao<NopMetaEntityField> fieldDao = daoFor(NopMetaEntityField.class);
        List<ResolvedTableField> fields = queryAction.fieldResolver().resolve(table, fieldDao);
        if (_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(table.getTableType())
                && table.getQuerySpace() != null && !table.getQuerySpace().trim().isEmpty()) {
            fields = inferResolvedSqlFieldTypes(table, fields);
        }
        ResolveTableFieldsResultDTO result = new ResolveTableFieldsResultDTO();
        result.setTableType(table.getTableType());
        result.setFields(toResolvedTableFieldDTOs(fields));
        return result;
    }

    /**
     * F4（plan 2026-08-14-0707-2）——{@code selection} 参数契约说明：
     * <p>GraphQL 引擎（{@code ReflectionBizModelBuilder}）会将<b>响应字段选择集</b>（DTO 级，
     * 如 {@code { tableType items }}）自动注入 {@code selection} 参数——它<b>不是</b>调用方
     * 显式传入的行列过滤规范。由于本方法返回 {@code List<Map<String,Object>>}（Map 为不透明 JSON，
     * GraphQL 无法对 Map 行做字段级选择），{@code selection} 在此为<b>显式 no-op</b>：
     * 行的所有列原样返回，不做基于 selection 的 key 过滤。
     *
     * <p>这与 {@link CrudBizModel} 不同——CrudBizModel 的结果是 ORM 实体（有已知字段），
     * selection 经 {@code fetchResultWithSelection} 驱动实体字段装载。nop-metadata 查询结果为
     * 不透明 Map（列名为 JDBC/ORM 返回键），无字段级 selection 语义。该 no-op 已显式声明，
     * 不再"静默接受又丢弃"。若未来需要行列裁剪，应新增显式的 {@code fields} 参数。
     */
    @BizQuery
    public QueryTableDataResultDTO queryTableData(@Name("metaTableId") String metaTableId,
                                                   @Optional @Name("filter") TreeBean filter,
                                                   @Optional @Name("limit") Long limit,
                                                   @Optional @Name("offset") Long offset,
                                                   @Optional @Name("selection") FieldSelectionBean selection,
                                                   IServiceContext context) {
        NopMetaTable table = requireEntity(metaTableId, "query", context);
        String tableType = table.getTableType();
        QueryTableDataResultDTO result = new QueryTableDataResultDTO();
        result.setTableType(tableType);
        limit = normalizeQueryLimit(limit);
        if (table.isEntityTable()) {
            result.setItems(queryAction.queryEntityData(table, filter, limit, offset, daoProvider(), orm()));
        } else if (table.isExternalTable()) {
            result.setItems(queryAction.queryExternalData(table, filter, limit, offset, connectionService, daoProvider(), orm()));
        } else if (table.isSqlTable()) {
            result.setItems(queryAction.querySqlData(table, filter, limit, offset, connectionService, daoProvider(), orm()));
        } else {
            throw new NopMetadataException(NopMetadataErrors.ERR_QUERY_UNSUPPORTED_TABLE_TYPE)
                    .param("metaTableId", metaTableId)
                    .param("tableType", String.valueOf(tableType));
        }
        return result;
    }

    /** F4：{@code selection} 同 {@link #queryTableData} 的显式 no-op 契约说明（不透明 Map 结果，不做行级 key 过滤）。 */
    @BizQuery
    public QueryJoinDataResultDTO queryJoinData(@Name("metaTableId") String metaTableId,
                                                  @Name("joinId") String joinId,
                                                  @Optional @Name("filter") TreeBean filter,
                                                  @Optional @Name("limit") Long limit,
                                                  @Optional @Name("offset") Long offset,
                                                  @Optional @Name("selection") FieldSelectionBean selection,
                                                  IServiceContext context) {
        NopMetaTable table = requireEntity(metaTableId, "query", context);
        // AR-09（plan 2026-08-06-0553-3 Phase 1 裁定 (c)）：拒绝点固定在 BizModel 入口——
        // 三条 JOIN SQL 路径的 LIMIT 占位符直接把负值绑给 DB（appendLimitOffset 对 limit=-5 仍生成
        // LIMIT ?，DB 层报错被包装为 ERR_JOIN_TABLE_EXEC_FAILED / ERR_AGGR_EXEC_FAILED，错误不可诊断），
        // 若只在截断层拒绝则新错误码在 3/5 路径永远不触发；截断层 long 运算 + 负值拒绝为 defense-in-depth。
        limit = normalizeJoinQueryLimit(limit);
        Map<String, Object> raw = joinExecutor.executeJoin(table, joinId, filter, limit, offset, buildQueryContext());
        QueryJoinDataResultDTO result = new QueryJoinDataResultDTO();
        Object items = raw.get("items");
        if (items instanceof List) {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> itemsList = (List<Map<String, Object>>) items;
            result.setItems(itemsList);
        }
        return result;
    }

    /** F4：{@code selection} 同 {@link #queryTableData} 的显式 no-op 契约说明（不透明 Map 结果，不做行级 key 过滤）。 */
    @BizQuery
    public AggregationResultDTO queryAggregation(@Name("metaTableId") String metaTableId,
                                                  @Name("measures") List<String> measures,
                                                  @Name("dimensions") List<String> dimensions,
                                                  @Optional @Name("filter") TreeBean filter,
                                                  @Optional @Name("joinId") String joinId,
                                                  @Optional @Name("limit") Long limit,
                                                  @Optional @Name("offset") Long offset,
                                                  @Optional @Name("having") TreeBean having,
                                                  @Optional @Name("orderBy") List<OrderFieldBean> orderBy,
                                                  @Optional @Name("selection") FieldSelectionBean selection,
                                                  IServiceContext context) {
        NopMetaTable table = requireEntity(metaTableId, "query", context);
        // AR-09（plan 2026-08-06-0553-3 Phase 1 裁定 (c)）：拒绝点固定在 BizModel 入口（同 queryJoinData）
        limit = normalizeJoinQueryLimit(limit);
        Map<String, Object> raw = aggregationExecutor.executeAggregation(table, measures, dimensions, filter, joinId, limit, offset,
                having, orderBy, buildQueryContext());
        AggregationResultDTO result = new AggregationResultDTO();
        Object rawItems = raw.get("items");
        if (rawItems instanceof List) {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> itemsList = (List<Map<String, Object>>) rawItems;
            result.setItems(itemsList);
        }
        return result;
    }

    private MetaQueryContext buildQueryContext() {
        return new MetaQueryContext(daoProvider(), orm(), connectionService, ensureTableRefExecutor(),
                queryAction.dataSourceResolver(), queryAction.fieldResolver(), queryAction.filterTranslator());
    }

    private List<ResolvedTableField> inferResolvedSqlFieldTypes(NopMetaTable table,
                                                                 List<ResolvedTableField> resolvedFields) {
        List<SqlViewField> asViewFields = new ArrayList<>(resolvedFields.size());
        for (ResolvedTableField f : resolvedFields) {
            asViewFields.add(new SqlViewField(f.getName(), null, null));
        }
        List<SqlViewField> inferred = queryAction.ensureSqlFieldTypeInferrer(connectionService).inferTypes(
                asViewFields, table.getSourceSql(), table.getQuerySpace(), daoFor(NopMetaDataSource.class)); // inferrer 边界：同 createSqlTable，保留 dao 直连（plan 353 MD-1 裁定）
        List<ResolvedTableField> out = new ArrayList<>(resolvedFields.size());
        for (int i = 0; i < resolvedFields.size(); i++) {
            ResolvedTableField orig = resolvedFields.get(i);
            out.add(new ResolvedTableField(orig.getName(), orig.getSourceType(), inferred.get(i).getType()));
        }
        return out;
    }

    NopMetaProfilingResult appendProfilingResult(String profilingRuleId, String metaTableId,
                                                  ProfilingSnapshot snapshot, IServiceContext context) {
        NopMetaProfilingResult row = profilingResultBiz.newEntity();
        if (profilingRuleId != null) row.setProfilingRuleId(profilingRuleId);
        row.setMetaTableId(metaTableId);
        row.setSnapshotTime(io.nop.api.core.time.CoreMetrics.currentTimestamp());
        row.setTableStats(JsonTool.stringify(snapshot.toTableStatsMap()));
        row.setColumnStats(JsonTool.stringify(snapshot.toColumnStatsList()));
        profilingResultBiz.saveEntity(row, null, context);
        return row;
    }

    private static List<SqlViewFieldDTO> toSqlViewFieldDTOs(List<SqlViewField> fields) {
        List<SqlViewFieldDTO> list = new ArrayList<>(fields.size());
        for (SqlViewField f : fields) {
            list.add(new SqlViewFieldDTO(f.getName(), f.getAlias(), f.getType()));
        }
        return list;
    }

    private static List<ResolvedTableFieldDTO> toResolvedTableFieldDTOs(List<ResolvedTableField> fields) {
        List<ResolvedTableFieldDTO> list = new ArrayList<>(fields.size());
        for (ResolvedTableField f : fields) {
            list.add(new ResolvedTableFieldDTO(f.getName(), f.getSourceType(), f.getDataType()));
        }
        return list;
    }

    private static String resolveDefaultSchema(String schemaPattern, NopMetaTable table) {
        if (schemaPattern != null && !schemaPattern.trim().isEmpty()) {
            return schemaPattern;
        }
        return table.getMetaSchema();
    }

    private TableReferenceExecutor ensureTableRefExecutor() {
        if (tableRefExecutor == null) {
            tableRefExecutor = new TableReferenceExecutor(connectionService, orm());
        }
        return tableRefExecutor;
    }

    private SearchableDoc toSearchableDoc(NopMetaTable entity) {
        return NopMetadataHelper.toSearchableDoc(entity);
    }

    /**
     * 归一化 queryTableData 的 limit（MA7.4-03 + INV-LIMIT）：
     * <ul>
     *   <li>{@code limit < 0} → 显式拒绝 {@code ERR_PAGINATION_LIMIT_INVALID}——负 limit 是参数错误，
     *       静默钳制到默认值会掩盖调用方 bug（INV-LIMIT，与 {@link #normalizeJoinQueryLimit} 对齐，
     *       沿 AR-09 先例）。MA7.4-03 的范围是「缺省值 + 上限」（null/大正值），不含负值。</li>
     *   <li>{@code limit == null 或 0} → 缺省值 {@link #DEFAULT_QUERY_LIMIT}（MA7.4-03：防止省略 limit
     *       的大表查询把全表拉入内存序列化）。</li>
     *   <li>{@code limit > 0} → 超上限封顶 {@code Math.min(limit, max)}（MA7.4-03 上限配置）。</li>
     * </ul>
     */
    private Long normalizeQueryLimit(Long limit) {
        if (limit != null && limit < 0) {
            throw new NopMetadataException(NopMetadataErrors.ERR_PAGINATION_LIMIT_INVALID)
                    .param(NopMetadataErrors.ARG_LIMIT, limit);
        }
        if (limit == null || limit == 0) {
            return (long) DEFAULT_QUERY_LIMIT;
        }
        long max = configuredMaxQueryLimit > 0 ? configuredMaxQueryLimit : DEFAULT_MAX_QUERY_LIMIT;
        return Math.min(limit, max);
    }

    /**
     * 归一化 queryJoinData / queryAggregation 的 limit（AR-09，plan 2026-08-06-0553-3 Phase 1 裁定 (a)/(b)/(d)）：
     * <ul>
     *   <li>{@code limit < 0} → 显式拒绝 {@code ERR_PAGINATION_LIMIT_INVALID}——负 limit 是参数错误，
     *       静默钳制到默认值会掩盖调用方 bug，且 LIMIT ? 占位符会把负值绑给 DB 得到不可诊断的 SQL 错误。</li>
     *   <li>{@code limit == null 或 0} → 缺省值 {@link #DEFAULT_QUERY_LIMIT}（有界，不提供"无界"选项，
     *       裁定 (d) 沿用 queryTableData 的缺省语义）。</li>
     *   <li>{@code limit > 0} → 原样透传；超 {@code Integer.MAX_VALUE} 由截断层
     *       {@code ERR_PAGINATION_LIMIT_TOO_LARGE} 显式拒绝，不做静默封顶。</li>
     * </ul>
     *
     * <p>与 {@link #normalizeQueryLimit}（queryTableData）的差异（裁定 (b)，文档化于
     * {@code docs-for-ai/03-modules/nop-metadata.md}）：两者对负值均显式拒绝（INV-LIMIT 统一）；
     * 差异仅在正值上限——queryTableData（数据浏览入口）对超大 limit 静默封顶，queryJoinData/queryAggregation
     * （分析/分页入口）原样透传由截断层显式拒绝——静默改 limit 会让分页语义静默漂移，两入口差异为有意裁定。
     */
    private Long normalizeJoinQueryLimit(Long limit) {
        if (limit != null && limit < 0) {
            throw new NopMetadataException(NopMetadataErrors.ERR_PAGINATION_LIMIT_INVALID)
                    .param(NopMetadataErrors.ARG_LIMIT, limit);
        }
        if (limit == null || limit == 0) {
            return (long) DEFAULT_QUERY_LIMIT;
        }
        return limit;
    }
}
