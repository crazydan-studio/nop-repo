
package io.nop.metadata.service.entity;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizQuery;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.annotations.core.Optional;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.json.JsonTool;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.biz.INopMetaDataSourceBiz;
import io.nop.metadata.biz.INopMetaQualityRuleBiz;
import io.nop.metadata.biz.INopMetaTableBiz;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.api.dto.ErrorDTO;
import io.nop.metadata.api.dto.QualityRuleExecuteResultDTO;
import io.nop.metadata.api.dto.QualityRulesForDataSourceResultDTO;
import io.nop.metadata.dao.entity.NopMetaDataSource;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaQualityResult;
import io.nop.metadata.dao.entity.NopMetaQualityRule;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.service.connection.IMetaDataSourceConnectionProcessor;
import io.nop.metadata.service.datasource.MetaDataSourceResolver;
import io.nop.metadata.service.quality.MetaQualityRuleExecutor;
import io.nop.metadata.service.quality.QualityAlertWorkflowProcessor;
import io.nop.metadata.service.quality.QualityResultWriter;
import io.nop.metadata.service.quality.QualityRuleJudgment;
import io.nop.metadata.service.tableref.MetaTableReferenceResolver;
import io.nop.metadata.service.tableref.TableReference;
import io.nop.metadata.service.tableref.TableReferenceExecutor;
import io.nop.metadata.service.NopMetadataException;

import static io.nop.metadata.service.query.AggregationHelper.safeProductName;

import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 质量规则 BizModel：基线 CRUD（{@link CrudBizModel}）+ 质量规则执行引擎（架构基线 §2.7.1）。
 *
 * <p>执行机制（D2）：BizModel action + P2-1 {@code withConnection} callback（不选 nop-batch）。
 *
 * <p>执行范围（D1 → D4 扩展）：external/entity/sql 任意 tableType 的逻辑表上挂载的 table/field 级规则均可执行
 * （field 规则 entityId 指向逻辑表，物理列名取自 params.column）。
 * entityType=database 首版 SKIP（带 details 标记）。
 *
 * <p>失败/不可执行路径均显式（不静默通过、不吞异常、不伪造值）：
 * <ul>
 *   <li>规则不存在 → 抛 {@link #NopMetadataErrors.ERR_QUALITY_RULE_NOT_FOUND}（不 NPE）</li>
 *   <li>目标表不存在 → 抛 {@link #NopMetadataErrors.ERR_QUALITY_TABLE_NOT_FOUND}</li>
 *   <li>表引用解析失败（未知 tableType / baseEntityId 为空 / 无注册数据源等） → 由
 *       {@code MetaTableReferenceResolver} 抛 ERR_TABLEREF_* 系列错误码</li>
 *   <li>DISABLED 数据源 → 抛 {@link #NopMetadataErrors.ERR_QUALITY_DATASOURCE_DISABLED}</li>
 *   <li>非 jdbc 类型 → 由 {@code withConnection} 抛 NopException</li>
 *   <li>缺 timestampColumn(freshness)/custom_sql 不返回单值 → 写 ERROR 结果行</li>
 *   <li>entityType=database / regex 方言不支持 REGEXP → 写 SKIP 结果行（带 details 标记）</li>
 * </ul>
 */
@BizModel("NopMetaQualityRule")
public class NopMetaQualityRuleBizModel extends CrudBizModel<NopMetaQualityRule> implements INopMetaQualityRuleBiz {

    private static final Logger LOG = LoggerFactory.getLogger(NopMetaQualityRuleBizModel.class);


    @Inject
    protected IMetaDataSourceConnectionProcessor connectionService;

    /** 跨聚合访问（plan 353 MD-1）：MetaTable/MetaDataSource 读取经 Biz 接口而非 dao 直连。 */
    @Inject
    protected INopMetaTableBiz tableBiz;

    @Inject
    protected INopMetaDataSourceBiz dataSourceBiz;

    /** querySpace→数据源 解析共享组件。 */
    private final MetaDataSourceResolver dataSourceResolver = new MetaDataSourceResolver();

    /** 共享 table-reference 解析器（架构基线 §4.4.3 D3）。 */
    private final MetaTableReferenceResolver tableRefResolver = new MetaTableReferenceResolver();

    /** 质量规则执行器（无状态，参考 MetaCatalogCollector 收集器模式）。 */
    private final MetaQualityRuleExecutor executor = new MetaQualityRuleExecutor();

    /** 结果写入共享 helper（§2.7.3 D3：与 checkpoint executor 共用，避免复制逻辑）。 */
    private final QualityResultWriter resultWriter = new QualityResultWriter();

    @Inject
    protected QualityAlertWorkflowProcessor alertWorkflowService;

    /** 按 table-reference 形态分派 Connection 获取（§4.4.3 D1/D2）。延迟初始化（需 orm()）。 */
    private TableReferenceExecutor tableRefExecutor;

    public NopMetaQualityRuleBizModel() {
        setEntityName(NopMetaQualityRule.class.getName());
    }

    // ============================================================
    // 单规则执行
    // ============================================================

    /**
     * 执行单条质量规则（架构基线 §2.7.1 D2 + §4.4.3 D1-D5）。
     *
     * <p>解析路径（D3）：rule.entityId → NopMetaTable → {@link MetaTableReferenceResolver} → {@link TableReference}
     * → {@link TableReferenceExecutor} 按 ref 形态分派 Connection → 执行器判定 → 追加一行 NopMetaQualityResult。
     *
     * <p>覆盖范围：external/entity/sql 任意 tableType 的逻辑表上挂载的 table/field 级规则均可执行（D4 能力边界）。
     * entityType=database 仍 SKIP（§2.7.1 D1）。
     *
     * @param qualityRuleId 规则 ID
     * @param schemaPattern 可选 schema 限定（null/空串表示依赖连接默认 schema）
     * @return {@code QualityRuleExecuteResultDTO}
     */
    @BizMutation
    public QualityRuleExecuteResultDTO executeQualityRule(@Name("qualityRuleId") String qualityRuleId,
                                                           @Optional @Name("schemaPattern") String schemaPattern,
                                                           IServiceContext context) {
        NopMetaQualityRule rule = requireEntity(qualityRuleId, "executeQualityRule", context);

        // entityType=database 首版 SKIP（§2.7.1 D1）——不解析表/数据源，直接写 SKIP 结果行
        if (_NopMetadataCoreConstants.QUALITY_ENTITY_TYPE_DATABASE.equals(rule.getEntityType())) {
            QualityRuleJudgment skip = new QualityRuleJudgment();
            skip.setStatus(_NopMetadataCoreConstants.QUALITY_RESULT_STATUS_SKIP);
            skip.setMessage("entityType=database not supported in first version (external-table-only execution)");
            skip.getDetails().put("reason", "database-not-supported-first-version");
            skip.getDetails().put("ruleType", rule.getRuleType());
            skip.getDetails().put("entityType", rule.getEntityType());
            NopMetaQualityResult row = appendQualityResult(rule.getQualityRuleId(), skip);
            return buildSingleResultDto(row, skip);
        }

        // 解析目标表（任意 tableType）+ table-reference
        NopMetaTable table = resolveTargetTableOrThrow(rule, context);
        // resolver 边界：MetaTableReferenceResolver API 消费 IEntityDao（tableref/resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        TableReference ref = tableRefResolver.resolve(table,
                daoFor(NopMetaDataSource.class), daoFor(NopMetaEntity.class),
                daoFor(NopMetaEntityField.class), orm());

        // plan 0852-3 Phase 3: 默认 schema 解析在 BizModel 层（持有 NopMetaTable）
        // 未显式传 schemaPattern 且 table.schema 非空 → 默认取 table.schema（持久化一次、多次执行无需重传）
        String effectiveSchema = resolveDefaultSchema(schemaPattern, table);

        // 按 ref 形态分派 Connection 获取并执行
        QualityRuleJudgment judgment = ensureTableRefExecutor().execute(ref,
                (conn, metaData, productName) -> executor.judge(conn, ref, effectiveSchema,
                        rule.getRuleType(), rule.getEntityType(),
                        rule.getParams(), rule.getSqlExpression(),
                        rule.getThreshold(), productName));

        NopMetaQualityResult row = appendQualityResult(rule.getQualityRuleId(), judgment);

        // 触发告警工作流：FAIL + severity=ERROR（MA7.6-02：显式传递上下文，createAlertWorkflow 内部再兜底）
        if ("FAIL".equals(judgment.getStatus())
                && _NopMetadataCoreConstants.QUALITY_SEVERITY_ERROR.equals(rule.getSeverity())) {
            try {
                alertWorkflowService.createAlertWorkflow(row, context);
            } catch (Exception e) {
                LOG.error("Failed to create alert workflow for quality rule: {}, errorCode={}",
                        rule.getQualityRuleId(), NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode(), e);
            }
        }

        return buildSingleResultDto(row, judgment);
    }

    // ============================================================
    // 批量执行（按数据源）
    // ============================================================

    /**
     * 批量执行某数据源 querySpace 下 external 表上挂载的质量规则（架构基线 §2.7.1 D2）。
     *
     * <p>与 {@code NopMetaDataSourceBizModel.collectCatalog} 同入口（dataSourceId）、同 callback 模式、
     * 同 per-rule 失败隔离（try/catch + flushSession/clearSession）。
     *
     * @param dataSourceId  目标数据源 ID
     * @param schemaPattern 可选 schema 限定
     * @return {@code QualityRulesForDataSourceResultDTO}
     */
    @BizMutation
    public QualityRulesForDataSourceResultDTO executeQualityRulesForDataSource(@Name("dataSourceId") String dataSourceId,
                                                                                @Optional @Name("schemaPattern") String schemaPattern,
                                                                                IServiceContext context) {
        NopMetaDataSource dataSource = dataSourceBiz.get(dataSourceId, false, context);
        if (dataSource == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_DATASOURCE_NOT_FOUND).param("dataSourceId", dataSourceId);
        }
        if (dataSource.isDisabled()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_DATASOURCE_DISABLED).param("dataSourceId", dataSourceId);
        }

        // 该 querySpace 下 external 表
        List<NopMetaTable> externalTables = findExternalTables(dataSource.getQuerySpace(), context);
        QualityRulesForDataSourceResultDTO dto = new QualityRulesForDataSourceResultDTO();
        dto.setDataSourceId(dataSourceId);

        if (externalTables.isEmpty()) {
            dto.setExecutedCount(0);
            return dto;
        }

        // 表 id → 物理表名 + schema（callback 内按规则 entityId 解析；plan 0852-3 Phase 3 多 schema 批量逐表）
        Map<String, String> tableIdToName = new HashMap<>();
        Map<String, NopMetaTable> tableIdToEntity = new HashMap<>();
        for (NopMetaTable t : externalTables) {
            tableIdToName.put(t.getMetaTableId(), t.getTableName());
            tableIdToEntity.put(t.getMetaTableId(), t);
        }
        List<String> tableIds = new ArrayList<>(tableIdToName.keySet());

        // 找挂载在这些表上的规则（entityId ∈ tableIds，覆盖 entityType=table 和 field；database 规则 entityId 不匹配）
        IEntityDao<NopMetaQualityRule> ruleDao = dao();
        QueryBean ruleQuery = new QueryBean();
        ruleQuery.addFilter(FilterBeans.in(NopMetaQualityRule.PROP_NAME_entityId, tableIds));
        List<NopMetaQualityRule> rules = ruleDao.findAllByQuery(ruleQuery);

        dto.setTotalRuleCount(rules.size());

        if (rules.isEmpty()) {
            return dto;
        }

        AtomicInteger executedCount = new AtomicInteger(0);
        List<QualityRuleExecuteResultDTO> results = new ArrayList<>();
        List<ErrorDTO> errors = new ArrayList<>();

        connectionService.withConnection(dataSource.getDatasourceType(), dataSource.getConnectionConfig(),
                (Connection conn, DatabaseMetaData metaData) -> {
                    String productName = safeProductName(metaData);
                    for (NopMetaQualityRule rule : rules) {
                        try {
                            String tableName = tableIdToName.get(rule.getEntityId());
                            if (tableName == null) {
                                // 规则 entityId 不在该批次 external 表范围内（理论不应发生，防御性显式失败）
                                throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_TABLE_NOT_FOUND)
                                        .param("qualityRuleId", rule.getQualityRuleId())
                                        .param("entityId", rule.getEntityId());
                            }
                            // plan 0852-3 Phase 3: 批量入口逐表默认 schema 解析（各表 schema 可能不同）
                            NopMetaTable targetTable = tableIdToEntity.get(rule.getEntityId());
                            String effectiveSchema = resolveDefaultSchema(schemaPattern, targetTable);
                            QualityRuleJudgment judgment = executor.judge(conn,
                                    new TableReference(TableReference.Kind.EXTERNAL, rule.getEntityId(),
                                            tableName, null, dataSource, null, null, null),
                                    effectiveSchema,
                                    rule.getRuleType(), rule.getEntityType(),
                                    rule.getParams(), rule.getSqlExpression(),
                                    rule.getThreshold(), productName);
                            NopMetaQualityResult row = appendQualityResult(rule.getQualityRuleId(), judgment);
                            orm().flushSession();
                            executedCount.incrementAndGet();
                            results.add(buildSingleResultDto(row, judgment));
                        } catch (Exception e) {
                            LOG.error("executeQualityRulesForDataSource failed for rule: {}, errorCode={}",
                                    rule.getQualityRuleId(), NopMetadataErrors.ERR_QUALITY_RULE_EXEC_ISOLATED.getErrorCode(), e);
                            errors.add(new ErrorDTO(rule.getQualityRuleId(), NopMetadataHelper.toErrorMessage(e), rule.getRuleName()));
                            // 隔离失败：清理未刷出的脏实体，不影响已 flush 的规则与后续规则
                            orm().clearSession();
                        }
                    }
                });

        dto.setExecutedCount(executedCount.get());
        dto.setResults(results);
        dto.setErrors(errors);
        return dto;
    }

    // ============================================================
    // helpers
    // ============================================================

    /** 解析规则目标表：entityId → NopMetaTable；不存在显式失败（任意 tableType，§4.4.3 D4）。 */
    private NopMetaTable resolveTargetTableOrThrow(NopMetaQualityRule rule, IServiceContext context) {
        NopMetaTable table = tableBiz.get(rule.getEntityId(), false, context);
        if (table == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_QUALITY_TABLE_NOT_FOUND)
                    .param("qualityRuleId", rule.getQualityRuleId())
                    .param("entityId", rule.getEntityId());
        }
        return table;
    }

    /** 延迟初始化 TableReferenceExecutor（需 orm()，构造时 orm 不可用）。 */
    private TableReferenceExecutor ensureTableRefExecutor() {
        if (tableRefExecutor == null) {
            tableRefExecutor = new TableReferenceExecutor(connectionService, orm());
        }
        return tableRefExecutor;
    }

    /**
     * 默认 schema 解析（plan 0852-3 Phase 3）：未显式传 schemaPattern（null/空/纯空白）且
     * {@code table.schema} 非空 → 默认取 {@code table.schema}；否则维持入参（可能为 null=不过滤）。
     * 与 {@code NopMetaDataSourceBizModel.resolveDefaultSchema} 同语义。
     */
    private static String resolveDefaultSchema(String schemaPattern, NopMetaTable table) {
        if (schemaPattern != null && !schemaPattern.trim().isEmpty()) {
            return schemaPattern;
        }
        return table.getMetaSchema();
    }

    /** 查找该 querySpace 下所有 external 类型逻辑表（按 tableType=external 限定；经 Biz 接口，plan 353 MD-1）。 */
    private List<NopMetaTable> findExternalTables(String querySpace, IServiceContext context) {
        // infra 边界：catalog 收集的外部表清单可超 Biz findList 的 max-page-size（1000），保留 dao 直连（plan 353 MD-1 裁定）
        QueryBean query = new QueryBean();
        query.addFilter(FilterBeans.eq(NopMetaTable.PROP_NAME_querySpace, querySpace));
        query.addFilter(FilterBeans.eq(NopMetaTable.PROP_NAME_tableType,
                _NopMetadataCoreConstants.TABLE_TYPE_EXTERNAL));
        return daoFor(NopMetaTable.class).findAllByQuery(query);
    }

    /**
     * 将单规则判定结果追加为一行新的 NopMetaQualityResult（时序语义：executeTime=now，不覆盖旧行）。
     *
     * <p>委托共享 {@link QualityResultWriter}（§2.7.3 D3），与检查点编排路径共用同一写入逻辑，不复制。
     * 无检查点上下文：checkpointId/runId 传 null（复合 UK 中任一列 NULL 不参与冲突判定，时序追加语义保持）。
     */
    private NopMetaQualityResult appendQualityResult(String qualityRuleId, QualityRuleJudgment judgment) {
        // writer 边界：QualityResultWriter.append API 消费 IEntityDao（quality 包 helper 不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        return resultWriter.append(daoFor(NopMetaQualityResult.class), qualityRuleId, null, null, judgment);
    }

    private static QualityRuleExecuteResultDTO buildSingleResultDto(NopMetaQualityResult row, QualityRuleJudgment j) {
        QualityRuleExecuteResultDTO dto = new QualityRuleExecuteResultDTO();
        dto.setQualityResultId(row.getQualityResultId());
        dto.setStatus(j.getStatus());
        dto.setActualValue(j.getActualValue());
        dto.setExpectedValue(j.getExpectedValue());
        dto.setMessage(j.getMessage());
        if (j.getDetails() != null) {
            dto.setDetails(j.getDetails());
        }
        return dto;
    }

    /**
     * 根据规则 ID 重新执行判定（用于工作流 re-judge 场景）。
     * 从 DB 加载规则全字段，重建执行上下文，返回判定结果。
     */
    @BizQuery
    public QualityRuleExecuteResultDTO judgeByRuleId(@Name("ruleId") String ruleId, IServiceContext context) {
        NopMetaQualityRule rule = requireEntity(ruleId, "judgeByRuleId", context);

        NopMetaTable table = resolveTargetTableOrThrow(rule, context);
        // resolver 边界：MetaTableReferenceResolver API 消费 IEntityDao（tableref/resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        TableReference ref = tableRefResolver.resolve(table,
                daoFor(NopMetaDataSource.class), daoFor(NopMetaEntity.class),
                daoFor(NopMetaEntityField.class), orm());

        String effectiveSchema = resolveDefaultSchema(null, table);

        QualityRuleJudgment judgment = ensureTableRefExecutor().execute(ref,
                (conn, metaData, productName) -> executor.judge(conn, ref, effectiveSchema,
                        rule.getRuleType(), rule.getEntityType(),
                        rule.getParams(), rule.getSqlExpression(),
                        rule.getThreshold(), productName));

        QualityRuleExecuteResultDTO dto = new QualityRuleExecuteResultDTO();
        dto.setStatus(judgment.getStatus());
        dto.setActualValue(judgment.getActualValue());
        dto.setExpectedValue(judgment.getExpectedValue());
        dto.setMessage(judgment.getMessage());
        if (judgment.getDetails() != null) {
            dto.setDetails(judgment.getDetails());
        }
        return dto;
    }

}
