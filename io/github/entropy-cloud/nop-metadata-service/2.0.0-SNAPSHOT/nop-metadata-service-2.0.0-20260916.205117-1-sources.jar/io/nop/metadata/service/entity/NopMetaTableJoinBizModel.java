
package io.nop.metadata.service.entity;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.exceptions.ErrorCode;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.commons.util.CollectionHelper;
import io.nop.core.context.IServiceContext;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.biz.INopMetaEntityBiz;
import io.nop.metadata.biz.INopMetaTableBiz;
import io.nop.metadata.biz.INopMetaTableJoinBiz;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaTable;
import io.nop.metadata.dao.entity.NopMetaTableJoin;
import io.nop.metadata.service.field.MetaTableFieldResolver;
import io.nop.metadata.service.field.ResolvedTableField;
import io.nop.metadata.service.NopMetadataException;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import jakarta.inject.Inject;

/**
 * 表关联 BizModel（架构基线 §2.5.2 D2/D4 / plan 0700-2 item 1.4 + plan 0700-1 sql/external 端点扩展）：
 * 基线 CRUD + save 端点一致性校验。
 *
 * <p>save 校验（item 1.1 裁定的 save override 落点 + plan 0700-1 D1 端点建模放宽）：保存 Join 时按端点类型校验：
 * <ul>
 *   <li><b>entity 端点</b>（{@code leftEntityId}/{@code rightEntityId} 非空）：对应 {@link NopMetaEntity} 存在 +
 *       {@code leftField}/{@code rightField} 属于该实体字段集合（经 entity→{@link NopMetaEntityField} 解析）。</li>
 *   <li><b>table 端点</b>（{@code leftTableId}/{@code rightTableId} 非空，plan 0700-1 新增）：对应 {@link NopMetaTable}
 *       存在且 {@code tableType ∈ {external, sql}}（entity-type 逻辑表作为端点应走 entity 路径，见 D1）+
 *       {@code leftField}/{@code rightField} 属于该表可解析列集合（external→buildSql JSON columnName；
 *       sql→SELECT 解析）。</li>
 *   <li><b>端点互斥</b>（D1）：同一端点的 {@code entityId}/{@code tableId} 同时非空 → 显式失败；同时为空 → 显式失败
 *       （端点 mandatory 从 entityId-only 放宽为「entity/table 二选一」，即 {@code NopMetadataErrors.ERR_JOIN_ENTITY_ID_NULL} 的放宽裁定）。</li>
 * </ul>
 * 不一致显式失败抛 inline {@link ErrorCode}。{@code joinType} 已由 dict {@code meta/join-type} 校验。
 *
 * <p>可用性边界：本 BizModel 交付「建模 + 防悬空校验」。sql/external 端点的 JOIN 查询执行属 successor plan 0700-2。
 */
@BizModel("NopMetaTableJoin")
public class NopMetaTableJoinBizModel extends CrudBizModel<NopMetaTableJoin> implements INopMetaTableJoinBiz {


    /** 跨表类型字段解析器（无状态）。 */
    private final MetaTableFieldResolver fieldResolver = new MetaTableFieldResolver();

    /** 跨聚合访问（plan 353 MD-1）：MetaEntity/MetaTable 读取经 Biz 接口而非 dao 直连。 */
    @Inject
    protected INopMetaEntityBiz entityBiz;

    @Inject
    protected INopMetaTableBiz tableBiz;

    public NopMetaTableJoinBizModel() {
        setEntityName(NopMetaTableJoin.class.getName());
    }

    /**
     * save override（item 1.1 裁定的 save override 新模式 + plan 0700-1 端点建模放宽）：持久化前校验
     * left/right 端点存在 + 字段归属（entity 端点或 external/sql table 端点）。
     *
     * <p>校验通过后委托 {@code super.save(...)} 走默认持久化逻辑。端点/字段集合解析失败显式抛 ErrorCode
     * （不静默存入悬空关联、不静默跳过校验）。
     */
    @Override
    public NopMetaTableJoin save(@Name("data") Map<String, Object> data, IServiceContext context) {
        // P2-19（plan 2026-08-16-0226-3）：null/empty data 提前委托基类，
        // 统一抛 ERR_BIZ_EMPTY_DATA_FOR_SAVE
        // （不 NPE 抢先——validateJoin 内 stringOf 会先解引用 data）
        if (CollectionHelper.isEmptyMap(data)) {
            return super.save(data, context);
        }
        validateJoin(data, context);
        return super.save(data, context);
    }

    private void validateJoin(Map<String, Object> data, IServiceContext context) {
        String metaTableId = NopMetadataHelper.stringOf(data,
                NopMetaTableJoin.PROP_NAME_metaTableId);
        if (metaTableId == null || metaTableId.isEmpty()) {
            return;
        }
        // P1-6（plan 2026-08-15-1913-3 轨 1）：update 路径 joinId 自 data map 下沉穿参
        // （create 路径 joinId 尚不存在，由 validateTableEndpoint 换无 joinId 占位符孪生码）
        String joinId = NopMetadataHelper.stringOf(data,
                NopMetaTableJoin.PROP_NAME_joinId);
        validateJoinSide(metaTableId, joinId, "left",
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_leftEntityId),
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_leftTableId),
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_leftField),
                context);
        validateJoinSide(metaTableId, joinId, "right",
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_rightEntityId),
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_rightTableId),
                NopMetadataHelper.stringOf(data,
                        NopMetaTableJoin.PROP_NAME_rightField),
                context);
    }

    /**
     * 校验单侧端点（D1 entity/table 二选一互斥 + 字段归属）。
     *
     * <p>端点解析：{@code entityId}/{@code tableId} 同时非空 → 互斥失败；同时为空 → 端点 mandatory 失败
     * （{@code NopMetadataErrors.ERR_JOIN_ENTITY_ID_NULL} 放宽为 entity/table 二选一）。entity 端点走实体字段集合校验，
     * table 端点走表可解析列集合校验（tableType 须 external/sql）。
     *
     * @param joinId 既有 Join 主键（update 路径自身份下沉，create 路径为空——
     *               P1-6 plan 2026-08-15-1913-3：{joinId} 占位符真实渲染）
     */
    private void validateJoinSide(String metaTableId, final String joinId,
                                  String side, String entityId,
                                  String tableId, String field, IServiceContext context) {
        boolean hasEntity = entityId != null && !entityId.isEmpty();
        boolean hasTable = tableId != null && !tableId.isEmpty();
        if (hasEntity && hasTable) {
            // entity/table 互斥：同一端点同时设置 entityId 和 tableId——显式失败（不静默猜测语义）
            throw new NopMetadataException(NopMetadataErrors.ERR_JOIN_ENDPOINT_BOTH_SET)
                    .param("metaTableId", metaTableId).param("side", side)
                    .param("entityId", entityId).param("tableId", tableId);
        }
        if (!hasEntity && !hasTable) {
            // 端点 mandatory：entity/table 二选一
            // （放宽原 ERR_JOIN_ENTITY_ID_NULL 的 entityId-only 语义）
            throw new NopMetadataException(NopMetadataErrors.ERR_JOIN_ENTITY_ID_NULL)
                    .param("metaTableId", metaTableId).param("side", side);
        }
        // resolver 边界：MetaTableFieldResolver API 消费 IEntityDao（resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        if (hasEntity) {
            validateEntityEndpoint(metaTableId, side, entityId, field,
                    daoFor(NopMetaEntityField.class), context);
        } else {
            validateTableEndpoint(metaTableId, joinId, side, tableId, field,
                    daoFor(NopMetaEntityField.class), context);
        }
    }

    /** entity 端点校验：实体存在 + 字段属于该实体字段集合。 */
    private void validateEntityEndpoint(String metaTableId, String side, String entityId, String field,
                                        IEntityDao<NopMetaEntityField> fieldDao, IServiceContext context) {
        NopMetaEntity entity = entityBiz.get(entityId, false, context);
        if (entity == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_JOIN_ENTITY_NOT_FOUND)
                    .param("metaTableId", metaTableId).param("side", side).param("entityId", entityId);
        }
        if (field == null || field.isEmpty()) {
            // 字段名空——交由 super.save 走框架校验，此处不重复报错
            return;
        }
        // 校验字段属于该实体字段集合（经 entity→NopMetaEntityField 解析；空集由 resolver 显式失败）
        Set<String> fieldNames = new LinkedHashSet<>();
        for (ResolvedTableField f : fieldResolver.resolveEntityFieldsByEntityId(entityId, fieldDao)) {
            fieldNames.add(f.getName());
        }
        if (!fieldNames.contains(field)) {
            throw new NopMetadataException(NopMetadataErrors.ERR_JOIN_FIELD_NOT_IN_ENTITY)
                    .param("metaTableId", metaTableId).param("side", side)
                    .param("entityId", entityId).param("field", field)
                    .param("availableFields", fieldNames);
        }
    }

    /**
     * table 端点校验（plan 0700-1 D1）：表存在 + tableType ∈ {external, sql} + 字段属于该表可解析列集合。
     *
     * <p>tableType=entity 的 NopMetaTable 作为 table 端点显式失败（应走 entityId 路径，避免解析路径混合）。
     * 列集合解析失败（buildSql 损坏 / sourceSql 不可解析）由 resolver 显式抛 ErrorCode（不静默空集放行）。
     */
    private void validateTableEndpoint(String metaTableId, final String joinId,
                                       String side, String tableId,
                                       String field, IEntityDao<NopMetaEntityField> fieldDao,
                                       IServiceContext context) {
        NopMetaTable table = tableBiz.get(tableId, false, context);
        if (table == null) {
            throw new NopMetadataException(
                    NopMetadataErrors.ERR_JOIN_TABLE_NOT_FOUND)
                    .param("metaTableId", metaTableId).param("side", side)
                    .param("tableId", tableId);
        }
        String tableType = table.getTableType();
        if (!_NopMetadataCoreConstants.TABLE_TYPE_EXTERNAL.equals(tableType)
                && !_NopMetadataCoreConstants.TABLE_TYPE_SQL.equals(tableType)) {
            // table 端点仅允许 external/sql；entity-type 逻辑表应走 entityId 路径（D1）。
            // P1-6（plan 2026-08-15-1913-3）：update 路径 joinId 传齐原码占位符；create 路径
            // joinId 尚不存在——禁止传 null（渲染空串=空壳修复），换无 joinId 占位符孪生码。
            if (joinId != null && !joinId.isEmpty()) {
                throw new NopMetadataException(
                        NopMetadataErrors.ERR_JOIN_TABLE_TYPE_NOT_ALLOWED)
                        .param("joinId", joinId).param("side", side)
                        .param("tableId", tableId)
                        .param("tableType", String.valueOf(tableType));
            }
            throw new NopMetadataException(
                    NopMetadataErrors.ERR_JOIN_TABLE_TYPE_NOT_ALLOWED_ON_CREATE)
                    .param("metaTableId", metaTableId).param("side", side)
                    .param("tableId", tableId).param("tableType", String.valueOf(tableType));
        }
        if (field == null || field.isEmpty()) {
            // 字段名空——交由 super.save 走框架校验，此处不重复报错
            return;
        }
        // 校验字段属于该表可解析列集合（external→buildSql JSON；sql→SELECT 解析；空集/损坏由 resolver 显式失败）
        Set<String> columnNames = fieldResolver.resolveFieldNames(table, fieldDao);
        if (!columnNames.contains(field)) {
            throw new NopMetadataException(NopMetadataErrors.ERR_JOIN_FIELD_NOT_IN_TABLE)
                    .param("metaTableId", metaTableId).param("side", side)
                    .param("tableId", tableId).param("field", field)
                    .param("availableFields", columnNames);
        }
    }

}
