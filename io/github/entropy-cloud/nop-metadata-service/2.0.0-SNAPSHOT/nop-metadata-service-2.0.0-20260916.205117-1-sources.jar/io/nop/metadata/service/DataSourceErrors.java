package io.nop.metadata.service;

import io.nop.api.core.exceptions.ErrorCode;

interface DataSourceErrors extends NopMetadataArgs {

    ErrorCode ERR_DATASOURCE_NOT_FOUND =
            ErrorCode.define("nop.err.metadata.datasource-not-found",
                    "MetaDataSource not found: {dataSourceId}", ARG_DATA_SOURCE_ID);
    ErrorCode ERR_DATASOURCE_DISABLED =
            ErrorCode.define("nop.err.metadata.datasource-disabled",
                    "DataSource is disabled, cannot test connection: {dataSourceId}", ARG_DATA_SOURCE_ID);
    ErrorCode ERR_DATASOURCE_TYPE_NOT_SUPPORTED =
            ErrorCode.define("nop.err.metadata.datasource-type-not-supported",
                    "DataSource type not supported yet: {datasourceType}", ARG_DATASOURCE_TYPE);
    ErrorCode ERR_DATASOURCE_CONFIG_INVALID =
            ErrorCode.define("nop.err.metadata.datasource-config-invalid",
                    "Invalid connection config for datasourceType={datasourceType}: {reason}",
                    ARG_DATASOURCE_TYPE, ARG_REASON);
    ErrorCode ERR_DATASOURCE_CONNECT_FAILED =
            ErrorCode.define("nop.err.metadata.datasource-connect-failed",
                    "DataSource connection failed for datasourceType={datasourceType}: {error}",
                    ARG_DATASOURCE_TYPE, ARG_ERROR);
    ErrorCode ERR_EXTERNAL_TABLE_SCAN_FAILED =
            ErrorCode.define("nop.err.metadata.external-table-scan-failed",
                    "Failed to scan external database table structure: {databaseProductName} -- {error}",
                    ARG_DATABASE_PRODUCT_NAME, ARG_ERROR);
    ErrorCode ERR_DATASOURCE_JDBC_URL_BLOCKED =
            ErrorCode.define("nop.err.metadata.datasource-jdbc-url-blocked",
                    "JDBC URL is blocked by security policy (protocol/host not allowed or dangerous parameter present): "
                            + "{jdbcUrl} reason={reason}", ARG_JDBC_URL, ARG_REASON);
    ErrorCode ERR_DATASOURCE_DRIVER_NOT_ALLOWED =
            ErrorCode.define("nop.err.metadata.datasource-driver-not-allowed",
                    "JDBC driver class is not in the allowed whitelist: {driverClassName}", ARG_DRIVER_CLASS_NAME);
    ErrorCode ERR_DATASOURCE_RESOLVE_NO_DATASOURCE =
            ErrorCode.define("nop.err.metadata.datasource-resolve-no-datasource",
                    "No registered MetaDataSource for querySpace: {querySpace}", ARG_QUERY_SPACE);
    ErrorCode ERR_DATASOURCE_RESOLVE_DISABLED =
            ErrorCode.define("nop.err.metadata.datasource-resolve-disabled",
                    "MetaDataSource is DISABLED, cannot be used for query execution: {dataSourceId} querySpace={querySpace}",
                    ARG_DATA_SOURCE_ID, ARG_QUERY_SPACE);
    ErrorCode ERR_DATASOURCE_DUPLICATE_QUERY_SPACE =
            ErrorCode.define("nop.err.metadata.datasource-duplicate-query-space",
                    "Multiple MetaDataSource rows match the same querySpace (UK violation in live data): "
                            + "querySpace={querySpace} dataSourceCount={dataSourceCount}",
                    ARG_QUERY_SPACE, ARG_DATA_SOURCE_COUNT);
    ErrorCode ERR_DATASOURCE_MIGRATE_ROW_FAIL =
            ErrorCode.define("nop.err.metadata.datasource-migrate-row-fail",
                    "DataSource credential migration failed for dataSourceId={dataSourceId}: {error}",
                    ARG_DATA_SOURCE_ID, ARG_ERROR);
    ErrorCode ERR_TABLEREF_ENTITY_QUERY_SPACE_NOT_JDBC =
            ErrorCode.define("nop.err.metadata.tableref-entity-query-space-not-jdbc",
                    "Platform transaction for entity querySpace is not a JDBC transaction: {querySpace}",
                    ARG_QUERY_SPACE);
    ErrorCode ERR_TABLEREF_UNKNOWN_TABLE_TYPE =
            ErrorCode.define("nop.err.metadata.tableref-unknown-table-type",
                    "Unknown tableType for table-reference resolution: {metaTableId} tableType={tableType}",
                    ARG_META_TABLE_ID, ARG_TABLE_TYPE);
    /**
     * P1-6（plan 2026-08-15-1913-3 轨 3）：table 实体为 null 的防御分支无身份值可传，
     * 换零占位符码（ERR_TABLEREF_UNKNOWN_TABLE_TYPE 的占位符在未知 tableType 点位传齐，禁削）。
     */
    ErrorCode ERR_TABLEREF_TABLE_NULL =
            ErrorCode.define("nop.err.metadata.tableref-table-null",
                    "MetaTable entity is null, cannot resolve table reference "
                            + "(no identity available)");
    ErrorCode ERR_TABLEREF_ENTITY_BASE_NULL =
            ErrorCode.define("nop.err.metadata.tableref-entity-base-null",
                    "Cannot resolve entity table: baseEntityId is null (dangling reference): {metaTableId}",
                    ARG_META_TABLE_ID);
    ErrorCode ERR_TABLEREF_ENTITY_NOT_FOUND =
            ErrorCode.define("nop.err.metadata.tableref-entity-not-found",
                    "Cannot resolve entity table: NopMetaEntity not found for baseEntityId: "
                            + "{metaTableId} baseEntityId={baseEntityId}", ARG_META_TABLE_ID, ARG_BASE_ENTITY_ID);
    ErrorCode ERR_TABLEREF_ENTITY_NOT_REGISTERED =
            ErrorCode.define("nop.err.metadata.tableref-entity-not-registered",
                    "Entity is not registered in runtime IOrmSessionFactory: "
                            + "{metaTableId} entityName={entityName}", ARG_META_TABLE_ID, ARG_ENTITY_NAME);
    ErrorCode ERR_TABLEREF_ENTITY_TABLE_NAME_EMPTY =
            ErrorCode.define("nop.err.metadata.tableref-entity-table-name-empty",
                    "Cannot resolve entity table: NopMetaEntity.tableName is empty: "
                            + "{metaTableId} entityName={entityName}", ARG_META_TABLE_ID, ARG_ENTITY_NAME);
    ErrorCode ERR_TABLEREF_SQL_SOURCE_EMPTY =
            ErrorCode.define("nop.err.metadata.tableref-sql-source-empty",
                    "Cannot resolve sql table: sourceSql is empty: {metaTableId}", ARG_META_TABLE_ID);
    ErrorCode ERR_TABLEREF_PLATFORM_META_FAILED =
            ErrorCode.define("nop.err.metadata.tableref-platform-meta-failed",
                    "Failed to get DatabaseMetaData from platform connection: {error}", ARG_ERROR);
    ErrorCode ERR_TABLEREF_EXEC_FAILED =
            ErrorCode.define("nop.err.metadata.tableref-exec-failed",
                    "Table-reference execution failed: {metaTableId} -- {error}",
                    ARG_META_TABLE_ID, ARG_ERROR);
    ErrorCode ERR_TABLE_NOT_FOUND =
            ErrorCode.define("nop.err.metadata.table-not-found",
                    "Meta table not found: {metaTableId}", ARG_META_TABLE_ID);
    ErrorCode ERR_QUERY_UNSUPPORTED_TABLE_TYPE =
            ErrorCode.define("nop.err.metadata.query-unsupported-table-type",
                    "Unsupported tableType for queryTableData: {metaTableId} tableType={tableType}",
                    ARG_META_TABLE_ID, ARG_TABLE_TYPE);
    ErrorCode ERR_QUERY_ENTITY_NOT_FOUND =
            ErrorCode.define("nop.err.metadata.query-entity-not-found",
                    "Entity record not found for entity table (baseEntityId dangling): "
                            + "{metaTableId} baseEntityId={baseEntityId}", ARG_META_TABLE_ID, ARG_BASE_ENTITY_ID);
    ErrorCode ERR_QUERY_ENTITY_NOT_REGISTERED =
            ErrorCode.define("nop.err.metadata.query-entity-not-registered",
                    "Entity is not registered in runtime IOrmSessionFactory: "
                            + "{metaTableId} entityName={entityName}", ARG_META_TABLE_ID, ARG_ENTITY_NAME);
    ErrorCode ERR_QUERY_SQL_SOURCE_EMPTY =
            ErrorCode.define("nop.err.metadata.query-sql-source-empty",
                    "sql table sourceSql is empty, cannot query: {metaTableId}", ARG_META_TABLE_ID);
    ErrorCode ERR_QUERY_UNSUPPORTED_DIALECT =
            ErrorCode.define("nop.err.metadata.query-unsupported-dialect",
                    "Dialect not supported in first version (only H2/MySQL/PostgreSQL): "
                            + "{databaseProductName} metaTableId={metaTableId}",
                    ARG_DATABASE_PRODUCT_NAME, ARG_META_TABLE_ID);
    ErrorCode ERR_QUERY_SQL_EXEC_FAILED =
            ErrorCode.define("nop.err.metadata.query-sql-exec-failed",
                    "Query SQL execution failed: metaTableId={metaTableId} -- {error}",
                    ARG_META_TABLE_ID, ARG_ERROR);

    // ===== DataSource operation isolation / type probe (clause-b formalize) =====

    ErrorCode ERR_DATASOURCE_TEST_CONNECT_FAILED =
            ErrorCode.define("nop.err.metadata.datasource-test-connect-failed",
                    "DataSource test connection failed: datasourceType={datasourceType} -- {error}",
                    ARG_DATASOURCE_TYPE, ARG_ERROR);
    ErrorCode ERR_DATASOURCE_SECURITY_CHECK_SKIPPED =
            ErrorCode.define("nop.err.metadata.datasource-security-check-skipped",
                    "DataSource security check skipped (SecurityManager denied, per-edge accepted): {error}",
                    ARG_ERROR);
    ErrorCode ERR_DATASOURCE_HOST_RESOLVE_SKIPPED =
            ErrorCode.define("nop.err.metadata.datasource-host-resolve-skipped",
                    "DataSource host resolution skipped (UnknownHostException, per-edge accepted): host={schema} "
                            + "-- {error}",
                    ARG_SCHEMA, ARG_ERROR);
    ErrorCode ERR_DATASOURCE_PORT_PARSE_SKIPPED =
            ErrorCode.define("nop.err.metadata.datasource-port-parse-skipped",
                    "DataSource port parse skipped (NumberFormatException, fallback applied, per-edge accepted): "
                            + "{error}",
                    ARG_ERROR);

    // ==================== W16-impl 数据源凭证（credentialId 深度迁移，设计 §五/§六） ====================

    ErrorCode ERR_DATASOURCE_CREDENTIAL_PROVIDER_NOT_AVAILABLE =
            ErrorCode.define("nop.err.metadata.datasource-credential-provider-not-available",
                    "connectionConfig declares credentialId but ICredentialProvider is not assembled "
                            + "(deployment inconsistency, fail-closed; no fallback to JSON plaintext): "
                            + "{credentialId}", ARG_CREDENTIAL_ID);

    ErrorCode ERR_DATASOURCE_CREDENTIAL_RESOLVE_FAILED =
            ErrorCode.define("nop.err.metadata.datasource-credential-resolve-failed",
                    "Credential resolution failed for dataSource (fail-closed, no fallback to JSON plaintext): "
                            + "{credentialId}", ARG_CREDENTIAL_ID);

    ErrorCode ERR_DATASOURCE_CREDENTIAL_TYPE_MISMATCH =
            ErrorCode.define("nop.err.metadata.datasource-credential-type-mismatch",
                    "Credential type does not match the jdbc-datasource family: "
                            + "{credentialId} typeName={typeName} expected={expectedTypeNames}",
                    ARG_CREDENTIAL_ID, ARG_TYPE_NAME, ARG_EXPECTED_TYPE_NAMES);

    ErrorCode ERR_DATASOURCE_CREDENTIAL_FIELD_REQUIRED =
            ErrorCode.define("nop.err.metadata.datasource-credential-field-required",
                    "Required credential field missing or blank: {credentialId} field={fieldName}",
                    ARG_CREDENTIAL_ID, ARG_FIELD_NAME);

    ErrorCode ERR_DATASOURCE_CREDENTIAL_ADMIN_REQUIRED =
            ErrorCode.define("nop.err.metadata.datasource-credential-admin-required",
                    "This action requires datasource credential admin roles (nop.metadata.credential-admin-roles): "
                            + "{requiredRoles}", ARG_REQUIRED_ROLES);
}
