
package io.nop.metadata.service.entity;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.beans.FilterBeans;
import io.nop.api.core.beans.query.QueryBean;
import io.nop.api.core.time.CoreMetrics;
import io.nop.biz.crud.CrudBizModel;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.json.JsonTool;
import io.nop.metadata.biz.INopMetaGlossaryTermBiz;
import io.nop.metadata.biz.INopMetaTagLabelBiz;
import io.nop.metadata.dao.entity.NopMetaGlossaryTerm;
import io.nop.metadata.dao.entity.NopMetaTagLabel;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.metadata.service.search.NopMetaSearchProcessor;
import io.nop.search.api.SearchableDoc;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@BizModel("NopMetaGlossaryTerm")
public class NopMetaGlossaryTermBizModel extends CrudBizModel<NopMetaGlossaryTerm> implements INopMetaGlossaryTermBiz {

    private static final Logger LOG = LoggerFactory.getLogger(NopMetaGlossaryTermBizModel.class);

    public NopMetaGlossaryTermBizModel() {
        setEntityName(NopMetaGlossaryTerm.class.getName());
    }

    @Inject
    protected NopMetaSearchProcessor searchService;

    /** 跨聚合访问（plan 353 MD-1）：TagLabel 经 Biz 接口而非 dao 直连。 */
    @Inject
    protected INopMetaTagLabelBiz tagLabelBiz;

    @Override
    public NopMetaGlossaryTerm save(@Name("data") Map<String, Object> data, IServiceContext context) {
        NopMetaGlossaryTerm saved = super.save(data, context);
        syncTagLabels(saved, context);
        searchService.addToIndex("GlossaryTerm", saved.getGlossaryTermId(), toSearchableDoc(saved));
        return saved;
    }

    @Override
    @io.nop.api.core.annotations.biz.BizMutation
    public NopMetaGlossaryTerm update(@Name("data") Map<String, Object> data, IServiceContext context) {
        NopMetaGlossaryTerm updated = super.update(data, context);
        syncTagLabels(updated, context);
        searchService.addToIndex("GlossaryTerm", updated.getGlossaryTermId(), toSearchableDoc(updated));
        return updated;
    }

    @Override
    public boolean delete(@Name("id") String id, IServiceContext context) {
        NopMetaGlossaryTerm before = requireEntity(id, "delete", context);
        boolean deleted = super.delete(id, context);
        searchService.removeFromIndex("GlossaryTerm", id);
        return deleted;
    }

    private SearchableDoc toSearchableDoc(NopMetaGlossaryTerm entity) {
        SearchableDoc doc = new SearchableDoc();
        doc.setId(entity.getGlossaryTermId());
        doc.setName(entity.getName());
        doc.setTitle(entity.getDisplayName());
        doc.setSummary(NopMetadataHelper.truncate(entity.getDescription(), 500));
        doc.setContent(NopMetadataHelper.join(" ", entity.getName(), entity.getFullyQualifiedName(), entity.getDisplayName(), entity.getDescription(), entity.getSynonyms()));
        doc.setTagSet(Set.of("GlossaryTerm"));
        return doc;
    }

    private void syncTagLabels(NopMetaGlossaryTerm term, IServiceContext context) {
        String glossaryTermId = term.getGlossaryTermId();
        String tagsJson = term.getTags();

        Set<String> newTagIds = parseTagIds(tagsJson);

        List<NopMetaTagLabel> existing = findExistingTagLabels(glossaryTermId, context);
        Set<String> existingTagIds = new HashSet<>();
        for (NopMetaTagLabel label : existing) {
            existingTagIds.add(label.getTagId());
        }

        String userId = context.getUserId() != null ? context.getUserId() : "system";

        for (String tagId : newTagIds) {
            if (!existingTagIds.contains(tagId)) {
                Map<String, Object> data = Map.of(
                        "tagLabelId", UUID.randomUUID().toString().replace("-", ""),
                        "source", "Classification",
                        "tagId", tagId,
                        "labelType", "Derived",
                        "state", "Suggested",
                        "entityType", "NopMetaGlossaryTerm",
                        "entityId", glossaryTermId,
                        "appliedBy", userId,
                        "appliedAt", CoreMetrics.currentTimestamp()
                );

                try {
                    bizObjectManager().getBizObject("NopMetaTagLabel")
                            .invoke("save", Map.of("data", data), null, context);
                } catch (Exception e) {
                    LOG.warn("Failed to save TagLabel for glossaryTerm {} tagId={}, errorCode={}",
                            glossaryTermId, tagId, NopMetadataErrors.ERR_ENTITY_SYNC_ISOLATED.getErrorCode(), e);
                }
            }
        }

        for (NopMetaTagLabel label : existing) {
            if (!newTagIds.contains(label.getTagId())) {
                tagLabelBiz.deleteEntity(label, null, context);
            }
        }
    }

    private Set<String> parseTagIds(String tagsJson) {
        Set<String> tagIds = new HashSet<>();
        if (tagsJson != null && !tagsJson.isEmpty()) {
            List<Object> parsed = (List<Object>) JsonTool.parse(tagsJson);
            for (Object obj : parsed) {
                tagIds.add(obj.toString());
            }
        }
        return tagIds;
    }

    private List<NopMetaTagLabel> findExistingTagLabels(String glossaryTermId, IServiceContext context) {
        QueryBean q = new QueryBean();
        q.addFilter(FilterBeans.eq(NopMetaTagLabel.PROP_NAME_entityType, "NopMetaGlossaryTerm"));
        q.addFilter(FilterBeans.eq(NopMetaTagLabel.PROP_NAME_entityId, glossaryTermId));
        q.addFilter(FilterBeans.eq(NopMetaTagLabel.PROP_NAME_labelType, "Derived"));
        return tagLabelBiz.findList(q, null, context);
    }
}
