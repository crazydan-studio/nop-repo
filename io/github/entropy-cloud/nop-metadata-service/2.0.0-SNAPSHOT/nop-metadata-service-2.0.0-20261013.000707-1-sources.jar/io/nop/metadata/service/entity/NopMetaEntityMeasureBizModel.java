
package io.nop.metadata.service.entity;

import io.nop.api.core.annotations.biz.BizModel;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataHelper;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.exceptions.ErrorCode;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.commons.util.CollectionHelper;
import io.nop.core.context.IServiceContext;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.biz.INopMetaEntityBiz;
import io.nop.metadata.biz.INopMetaEntityMeasureBiz;
import io.nop.metadata.dao.entity.NopMetaEntityField;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityJoin;
import io.nop.metadata.dao.entity.NopMetaEntityMeasure;
import io.nop.metadata.service.field.ExpressionMeasureValidator;
import io.nop.metadata.service.field.MetaEntityFieldResolver;
import io.nop.metadata.service.NopMetadataException;
import jakarta.inject.Inject;

import java.util.Map;

/**
 * 表指标 BizModel（架构基线 §2.5.2 D2/D3 / plan 0700-2 item 1.3 + plan 0228-3 跨表扩展）：
 * 基线 CRUD + save 字段引用校验。
 *
 * <p>save 校验（item 1.1 裁定的 save override 落点 + plan 0228-3 跨表范围扩展）：保存 Measure 时校验
 * {@code entityFieldId} 字段引用属于该表可达字段集合（语义按 entityKind 重载：entity→NopMetaEntityField 主键，
 * 可达集合 = {@code baseEntity ∪ join 直连可达 rightEntity}，见 §2.5.2 D3；external/sql→字段名）。
 * 不合法显式失败抛 inline {@link ErrorCode}（不静默存入悬空引用）。
 *
 * <p><b>expression 型 save-time 校验（§4.4.2 D12.5，plan 2026-07-18-1400-1 落地）</b>：当 {@code entityFieldId}
 * 为空且 {@code expression} 非空时，调 {@link ExpressionMeasureValidator#validateStatic} 做 save-time 宽松校验
 * （关键字黑名单 + parse 结构 + 容量；标识符宽松接受裸名 / {@code l.}/{@code r.} 前缀，不校验列存在性 / 端点归属——
 * 这些延迟到 query-time loader，它知道运行时上下文：单表 vs JOIN）。
 *
 * <p>跳过校验的情形：{@code entityFieldId} 为 null 且 {@code expression} 为空（数据错误由 mandatory 校验抛错）。
 * {@code aggFunc} 已由 dict {@code meta/agg-func} 校验，不重复。
 */
@BizModel("NopMetaEntityMeasure")
public class NopMetaEntityMeasureBizModel extends CrudBizModel<NopMetaEntityMeasure> implements INopMetaEntityMeasureBiz {


    /** 跨表类型字段解析器（无状态，与 NopMetaEntityBizModel 共用同一解析逻辑）。 */
    private final MetaEntityFieldResolver fieldResolver = new MetaEntityFieldResolver();

    /** 跨聚合访问（plan 353 MD-1）：MetaEntity 读取经 Biz 接口而非 dao 直连。 */
    @Inject
    protected INopMetaEntityBiz tableBiz;

    public NopMetaEntityMeasureBizModel() {
        setEntityName(NopMetaEntityMeasure.class.getName());
    }

    /**
     * save override（item 1.1 裁定的 save override 新模式 + plan 0228-3 跨表扩展 + plan 2026-07-18-1400-1 expression save-time）：
     * 持久化前校验 {@code entityFieldId} 字段引用（entity 表可校验通过 NopMetaEntityJoin 直连可达的 rightEntity 字段，
     * 跨表指标，架构基线 §2.5.2 D3）；以及 expression 文本（当 entityFieldId 为空且 expression 非空时）。
     *
     * <p>校验通过后委托 {@code super.save(...)} 走默认持久化逻辑（不破坏既有 CRUD 契约）。
     * 字段集合解析失败（baseEntityId null / buildSql 损坏 / sourceSql 不可解析）由解析器显式抛 ErrorCode。
     */
    @Override
    public NopMetaEntityMeasure save(@Name("data") Map<String, Object> data, IServiceContext context) {
        // P2-19（plan 2026-08-16-0226-3）：null/empty data 提前委托基类，
        // 统一抛 ERR_BIZ_EMPTY_DATA_FOR_SAVE
        if (CollectionHelper.isEmptyMap(data)) {
            return super.save(data, context);
        }
        String metaEntityId = NopMetadataHelper.stringOf(data, NopMetaEntityMeasure.PROP_NAME_metaEntityId);
        String entityFieldId = NopMetadataHelper.stringOf(data, NopMetaEntityMeasure.PROP_NAME_entityFieldId);
        String measureName = NopMetadataHelper.stringOf(data, NopMetaEntityMeasure.PROP_NAME_measureName);
        String expression = NopMetadataHelper.stringOf(data, NopMetaEntityMeasure.PROP_NAME_expression);
        inheritBusinessDomain(data, metaEntityId, context);
        validateMeasureField(metaEntityId, entityFieldId, measureName, expression, context);
        return super.save(data, context);
    }

    private void inheritBusinessDomain(Map<String, Object> data, String metaEntityId, IServiceContext context) {
        String businessDomainId = NopMetadataHelper.stringOf(data, NopMetaEntityMeasure.PROP_NAME_businessDomainId);
        if ((businessDomainId == null || businessDomainId.isEmpty())
                && metaEntityId != null && !metaEntityId.isEmpty()) {
            NopMetaEntity table = tableBiz.get(metaEntityId, false, context);
            if (table != null && table.getBusinessDomainId() != null) {
                data.put(NopMetaEntityMeasure.PROP_NAME_businessDomainId, table.getBusinessDomainId());
            }
        }
    }

    /**
     * 加载目标表 + 校验 entityFieldId 字段引用（entityFieldId 为空时跳过；用于 expression 型指标——
     * 此处接入 D12.5 expression save-time 校验）。
     *
     * @param measureName 错误上下文（expression 校验需要）
     * @param expression  expression 文本（entityFieldId 为空 + expression 非空时触发 D12.5 校验）
     */
    private void validateMeasureField(String metaEntityId, String entityFieldId, String measureName, String expression,
                                      IServiceContext context) {
        if (metaEntityId == null || metaEntityId.isEmpty()) {
            // metaEntityId 为 mandatory 列，框架会在 super.save 做必填校验；此处不重复报错
            return;
        }
        // D12.5 expression save-time 校验（entityFieldId 为空 + expression 非空 → expression 型指标）
        if ((entityFieldId == null || entityFieldId.isEmpty())
                && expression != null && !expression.trim().isEmpty()) {
            ExpressionMeasureValidator.validateStatic(expression,
                    ExpressionMeasureValidator.ValidationOptions.saveTimeLoose(),
                    metaEntityId, measureName == null ? "<unknown>" : measureName);
        }
        NopMetaEntity table = tableBiz.get(metaEntityId, false, context);
        if (table == null) {
            throw new NopMetadataException(NopMetadataErrors.ERR_MEASURE_TABLE_NOT_FOUND).param("metaEntityId", metaEntityId);
        }
        // resolver 边界：MetaEntityFieldResolver API 消费 IEntityDao（resolver 包不在 MD-1 转换范围），保留 dao 直连（plan 353 MD-1 裁定）
        IEntityDao<NopMetaEntityField> fieldDao = daoFor(NopMetaEntityField.class);
        // joinDao 用于 entity 表跨表可达 rightEntityId 集合解析（§2.5.2 D3）+ external/sql name-based 可达列名集合并集（§2.5.2 D4）
        IEntityDao<NopMetaEntityJoin> joinDao = daoFor(NopMetaEntityJoin.class);
        // tableDao 用于 external/sql 表解析 table 端点 NopMetaEntity 列结构（§2.5.2 D4，同上 resolver 边界）
        IEntityDao<NopMetaEntity> tableDao = daoFor(NopMetaEntity.class);
        // entityFieldId 为 null（expression 型）时 validateFieldReference 内部跳过校验
        fieldResolver.validateFieldReference(table, entityFieldId, fieldDao, joinDao, tableDao,
                NopMetadataErrors.ERR_MEASURE_FIELD_NOT_FOUND, "measure");
    }

}
