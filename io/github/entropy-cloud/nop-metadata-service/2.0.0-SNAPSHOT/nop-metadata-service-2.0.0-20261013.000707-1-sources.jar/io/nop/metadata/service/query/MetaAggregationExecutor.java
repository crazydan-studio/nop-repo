
package io.nop.metadata.service.query;

import io.nop.api.core.beans.FilterBeanConstants;
import io.nop.api.core.beans.TreeBean;
import io.nop.api.core.beans.query.OrderFieldBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.dao.api.IEntityDao;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityFilter;
import io.nop.metadata.dao.entity.NopMetaEntityJoin;
import io.nop.metadata.service.field.ExpressionMeasureValidator;
import io.nop.metadata.service.NopMetadataException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 指标/维度聚合查询执行器（架构基线 §4.4.2，落地 D6/D7）。
 *
 * <p>按 entityKind 路由聚合执行（D6）：
 * <ul>
 *   <li>{@code external}/{@code sql}：经 ExternalAggregationProcessor / SqlAggregationProcessor 跑原生聚合 SQL。</li>
 *   <li>{@code entity}：经 EntityAggregationProcessor 跑聚合 SQL。</li>
 *   <li>JOIN 聚合：经对应 Join Processor 按端点组合路由。</li>
 * </ul>
 *
 * <p>aggFunc 翻译：sum/count/avg/min/max/count_distinct。时间维度 granularity 按 {@link GranularityBucketing}
 * 翻译为 SQL 分桶表达式（D7，仅 external/sql 路径完整支持）。
 *
 * <p>失败路径显式（Minimum Rules #24）：无 measure/dimension / 字段无法解析 / aggFunc 不支持 /
 * granularity 不约定 / 方言不支持 / expression unparseable/unsafe/dialect-unsupported/too-long / 实体未注册。
 */
public class MetaAggregationExecutor {

    private final MetaJoinExecutor joinExecutor;

    public MetaAggregationExecutor() {
        this(new MetaJoinExecutor());
    }

    public MetaAggregationExecutor(MetaJoinExecutor joinExecutor) {
        this.joinExecutor = Objects.requireNonNull(joinExecutor, "joinExecutor");
    }

    static final Set<String> SUPPORTED_DIALECTS =
            Collections.unmodifiableSet(new HashSet<>(Arrays.asList("H2", "MySQL", "PostgreSQL")));

    /* All ErrorCode constants migrated to NopMetadataErrors */

    /**
     * 执行聚合查询（分派入口）。
     */
    public Map<String, Object> executeAggregation(NopMetaEntity table, List<String> measureNames,
                                                   List<String> dimensionNames, TreeBean userFilter, String joinId,
                                                   Long limit, Long offset, TreeBean having,
                                                   List<OrderFieldBean> orderBy, MetaQueryContext ctx) {
        if (measureNames == null || measureNames.isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_NO_MEASURE).param(NopMetadataErrors.ARG_META_ENTITY_ID, table.getMetaEntityId());
        }
        if (dimensionNames == null || dimensionNames.isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_NO_DIMENSION).param(NopMetadataErrors.ARG_META_ENTITY_ID, table.getMetaEntityId());
        }
        IEntityDao<NopMetaEntityFilter> filterDao = ctx.daoProvider().daoFor(NopMetaEntityFilter.class);
        TreeBean mergedFilter = DefaultFilterApplicator.applyDefaults(table, userFilter, filterDao);

        // Build shared AggregationContext
        AggregationContext aggrCtx = new AggregationContext(ctx, joinExecutor);
        aggrCtx.setTable(table);
        aggrCtx.setMeasureNames(measureNames);
        aggrCtx.setDimensionNames(dimensionNames);
        aggrCtx.setFilter(mergedFilter);
        aggrCtx.setJoinId(joinId);
        aggrCtx.setLimit(limit);
        aggrCtx.setOffset(offset);
        aggrCtx.setHaving(having);
        aggrCtx.setOrderBy(orderBy);

        if (joinId != null && !joinId.isEmpty()) {
            return AggregationHelper.buildResult(executeJoinAggregation(aggrCtx, table, measureNames, dimensionNames,
                    mergedFilter, joinId, limit, offset, having, orderBy, ctx));
        }

        String entityKind = table.getEntityKind();
        AggregationProcessor processor;
        if (_NopMetadataCoreConstants.ENTITY_KIND_PHYSICAL.equals(entityKind)) {
            processor = new EntityAggregationProcessor();
        } else if (_NopMetadataCoreConstants.ENTITY_KIND_EXTERNAL.equals(entityKind)) {
            processor = new ExternalAggregationProcessor();
        } else if (_NopMetadataCoreConstants.ENTITY_KIND_SQL_VIEW.equals(entityKind)) {
            processor = new SqlAggregationProcessor();
        } else {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXEC_FAILED)
                    .param("metaEntityId", table.getMetaEntityId())
                    .param("error", "unsupported entityKind: " + entityKind);
        }
        return AggregationHelper.buildResult(processor.execute(aggrCtx));
    }

    /**
     * JOIN 聚合执行入口（端点组合路由）：加载/校验 join + 解析端点后，按端点组合分派到对应 Processor。
     */
    private List<Map<String, Object>> executeJoinAggregation(AggregationContext aggrCtx, NopMetaEntity table,
                                                              List<String> measureNames, List<String> dimensionNames,
                                                              TreeBean filter, String joinId, Long limit, Long offset,
                                                              TreeBean having, List<OrderFieldBean> orderBy,
                                                              MetaQueryContext ctx) {
        NopMetaEntityJoin join = joinExecutor.loadValidatedJoin(table, joinId, ctx);

        MetaJoinExecutor.Endpoint leftEp = joinExecutor.resolveEndpoint(join, "left",
                join.getLeftEntityId(), ctx);
        MetaJoinExecutor.Endpoint rightEp = joinExecutor.resolveEndpoint(join, "right",
                join.getRightEntityId(), ctx);

        aggrCtx.setJoin(join);
        aggrCtx.setLeftEndpoint(leftEp);
        aggrCtx.setRightEndpoint(rightEp);

        if (leftEp.isEntity() && rightEp.isEntity()) {
            String leftQs = leftEp.entity.getQuerySpace();
            String rightQs = rightEp.entity.getQuerySpace();
            if (!AggregationHelper.equalsStr(leftQs, rightQs)) {
                return new CrossDbInMemoryAggregationProcessor().execute(aggrCtx);
            }
            return new EntityEntityJoinAggregationProcessor().execute(aggrCtx);
        }
        if (!leftEp.isEntity() && !rightEp.isEntity()) {
            String leftQs = leftEp.table.getQuerySpace();
            String rightQs = rightEp.table.getQuerySpace();
            if (!AggregationHelper.equalsStr(leftQs, rightQs)) {
                return new CrossDbInMemoryAggregationProcessor().execute(aggrCtx);
            }
            return new ExternalExternalJoinAggregationProcessor().execute(aggrCtx);
        }
        return new MixedSameDbJoinAggregationProcessor().execute(aggrCtx);
    }

    // ============================ 多列算术 having 预处理（plan 2026-07-18-1500-2）============================

    private static final Pattern HAVING_EXPR_NAME_TOKEN =
            Pattern.compile("[A-Za-z_][A-Za-z0-9_]*");

    public static void preprocessHavingArithmetic(TreeBean having, Map<String, String> nameToExpr,
                                                   NopMetaEntity table, List<String> measureNames,
                                                   List<String> dimensionNames) {
        if (having == null) {
            return;
        }
        // F1（plan 2026-08-14-0707-1）：清除客户端可伪造的 havingExprResolved 标记。
        // TreeBean.createFromJson 把任意客户端 JSON key 写为 attr，故该标记可被客户端伪造在任意叶子上，
        // 致使 nameResolverFor 信任伪造标记并把恶意 name 原文回填 HAVING SQL。本方法递归遍历整棵树，
        // 对每个节点先清除该标记，仅当本节点经 expr 路径合法处理后（下方 setAttr）才重新置位。
        having.removeAttr(HAVING_EXPR_RESOLVED_ATTR);
        Object exprAttr = having.getAttr(HAVING_EXPR_ATTR);
        if (exprAttr != null && !exprAttr.toString().isEmpty()) {
            String userExpr = exprAttr.toString();
            String finalSql = substituteAndValidateHavingExpr(userExpr, nameToExpr, table,
                    measureNames, dimensionNames);
            having.setAttr(FilterBeanConstants.FILTER_ATTR_NAME, finalSql);
            // MA7.1-01：显式标记该叶子——name 已是逐 token 白名单校验后的 SQL 表达式，
            // nameResolverFor 仅对带此标记的叶子允许直通，原始用户 name 一律显式失败。
            having.setAttr(HAVING_EXPR_RESOLVED_ATTR, Boolean.TRUE);
            return;
        }
        List<TreeBean> children = having.getChildren();
        if (children == null || children.isEmpty()) {
            return;
        }
        for (TreeBean child : children) {
            preprocessHavingArithmetic(child, nameToExpr, table, measureNames, dimensionNames);
        }
    }

    public static final String HAVING_EXPR_ATTR = "expr";

    /**
     * expr 叶子预处理完成后设置在叶子上的标记（MA7.1-01 修复）：标识该 leaf 的 {@code name} 已是
     * {@link #substituteAndValidateHavingExpr} 逐 token 白名单校验后的 SQL 表达式。
     * {@code AggregationHelper.nameResolverFor} 仅对带此标记的叶子允许直通拼接；未带标记的原始用户
     * name 一律抛 {@code ERR_AGGR_HAVING_UNKNOWN_NAME}，禁止原样进入 HAVING SQL。
     *
     * <p><b>F1 修复（plan 2026-08-14-0707-1）</b>：由于 {@code TreeBean.createFromJson} 把任意客户端
     * JSON key 写为 attr，该标记可被客户端伪造。{@code preprocessHavingArithmetic} 在递归入口对每个节点
     * 先清除该标记，仅经 expr 路径合法处理后重新置位——伪造标记不再被信任。
     */
    public static final String HAVING_EXPR_RESOLVED_ATTR = "havingExprResolved";

    static String substituteAndValidateHavingExpr(String userExpr, Map<String, String> nameToExpr,
                                                    NopMetaEntity table, List<String> measureNames,
                                                    List<String> dimensionNames) {
        Matcher m = HAVING_EXPR_NAME_TOKEN.matcher(userExpr);
        StringBuilder out = new StringBuilder(userExpr.length() + 32);
        int last = 0;
        while (m.find()) {
            out.append(userExpr, last, m.start());
            String token = m.group();
            String aggSql = nameToExpr.get(token);
            if (aggSql == null) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_UNKNOWN_NAME)
                        .param("metaEntityId", table.getMetaEntityId())
                        .param("name", token)
                        .param("selectedMeasures", String.valueOf(measureNames))
                        .param("selectedDimensions", String.valueOf(dimensionNames));
            }
            if (aggSql.indexOf('?') >= 0) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXPRESSION_HAVING_ORDER_BY_UNSUPPORTED)
                        .param("metaEntityId", table.getMetaEntityId())
                        .param("measureName", token)
                        .param("clause", "HAVING");
            }
            out.append(aggSql);
            last = m.end();
        }
        out.append(userExpr, last, userExpr.length());
        String finalSql = out.toString();

        ExpressionMeasureValidator.ValidatedExpression ve;
        try {
            ve = ExpressionMeasureValidator.validateStatic(finalSql,
                    ExpressionMeasureValidator.ValidationOptions.saveTimeLoose(),
                    table.getMetaEntityId(), "<having-arithmetic>");
        } catch (NopException e) {
            if (NopMetadataErrors.ERR_AGGR_EXPRESSION_UNPARSEABLE.getErrorCode().equals(e.getErrorCode())) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_EXPR_UNPARSEABLE, e)
                        .param("metaEntityId", table.getMetaEntityId())
                        .param("expr", userExpr)
                        .param("error", String.valueOf(e.getParam("error")));
            }
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_EXPR_UNSAFE, e)
                    .param("metaEntityId", table.getMetaEntityId())
                    .param("expr", userExpr)
                    .param("reason", String.valueOf(e.getParam("reason")));
        }
        if (ve.params != null && !ve.params.isEmpty()) {
            throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_EXPR_UNSAFE)
                    .param("metaEntityId", table.getMetaEntityId())
                    .param("expr", userExpr)
                    .param("reason", "literals are not allowed in having arithmetic expression "
                            + "(Phase 1 only allows measure-name arithmetic combination): "
                            + "params=" + ve.params);
        }
        return finalSql;
    }

    static boolean containsHavingArithmeticLeaf(TreeBean having) {
        if (having == null) {
            return false;
        }
        Object exprAttr = having.getAttr(HAVING_EXPR_ATTR);
        if (exprAttr != null && !exprAttr.toString().isEmpty()) {
            return true;
        }
        List<TreeBean> children = having.getChildren();
        if (children == null || children.isEmpty()) {
            return false;
        }
        for (TreeBean child : children) {
            if (containsHavingArithmeticLeaf(child)) {
                return true;
            }
        }
        return false;
    }
}
