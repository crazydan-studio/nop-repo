
package io.nop.metadata.service.query;

import io.nop.api.core.beans.query.OrderFieldBean;
import io.nop.api.core.beans.TreeBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.metadata.core._NopMetadataCoreConstants;
import io.nop.metadata.dao.entity.NopMetaEntity;
import io.nop.metadata.dao.entity.NopMetaEntityDimension;
import io.nop.metadata.dao.entity.NopMetaEntityJoin;
import io.nop.metadata.dao.entity.NopMetaEntityMeasure;
import io.nop.metadata.service.NopMetadataErrors;
import io.nop.metadata.service.NopMetadataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static io.nop.metadata.service.query.AggregationContext.*;
import static io.nop.metadata.service.query.AggregationHelper.*;

public class CrossDbInMemoryAggregationProcessor implements AggregationProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(CrossDbInMemoryAggregationProcessor.class);

    @Override
    public List<Map<String, Object>> execute(AggregationContext context) {
        NopMetaEntity table = context.getTable();
        List<String> measureNames = context.getMeasureNames();
        List<String> dimensionNames = context.getDimensionNames();
        TreeBean filter = context.getFilter();
        String joinId = context.getJoinId();
        Long limit = context.getLimit();
        Long offset = context.getOffset();
        TreeBean having = context.getHaving();
        List<OrderFieldBean> orderBy = context.getOrderBy();
        MetaQueryContext ctx = context.ctx();
        NopMetaEntityJoin join = context.getJoin();
        MetaJoinExecutor.Endpoint leftEp = context.getLeftEndpoint();
        MetaJoinExecutor.Endpoint rightEp = context.getRightEndpoint();

        // Self-join guards
        if (leftEp.isEntity() && rightEp.isEntity()) {
            if (equalsStr(leftEp.entity.getMetaEntityId(), rightEp.entity.getMetaEntityId())) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_JOIN_SELF_JOIN)
                        .param(NopMetadataErrors.ARG_JOIN_ID, joinId).param(NopMetadataErrors.ARG_ENTITY_ID, leftEp.entity.getMetaEntityId());
            }
        } else if (!leftEp.isEntity() && !rightEp.isEntity()) {
            if (equalsStr(leftEp.table.getMetaEntityId(), rightEp.table.getMetaEntityId())) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_JOIN_SELF_JOIN)
                        .param(NopMetadataErrors.ARG_JOIN_ID, joinId).param(NopMetadataErrors.ARG_ENTITY_ID, leftEp.table.getMetaEntityId());
            }
        }

        CrossDbFieldResolver resolver = new CrossDbFieldResolver(leftEp, rightEp, join, joinId, table, ctx);
        List<CrossDbMeasureSpec> measures = loadCrossDbMeasures(table, measureNames, ctx, resolver);
        List<CrossDbDimensionSpec> dims = loadCrossDbDimensions(table, dimensionNames, ctx, resolver);

        MetaJoinExecutor joinExecutor = context.joinExecutor();
        Map<String, Object> joinResult = joinExecutor.executeJoin(table, joinId, filter, null, 0L, ctx);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> mergedRows = joinResult.get("items") instanceof List
                ? (List<Map<String, Object>>) joinResult.get("items")
                : new ArrayList<>();

        String alias = crossDbAliasOf(join);
        if (!mergedRows.isEmpty()) {
            Map<String, Object> sample = mergedRows.get(0);
            resolveAndValidateLookupKeys(measures, alias, sample, table, joinId, "measure");
            resolveAndValidateLookupKeys(dims, alias, sample, table, joinId, "dimension");
        }

        List<Map<String, Object>> items = memoryGroupBy(mergedRows, measures, dims);

        if (having != null) {
            if (MetaAggregationExecutor.containsHavingArithmeticLeaf(having)) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_HAVING_EXPR_MEMORY_NOT_COMPUTABLE)
                        .param(NopMetadataErrors.ARG_META_ENTITY_ID, table.getMetaEntityId())
                        .param(NopMetadataErrors.ARG_EXPR, "<having arithmetic in cross-DB memory path>");
            }
            Map<String, String> nameToAlias = buildCrossDbNameToAliasTable(measures, dims, measureNames,
                    dimensionNames, table);
            MemoryFilterEvaluator evaluator = new MemoryFilterEvaluator(having, nameToAlias, table, measureNames,
                    dimensionNames);
            items = evaluator.filter(items);
        }

        if (orderBy != null && !orderBy.isEmpty()) {
            Map<String, String> nameToAlias = buildCrossDbNameToAliasTable(measures, dims, measureNames,
                    dimensionNames, table);
            items = MemoryOrderByComparator.sort(items, orderBy, nameToAlias, table, measureNames, dimensionNames);
        }

        return truncateCrossDb(items, limit, offset);
    }

    private static List<CrossDbMeasureSpec> loadCrossDbMeasures(NopMetaEntity table, List<String> names,
                                                                  MetaQueryContext ctx, CrossDbFieldResolver resolver) {
        List<NopMetaEntityMeasure> all = loadMeasures(table, names, ctx);
        List<CrossDbMeasureSpec> specs = new ArrayList<>(all.size());
        for (NopMetaEntityMeasure m : all) {
            if (m.getExpression() != null && !m.getExpression().trim().isEmpty()) {
                throw new NopMetadataException(NopMetadataErrors.ERR_AGGR_EXPRESSION_MEMORY_NOT_COMPUTABLE)
                        .param(NopMetadataErrors.ARG_META_ENTITY_ID, table.getMetaEntityId())
                        .param(NopMetadataErrors.ARG_MEASURE_NAME, m.getMeasureName())
                        .param(NopMetadataErrors.ARG_JOIN_ID, resolver.joinId());
            }
            CrossDbField f = resolver.resolve(m.getEntityFieldId(), m.getMeasureName(), m.getSide(), "measure");
            specs.add(new CrossDbMeasureSpec(safeAlias(m.getMeasureName()), m.getAggFunc(), f.rawKey, f.side));
        }
        return specs;
    }

    private static List<CrossDbDimensionSpec> loadCrossDbDimensions(NopMetaEntity table, List<String> names,
                                                                     MetaQueryContext ctx, CrossDbFieldResolver resolver) {
        List<NopMetaEntityDimension> all = loadDimensions(table, names, ctx);
        List<CrossDbDimensionSpec> specs = new ArrayList<>(all.size());
        for (NopMetaEntityDimension d : all) {
            CrossDbField f = resolver.resolve(d.getEntityFieldId(), d.getDimensionName(), d.getSide(), "dimension");
            specs.add(new CrossDbDimensionSpec(safeAlias(d.getDimensionName()), f.rawKey, f.side));
        }
        return specs;
    }
}
