/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.http.api.server;

import io.nop.api.core.context.IContext;
import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.exceptions.NopException;

import java.io.InputStream;
import java.net.HttpCookie;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Flow;
import java.util.function.Function;

import static io.nop.http.api.HttpApiErrors.ARG_HEADER_NAME;

/**
 * 封装http请求过程，底层支持不同的Web框架，如vertx，servlet等
 */
public interface IHttpServerContext {
    String HEADER_AUTHORIZATION = "authorization";
    String BEARER_PREFIX = "Bearer ";

    String HEADER_X_REQUESTED_WITH = "x-requested-with";
    String HEADER_X_ACCESS_TOKEN = "x-access-token";
    String HEADER_ACCEPT = "accept";

    String getHost();

    String getRemoteAddr();

    int getRemotePort();

    /**
     * 不包含queryString的后端服务路径
     */
    String getRequestPath();

    default String getMethod(){
        return null;
    }

    /**
     * 包含queryString的完整请求链接
     */
    String getRequestUrl();

    String getQueryParam(String name);

    Map<String, String> getQueryParams();

    Map<String, Object> getRequestHeaders();

    Object getRequestHeader(String headerName);

    default String getRequestStringHeader(String headerName) {
        return (String) getRequestHeader(headerName);
    }

    default long getRequestLongHeader(String headerName, long defaultValue) {
        Long value = ConvertHelper.toLong(getRequestHeader(headerName), err -> new NopException(err).param(ARG_HEADER_NAME, headerName));
        if (value == null)
            return defaultValue;
        return value;
    }

    default void resumeRequest() {

    }

    String getCookie(String name);

    void addCookie(String sameSite, HttpCookie cookie);

    void removeCookie(String name);

    void removeCookie(String name, String domain, String path);

    void setResponseHeader(String headerName, Object value);

    void sendRedirect(String url);

    void sendResponse(int httpStatus, String body);

    void sendResponse(int httpStatus, InputStream body);

    /**
     * 发送流式响应
     *
     * @param httpStatus HTTP状态码
     * @param contentType Content-Type，如 "text/event-stream" 或 "application/x-ndjson"
     * @param publisher 流式数据发布者
     * @return 完成时返回的Future
     */
    default CompletionStage<Void> sendStreamingResponse(int httpStatus, String contentType,
                                                        Flow.Publisher<String> publisher) {
        throw new UnsupportedOperationException("Streaming response not supported");
    }

    /**
     * 使用回调方式发送流式响应
     *
     * @param httpStatus HTTP状态码
     * @param contentType Content-Type
     * @param writerFn 写入器函数，接收 IStreamResponseWriter，返回完成时的 Future
     * @return 完成时返回的Future
     */
    default CompletionStage<Void> sendStreamingResponse(int httpStatus, String contentType,
                                                        Function<IStreamResponseWriter, CompletionStage<Void>> writerFn) {
        throw new UnsupportedOperationException("Streaming response not supported");
    }

    boolean isResponseSent();

    String getAcceptableContentType();

    String getResponseContentType();

    void setResponseContentType(String contentType);

    void setResponseCharacterEncoding(String encoding);

    IAsyncBody getRequestBody();

    CompletionStage<Object> executeBlocking(Callable<?> task);

    IContext getContext();

    void setContext(IContext context);
}
