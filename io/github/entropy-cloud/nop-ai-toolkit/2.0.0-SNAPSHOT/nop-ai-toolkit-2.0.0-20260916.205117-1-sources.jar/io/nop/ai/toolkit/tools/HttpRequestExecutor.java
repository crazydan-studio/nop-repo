package io.nop.ai.toolkit.tools;

import io.nop.ai.toolkit.api.IToolExecuteContext;
import io.nop.ai.toolkit.api.IToolExecutor;
import io.nop.ai.toolkit.model.AiToolCall;
import io.nop.ai.toolkit.model.AiToolCallResult;
import io.nop.ai.toolkit.tools.ssrf.SsrfAddressGuard;
import io.nop.ai.toolkit.tools.ssrf.SsrfGuardDnsResolver;
import io.nop.api.core.util.FutureHelper;
import io.nop.commons.util.StringHelper;
import io.nop.core.lang.xml.XNode;
import io.nop.http.api.HttpApiConstants;
import io.nop.http.api.IDnsResolver;
import io.nop.http.api.client.HttpRequest;
import io.nop.http.api.client.IHttpClient;
import io.nop.http.api.client.IHttpResponse;
import jakarta.annotation.Nullable;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.regex.Pattern;

public class HttpRequestExecutor implements IToolExecutor {
    static final Logger LOG = LoggerFactory.getLogger(HttpRequestExecutor.class);
    public static final String TOOL_NAME = "http-request";

    private static final Pattern URL_WHITELIST_PATTERN = Pattern.compile(
            "^https?://[a-zA-Z0-9.-]+(:\\d+)?(/.*)?$");

    private IHttpClient httpClient;

    /**
     * Resolution-time SSRF enforcement (DR-4a). Defaults to
     * {@link SsrfGuardDnsResolver} so every request's hostname is resolved
     * through the guard before the transport is reached — a hostname that
     * resolves to an internal / cloud-metadata address (DNS rebinding-style
     * attacks) fails closed before any connection is established.
     */
    private IDnsResolver dnsResolver = new SsrfGuardDnsResolver();

    @Inject
    public void setHttpClient(IHttpClient httpClient) {
        this.httpClient = httpClient;
    }

    /**
     * Optional injection: overrides the resolution-time SSRF resolver (test
     * mocks, custom policy). When no {@code IDnsResolver} bean is registered,
     * the {@link SsrfGuardDnsResolver} default stays in effect.
     */
    @Inject
    public void setDnsResolver(@Nullable IDnsResolver dnsResolver) {
        if (dnsResolver != null) {
            this.dnsResolver = dnsResolver;
        }
    }

    @Override
    public String getToolName() {
        return TOOL_NAME;
    }

    @Override
    public CompletionStage<AiToolCallResult> executeAsync(AiToolCall call, IToolExecuteContext context) {
        if (httpClient == null) {
            return FutureHelper.success(
                AiToolCallResult.errorResult(call.getId(), "HTTP client not available")
            );
        }

        String url = call.attrText("url", "");
        String method = call.attrText("method", "GET").toUpperCase();
        int timeoutMs = call.attrInt("timeoutMs", call.getTimeoutMs() != null ? call.getTimeoutMs() : 30000);

        if (url.isEmpty()) {
            return FutureHelper.success(
                AiToolCallResult.errorResult(call.getId(), "URL is required")
            );
        }

        String validationError = validateUrl(url);
        if (validationError != null) {
            return FutureHelper.success(
                    AiToolCallResult.errorResult(call.getId(), "URL blocked: " + validationError)
            );
        }

        return context.getExecutor().submit(() -> doExecute(call, url, method, timeoutMs));
    }

    private String validateUrl(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            if (host == null || host.isEmpty()) {
                return "No host in URL";
            }
            String scheme = uri.getScheme();
            if (scheme == null || (!scheme.equals("http") && !scheme.equals("https"))) {
                return "Only http and https schemes are allowed";
            }
            return SsrfAddressGuard.validateHost(host);
        } catch (Exception e) {
            LOG.warn("Invalid URL: {}", url, e);
            return "Invalid URL: " + e;
        }
    }

    /**
     * Second-stage SSRF enforcement: resolves the request's hostname through
     * the configured {@link IDnsResolver} (default {@link SsrfGuardDnsResolver})
     * and rejects hosts that fail closed — internal addresses, DNS-rebinding
     * multi-answer sets, cloud metadata, unresolved hosts.
     */
    private String validateResolvedHost(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            if (host == null || host.isEmpty()) {
                return "No host in URL";
            }
            InetAddress[] addresses = dnsResolver.resolve(host);
            if (addresses == null || addresses.length == 0) {
                return "SSRF guard: unresolved host: " + host;
            }
            return null;
        } catch (UnknownHostException e) {
            LOG.warn("SSRF guard: host resolution failed for {}", url, e);
            return "SSRF guard: host resolution failed: " + e;
        } catch (Exception e) {
            LOG.warn("Invalid URL: {}", url, e);
            return "Invalid URL: " + e;
        }
    }

    private AiToolCallResult doExecute(AiToolCall call, String url, String method, int timeoutMs) {
        try {
            // Resolution-time SSRF enforcement: the hostname is resolved
            // through the guarded resolver right before the request is sent,
            // so a hostname resolving to an internal/metadata address (DNS
            // rebinding) fails closed before the transport is reached.
            String resolutionError = validateResolvedHost(url);
            if (resolutionError != null) {
                return AiToolCallResult.errorResult(call.getId(), "URL blocked: " + resolutionError);
            }

            HttpRequest request = new HttpRequest();
            request.setUrl(url);
            request.setMethod(method);
            request.setTimeout(timeoutMs);

            Map<String, Object> headers = parseHeaders(call);
            if (headers != null && !headers.isEmpty()) {
                request.setHeaders(headers);
            }

            Map<String, Object> params = parseParams(call);
            if (params != null && !params.isEmpty()) {
                request.setParams(params);
            }

            String body = call.childText("body");
            if (body != null && !body.isEmpty()) {
                request.setBody(body);
            }

            applyAuth(call, request);

            IHttpResponse response = httpClient.fetch(request, null);

            return buildSuccessResult(call, response);
        } catch (Exception e) {
            LOG.error("HTTP request to {} failed", url, e);
            return AiToolCallResult.errorResult(call.getId(), e.toString());
        }
    }

    private Map<String, Object> parseHeaders(AiToolCall call) {
        Map<String, Object> headers = new LinkedHashMap<>();
        XNode headersNode = call.childNode("headers");
        if (headersNode != null) {
            for (XNode headerNode : headersNode.getChildren()) {
                if ("header".equals(headerNode.getTagName())) {
                    String name = headerNode.attrText("name");
                    String value = headerNode.attrText("value");
                    if (name != null && value != null) {
                        headers.put(name, StringHelper.unescapeXml(value));
                    }
                }
            }
        }
        return headers;
    }

    private Map<String, Object> parseParams(AiToolCall call) {
        Map<String, Object> params = new LinkedHashMap<>();
        XNode paramsNode = call.childNode("params");
        if (paramsNode != null) {
            for (XNode paramNode : paramsNode.getChildren()) {
                if ("param".equals(paramNode.getTagName())) {
                    String name = paramNode.attrText("name");
                    String value = paramNode.attrText("value");
                    if (name != null) {
                        params.put(name, value != null ? StringHelper.unescapeXml(value) : "");
                    }
                }
            }
        }
        return params;
    }

    private void applyAuth(AiToolCall call, HttpRequest request) {
        XNode authNode = call.childNode("auth");
        if (authNode == null) return;

        String authType = authNode.attrText("type", "none");
        if ("basic".equals(authType)) {
            XNode usernameNode = authNode.childByTag("username");
            XNode passwordNode = authNode.childByTag("password");
            String username = usernameNode != null ? usernameNode.contentText() : "";
            String password = passwordNode != null ? passwordNode.contentText() : "";
            // Basic 认证凭据编码固定 UTF-8（ASCII 凭据与默认字符集结果一致，非 ASCII 凭据行为确定化）
            String credentials = Base64.getEncoder().encodeToString(
                    (username + ":" + password).getBytes(StandardCharsets.UTF_8));
            request.header(HttpApiConstants.HEADER_AUTHORIZATION, "Basic " + credentials);
        } else if ("bearer".equals(authType)) {
            XNode tokenNode = authNode.childByTag("token");
            String token = tokenNode != null ? tokenNode.contentText() : "";
            if (!StringHelper.isEmpty(token)) {
                request.bearerToken(token);
            }
        }
    }

    private AiToolCallResult buildSuccessResult(AiToolCall call, IHttpResponse response) {
        int status = response.getHttpStatus();
        String body = response.getBodyAsString();
        Map<String, String> headers = response.getHeaders();

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"status\": ").append(status).append(",\n");
        sb.append("  \"headers\": {\n");
        if (headers != null) {
            boolean first = true;
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                if (!first) sb.append(",\n");
                first = false;
                sb.append("    \"").append(entry.getKey()).append("\": \"")
                        .append(StringHelper.escapeJson(entry.getValue())).append("\"");
            }
        }
        sb.append("\n  },\n");
        sb.append("  \"body\": ");
        if (body != null && body.trim().startsWith("{")) {
            sb.append(body);
        } else {
            sb.append("\"").append(body != null ? StringHelper.escapeJson(body) : "").append("\"");
        }
        sb.append("\n}");

        return AiToolCallResult.successResult(call.getId(), sb.toString());
    }
}
