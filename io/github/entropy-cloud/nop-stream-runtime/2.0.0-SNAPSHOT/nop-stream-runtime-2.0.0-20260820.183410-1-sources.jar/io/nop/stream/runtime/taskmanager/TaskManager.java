/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.taskmanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.annotations.core.Internal;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.message.IMessageService;
import io.nop.stream.core.checkpoint.CheckpointBarrier;
import io.nop.stream.core.checkpoint.TaskLocation;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.execution.CheckpointBarrierTracker;
import io.nop.stream.core.execution.StreamTaskInvokable;
import io.nop.stream.core.execution.plan.DeploymentPlan;
import io.nop.stream.core.jobgraph.OperatorChain;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ACTUAL_TOKEN;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_EXPECTED_TOKEN;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_FENCING_TOKEN_MISMATCH;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import io.nop.stream.runtime.cluster.ClusterRegistry;
import io.nop.stream.runtime.cluster.TaskAssignment;
import io.nop.stream.runtime.coordinator.TaskProgress;
import io.nop.stream.runtime.coordinator.TaskStatusReport;
import io.nop.stream.runtime.rpc.IStreamCoordinatorRpcService;
import io.nop.stream.runtime.rpc.IStreamTaskRpcService;
import io.nop.stream.runtime.rpc.TaskDeploymentDescriptor;
import io.nop.stream.runtime.transport.RemoteInputChannel;
import io.nop.stream.runtime.transport.RemoteResultPartition;
import io.nop.stream.runtime.transport.SubtaskPlanBuilder;

/**
 * TaskManager is the distributed runtime component on each worker node.
 *
 * <p>It is responsible for:
 * <ul>
 *   <li>Registering with the {@link ClusterRegistry} and sending periodic heartbeats</li>
 *   <li>Receiving task assignments and creating {@link StreamTaskInvokable} instances</li>
 *   <li>Running tasks in a local thread pool with {@link RemoteResultPartition}/{@link RemoteInputChannel}</li>
 *   <li>Handling checkpoint barrier signals from the coordinator</li>
 *   <li>Sending checkpoint ACKs back to the coordinator via control topic</li>
 *   <li>Enforcing fencing tokens to reject stale operations</li>
 * </ul>
 *
 * <p><strong>Fencing:</strong> Each job execution epoch has a fencing token. When the
 * coordinator performs global recovery, a new fencing token is issued. The TaskManager
 * rejects any operation carrying an old fencing token.
 */
@Internal
public class TaskManager implements IStreamTaskRpcService {

    private static final Logger LOG = LoggerFactory.getLogger(TaskManager.class);

    private static final long DEFAULT_HEARTBEAT_INTERVAL_MS = 5000L;
    private static final long DEFAULT_LEASE_TIMEOUT_MS = 15000L;

    private final String nodeId;
    private final String endpoint;
    private final int capacity;
    private final IMessageService messageService;
    private final ClusterRegistry clusterRegistry;

    private final Semaphore capacitySemaphore;

    private final ExecutorService taskExecutor;
    private final ScheduledExecutorService heartbeatExecutor;

    /** taskKey (jobId/vertexId/subtaskIndex) → RunningTask */
    private final ConcurrentHashMap<String, RunningTask> runningTasks;

    /** taskKey → TaskResult for completed tasks (bounded to MAX_COMPLETED_TASKS) */
    private static final int MAX_COMPLETED_TASKS = 1000;
    private final ConcurrentHashMap<String, TaskResult> completedTasks;

    /** The currently active fencing epoch for this node (updated on global recovery). */
    private final AtomicLong currentFencingEpoch;

    /** Control topic for sending ACKs via message service (fallback when no RPC service) */
    private final String controlTopic;

    /** RPC service for sending ACKs directly to coordinator */
    private volatile IStreamCoordinatorRpcService coordinatorRpcService;

    private volatile boolean running;

    public TaskManager(String nodeId,
                       String endpoint,
                       int capacity,
                       IMessageService messageService,
                       ClusterRegistry clusterRegistry,
                       String controlTopic) {
        this.nodeId = nodeId;
        this.endpoint = endpoint;
        this.capacity = capacity;
        this.messageService = messageService;
        this.clusterRegistry = clusterRegistry;
        this.controlTopic = controlTopic;
        this.capacitySemaphore = new Semaphore(Math.max(1, capacity));
        this.taskExecutor = Executors.newFixedThreadPool(Math.max(1, capacity), r -> {
            Thread t = new Thread(r, "tm-task-" + nodeId);
            t.setDaemon(true);
            return t;
        });
        this.heartbeatExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "tm-heartbeat-" + nodeId);
            t.setDaemon(true);
            return t;
        });
        this.runningTasks = new ConcurrentHashMap<>();
        this.completedTasks = new ConcurrentHashMap<>();
        this.currentFencingEpoch = new AtomicLong(0L);
        this.running = false;
    }

    // ==================== Lifecycle ====================

    /**
     * Registers this node in the ClusterRegistry and starts the heartbeat loop.
     */
    public void start() {
        if (running) {
            LOG.warn("TaskManager {} already started", nodeId);
            return;
        }

        clusterRegistry.registerNode(nodeId, endpoint, capacity);
        running = true;

        heartbeatExecutor.scheduleAtFixedRate(
                this::heartbeat,
                DEFAULT_HEARTBEAT_INTERVAL_MS,
                DEFAULT_HEARTBEAT_INTERVAL_MS,
                TimeUnit.MILLISECONDS);

        LOG.info("TaskManager {} started at endpoint {} with capacity {}", nodeId, endpoint, capacity);
    }

    /**
     * Shuts down the thread pool, cancels heartbeats, and unregisters from the ClusterRegistry.
     */
    public void stop() {
        if (!running) {
            return;
        }
        running = false;

        heartbeatExecutor.shutdownNow();
        taskExecutor.shutdownNow();

        try {
            if (!taskExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                LOG.warn("TaskExecutor did not terminate within 5 seconds for node {}", nodeId);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            LOG.warn("Interrupted while waiting for TaskExecutor termination for node {}", nodeId);
        }

        for (Map.Entry<String, RunningTask> entry : runningTasks.entrySet()) {
            entry.getValue().cancel();
        }
        runningTasks.clear();

        LOG.info("TaskManager {} stopped", nodeId);
    }

    // ==================== Heartbeat ====================

    /**
     * Renews the lease for this node in the ClusterRegistry and (G52) piggybacks
     * per-task liveness to the coordinator on the existing heartbeat cadence.
     *
     * <p>No new task-level heartbeat thread is introduced: this method reads each
     * RunningTask's invokable liveness signal (null-checking the invokable
     * since it is set lazily by {@link RunningTask#setInvokable} after a 30s
     * {@code waitForInvokable} window) and reports a {@link TaskProgress} batch to
     * the coordinator via {@link IStreamCoordinatorRpcService#reportNodeTaskLiveness}.
     *
     * <p>G52 / AR-01 liveness semantics: the reported value is the <b>task
     * aliveness</b> signal, decoupled from data progress. MIDDLE/SINK roles
     * report the task thread's loop-activity timestamp
     * ({@link StreamTaskInvokable#getLastActivityTime()}) — fresh while the
     * loop cycles (data or idle), aging only when the thread is genuinely
     * stuck. SOURCE/SELF_CONTAINED roles report the TM-side wall clock: their
     * run loop may legitimately block for the whole source lifetime (e.g. a
     * polling source with no data), so an idle source must never age out of
     * the coordinator's liveness window.
     */
    public void heartbeat() {
        if (!running) {
            return;
        }
        try {
            boolean renewed = clusterRegistry.renewLease(nodeId, DEFAULT_LEASE_TIMEOUT_MS);
            if (!renewed) {
                LOG.warn("Failed to renew lease for node {}. Re-registering.", nodeId);
                clusterRegistry.registerNode(nodeId, endpoint, capacity);
            }
        } catch (Exception e) {
            LOG.error("Heartbeat failed for node {}", nodeId, e);
        }

        // G52: piggyback per-task liveness on the node heartbeat
        IStreamCoordinatorRpcService rpc = this.coordinatorRpcService;
        if (rpc == null || runningTasks.isEmpty()) {
            return;
        }
        List<TaskProgress> progress = new ArrayList<>();
        for (RunningTask task : runningTasks.values()) {
            StreamTaskInvokable inv = task.invokable;
            // null-check defense: invokable is volatile, lazily set by setInvokable()
            // (30s waitForInvokable window). Skip liveness for tasks whose invokable
            // is not yet installed — consistent with Phase 3 cancel null-check.
            if (inv == null) {
                continue;
            }
            progress.add(new TaskProgress(
                    task.vertexId,
                    task.subtaskIndex,
                    task.attemptNumber,
                    livenessValue(inv)));
        }
        if (!progress.isEmpty()) {
            try {
                rpc.reportNodeTaskLiveness(nodeId, progress);
            } catch (Exception e) {
                // #24 — no silent skip: log and continue. A transient RPC failure
                // does not tear down the heartbeat loop; the next beat retries.
                LOG.warn("reportNodeTaskLiveness failed for node {} ({} tasks)", nodeId, progress.size(), e);
            }
        }
    }

    /**
     * G52 / AR-01: computes the per-task liveness value reported to the
     * coordinator (see {@link #heartbeat()} javadoc for the semantics split).
     */
    private long livenessValue(StreamTaskInvokable inv) {
        StreamTaskInvokable.TaskRole role = inv.getRole();
        if (role == StreamTaskInvokable.TaskRole.SOURCE
                || role == StreamTaskInvokable.TaskRole.SELF_CONTAINED) {
            return System.currentTimeMillis();
        }
        return inv.getLastActivityTime();
    }

    // ==================== Task Assignment ====================

    /**
     * Receives a task assignment, creates the invokable, and starts execution.
     *
     * <p>The assignment must carry the current fencing token; otherwise it is rejected.
     *
     * @param assignment the task assignment from the coordinator
     */
    @Override
    public void receiveAssignment(TaskAssignment assignment) {
        if (!running) {
            LOG.warn("TaskManager {} not running, rejecting assignment", nodeId);
            return;
        }

        // Fencing epoch check
        // P0-6: harden stale-epoch handling to throw StreamException. The prior
        // implementation only LOG.warn'd and returned, silently swallowing the
        // operation despite the documented contract (TaskManager Javadoc: "rejects
        // any operation carrying an old fencing token"). Cross-JVM fencing is
        // owned by Stage 39 — this hardens the in-process check.
        long activeEpoch = currentFencingEpoch.get();
        if (activeEpoch != assignment.getFencingEpoch()) {
            throw new StreamException(ERR_STREAM_FENCING_TOKEN_MISMATCH)
                    .param(ARG_EXPECTED_TOKEN, activeEpoch)
                    .param(ARG_ACTUAL_TOKEN, assignment.getFencingEpoch());
        }

        // AR-9: Use semaphore for capacity control instead of race-prone size check
        if (!capacitySemaphore.tryAcquire()) {
            LOG.warn("Node {} at capacity ({}/{}), rejecting assignment for {}/{}",
                    nodeId, capacity - capacitySemaphore.availablePermits(), capacity,
                    assignment.getVertexId(), assignment.getSubtaskIndex());
            return;
        }

        String taskKey = taskKey(assignment);
        if (runningTasks.containsKey(taskKey)) {
            LOG.warn("Task {} already running, ignoring duplicate assignment", taskKey);
            capacitySemaphore.release();
            return;
        }

        // Two-phase assignment: receiveAssignment creates the RunningTask slot (its
        // invokable is not yet installed); the coordinator then populates the
        // invokable via a separate installInvokable() call (see EmbeddedDistributedExecutor
        // / RpcDistributedExecutor). RunningTask.run() blocks on invokableLatch until
        // the invokable arrives (or times out).
        RunningTask runningTask = new RunningTask(
                assignment.getJobId(),
                assignment.getVertexId(),
                assignment.getSubtaskIndex(),
                assignment.getFencingEpoch(),
                assignment.getAttemptId(),
                assignment.getAttemptNumber());

        RunningTask existing = runningTasks.putIfAbsent(taskKey, runningTask);
        if (existing != null) {
            capacitySemaphore.release();
            return;
        }

        Future<?> future = taskExecutor.submit(runningTask);
        runningTask.setFuture(future);

        LOG.info("TaskManager {} accepted assignment for {}/{} (attempt={})",
                nodeId, assignment.getVertexId(), assignment.getSubtaskIndex(),
                assignment.getAttemptId());
    }

    /**
     * Receive and install a fully-built {@link StreamTaskInvokable} for a previously assigned task slot.
     *
     * <p>This is called after {@link #receiveAssignment} when the coordinator sends the
     * serialized operator chain and deployment plan.
     */
    public void installInvokable(String jobId, String vertexId, int subtaskIndex,
                                 StreamTaskInvokable invokable) {
        String taskKey = taskKey(jobId, vertexId, subtaskIndex);
        RunningTask runningTask = runningTasks.get(taskKey);
        if (runningTask == null) {
            LOG.warn("No running task slot for {}/{}/{}", jobId, vertexId, subtaskIndex);
            return;
        }
        runningTask.setInvokable(invokable);
    }

    // ==================== Remote Deploy (Stage 42 Phase 0) ====================

    /**
     * Stage 42 Phase 0: deploys task logic to this TaskManager as a serializable
     * {@link TaskDeploymentDescriptor}. The TaskManager reconstructs its own
     * {@link StreamTaskInvokable} locally from the descriptor's
     * {@link io.nop.stream.core.jobgraph.JobGraph} + edge config (via
     * {@link SubtaskPlanBuilder}), installs it, and starts running the task.
     *
     * <p>This is the cross-JVM replacement for the in-process direct-Java
     * {@link #installInvokable} call. In remote-deploy mode the coordinator calls
     * this instead of {@link #receiveAssignment} + a separate direct install — the
     * descriptor is self-contained (carries {@link TaskAssignment} metadata).
     *
     * <p><strong>No silent skip</strong> (#24): if deployment fails (build error,
     * fencing mismatch, target-node mismatch, capacity exhausted), this method
     * throws a {@link StreamException} AND reports a FAILED
     * {@link io.nop.stream.runtime.coordinator.TaskStatusReport} to the coordinator
     * so the failure is observable and triggers recovery. Throwing alone is
     * insufficient because the {@code deployTask} RPC is one-way (fire-and-forget,
     * see {@code StreamControlRpcTransformer}) — the exception does not propagate
     * back to the coordinator over RPC.
     *
     * @param descriptor   the serializable deployment descriptor
     * @param fencingEpoch the monotonic fencing epoch the deployment is valid under
     */
    @Override
    public void deployTask(TaskDeploymentDescriptor descriptor, long fencingEpoch) {
        if (!running) {
            NopException ex = new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "TaskManager " + nodeId + " not running, rejecting deployTask");
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }
        if (descriptor == null) {
            NopException ex = new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "descriptor");
            reportDeployFailure(null, fencingEpoch, ex);
            throw ex;
        }
        if (descriptor.getJobGraph() == null) {
            NopException ex = new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "TaskDeploymentDescriptor carries no JobGraph; cannot deployTask for "
                            + descriptor.getVertexId() + "/" + descriptor.getSubtaskIndex());
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }

        long activeEpoch = currentFencingEpoch.get();
        if (activeEpoch != fencingEpoch) {
            NopException ex = new StreamException(ERR_STREAM_FENCING_TOKEN_MISMATCH)
                    .param(ARG_EXPECTED_TOKEN, activeEpoch)
                    .param(ARG_ACTUAL_TOKEN, fencingEpoch);
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }

        if (descriptor.getNodeId() != null && !descriptor.getNodeId().equals(nodeId)) {
            NopException ex = new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "deployTask target mismatch: descriptor nodeId=" + descriptor.getNodeId()
                            + " but this TaskManager is " + nodeId);
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }

        if (!capacitySemaphore.tryAcquire()) {
            NopException ex = new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                    "Node " + nodeId + " at capacity (" + (capacity - capacitySemaphore.availablePermits())
                            + "/" + capacity + "), rejecting deployTask for "
                            + descriptor.getVertexId() + "/" + descriptor.getSubtaskIndex());
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }

        String taskKey = taskKey(descriptor.getJobId(), descriptor.getVertexId(), descriptor.getSubtaskIndex());

        // Recovery may redeploy to the same slot before the old task is GC'd.
        // Fence the old slot out and reclaim its permit into this deployment.
        //
        // P1 hardening (permit conservation): the new deployment's permit was
        // acquired above (tryAcquire at the method entry). Releasing the old
        // slot's permit below balances the old task — net permit change for a
        // redeploy is therefore 0 (one task leaves, one task enters). The
        // legacy code re-acquired a permit here (acquireUninterruptibly), which
        // produced a net -1 per redeploy and wedged the node after `capacity`
        // recoveries. That extra acquire is removed; the entry acquire + this
        // release are the only permit touches for the redeploy path.
        RunningTask existing = runningTasks.get(taskKey);
        if (existing != null) {
            LOG.warn("Slot {} already occupied (attempt={}); fencing old before redeploy",
                    taskKey, existing.attemptId);
            runningTasks.remove(taskKey);
            existing.cancel();
            if (existing.semaphoreReleased.compareAndSet(false, true)) {
                capacitySemaphore.release();
            }
        }

        RunningTask runningTask = new RunningTask(
                descriptor.getJobId(),
                descriptor.getVertexId(),
                descriptor.getSubtaskIndex(),
                descriptor.getFencingEpoch(),
                descriptor.getAttemptId(),
                descriptor.getAttemptNumber());
        runningTasks.put(taskKey, runningTask);
        Future<?> future = taskExecutor.submit(runningTask);
        runningTask.setFuture(future);

        // Build the invokable locally from the descriptor. SubtaskPlanBuilder
        // rebuilds the subtask using this TaskManager's IMessageService, which
        // connects to the same deterministic data-plane topics the coordinator
        // would have wired — so cross-JVM data exchange works.
        StreamTaskInvokable invokable;
        try {
            SubtaskPlanBuilder builder = new SubtaskPlanBuilder(messageService, null);
            invokable = builder.buildSubtaskInvokable(descriptor);
        } catch (Throwable t) {
            LOG.error("Failed to build invokable from deployTask descriptor for {} on {}", taskKey, nodeId, t);
            runningTasks.remove(taskKey);
            runningTask.cancel();
            if (runningTask.semaphoreReleased.compareAndSet(false, true)) {
                capacitySemaphore.release();
            }
            NopException ex = new StreamException(ERR_STREAM_INVALID_STATE, t).param(ARG_DETAIL,
                    "Failed to build invokable from deployTask descriptor for " + taskKey
                            + " on TaskManager " + nodeId + ": " + t);
            reportDeployFailure(descriptor, fencingEpoch, ex);
            throw ex;
        }

        runningTask.setInvokable(invokable);
        LOG.info("TaskManager {} deployed task {} via deployTask RPC (attempt={}, checkpointRestorePath={})",
                nodeId, taskKey, descriptor.getAttemptId(), descriptor.getCheckpointRestorePath());
    }

    /**
     * Stage 42 Phase 0: reports a deployTask failure to the coordinator as a
     * FAILED {@link TaskStatusReport} so the failure is observable and triggers
     * recovery. Best-effort — failure to report is logged (not swallowed).
     */
    private void reportDeployFailure(TaskDeploymentDescriptor descriptor, long fencingEpoch, Throwable cause) {
        IStreamCoordinatorRpcService rpc = this.coordinatorRpcService;
        if (rpc == null) {
            return;
        }
        String dJobId = descriptor != null ? descriptor.getJobId() : null;
        String dVertexId = descriptor != null ? descriptor.getVertexId() : null;
        int dSubtaskIndex = descriptor != null ? descriptor.getSubtaskIndex() : -1;
        int dAttemptNumber = descriptor != null ? descriptor.getAttemptNumber() : 0;
        TaskStatusReport report = new TaskStatusReport(
                dJobId, dVertexId, dSubtaskIndex, dAttemptNumber,
                TaskStatusReport.TerminalState.FAILED,
                cause == null ? "deployTask failure" : cause.toString(),
                -1L, fencingEpoch, System.currentTimeMillis());
        try {
            rpc.reportTaskStatus(report);
        } catch (Exception e) {
            LOG.warn("Failed to report deployTask failure to coordinator for {}/{}/{}",
                    dJobId, dVertexId, dSubtaskIndex, e);
        }
    }

    // ==================== Checkpoint ====================

    /**
     * Handles a checkpoint barrier signal from the coordinator.
     *
     * <p>Injects the barrier into the source operator's pending barrier queue
     * (via {@link CheckpointBarrierTracker}).
     *
     * @param barrier       the checkpoint barrier
     * @param fencingToken  the fencing token of the current epoch
     */
    @Override
    public void triggerCheckpoint(CheckpointBarrier barrier, long fencingEpoch) {
        // P0-6: harden stale-epoch handling to throw StreamException. The prior
        // implementation only LOG.warn'd and returned, silently dropping the
        // barrier — which let a stale coordinator's checkpoint succeed against
        // the active epoch's state, breaking fencing semantics.
        long activeEpoch = currentFencingEpoch.get();
        if (activeEpoch != fencingEpoch) {
            throw new StreamException(ERR_STREAM_FENCING_TOKEN_MISMATCH)
                    .param(ARG_EXPECTED_TOKEN, activeEpoch)
                    .param(ARG_ACTUAL_TOKEN, fencingEpoch);
        }

        for (RunningTask task : runningTasks.values()) {
            if (task.getFencingEpoch() == fencingEpoch) {
                task.triggerCheckpoint(barrier);
            }
        }
    }

    @Override
    public void cancelTask(String jobId, String vertexId, int subtaskIndex) {
        String taskKey = taskKey(jobId, vertexId, subtaskIndex);
        RunningTask task = runningTasks.remove(taskKey);
        if (task != null) {
            task.cancel();
            if (task.semaphoreReleased.compareAndSet(false, true)) {
                capacitySemaphore.release();
            }
            LOG.info("Canceled task {}/{}/{}", jobId, vertexId, subtaskIndex);
        } else {
            LOG.warn("No running task to cancel for {}/{}/{}", jobId, vertexId, subtaskIndex);
        }
    }

    /**
     * Sends a checkpoint ACK to the coordinator via the control topic.
     *
     * @param checkpointId the checkpoint ID
     * @param snapshot     the task state snapshot
     */
    public void sendCheckpointAck(long checkpointId, TaskStateSnapshot snapshot) {
        CheckpointAckMessage ack = new CheckpointAckMessage(
                snapshot.getTaskLocation(),
                checkpointId,
                snapshot,
                currentFencingEpoch.get());

        try {
            if (coordinatorRpcService != null) {
                coordinatorRpcService.receiveCheckpointAck(ack);
            } else {
                throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                        "No coordinator RPC service available. "
                        + "All checkpoint ACKs require IStreamCoordinatorRpcService.");
            }
            LOG.debug("Sent checkpoint ACK for checkpoint {} from {}",
                    checkpointId, snapshot.getTaskLocation());
        } catch (Exception e) {
            LOG.error("Failed to send checkpoint ACK for checkpoint {}", checkpointId, e);
        }
    }

    // ==================== Fencing ====================

    /**
     * Updates the fencing epoch. Tasks with the old epoch are canceled.
     *
     * @param fencingEpoch the new monotonic fencing epoch
     */
    public void updateFencingToken(long fencingEpoch) {
        long oldEpoch = currentFencingEpoch.getAndSet(fencingEpoch);
        if (oldEpoch != fencingEpoch) {
            LOG.info("Fencing epoch updated from {} to {}. Canceling old tasks.", oldEpoch, fencingEpoch);
            runningTasks.entrySet().removeIf(entry -> {
                if (entry.getValue().getFencingEpoch() == oldEpoch) {
                    entry.getValue().cancel();
                    if (entry.getValue().semaphoreReleased.compareAndSet(false, true)) {
                        capacitySemaphore.release();
                    }
                    return true;
                }
                return false;
            });
        }
    }

    // ==================== Status ====================

    public String getNodeId() {
        return nodeId;
    }

    public void setCoordinatorRpcService(IStreamCoordinatorRpcService coordinatorRpcService) {
        this.coordinatorRpcService = coordinatorRpcService;
    }

    public int getRunningTaskCount() {
        return runningTasks.size();
    }

    int availablePermits() {
        return capacitySemaphore.availablePermits();
    }

    public Map<String, TaskResult> getCompletedTaskResults() {
        return Collections.unmodifiableMap(completedTasks);
    }

    public boolean isRunning() {
        return running;
    }

    // ==================== Helpers ====================

    private String taskKey(TaskAssignment assignment) {
        return taskKey(assignment.getJobId(), assignment.getVertexId(), assignment.getSubtaskIndex());
    }

    private String taskKey(String jobId, String vertexId, int subtaskIndex) {
        return jobId + "/" + vertexId + "/" + subtaskIndex;
    }

    // ==================== Inner Classes ====================

    /**
     * A running task tracked by the TaskManager.
     */
    public class RunningTask implements Runnable {
        private final String jobId;
        private final String vertexId;
        private final int subtaskIndex;
        private final long fencingEpoch;
        private final String attemptId;
        /**
         * G56: per-subtask attempt number (mirrors {@link TaskAssignment#getAttemptNumber()}).
         * Carried in {@link TaskStatusReport} so the coordinator can correlate reports
         * with the right attempt.
         */
        private final int attemptNumber;
        private final TaskLocation taskLocation;
        private final CountDownLatch invokableLatch;

        private volatile StreamTaskInvokable invokable;
        private volatile Future<?> future;
        private volatile boolean canceled;
        private volatile Throwable error;
        private final AtomicBoolean semaphoreReleased = new AtomicBoolean(false);

        public RunningTask(String jobId, String vertexId, int subtaskIndex,
                           long fencingEpoch, String attemptId) {
            this(jobId, vertexId, subtaskIndex, fencingEpoch, attemptId, 1);
        }

        public RunningTask(String jobId, String vertexId, int subtaskIndex,
                           long fencingEpoch, String attemptId, int attemptNumber) {
            this.jobId = jobId;
            this.vertexId = vertexId;
            this.subtaskIndex = subtaskIndex;
            this.fencingEpoch = fencingEpoch;
            this.attemptId = attemptId;
            this.attemptNumber = attemptNumber;
            this.taskLocation = new TaskLocation(jobId, "pipeline-0", vertexId, subtaskIndex);
            this.invokableLatch = new CountDownLatch(1);
        }

        @Override
        public void run() {
            if (canceled) {
                LOG.info("Task {}/{}/{} was canceled before execution", jobId, vertexId, subtaskIndex);
                return;
            }

            LOG.info("Running task {}/{}/{} (attempt={})", jobId, vertexId, subtaskIndex, attemptId);

            try {
                // Wait for invokable to be installed if not yet available
                StreamTaskInvokable inv = waitForInvokable();
                if (inv == null || canceled) {
                    LOG.info("Task {}/{}/{} canceled while waiting for invokable", jobId, vertexId, subtaskIndex);
                    return;
                }

                inv.invoke();

                if (!canceled) {
                    LOG.info("Task {}/{}/{} completed successfully", jobId, vertexId, subtaskIndex);
                }
            } catch (Throwable t) {
                if (!canceled) {
                    this.error = t;
                    LOG.error("Task {}/{}/{} failed", jobId, vertexId, subtaskIndex, t);
                }
            } finally {
                String key = taskKey(jobId, vertexId, subtaskIndex);
                boolean success = error == null && !canceled;
                completedTasks.put(key, new TaskResult(jobId, vertexId, subtaskIndex,
                        success, canceled, error));
                if (completedTasks.size() > MAX_COMPLETED_TASKS) {
                    Iterator<String> it = completedTasks.keySet().iterator();
                    if (it.hasNext()) {
                        it.next();
                        it.remove();
                    }
                }
                runningTasks.remove(key);
                if (semaphoreReleased.compareAndSet(false, true)) {
                    capacitySemaphore.release();
                }

                // G52: per-task terminal-state report to the coordinator. Only
                // COMPLETED / FAILED are reported (CANCELED is initiated by the
                // coordinator itself, no need to echo back). #24 — failure to
                // report is logged (no silent swallow).
                if (!canceled) {
                    reportTerminalStatus(success);
                }
            }
        }

        /**
         * G52: reports this task's terminal state to the coordinator. Failures
         * are logged but do not tear down the run loop (#24 — explicit handling,
         * not silent).
         */
        private void reportTerminalStatus(boolean success) {
            IStreamCoordinatorRpcService rpc = TaskManager.this.coordinatorRpcService;
            if (rpc == null) {
                // No coordinator wired (e.g. unit-test fixture); skip silently.
                return;
            }
            long lastProgress = -1L;
            StreamTaskInvokable inv = this.invokable;
            if (inv != null) {
                lastProgress = inv.getLastProgressTime();
            }
            TaskStatusReport.TerminalState state = success
                    ? TaskStatusReport.TerminalState.COMPLETED
                    : TaskStatusReport.TerminalState.FAILED;
            String cause = error != null ? error.toString() : null;
            TaskStatusReport report = new TaskStatusReport(
                    jobId, vertexId, subtaskIndex, attemptNumber,
                    state, cause, lastProgress, fencingEpoch,
                    System.currentTimeMillis());
            try {
                rpc.reportTaskStatus(report);
            } catch (Exception e) {
                LOG.warn("Failed to report terminal status for {}/{}/{} (state={})",
                        jobId, vertexId, subtaskIndex, state, e);
            }
        }

        private StreamTaskInvokable waitForInvokable() throws InterruptedException {
            if (!invokableLatch.await(30, TimeUnit.SECONDS)) {
                LOG.warn("Timed out waiting for invokable for {}/{}/{}", jobId, vertexId, subtaskIndex);
                return null;
            }
            return invokable;
        }

        public void setInvokable(StreamTaskInvokable invokable) {
            this.invokable = invokable;
            invokableLatch.countDown();
        }

        public void setFuture(Future<?> future) {
            this.future = future;
        }

        public void cancel() {
            canceled = true;
            invokableLatch.countDown();
            // G58: cooperative mailbox cancel first, then interrupt. Mirrors the
            // LOCAL path (GraphModelCheckpointExecutor.java:683) — the mailbox
            // signalCancel() raises the cancel flag and queues a cancel marker so
            // the task thread observes cancellation at its next mailbox drain even
            // if it is not in a blocking-interruptible section.
            //
            // null-check defense: invokable is volatile, lazily set by
            // setInvokable() (30s waitForInvokable window). If cancel arrives
            // before the invokable is installed, skip the mailbox call (no NPE);
            // the state-transition + future.cancel(true) + latch countdown still
            // apply so the task exits cleanly once the invokable arrives (or
            // waitForInvokable times out).
            StreamTaskInvokable inv = this.invokable;
            if (inv != null) {
                try {
                    inv.getMailboxExecutor().signalCancel();
                } catch (Exception e) {
                    LOG.warn("signalCancel failed for {}/{}/{} (falling back to interrupt-only)",
                            jobId, vertexId, subtaskIndex, e);
                }
            }
            if (future != null) {
                future.cancel(true);
            }
        }

        public void triggerCheckpoint(CheckpointBarrier barrier) {
            StreamTaskInvokable inv = this.invokable;
            if (inv == null) {
                LOG.debug("Cannot trigger checkpoint: invokable not yet installed for {}/{}/{}",
                        jobId, vertexId, subtaskIndex);
                return;
            }
            CheckpointBarrierTracker tracker = inv.getBarrierTracker();
            if (tracker == null) {
                LOG.debug("No barrier tracker for {}/{}/{}", jobId, vertexId, subtaskIndex);
                return;
            }
            try {
                tracker.triggerCheckpoint(barrier.getId(), barrier.getTimestamp(), barrier.getCheckpointType());
            } catch (Exception e) {
                LOG.error("Failed to trigger checkpoint on {}/{}/{}", jobId, vertexId, subtaskIndex, e);
            }
        }

        public long getFencingEpoch() {
            return fencingEpoch;
        }

        public String getJobId() { return jobId; }
        public String getVertexId() { return vertexId; }
        public int getSubtaskIndex() { return subtaskIndex; }
        public TaskLocation getTaskLocation() { return taskLocation; }
    }

    public static class TaskResult {
        private final String jobId;
        private final String vertexId;
        private final int subtaskIndex;
        private final boolean success;
        private final boolean canceled;
        private final Throwable error;

        public TaskResult(String jobId, String vertexId, int subtaskIndex,
                          boolean success, boolean canceled, Throwable error) {
            this.jobId = jobId;
            this.vertexId = vertexId;
            this.subtaskIndex = subtaskIndex;
            this.success = success;
            this.canceled = canceled;
            this.error = error;
        }

        public String getJobId() { return jobId; }
        public String getVertexId() { return vertexId; }
        public int getSubtaskIndex() { return subtaskIndex; }
        public boolean isSuccess() { return success; }
        public boolean isCanceled() { return canceled; }
        public Throwable getError() { return error; }
    }
}
