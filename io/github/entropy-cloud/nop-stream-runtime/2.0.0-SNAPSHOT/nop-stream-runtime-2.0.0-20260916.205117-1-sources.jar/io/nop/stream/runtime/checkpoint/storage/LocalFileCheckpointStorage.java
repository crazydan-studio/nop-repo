/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.checkpoint.storage;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.annotations.core.Internal;
import io.nop.core.lang.json.JsonTool;
import io.nop.stream.core.checkpoint.CompletedCheckpoint;
import io.nop.stream.core.checkpoint.EpochManifest;
import io.nop.stream.core.checkpoint.SavepointMetadata;
import io.nop.stream.core.checkpoint.TaskLocation;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.checkpoint.storage.CheckpointStorageException;
import io.nop.stream.core.checkpoint.storage.ICheckpointStorage;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CHECKPOINT_ERROR;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;

@Internal
public class LocalFileCheckpointStorage implements ICheckpointStorage {

    private static final Logger LOG = LoggerFactory.getLogger(LocalFileCheckpointStorage.class);

    private static final String CHECKPOINT_SUFFIX = ".checkpoint";
    private static final String EPOCH_MANIFEST_SUFFIX = ".epoch";
    private static final String TEMP_SUFFIX = ".tmp";
    private static final String SAVEPOINT_DIR_PREFIX = "savepoint-";
    private static final String METADATA_SUFFIX = ".metadata";
    private static final Pattern SAFE_ID_PATTERN = Pattern.compile("[a-zA-Z0-9_-]+");

    private final String baseDir;
    private final Path baseDirCanonical;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public LocalFileCheckpointStorage(String baseDir) {
        this.baseDir = baseDir;
        this.baseDirCanonical = Paths.get(baseDir).toAbsolutePath().normalize();
        ensureDirectoryExists(baseDir);
    }

    /**
     * Stage 42 Phase 0: returns the base directory path. Exposed so a
     * {@link io.nop.stream.runtime.coordinator.JobCoordinator} in remote-deploy
     * mode can pass it to each {@link io.nop.stream.runtime.rpc.TaskDeploymentDescriptor}
     * for cross-JVM state restore on the same machine.
     */
    public String getBaseDir() {
        return baseDir;
    }

    @Override
    public String getName() {
        return "LocalFileCheckpointStorage";
    }

    @Override
    public String storeCheckPoint(CompletedCheckpoint checkpoint) throws CheckpointStorageException {
        try {
            Path checkpointPath = getCheckpointPath(
                    checkpoint.getJobId(),
                    checkpoint.getPipelineId(),
                    checkpoint.getCheckpointId());

            Path tempPath = Paths.get(checkpointPath.toString() + TEMP_SUFFIX);

            lock.writeLock().lock();
            try {
                ensureDirectoryExists(checkpointPath.getParent().toString());

                byte[] data = serializeCheckpoint(checkpoint);
                Files.write(tempPath, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

                Files.move(tempPath, checkpointPath, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);

                return checkpointPath.toString();
            } finally {
                lock.writeLock().unlock();
                deleteIfExists(tempPath);
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "storeCheckPoint failed");
        }
    }

    @Override
    public CompletedCheckpoint getLatestCheckpoint(String jobId, String pipelineId) throws CheckpointStorageException {
        try {
            Path jobDir = getJobDir(jobId, pipelineId);

            lock.readLock().lock();
            try {
                if (!Files.exists(jobDir)) {
                    return null;
                }

                try (Stream<Path> files = Files.list(jobDir)) {
                    Optional<Path> latest = files
                            .filter(p -> p.toString().endsWith(CHECKPOINT_SUFFIX))
                            .max((a, b) -> Long.compare(
                                    extractCheckpointId(a.getFileName().toString()),
                                    extractCheckpointId(b.getFileName().toString())));

                    if (latest.isPresent()) {
                        return deserializeCheckpoint(latest.get());
                    }
                    return null;
                }
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "getLatestCheckpoint failed");
        }
    }

    @Override
    public List<CompletedCheckpoint> getAllCheckpoints(String jobId) throws CheckpointStorageException {
        try {
            validateId(jobId, "jobId");
            List<CompletedCheckpoint> result = new ArrayList<>();

            lock.readLock().lock();
            try {
                Path jobRootDir = validatePath(Paths.get(baseDir, jobId));
                if (!Files.exists(jobRootDir)) {
                    return result;
                }

                try (Stream<Path> pipelineDirs = Files.list(jobRootDir)) {
                    pipelineDirs.filter(Files::isDirectory)
                            .forEach(pipelineDir -> {
                                try (Stream<Path> files = Files.list(pipelineDir)) {
                                    files.filter(p -> p.toString().endsWith(CHECKPOINT_SUFFIX))
                                            .forEach(p -> {
                                                try {
                                                    CompletedCheckpoint cp = deserializeCheckpoint(p);
                                                    if (cp != null) {
                                                        result.add(cp);
                                                    }
                                                } catch (Exception e) {
                                                    LOG.warn("Failed to deserialize checkpoint file: {}", p, e);
                                                }
                                            });
                                } catch (Exception e) {
                                    LOG.warn("Failed to list checkpoint files in directory: {}", pipelineDir, e);
                                }
                            });
                }

                result.sort((a, b) -> Long.compare(b.getCheckpointId(), a.getCheckpointId()));
                return result;
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "getAllCheckpoints failed");
        }
    }

    @Override
    public List<CompletedCheckpoint> getLatestCheckpoints(String jobId, int count) throws CheckpointStorageException {
        try {
            validateId(jobId, "jobId");
            List<CompletedCheckpoint> all = new ArrayList<>();

            lock.readLock().lock();
            try {
                Path jobDir = validatePath(Paths.get(baseDir, jobId));
                if (!Files.exists(jobDir)) {
                    return all;
                }

                try (Stream<Path> files = Files.walk(jobDir)) {
                    files.filter(p -> p.toString().endsWith(CHECKPOINT_SUFFIX))
                            .forEach(p -> {
                                 try {
                                    CompletedCheckpoint cp = deserializeCheckpoint(p);
                                    if (cp != null) {
                                        all.add(cp);
                                    }
                                } catch (Exception e) {
                                    LOG.warn("Failed to deserialize checkpoint file: {}", p, e);
                                }
                            });
                }

                all.sort((a, b) -> Long.compare(b.getCheckpointId(), a.getCheckpointId()));
                if (all.size() <= count) {
                    return all;
                }
                return all.subList(0, count);
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "getLatestCheckpoints failed");
        }
    }

    @Override
    public void deleteCheckpoint(String jobId, String pipelineId, long checkpointId) throws CheckpointStorageException {
        try {
            Path checkpointPath = getCheckpointPath(jobId, pipelineId, checkpointId);

            lock.writeLock().lock();
            try {
                deleteIfExists(checkpointPath);
            } finally {
                lock.writeLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "deleteCheckpoint failed");
        }
    }

    @Override
    public void deleteAllCheckpoints(String jobId) throws CheckpointStorageException {
        try {
            validateId(jobId, "jobId");
            Path jobRootDir = validatePath(Paths.get(baseDir, jobId));

            lock.writeLock().lock();
            try {
                if (Files.exists(jobRootDir)) {
                    try (Stream<Path> files = Files.walk(jobRootDir)) {
                        files.sorted(Comparator.reverseOrder())
                                .forEach(p -> {
                                    try {
                                        Files.deleteIfExists(p);
                                    } catch (Exception e) {
                                        LOG.warn("Failed to delete checkpoint file: {}", p, e);
                                    }
                                });
                    }
                }
            } finally {
                lock.writeLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "deleteAllCheckpoints failed");
        }
    }

    @Override
    public int getCheckpointCount(String jobId) throws CheckpointStorageException {
        try {
            validateId(jobId, "jobId");
            int[] count = {0};
            Path jobRootDir = validatePath(Paths.get(baseDir, jobId));

            lock.readLock().lock();
            try {
                if (!Files.exists(jobRootDir)) {
                    return 0;
                }

                try (Stream<Path> files = Files.walk(jobRootDir)) {
                    files.filter(p -> p.toString().endsWith(CHECKPOINT_SUFFIX))
                            .forEach(p -> count[0]++);
                }
                return count[0];
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "getCheckpointCount failed");
        }
    }

    private Path getJobDir(String jobId, String pipelineId) {
        validateId(jobId, "jobId");
        validateId(pipelineId, "pipelineId");
        return validatePath(Paths.get(baseDir, jobId, pipelineId));
    }

    private Path getCheckpointPath(String jobId, String pipelineId, long checkpointId) {
        validateId(jobId, "jobId");
        validateId(pipelineId, "pipelineId");
        return validatePath(Paths.get(baseDir, jobId, pipelineId,
                checkpointId + CHECKPOINT_SUFFIX));
    }

    private void validateId(String id, String name) {
        if (id == null || !SAFE_ID_PATTERN.matcher(id).matches()) {
            throw new StreamException(ERR_STREAM_INVALID_ARG)
                    .param(ARG_ARG_NAME, name)
                    .param(ARG_DETAIL, "must match [a-zA-Z0-9_-]+, got: " + id);
        }
    }

    private Path validatePath(Path path) {
        Path canonical = path.toAbsolutePath().normalize();
        if (!canonical.startsWith(baseDirCanonical)) {
            throw new StreamException(ERR_STREAM_INVALID_STATE)
                    .param(ARG_DETAIL, "Path traversal detected: " + path + " is outside baseDir " + baseDirCanonical);
        }
        return canonical;
    }

    private long extractCheckpointId(String fileName) {
        return extractIdFromFileName(fileName, CHECKPOINT_SUFFIX);
    }

    private long extractIdFromFileName(String fileName, String suffix) {
        String name = fileName.replace(suffix, "");
        try {
            return Long.parseLong(name);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private byte[] serializeCheckpoint(CompletedCheckpoint checkpoint) {
        return CheckpointSerDe.serializeCheckpoint(checkpoint);
    }

    private CompletedCheckpoint deserializeCheckpoint(Path path) throws Exception {
        byte[] data = Files.readAllBytes(path);
        return CheckpointSerDe.deserializeCheckpoint(data);
    }

    private CompletedCheckpoint deserializeCheckpoint(byte[] data) {
        return CheckpointSerDe.deserializeCheckpoint(data);
    }

    private TaskStateSnapshot deserializeTaskStateSnapshot(Map<String, Object> map, TaskLocation taskLocation) {
        return CheckpointSerDe.deserializeTaskStateSnapshot(map, taskLocation);
    }

    private void ensureDirectoryExists(String dir) {
        try {
            Files.createDirectories(Paths.get(dir));
        } catch (Exception e) {
            LOG.warn("Failed to create directory: {}", dir, e);
        }
    }

    private void deleteIfExists(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (Exception e) {
            LOG.warn("Failed to delete file: {}", path, e);
        }
    }

    @Override
    public String storeSavepoint(CompletedCheckpoint checkpoint, String targetPath) throws CheckpointStorageException {
        try {
            String savepointDirName = SAVEPOINT_DIR_PREFIX + checkpoint.getCheckpointId();
            Path savepointDir = validatePath(Paths.get(targetPath, savepointDirName));

            lock.writeLock().lock();
            try {
                ensureDirectoryExists(savepointDir.toString());

                Path checkpointFile = savepointDir.resolve(checkpoint.getCheckpointId() + CHECKPOINT_SUFFIX);
                Path tempFile = Paths.get(checkpointFile.toString() + TEMP_SUFFIX);

                byte[] data = serializeCheckpoint(checkpoint);
                Files.write(tempFile, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                Files.move(tempFile, checkpointFile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);

                SavepointMetadata metadata = SavepointMetadata.fromCompletedCheckpoint(checkpoint);
                Path metadataFile = savepointDir.resolve("savepoint-" + checkpoint.getCheckpointId() + METADATA_SUFFIX);
                Path tempMetadata = Paths.get(metadataFile.toString() + TEMP_SUFFIX);

                byte[] metadataBytes = JsonTool.serialize(metadata, false).getBytes(StandardCharsets.UTF_8);
                Files.write(tempMetadata, metadataBytes, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                Files.move(tempMetadata, metadataFile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);

                LOG.info("Stored savepoint {} to {}", checkpoint.getCheckpointId(), savepointDir);
                return savepointDir.toString();
            } finally {
                lock.writeLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "storeSavepoint failed");
        }
    }

    @Override
    public CompletedCheckpoint loadSavepoint(String savepointPath) throws CheckpointStorageException {
        try {
            Path dir = validatePath(Paths.get(savepointPath));
            if (!Files.isDirectory(dir)) {
                LOG.warn("Savepoint path does not exist or is not a directory: {}", savepointPath);
                return null;
            }

            lock.readLock().lock();
            try {
                try (Stream<Path> files = Files.list(dir)) {
                    Optional<Path> checkpointFile = files
                            .filter(p -> p.toString().endsWith(CHECKPOINT_SUFFIX))
                            .findFirst();

                    if (checkpointFile.isPresent()) {
                        return deserializeCheckpoint(checkpointFile.get());
                    }
                    return null;
                }
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "loadSavepoint failed");
        }
    }

    @Override
    public SavepointMetadata loadSavepointMetadata(String savepointPath) throws CheckpointStorageException {
        try {
            Path dir = validatePath(Paths.get(savepointPath));
            if (!Files.isDirectory(dir)) {
                return null;
            }

            lock.readLock().lock();
            try {
                try (Stream<Path> files = Files.list(dir)) {
                    Optional<Path> metadataFile = files
                            .filter(p -> p.toString().endsWith(METADATA_SUFFIX))
                            .findFirst();

                    if (metadataFile.isPresent()) {
                        byte[] data = Files.readAllBytes(metadataFile.get());
                        String json = new String(data, StandardCharsets.UTF_8);
                        return JsonTool.parseBeanFromText(json, SavepointMetadata.class);
                    }
                    return null;
                }
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "loadSavepointMetadata failed");
        }
    }

    @Override
    public void storeEpochManifest(String jobId, String pipelineId, EpochManifest manifest) throws CheckpointStorageException {
        try {
            Path manifestPath = getEpochManifestPath(jobId, pipelineId, manifest.getEpochId());
            Path tempPath = Paths.get(manifestPath.toString() + TEMP_SUFFIX);

            lock.writeLock().lock();
            try {
                ensureDirectoryExists(manifestPath.getParent().toString());

                byte[] data = serializeEpochManifest(manifest);
                Files.write(tempPath, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                Files.move(tempPath, manifestPath, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);

                LOG.debug("Stored epoch manifest {} for job {}/{}", manifest.getEpochId(), jobId, pipelineId);
            } finally {
                lock.writeLock().unlock();
                deleteIfExists(tempPath);
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "storeEpochManifest failed");
        }
    }

    @Override
    public EpochManifest loadLatestEpochManifest(String jobId, String pipelineId) throws CheckpointStorageException {
        try {
            Path jobDir = getJobDir(jobId, pipelineId);

            lock.readLock().lock();
            try {
                if (!Files.exists(jobDir)) {
                    return null;
                }

                try (Stream<Path> files = Files.list(jobDir)) {
                    Optional<Path> latest = files
                            .filter(p -> p.toString().endsWith(EPOCH_MANIFEST_SUFFIX))
                            .max((a, b) -> Long.compare(
                                    extractIdFromFileName(a.getFileName().toString(), EPOCH_MANIFEST_SUFFIX),
                                    extractIdFromFileName(b.getFileName().toString(), EPOCH_MANIFEST_SUFFIX)));

                    if (latest.isPresent()) {
                        return deserializeEpochManifest(latest.get());
                    }
                    return null;
                }
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e).param(ARG_DETAIL, "loadLatestEpochManifest failed");
        }
    }

    private Path getEpochManifestPath(String jobId, String pipelineId, long epochId) {
        validateId(jobId, "jobId");
        validateId(pipelineId, "pipelineId");
        return validatePath(Paths.get(baseDir, jobId, pipelineId, epochId + EPOCH_MANIFEST_SUFFIX));
    }

    /**
     * Stage 31 restart recovery: load up to {@code count} most-recent retained epoch
     * manifests (newest first) by listing the {@code .epoch} files for the job/pipeline.
     */
    @Override
    public java.util.List<EpochManifest> loadRetainedEpochManifests(String jobId, String pipelineId, int count)
            throws CheckpointStorageException {
        if (count <= 0) {
            return java.util.Collections.emptyList();
        }
        try {
            Path jobDir = getJobDir(jobId, pipelineId);
            lock.readLock().lock();
            try {
                if (!Files.exists(jobDir)) {
                    return java.util.Collections.emptyList();
                }
                java.util.List<Path> files = new java.util.ArrayList<>();
                try (Stream<Path> stream = Files.list(jobDir)) {
                    stream.filter(p -> p.toString().endsWith(EPOCH_MANIFEST_SUFFIX)).forEach(files::add);
                }
                files.sort((a, b) -> Long.compare(
                        extractIdFromFileName(b.getFileName().toString(), EPOCH_MANIFEST_SUFFIX),
                        extractIdFromFileName(a.getFileName().toString(), EPOCH_MANIFEST_SUFFIX)));
                java.util.List<EpochManifest> result = new java.util.ArrayList<>();
                for (int i = 0; i < Math.min(count, files.size()); i++) {
                    result.add(deserializeEpochManifest(files.get(i)));
                }
                return result;
            } finally {
                lock.readLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e)
                    .param(ARG_DETAIL, "loadRetainedEpochManifests failed");
        }
    }

    private byte[] serializeEpochManifest(EpochManifest manifest) {
        return CheckpointSerDe.serializeEpochManifest(manifest);
    }

    /**
     * Manifest retention (roadmap item 33, checkpoint-design §9.2 D1/D2): list the
     * {@code .epoch} files for the job/pipeline, keep the newest {@code maxRetained}
     * by epochId (descending — the same ordering as {@link #loadRetainedEpochManifests}),
     * delete the rest and return their epoch ids. Deletion targets are restricted to
     * the files OBSERVED in this listing; a manifest stored concurrently (by the persist
     * executor) is never a target. I/O failure surfaces as the typed
     * {@link CheckpointStorageException} (deleteCheckpoint parity); the retention caller
     * contains it with WARN + next-round self-heal.
     */
    @Override
    public List<Long> pruneEpochManifests(String jobId, String pipelineId, int maxRetained)
            throws CheckpointStorageException {
        try {
            Path jobDir = getJobDir(jobId, pipelineId);
            List<Long> pruned = new ArrayList<>();

            lock.writeLock().lock();
            try {
                if (!Files.exists(jobDir)) {
                    return pruned;
                }

                List<Path> files = new ArrayList<>();
                try (Stream<Path> stream = Files.list(jobDir)) {
                    stream.filter(p -> p.toString().endsWith(EPOCH_MANIFEST_SUFFIX)).forEach(files::add);
                }
                files.sort((a, b) -> Long.compare(
                        extractIdFromFileName(b.getFileName().toString(), EPOCH_MANIFEST_SUFFIX),
                        extractIdFromFileName(a.getFileName().toString(), EPOCH_MANIFEST_SUFFIX)));

                for (int i = Math.max(0, maxRetained); i < files.size(); i++) {
                    Path stale = files.get(i);
                    long epochId = extractIdFromFileName(stale.getFileName().toString(), EPOCH_MANIFEST_SUFFIX);
                    Files.deleteIfExists(stale);
                    pruned.add(epochId);
                    LOG.debug("Pruned epoch manifest {} for job {}/{}", epochId, jobId, pipelineId);
                }
                return pruned;
            } finally {
                lock.writeLock().unlock();
            }
        } catch (NopException e) {
            throw e;
        } catch (Exception e) {
            throw new CheckpointStorageException(ERR_STREAM_CHECKPOINT_ERROR, e)
                    .param(ARG_DETAIL, "pruneEpochManifests failed");
        }
    }

    private Map<String, Object> serializeTaskStateSnapshot(TaskStateSnapshot snapshot) {
        return CheckpointSerDe.serializeTaskStateSnapshot(snapshot);
    }

    private EpochManifest deserializeEpochManifest(Path path) throws Exception {
        byte[] data = Files.readAllBytes(path);
        return CheckpointSerDe.deserializeEpochManifest(data);
    }
}
