/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.alert;

import io.nop.core.lang.json.JsonTool;
import io.nop.stream.core.exceptions.StreamException;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_ARG;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Item 16 (P-REQ-12): webhook alert channel — HTTP POST of the alert as JSON
 * (JDK HttpClient, zero new framework dependency). URL / timeout / retry
 * count are configurable.
 *
 * <p>Delivery is asynchronous on a bounded single-thread executor: the alert
 * path is invoked synchronously from the job event bus (recovery / failure
 * events), so a slow or unreachable webhook endpoint must never stall job
 * control flow. When the bounded queue is full, alerts are dropped with a
 * WARN (alerting is best-effort by contract; the logging channel remains the
 * always-on record). Delivery results (including final failure after all
 * retries) are logged with the channel identity — never silently swallowed.
 */
public class WebhookAlertChannel implements IAlertChannel {

    private static final Logger LOG = LoggerFactory.getLogger(WebhookAlertChannel.class);

    public static final long DEFAULT_RETRY_BACKOFF_MS = 200L;

    /** Bounded async queue capacity (overflow = drop with WARN). */
    private static final int QUEUE_CAPACITY = 256;

    public static final long DEFAULT_TIMEOUT_MS = 5_000L;
    public static final int DEFAULT_RETRIES = 2;

    private final URI url;
    private final long timeoutMs;
    private final int retries;
    private final long retryBackoffMs;
    private final HttpClient client;
    private final BlockingQueue<AlertEvent> pending;

    /**
     * ST-6 裁定（2026-09-13，审计 plan 357）：保留引擎自建调度线程——流引擎是自包含运行时
     * （可独立于 nop-job 部署），ops 周期任务（治理清扫/指标上报）随引擎生命周期；宿主集成
     * nop-job 时可外置触发（successor 候选）。
     */
    private final java.util.concurrent.ExecutorService deliveryExecutor;
    private final List<AlertEvent> delivered = new CopyOnWriteArrayList<>();

    public WebhookAlertChannel(String url) {
        this(url, DEFAULT_TIMEOUT_MS, DEFAULT_RETRIES);
    }

    public WebhookAlertChannel(String url, long timeoutMs, int retries) {
        this(url, timeoutMs, retries, DEFAULT_RETRY_BACKOFF_MS);
    }

    /**
     * @param retryBackoffMs 重试间隔（ms）。不引 nop-retry（裁定）：webhook 投递是 best-effort
     *                        ops 路径，nop-retry 是持久化分布式重试，语义不匹配；可配化覆盖
     *                        owner doc 原固定 200ms 决策，默认值保持 200。
     */
    public WebhookAlertChannel(String url, long timeoutMs, int retries, long retryBackoffMs) {
        if (url == null || url.isBlank()) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_DETAIL, "webhook alert channel requires a non-blank url");
        }
        try {
            this.url = URI.create(url);
        } catch (Exception e) {
            throw new StreamException(ERR_STREAM_INVALID_ARG, e).param(ARG_DETAIL, "webhook alert channel url is not a valid URI: " + url);
        }
        if (!"http".equalsIgnoreCase(this.url.getScheme()) && !"https".equalsIgnoreCase(this.url.getScheme())) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_DETAIL, "webhook alert channel url must be http(s): " + url);
        }
        if (timeoutMs <= 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_DETAIL, "webhook timeout must be positive: " + timeoutMs);
        }
        if (retries < 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_DETAIL, "webhook retries must be >= 0: " + retries);
        }
        if (retryBackoffMs < 0) {
            throw new StreamException(ERR_STREAM_INVALID_ARG).param(ARG_DETAIL, "webhook retryBackoffMs must be >= 0: " + retryBackoffMs);
        }
        this.timeoutMs = timeoutMs;
        this.retries = retries;
        this.retryBackoffMs = retryBackoffMs;
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofMillis(timeoutMs))
                .build();
        this.pending = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
        this.deliveryExecutor = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "stream-alert-webhook");
            t.setDaemon(true);
            return t;
        });
        this.deliveryExecutor.execute(this::drainLoop);
    }

    @Override
    public String getName() {
        return "webhook";
    }

    @Override
    public void send(AlertEvent event) {
        if (!pending.offer(event)) {
            LOG.warn("webhook alert queue full (capacity {}) — dropping alert {} for job {} "
                    + "(best-effort contract; the logging channel retains the record)",
                    QUEUE_CAPACITY, event.getEventType(), event.getJobId());
        }
    }

    /** Delivered alerts (test observability). */
    public List<AlertEvent> getDelivered() {
        return delivered;
    }

    public void close() {
        deliveryExecutor.shutdownNow();
    }

    private void drainLoop() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                AlertEvent event = pending.poll(1, TimeUnit.SECONDS);
                if (event == null) {
                    continue;
                }
                deliverWithRetries(event);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void deliverWithRetries(AlertEvent event) {
        String body = JsonTool.stringify(new WebhookAlertPayload(event));

        for (int attempt = 0; attempt <= retries; attempt++) {
            if (attempt > 0) {
                try {
                    TimeUnit.MILLISECONDS.sleep(retryBackoffMs);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
            try {
                HttpRequest request = HttpRequest.newBuilder(url)
                        .timeout(Duration.ofMillis(timeoutMs))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(body))
                        .build();
                HttpResponse<String> response =
                        client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    delivered.add(event);
                    return;
                }
                LOG.warn("webhook alert delivery attempt {}/{} returned {} for job {} (type={})",
                        attempt + 1, retries + 1, response.statusCode(),
                        event.getJobId(), event.getEventType());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                LOG.warn("webhook alert delivery attempt {}/{} failed for job {} (type={}): {}",
                        attempt + 1, retries + 1, event.getJobId(), event.getEventType(), e.toString());
            }
        }
        LOG.error("webhook alert delivery gave up after {} attempts for job {} (type={}, message={})",
                retries + 1, event.getJobId(), event.getEventType(), event.getMessage());
    }

    private static String json(String value) {
        if (value == null) {
            return "null";
        }
        // minimal JSON string escaping
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\"";
    }
}
