/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.checkpoint.metrics;

import io.nop.api.core.time.CoreMetrics;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Checkpoint monitoring metrics.
 */
public class CheckpointMetrics {

    private final AtomicLong numCompletedCheckpoints = new AtomicLong();
    private final AtomicLong numFailedCheckpoints = new AtomicLong();
    private final AtomicLong numAbortedCheckpoints = new AtomicLong();
    private final AtomicLong latestCheckpointSize = new AtomicLong();
    private final AtomicLong latestCheckpointDuration = new AtomicLong();
    private final AtomicLong totalStateSize = new AtomicLong();
    private final AtomicLong lastCheckpointTimestamp = new AtomicLong();
    private volatile String failureCause;

    public void incrementCompletedCheckpoints() {
        numCompletedCheckpoints.incrementAndGet();
    }

    public void incrementFailedCheckpoints() {
        numFailedCheckpoints.incrementAndGet();
    }

    public void incrementAbortedCheckpoints() {
        numAbortedCheckpoints.incrementAndGet();
    }

    public void updateLatestCheckpoint(long size, long duration) {
        latestCheckpointSize.set(size);
        latestCheckpointDuration.set(duration);
        lastCheckpointTimestamp.set(CoreMetrics.currentTimeMillis());
    }

    public void addToTotalStateSize(long size) {
        totalStateSize.addAndGet(size);
    }

    public long getNumCompletedCheckpoints() {
        return numCompletedCheckpoints.get();
    }

    public long getNumFailedCheckpoints() {
        return numFailedCheckpoints.get();
    }

    public long getNumAbortedCheckpoints() {
        return numAbortedCheckpoints.get();
    }

    public long getLatestCheckpointSize() {
        return latestCheckpointSize.get();
    }

    public long getLatestCheckpointDuration() {
        return latestCheckpointDuration.get();
    }

    public long getTotalStateSize() {
        return totalStateSize.get();
    }

    public long getLastCheckpointTimestamp() {
        return lastCheckpointTimestamp.get();
    }

    public void recordDuration(long durationMs) {
        latestCheckpointDuration.set(durationMs);
    }

    public void recordStateSize(long bytes) {
        latestCheckpointSize.set(bytes);
        totalStateSize.addAndGet(bytes);
    }

    public void recordAborted(String reason) {
        numAbortedCheckpoints.incrementAndGet();
        this.failureCause = reason;
    }

    public void recordFailure(String cause) {
        incrementFailedCheckpoints();
        this.failureCause = cause;
    }

    public String getFailureCause() {
        return failureCause;
    }

    public void reset() {
        numCompletedCheckpoints.set(0);
        numFailedCheckpoints.set(0);
        numAbortedCheckpoints.set(0);
        latestCheckpointSize.set(0);
        latestCheckpointDuration.set(0);
        totalStateSize.set(0);
        lastCheckpointTimestamp.set(0);
        failureCause = null;
    }

    public synchronized CheckpointMetricsSnapshot snapshot() {
        return new CheckpointMetricsSnapshot(
                numCompletedCheckpoints.get(),
                numFailedCheckpoints.get(),
                numAbortedCheckpoints.get(),
                latestCheckpointSize.get(),
                latestCheckpointDuration.get(),
                totalStateSize.get(),
                lastCheckpointTimestamp.get(),
                failureCause
        );
    }
}
