/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.nop.stream.runtime.operators.windowing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

import io.nop.api.core.annotations.core.Internal;
import static io.nop.api.core.util.Guard.checkArgument;
import static io.nop.api.core.util.Guard.notNull;

import io.nop.commons.tuple.Tuple2;

import io.nop.stream.core.checkpoint.OperatorSnapshotResult;
import io.nop.stream.core.checkpoint.StateSnapshotContext;
import io.nop.stream.core.exceptions.StreamException;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ACTUAL_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_ARG_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DESCRIPTOR_NAME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_EXPECTED_TYPE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATION;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_PROCESSING_TIME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_WATERMARK;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_WINDOW;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_NULL_ARG;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_STATE_ERROR;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_TYPE_MISMATCH;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_WINDOW_MERGE_INVALID_PROCESSING_TIME;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_WINDOW_MERGE_INVALID_WATERMARK;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_WINDOW_NON_ACCUMULATOR_MERGE_CONFLICT;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_WINDOW_TRIGGER_STATE_ACCUMULATOR_FAILED;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.common.accumulators.SimpleAccumulator;
import io.nop.stream.core.common.functions.AggregateFunction;
import io.nop.stream.core.common.functions.KeySelector;
import io.nop.stream.core.common.state.AggregatingState;
import io.nop.stream.core.common.state.AggregatingStateDescriptor;
import io.nop.stream.core.common.state.ListState;
import io.nop.stream.core.common.state.ReducingState;
import io.nop.stream.core.common.state.ValueState;
import io.nop.stream.core.common.state.ValueStateDescriptor;
import io.nop.stream.core.common.state.backend.IInternalStateBackend;
import io.nop.stream.core.common.state.backend.IKeyedStateBackend;
import io.nop.stream.core.common.state.backend.memory.MemoryStateBackend;
import io.nop.stream.core.common.state.InternalAppendingState;
import io.nop.stream.core.common.state.InternalListState;
import io.nop.stream.core.common.state.KeyedStateStore;
import io.nop.stream.core.common.state.ListStateDescriptor;
import io.nop.stream.core.common.state.MapState;
import io.nop.stream.core.common.state.MapStateDescriptor;
import io.nop.stream.core.common.state.ReducingStateDescriptor;
import io.nop.stream.core.common.state.StateDescriptor;
import io.nop.stream.core.common.state.VoidNamespace;
import io.nop.stream.core.common.typeutils.TypeSerializer;
import io.nop.stream.core.operators.AbstractUdfStreamOperator;
import io.nop.stream.core.operators.HeapInternalTimerService;
import io.nop.stream.core.operators.InternalTimer;
import io.nop.stream.core.operators.InternalTimerService;
import io.nop.stream.core.operators.OneInputStreamOperator;
import io.nop.stream.core.operators.TimestampedCollector;
import io.nop.stream.core.operators.Triggerable;
import io.nop.stream.core.streamrecord.StreamRecord;
import io.nop.stream.core.streamrecord.watermark.Watermark;
import io.nop.stream.core.util.OutputTag;
import io.nop.stream.core.windowing.AccumulationMode;
import io.nop.stream.core.windowing.PaneInfo;
import io.nop.stream.core.windowing.assigners.MergingWindowAssigner;
import io.nop.stream.core.windowing.assigners.WindowAssigner;
import io.nop.stream.core.windowing.triggers.Trigger;
import io.nop.stream.core.windowing.triggers.TriggerResult;
import io.nop.stream.core.windowing.evictors.Evictor;
import io.nop.stream.core.windowing.utils.TimestampedValue;
import io.nop.stream.core.windowing.windows.TimeWindow;
import io.nop.stream.core.windowing.windows.Window;
import io.nop.stream.runtime.operators.windowing.functions.InternalWindowFunction;

/**
 * An operator that implements the logic for windowing based on a {@link WindowAssigner} and {@link
 * Trigger}.
 *
 * <p>When an element arrives it gets assigned a key using a {@link KeySelector} and it gets
 * assigned to zero or more windows using a {@link WindowAssigner}. Based on this, the element is
 * put into panes. A pane is the bucket of elements that have the same key and same {@code Window}.
 * An element can be in multiple panes if it was assigned to multiple windows by the {@code
 * WindowAssigner}.
 *
 * <p>Each pane gets its own instance of the provided {@code Trigger}. This trigger determines when
 * the contents of the pane should be processed to emit results. When a trigger fires, the given
 * {@link InternalWindowFunction} is invoked to produce the results that are emitted for the pane to
 * which the {@code Trigger} belongs.
 *
 * @param <K>   The type of key returned by the {@code KeySelector}.
 * @param <IN>  The type of the incoming elements.
 * @param <OUT> The type of elements emitted by the {@code InternalWindowFunction}.
 * @param <W>   The type of {@code Window} that the {@code WindowAssigner} assigns.
 */
@Internal
public class WindowOperator<K, IN, ACC, OUT, W extends Window>
        extends AbstractUdfStreamOperator<OUT, InternalWindowFunction<ACC, OUT, K, W>>
        implements OneInputStreamOperator<IN, OUT>, Triggerable<K, W> {

    private static final long serialVersionUID = 1L;
    private static final String WINDOW_VALUE_KEY = "__window_value__";
    private static final String ELEMENT_TIMESTAMPS_KEY = "__element_timestamps__";
    private static final String STATE_KEY_SEPARATOR = "\u0000";
    private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(WindowOperator.class);

    // ------------------------------------------------------------------------
    // Configuration values and user functions
    // ------------------------------------------------------------------------

    protected final WindowAssigner<? super IN, W> windowAssigner;

    protected final KeySelector<IN, K> keySelector;

    protected final Trigger<? super IN, ? super W> trigger;

    protected transient InternalAppendingState<K, W, IN, ACC, ACC> windowState;

    protected transient InternalAppendingState<K, W, IN, ACC, ACC> newAppendingWindowState;

    protected transient InternalListState<K, W, IN> newListWindowState;

    /**
     * For serializing the key in checkpoints.
     */
    protected final TypeSerializer<K> keySerializer;

    /**
     * The class of the key type, used for state backend creation.
     */
    protected final Class<K> keyClass;

    /**
     * For serializing the window in checkpoints.
     */
    protected final TypeSerializer<W> windowSerializer;

    /**
     * The allowed lateness for elements. This is used for:
     *
     * <ul>
     *   <li>Deciding if an element should be dropped from a window due to lateness.
     *   <li>Clearing the state of a window if the system time passes the {@code window.maxTimestamp
     *       + allowedLateness} landmark.
     * </ul>
     */
    protected final long allowedLateness;

    /**
     * {@link OutputTag} to use for late arriving events. Elements for which {@code
     * window.maxTimestamp + allowedLateness} is smaller than the current watermark will be emitted
     * to this.
     */
    protected final OutputTag<IN> lateDataOutputTag;

    protected final Class<?> accClass;

    protected final StateDescriptor<?> windowStateDescriptor;

    protected final BiFunction<ACC, ACC, ACC> mergeFunction;

    protected final Evictor<IN, W> evictor;

    protected final AccumulationMode accumulationMode;

    private static final String LATE_ELEMENTS_DROPPED_METRIC_NAME = "numLateRecordsDropped";

    /**
     * Per-(key,window) pane tracking: pane index + onTimeEmitted flag. Used by
     * {@link #computePaneInfo} to classify firings as EARLY/ON_TIME/LATE and assign
     * pane indices. Participates in checkpoint/restore (G48, TimeWindow-scoped only).
     */
    private transient Map<String, PaneTrackingInfo> paneTracking;

    // ------------------------------------------------------------------------
    // State that is not checkpointed
    // ------------------------------------------------------------------------

    /** The state in which the window contents is stored. Each window is a namespace */

    /** The state that holds the merging window metadata (the sets that describe what is merged). */
    private transient InternalListState<K, VoidNamespace, Tuple2<W, W>> mergingSetsState;

    /**
     * This is given to the {@code InternalWindowFunction} for emitting elements with a given
     * timestamp.
     */
    protected transient TimestampedCollector<OUT> timestampedCollector;

    protected transient Context triggerContext = new Context(null, null);

    protected transient WindowContext processContext;

    protected transient WindowAssigner.WindowAssignerContext windowAssignerContext;

    // ------------------------------------------------------------------------
    // State that needs to be checkpointed
    // ------------------------------------------------------------------------

    protected transient HeapInternalTimerService<K, W> internalTimerService;

    /**
     * Timer snapshot captured by {@link #restoreState} when the timer service is not yet
     * created (restoreState runs before open). Applied deferredly in {@link #open()} after
     * {@code internalTimerService} is constructed. See {@code TestCheckpointRecovery.java:478}
     * for the lifecycle constraint that motivates this pattern.
     */
    private transient HeapInternalTimerService.TimerSnapshot<K, W> restoredTimerSnapshot;

    /**
     * Pane-tracking snapshot captured by {@link #restoreState} (runs before {@link #open()}).
     * Applied deferredly in {@link #open()} after {@code paneTracking} is initialized.
     *
     * <p>Only {@code TimeWindow}-scoped panes participate (see {@link #isTimeWindowPaneKey}).
     * Non-TimeWindow panes are skipped because {@code windowNamespace} is irreversible for them,
     * which could cause restore mismatch.
     */
    private transient PaneTrackingSnapshot restoredPaneTrackingSnapshot;

    /**
     * Namespace-backed window contents state.
     *
     * <p>Uses `currentKey + namespace(window)` to scope each pane.
     */
    private transient MapState<String, ACC> windowContentsState;

    private transient MapState<String, List<Long>> elementTimestampsState;

    /**
     * Per-trigger SimpleAccumulator state, keyed by composite key (key + window + descriptor name).
     * Used by triggers like CountTrigger that need to maintain state via getSimpleAccumulator().
     */
    protected Map<String, SimpleAccumulator<?>> triggerAccumulators;

    public WindowOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            TypeSerializer<W> windowSerializer,
            KeySelector<IN, K> keySelector,
            TypeSerializer<K> keySerializer,
            Class<K> keyClass,
            InternalWindowFunction<ACC, OUT, K, W> windowFunction,
            Trigger<? super IN, ? super W> trigger,
            long allowedLateness,
            OutputTag<IN> lateDataOutputTag) {
        this(windowAssigner, windowSerializer, keySelector, keySerializer, keyClass,
                windowFunction, trigger, allowedLateness, lateDataOutputTag,
                (Class<ACC>) (Class<?>) Object.class, null, null, null, null);
    }

    public WindowOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            TypeSerializer<W> windowSerializer,
            KeySelector<IN, K> keySelector,
            TypeSerializer<K> keySerializer,
            Class<K> keyClass,
            InternalWindowFunction<ACC, OUT, K, W> windowFunction,
            Trigger<? super IN, ? super W> trigger,
            long allowedLateness,
            OutputTag<IN> lateDataOutputTag,
            Class<ACC> accClass) {
        this(windowAssigner, windowSerializer, keySelector, keySerializer, keyClass,
                windowFunction, trigger, allowedLateness, lateDataOutputTag,
                accClass, null, null, null, null);
    }

    public WindowOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            TypeSerializer<W> windowSerializer,
            KeySelector<IN, K> keySelector,
            TypeSerializer<K> keySerializer,
            Class<K> keyClass,
            InternalWindowFunction<ACC, OUT, K, W> windowFunction,
            Trigger<? super IN, ? super W> trigger,
            long allowedLateness,
            OutputTag<IN> lateDataOutputTag,
            StateDescriptor<?> windowStateDescriptor,
            BiFunction<ACC, ACC, ACC> mergeFunction) {
        this(windowAssigner, windowSerializer, keySelector, keySerializer, keyClass,
                windowFunction, trigger, allowedLateness, lateDataOutputTag,
                (Class<ACC>) (Class<?>) Object.class, windowStateDescriptor, mergeFunction, null, null);
    }

    WindowOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            TypeSerializer<W> windowSerializer,
            KeySelector<IN, K> keySelector,
            TypeSerializer<K> keySerializer,
            Class<K> keyClass,
            InternalWindowFunction<ACC, OUT, K, W> windowFunction,
            Trigger<? super IN, ? super W> trigger,
            long allowedLateness,
            OutputTag<IN> lateDataOutputTag,
            Class<ACC> accClass,
            StateDescriptor<?> windowStateDescriptor,
            BiFunction<ACC, ACC, ACC> mergeFunction,
            Evictor<IN, W> evictor,
            AccumulationMode accumulationMode) {

        super(windowFunction);

        checkArgument(allowedLateness >= 0);

        this.windowAssigner = notNull(windowAssigner, "windowAssigner");
        this.windowSerializer = notNull(windowSerializer, "windowSerializer");
        this.keySelector = notNull(keySelector, "keySelector");
        this.keySerializer = notNull(keySerializer, "keySerializer");
        this.keyClass = notNull(keyClass, "keyClass");
        this.trigger = notNull(trigger, "trigger");
        this.allowedLateness = allowedLateness;
        this.lateDataOutputTag = lateDataOutputTag;
        this.accClass = notNull(accClass, "accClass");
        this.windowStateDescriptor = windowStateDescriptor;
        this.mergeFunction = mergeFunction;
        this.evictor = evictor;
        this.accumulationMode = accumulationMode != null ? accumulationMode : AccumulationMode.ACCUMULATING;
    }

    /**
     * Package-private copy constructor used by {@link #copyForSubtask()}.
     *
     * <p>Copies the immutable configuration (window assigner, serializers,
     * trigger, accumulator class, descriptors, merge function, evictor,
     * accumulation mode, user function) by reference — they are shared across
     * subtasks. All transient per-subtask state (timer service, collectors,
     * contexts, in-flight window contents) is left null and re-initialized by
     * {@link #open()}.
     *
     * @param other the source operator to copy configuration from
     */
    WindowOperator(WindowOperator<K, IN, ACC, OUT, W> other) {
        super(other.userFunction);
        this.windowAssigner = other.windowAssigner;
        this.windowSerializer = other.windowSerializer;
        this.keySelector = other.keySelector;
        this.keySerializer = other.keySerializer;
        this.keyClass = other.keyClass;
        this.trigger = other.trigger;
        this.allowedLateness = other.allowedLateness;
        this.lateDataOutputTag = other.lateDataOutputTag;
        this.accClass = other.accClass;
        this.windowStateDescriptor = other.windowStateDescriptor;
        this.mergeFunction = other.mergeFunction;
        this.evictor = other.evictor;
        this.accumulationMode = other.accumulationMode;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Window operator: immutable configuration is shared across subtasks,
     * per-subtask mutable state (timer service, collectors, contexts, in-flight
     * window contents, pane tracking) is left null and re-initialized by
     * {@link #open()}.
     */
    @Override
    public WindowOperator<K, IN, ACC, OUT, W> copyForSubtask() {
        return new WindowOperator<>(this);
    }

    @Override
    public void open() throws Exception {
        super.open();

        if (accumulationMode == AccumulationMode.ACCUMULATING_AND_RETRACTING) {
            throw new StreamException(ERR_STREAM_UNSUPPORTED)
                    .param(ARG_OPERATION, "WindowOperator.emitWindowContents")
                    .param(ARG_DETAIL, "AccumulationMode.ACCUMULATING_AND_RETRACTING is spec-only "
                            + "and not implemented; retract logic has no downstream consumer. "
                            + "Use DISCARDING or ACCUMULATING instead.");
        }

        timestampedCollector = new TimestampedCollector<>(output);
        if (this.triggerAccumulators == null) {
            this.triggerAccumulators = new HashMap<>();
        }
        if (this.paneTracking == null) {
            this.paneTracking = new HashMap<>();
        }

        // Apply any pane-tracking snapshot captured by restoreState() (called before open()).
        // Restores pane index / onTimeEmitted so that post-recovery firings are not mistaken
        // for ON_TIME / isFirst. Only TimeWindow-scoped panes are snapshotted.
        if (restoredPaneTrackingSnapshot != null) {
            for (PaneTrackingSnapshot.PaneTrackingEntry entry : restoredPaneTrackingSnapshot.getEntries()) {
                PaneTrackingInfo info = new PaneTrackingInfo();
                info.paneIndex = entry.getPaneIndex();
                info.onTimeEmitted = entry.isOnTimeEmitted();
                this.paneTracking.put(entry.getPaneKey(), info);
            }
            restoredPaneTrackingSnapshot = null;
        }

        if (this.stateBackend == null) {
            this.stateBackend = new MemoryStateBackend();
        }
        this.keyedStateBackend = this.stateBackend.createKeyedStateBackend(keyClass);

        // P1-01 (Decision: 方案 1 = live function reuse): register the live
        // descriptor's aggregate function BEFORE the deferred keyed-state
        // restore (applyPendingRestoreState) runs, so the serde restore path
        // reuses the live function instance instead of failing to reflectively
        // recreate capturing anonymous classes / lambdas. Also covers the
        // region-restart path (rebuildTask restores before open; the provider
        // is re-registered here on the fresh operator).
        registerRestoreAggregateFunctionIfPresent();

        applyPendingRestoreState();

        if (windowStateDescriptor != null && keyedStateBackend instanceof IInternalStateBackend) {
            @SuppressWarnings("unchecked")
            IInternalStateBackend<K> internalBackend = (IInternalStateBackend<K>) keyedStateBackend;

            if (windowStateDescriptor instanceof AggregatingStateDescriptor) {
                @SuppressWarnings("unchecked")
                AggregatingStateDescriptor<IN, ACC, ?> aggDesc =
                        (AggregatingStateDescriptor<IN, ACC, ?>) windowStateDescriptor;
                newAppendingWindowState =
                        (InternalAppendingState<K, W, IN, ACC, ACC>)
                                (InternalAppendingState<?, ?, ?, ?, ?>)
                                        internalBackend.getInternalAppendingState(aggDesc);
            } else if (windowStateDescriptor instanceof ListStateDescriptor) {
                @SuppressWarnings("unchecked")
                ListStateDescriptor<IN> listDesc = (ListStateDescriptor<IN>) windowStateDescriptor;
                newListWindowState = internalBackend.getInternalListState(listDesc);
            }
        } else {
            @SuppressWarnings("unchecked")
            Class<ACC> accType = (Class<ACC>) accClass;
            MapStateDescriptor<String, ACC> windowContentsDescriptor =
                    new MapStateDescriptor<>("window-contents", String.class, accType);
            windowContentsState = this.keyedStateBackend.getMapState(windowContentsDescriptor);
        }

        // AR-3 (plan 1326-2 Phase 1, D0 option b): the element-timestamps side store is
        // created on BOTH state layouts when an evictor is present — internal-descriptor
        // path (Memory/RocksDB via builder) and the fallback MapState path. Previously it
        // existed only on the fallback path, so every TimestampedValue seen by an evictor
        // on the descriptor path was stamped with the current watermark (fake timestamp →
        // TimeEvictor never evicts). Created only when evictor != null so non-evictor jobs
        // keep a byte-identical checkpoint payload (no extra registered state).
        if (evictor != null) {
            @SuppressWarnings("unchecked")
            MapStateDescriptor<String, List<Long>> timestampsDescriptor =
                    new MapStateDescriptor<>("element-timestamps", String.class,
                            (Class<List<Long>>) (Class<?>) List.class);
            elementTimestampsState = this.keyedStateBackend.getMapState(timestampsDescriptor);
        }

        internalTimerService = new HeapInternalTimerService<>(this,
                () -> getKeyedStateBackend() != null ? (K) getKeyedStateBackend().getCurrentKey() : null);
        // AR-22 (P0): declare the operator's key class so restored timer keys are
        // re-materialized to it — the JSON checkpoint persist path (storageType=local)
        // round-trips Long keys < 2^31 as Integer and @DataBean POJO keys as
        // LinkedHashMap, and the class-sensitive TypedNamespaceAndKey lookups in
        // onEventTime/onProcessingTime would silently miss (window output lost).
        internalTimerService.setKeyType(keyClass);

        // Register with the task's TimerServiceManager (mirroring ProcessOperator.open()).
        // Null-guarded: direct unit-test usage without a task has no manager — the timer
        // service still works standalone (fired via advanceWatermark/onProcessingTime).
        if (timeServiceManager != null) {
            timeServiceManager.registerTimerService(internalTimerService);
        }

        // Explicit warning instead of silent zero output (plan `2026-08-13-0132-1` Phase 2):
        // a processing-time window without a wired ProcessingTimeService/TimerServiceManager
        // has no driver to fire its timers — without this WARN the job would silently never
        // emit. The production task wiring always injects both before open(); this fires only
        // when the operator is opened outside a task (direct unit-test usage).
        if (!windowAssigner.isEventTime() && getProcessingTimeService() == null) {
            LOG.warn("Processing-time window operator opened without a ProcessingTimeService; "
                    + "its processing-time timers will never fire (no processing-time driver). "
                    + "The production task wiring injects the service before open(); "
                    + "direct open() outside a task has no driver.");
        }

        // Apply any timer snapshot captured by restoreState() (called before open()).
        // This deferred-application pattern is required because restoreState() runs
        // before open() creates the timer service (see TestCheckpointRecovery.java:478).
        if (restoredTimerSnapshot != null) {
            internalTimerService.restoreTimers(restoredTimerSnapshot);
            restoredTimerSnapshot = null;
        }

        triggerContext = new Context(null, null);
        processContext = new WindowContext(null);

        windowAssignerContext =
                new WindowAssigner.WindowAssignerContext() {
                    @Override
                    public long getCurrentProcessingTime() {
                        return internalTimerService.currentProcessingTime();
                    }
                };

        if (windowAssigner instanceof MergingWindowAssigner) {

            @SuppressWarnings("unchecked") final Class<Tuple2<W, W>> typedTuple = (Class<Tuple2<W, W>>) (Class<?>) Tuple2.class;

            final ListStateDescriptor<Tuple2<W, W>> mergingSetsStateDescriptor =
                    new ListStateDescriptor<>("merging-window-set", typedTuple);

            if (keyedStateBackend instanceof IInternalStateBackend) {
                @SuppressWarnings("unchecked")
                IInternalStateBackend<K> internalBackend = (IInternalStateBackend<K>) keyedStateBackend;
                mergingSetsState = internalBackend.getInternalListState(mergingSetsStateDescriptor);
                mergingSetsState.setCurrentNamespace(VoidNamespace.INSTANCE);
            }
        }
    }

    @Override
    public void processWatermark(Watermark mark) throws Exception {
        internalTimerService.advanceWatermark(mark.getTimestamp());
        super.processWatermark(mark);
    }

    @Override
    public void close() throws Exception {
        super.close();
        timestampedCollector = null;
        triggerContext = null;
        processContext = null;
        windowAssignerContext = null;
        windowContentsState = null;
        elementTimestampsState = null;
        triggerAccumulators = null;
        paneTracking = null;
    }

    @Override
    public OperatorSnapshotResult snapshotState(StateSnapshotContext context) throws Exception {
        OperatorSnapshotResult result = super.snapshotState(context);
        if (triggerAccumulators != null) {
            Map<String, SimpleAccumulator<?>> snapshot = new HashMap<>();
            for (Map.Entry<String, SimpleAccumulator<?>> entry : triggerAccumulators.entrySet()) {
                @SuppressWarnings("unchecked")
                SimpleAccumulator<?> cloned = (SimpleAccumulator<?>) entry.getValue().clone();
                snapshot.put(entry.getKey(), cloned);
            }
            result.putOperatorState("trigger-accumulators", snapshot);
        }
        // G2: include in-flight timers in the checkpoint so that event-time and
        // processing-time timers registered before the checkpoint fire correctly
        // after restore. checkpoint-design.md §2.1 lists "timer state" as part of
        // the epoch binding. Only already-registered (not-yet-fired) timers are
        // snapshotted — fired timers are naturally excluded because they are removed
        // from the internal data structures when they fire (no double-fire risk).
        if (internalTimerService != null) {
            result.putOperatorState("internal-timers", internalTimerService.snapshotTimers());
        }
        // G48: persist pane-tracking (pane index + onTimeEmitted) so that post-recovery
        // window firings are not mistaken for ON_TIME / isFirst. Only TimeWindow-scoped
        // panes participate (see isTimeWindowPaneKey); non-TimeWindow panes are skipped
        // because their windowNamespace is irreversible.
        if (paneTracking != null && !paneTracking.isEmpty()) {
            result.putOperatorState("pane-tracking", snapshotPaneTracking());
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void restoreState(io.nop.stream.core.checkpoint.OperatorSnapshotResult snapshotResult) throws Exception {
        registerRestoreAggregateFunctionIfPresent();
        super.restoreState(snapshotResult);
        if (snapshotResult != null) {
            Object restored = snapshotResult.getOperatorState("trigger-accumulators");
            if (restored instanceof Map) {
                Map<?, ?> restoredMap = (Map<?, ?>) restored;
                for (Map.Entry<?, ?> entry : restoredMap.entrySet()) {
                    if (!(entry.getValue() instanceof SimpleAccumulator)) {
                        throw new StreamException(ERR_STREAM_TYPE_MISMATCH)
                                .param(ARG_EXPECTED_TYPE, "SimpleAccumulator")
                                .param(ARG_ACTUAL_TYPE, entry.getValue().getClass().getName());
                    }
                }
                this.triggerAccumulators = (Map<String, SimpleAccumulator<?>>) restored;
            }
            // G2: capture timer snapshot for deferred application in open(). At this
            // point internalTimerService is still null (restoreState runs before
            // open()), so we cannot apply the snapshot immediately — we store it
            // and apply it in open() after the timer service is constructed.
            Object timerSnapshot = snapshotResult.getOperatorState("internal-timers");
            if (timerSnapshot instanceof HeapInternalTimerService.TimerSnapshot) {
                this.restoredTimerSnapshot =
                        (HeapInternalTimerService.TimerSnapshot<K, W>) timerSnapshot;
            }
            // G48: capture pane-tracking snapshot for deferred application in open().
            Object paneSnapshot = snapshotResult.getOperatorState("pane-tracking");
            if (paneSnapshot instanceof PaneTrackingSnapshot) {
                this.restoredPaneTrackingSnapshot = (PaneTrackingSnapshot) paneSnapshot;
            }
        }
    }

    /**
     * P1-01: registers the live {@code windowStateDescriptor}'s aggregate
     * function into the keyed state backend's restore-function provider (when
     * both exist), so the serde restore path prefers the live instance over
     * class-name reflection. No-op when the window contents state is not an
     * aggregating descriptor (evictor path uses a list descriptor) or the
     * backend is not yet created.
     */
    @SuppressWarnings("unchecked")
    private void registerRestoreAggregateFunctionIfPresent() {
        if (keyedStateBackend == null || !(windowStateDescriptor instanceof AggregatingStateDescriptor)) {
            return;
        }
        AggregatingStateDescriptor<IN, ACC, ?> aggDesc =
                (AggregatingStateDescriptor<IN, ACC, ?>) windowStateDescriptor;
        keyedStateBackend.registerRestoreAggregateFunction(
                aggDesc.getName(), aggDesc.getAggregateFunction());
    }

    @Override
    public void processElement(StreamRecord<IN> element) throws Exception {
        final Collection<W> elementWindows =
                windowAssigner.assignWindows(
                        element.getValue(), element.getTimestamp(), windowAssignerContext);

        boolean isSkippedElement = true;

        final K key = keySelector.getKey(element.getValue());
        if (keyedStateBackend != null) {
            this.<K>getKeyedStateBackend().setCurrentKey(key);
        }

        final long elementTimestamp = element.getTimestamp();

        if (windowAssigner instanceof MergingWindowAssigner) {
            isSkippedElement = processElementForMergingWindow(element, elementWindows, key, elementTimestamp);
        } else {
            isSkippedElement = processElementForRegularWindow(element, elementWindows, key, elementTimestamp);
        }

        if (isSkippedElement && isElementLate(element)) {
            if (lateDataOutputTag != null) {
                sideOutput(element);
            }
        }
    }

    private boolean processElementForMergingWindow(
            StreamRecord<IN> element, Collection<W> elementWindows, K key, long elementTimestamp) throws Exception {
        MergingWindowSet<W> mergingWindows = getMergingWindowSet();
        boolean isSkippedElement = true;

        for (W window : elementWindows) {
            W actualWindow =
                    mergingWindows.addWindow(
                            window,
                            new MergingWindowSet.MergeFunction<W>() {
                                @Override
                                public void merge(
                                        W mergeResult,
                                        Collection<W> mergedWindows,
                                        W stateWindowResult,
                                        Collection<W> mergedStateWindows)
                                        throws Exception {

                                    if ((windowAssigner.isEventTime()
                                            && mergeResult.maxTimestamp() + allowedLateness
                                            <= internalTimerService
                                            .currentWatermark())) {
                                        throw new StreamException(ERR_STREAM_WINDOW_MERGE_INVALID_WATERMARK)
                                                .param(ARG_WATERMARK, internalTimerService.currentWatermark())
                                                .param(ARG_WINDOW, mergeResult);
                                    } else if (!windowAssigner.isEventTime()) {
                                        long currentProcessingTime =
                                                internalTimerService.currentProcessingTime();
                                        if (mergeResult.maxTimestamp()
                                                <= currentProcessingTime) {
                                            throw new StreamException(ERR_STREAM_WINDOW_MERGE_INVALID_PROCESSING_TIME)
                                                    .param(ARG_PROCESSING_TIME, currentProcessingTime)
                                                    .param(ARG_WINDOW, mergeResult);
                                        }
                                    }

                                    triggerContext.key = key;
                                    triggerContext.window = mergeResult;

                                    triggerContext.onMerge(mergedWindows);

                                    for (W m : mergedWindows) {
                                        triggerContext.window = m;
                                        triggerContext.clear();
                                        // P1-INV-1: delete with the MERGED window m as the
                                        // baseline — the trigger accumulator stateKey embeds
                                        // triggerContext.window (the actual/merged window),
                                        // which differs from the stateWindow in merge
                                        // scenarios. Must run after triggerContext.clear()
                                        // (which may rebuild the entry via getSimpleAccumulator).
                                        removeTriggerAccumulators(key, m);
                                        // AR-4 (plan 1326-2 Phase 1): pane entries are
                                        // registered by the actual window a firing saw; a
                                        // merged-away window's pane entry dies with the merge.
                                        if (paneTracking != null) {
                                            paneTracking.remove(paneKey(key, m));
                                        }
                                        deleteCleanupTimer(m);
                                    }

                                    mergeWindowContents(key, stateWindowResult, mergedStateWindows);
                                }
                            });

            if (isWindowLate(actualWindow)) {
                mergingWindows.retireWindow(actualWindow);
                continue;
            }
            isSkippedElement = false;

            W stateWindow = mergingWindows.getStateWindow(actualWindow);
            if (stateWindow == null) {
                throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                        "Window " + window + " is not in in-flight window set.");
            }
            addWindowElement(key, stateWindow, element.getValue(), elementTimestamp);

            triggerContext.key = key;
            triggerContext.window = actualWindow;

            TriggerResult triggerResult = triggerContext.onElement(element);

            if (triggerResult.isFire()) {
                ACC contents = getWindowContents(key, stateWindow);
                if (contents != null) {
                    emitWindowContents(key, actualWindow, stateWindow, contents);
                }
            }

            if (triggerResult.isPurge()) {
                clearWindowContents(key, actualWindow, stateWindow);
                // P1-INV-1: symmetric with the regular element path — the merging
                // path cleared window contents without clearing the trigger state.
                // Entries are keyed with triggerContext.window (the ACTUAL window),
                // so the delete baseline is actualWindow, not stateWindow.
                triggerContext.clear();
                removeTriggerAccumulators(key, actualWindow);
            }
            registerCleanupTimer(actualWindow);
        }

        mergingWindows.persist();
        return isSkippedElement;
    }

    private boolean processElementForRegularWindow(
            StreamRecord<IN> element, Collection<W> elementWindows, K key, long elementTimestamp) throws Exception {
        boolean isSkippedElement = true;

        for (W window : elementWindows) {
            if (isWindowLate(window)) {
                continue;
            }
            isSkippedElement = false;
            addWindowElement(key, window, element.getValue(), elementTimestamp);

            triggerContext.key = key;
            triggerContext.window = window;

            TriggerResult triggerResult = triggerContext.onElement(element);

            if (triggerResult.isFire()) {
                ACC contents = getWindowContents(key, window);
                if (contents != null) {
                    emitWindowContents(key, window, window, contents);
                }
            }

            if (triggerResult.isPurge()) {
                clearWindowContents(key, window, window);
                triggerContext.clear();
                // P1-INV-1: delete after the last clear (the clear may rebuild).
                removeTriggerAccumulators(key, window);
            }
            registerCleanupTimer(window);
        }

        return isSkippedElement;
    }

    @Override
    public void onEventTime(InternalTimer<K, W> timer) throws Exception {
        triggerContext.key = timer.getKey();
        triggerContext.window = timer.getNamespace();

        // Restore the key context before reading any key-scoped state (e.g.
        // MergingWindowSet). Timers fire in timestamp order across all keys, so
        // the backend's current key may still point at whichever key was being
        // processed when this timer was registered. Without this, getMergingWindowSet()
        // would read the wrong key's mapping and getStateWindow() would return null,
        // silently dropping the window's output.
        if (keyedStateBackend != null) {
            this.<K>getKeyedStateBackend().setCurrentKey(triggerContext.key);
        }

        MergingWindowSet<W> mergingWindows;

        if (windowAssigner instanceof MergingWindowAssigner) {
            mergingWindows = getMergingWindowSet();
            W stateWindow = mergingWindows.getStateWindow(triggerContext.window);
            if (stateWindow == null) {
                // Timer firing for non-existent window, this can only happen if a
                // trigger did not clean up timers. We have already cleared the merging
                // window and therefore the Trigger state, however, so nothing to do.
                return;
            }
        } else {
            mergingWindows = null;
        }

        TriggerResult triggerResult = triggerContext.onEventTime(timer.getTimestamp());

        if (triggerResult.isFire()) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            ACC contents = getWindowContents(triggerContext.key, stateWindow);
            if (contents != null) {
                emitWindowContents(triggerContext.key, triggerContext.window, stateWindow, contents);
            }
        }

        if (triggerResult.isPurge()) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            clearWindowContents(triggerContext.key, triggerContext.window, stateWindow);
            // P1-INV-1: symmetric with the element paths — the timer PURGE branch
            // cleared window contents without clearing the trigger state (leaking
            // both the accumulator entry AND the trigger's registered timers).
            triggerContext.clear();
            removeTriggerAccumulators(triggerContext.key, triggerContext.window);
        }

        if (windowAssigner.isEventTime()
                && isCleanupTime(triggerContext.window, timer.getTimestamp())) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            if (stateWindow != null) {
                clearWindowContents(triggerContext.key, triggerContext.window, stateWindow);
                triggerContext.clear();
                // P1-INV-1: delete after the last clear (the clear may rebuild).
                removeTriggerAccumulators(triggerContext.key, triggerContext.window);
                // RL-6 (R15-AR-8): retire the in-flight window (= cleanup timer namespace =
                // MergingWindowSet mapping KEY) so the mapping converges after cleanup —
                // otherwise the cleaned window leaks into the checkpointed merging-sets
                // state (unbounded growth) and later overlapping elements merge into a
                // stale range. Retiring the state-window VALUE instead would throw
                // StreamException (key not found, MergingWindowSet.java:134-139).
                if (mergingWindows != null) {
                    mergingWindows.retireWindow(triggerContext.window);
                }
            }
        }

        if (mergingWindows != null) {
            // need to make sure to update the merging state in state
            mergingWindows.persist();
        }
    }

    @Override
    public void onProcessingTime(InternalTimer<K, W> timer) throws Exception {
        triggerContext.key = timer.getKey();
        triggerContext.window = timer.getNamespace();

        // Restore the key context before reading any key-scoped state (see onEventTime).
        if (keyedStateBackend != null) {
            this.<K>getKeyedStateBackend().setCurrentKey(triggerContext.key);
        }

        MergingWindowSet<W> mergingWindows;

        if (windowAssigner instanceof MergingWindowAssigner) {
            mergingWindows = getMergingWindowSet();
            W stateWindow = mergingWindows.getStateWindow(triggerContext.window);
            if (stateWindow == null) {
                // Timer firing for non-existent window, this can only happen if a
                // trigger did not clean up timers. We have already cleared the merging
                // window and therefore the Trigger state, however, so nothing to do.
                return;
            }
        } else {
            mergingWindows = null;
        }

        TriggerResult triggerResult = triggerContext.onProcessingTime(timer.getTimestamp());

        if (triggerResult.isFire()) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            ACC contents = getWindowContents(triggerContext.key, stateWindow);
            if (contents != null) {
                emitWindowContents(triggerContext.key, triggerContext.window, stateWindow, contents);
            }
        }

        if (triggerResult.isPurge()) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            clearWindowContents(triggerContext.key, triggerContext.window, stateWindow);
            // P1-INV-1: symmetric with the element paths — the timer PURGE branch
            // cleared window contents without clearing the trigger state (leaking
            // both the accumulator entry AND the trigger's registered timers).
            triggerContext.clear();
            removeTriggerAccumulators(triggerContext.key, triggerContext.window);
        }

        if (!windowAssigner.isEventTime()
                && isCleanupTime(triggerContext.window, timer.getTimestamp())) {
            W stateWindow = mergingWindows != null
                    ? mergingWindows.getStateWindow(triggerContext.window)
                    : triggerContext.window;
            if (stateWindow != null) {
                clearWindowContents(triggerContext.key, triggerContext.window, stateWindow);
                triggerContext.clear();
                // P1-INV-1: delete after the last clear (the clear may rebuild).
                removeTriggerAccumulators(triggerContext.key, triggerContext.window);
                // RL-6 (R15-AR-8): same convergence fix as the onEventTime cleanup branch —
                // retire the in-flight window (mapping key = cleanup timer namespace).
                if (mergingWindows != null) {
                    mergingWindows.retireWindow(triggerContext.window);
                }
            }
        }

        if (mergingWindows != null) {
            // need to make sure to update the merging state in state
            mergingWindows.persist();
        }
    }

    /**
     * P1-INV-1 (AR-02 Phase 4): removes every {@link #triggerAccumulators} entry
     * whose stateKey was built for {@code (key, window)} — the exact prefix
     * constructed by {@code Context#getSimpleAccumulator}
     * ({@code "trigger_" + key + STATE_KEY_SEPARATOR + window + STATE_KEY_SEPARATOR}).
     *
     * <p><b>Call-site contract:</b> must run AFTER the last
     * {@code triggerContext.clear()} on the path. {@code CountTrigger.clear} /
     * {@code ContinuousProcessingTimeTrigger.clear} call
     * {@code getSimpleAccumulator()}, which RE-CREATES a deleted entry on miss
     * (the {@code accums.put} in getSimpleAccumulator), so deleting inside
     * {@code clearWindowContents} (which purge paths run BEFORE the trigger
     * clear) would be silently undone. After the final clear, no further
     * {@code getSimpleAccumulator} call can occur for this window, so the
     * prefix delete is the terminal state. This closes the unbounded-growth
     * defect: entries were only ever put (single write point) and never
     * removed — purged/cleaned/merged windows leaked into the map, the
     * checkpoint, and the restored operator forever.
     */
    private void removeTriggerAccumulators(K key, W window) {
        if (triggerAccumulators == null || triggerAccumulators.isEmpty()) {
            return;
        }
        String prefix = "trigger_" + key + STATE_KEY_SEPARATOR + window + STATE_KEY_SEPARATOR;
        triggerAccumulators.keySet().removeIf(stateKey -> stateKey.startsWith(prefix));
    }

    /**
     * AR-3/AR-4 (plan 1326-2 Phase 1): {@code window} is the ACTUAL window (used for
     * pane tracking, user-function context and output timestamp); {@code stateWindow} is
     * the STATE window (namespace under which contents and element timestamps live —
     * differs from the actual window after a merging-assigner merge). Previously the
     * timestamps were read via the actual window while written via the state window,
     * which read null on every merging fire; the DISCARDING clear also hit the wrong
     * namespace.
     */
    @SuppressWarnings("unchecked")
    private void emitWindowContents(K key, W window, W stateWindow, ACC contents) throws Exception {
        timestampedCollector.setAbsoluteTimestamp(window.maxTimestamp());
        processContext.window = window;

        PaneInfo paneInfo = computePaneInfo(key, window);
        processContext.currentPaneInfo = paneInfo;

        if (evictor != null) {
            if (newAppendingWindowState != null) {
                // The builder never combines an appending descriptor with an evictor
                // (evictor ⇒ ListStateDescriptor); reaching here means a hand-built
                // operator has an incompatible layout — fail fast instead of CCE-ing
                // on the Iterable cast below (no-silent-skip, plan guide #24).
                throw new StreamException(ERR_STREAM_UNSUPPORTED)
                        .param(ARG_OPERATION, "WindowOperator.emitWindowContents")
                        .param(ARG_DETAIL, "Evictor path requires a list or map window-contents state, "
                                + "but an appending-state descriptor is configured");
            }
            Iterable<IN> elements = (Iterable<IN>) contents;
            List<TimestampedValue<IN>> wrapped = new ArrayList<>();
            List<Long> storedTimestamps = getElementTimestamps(key, stateWindow);
            int idx = 0;
            for (IN element : elements) {
                long elementTimestamp;
                if (storedTimestamps != null && idx < storedTimestamps.size()) {
                    elementTimestamp = storedTimestamps.get(idx);
                } else {
                    elementTimestamp = internalTimerService.currentWatermark();
                }
                wrapped.add(new TimestampedValue<>(element, elementTimestamp));
                idx++;
            }
            Evictor.EvictorContext evictorContext = new Evictor.EvictorContext() {
                @Override
                public long getCurrentProcessingTime() {
                    return internalTimerService.currentProcessingTime();
                }

                @Override
                public long getCurrentWatermark() {
                    return internalTimerService.currentWatermark();
                }
            };
            // AR-2: Flink semantics pass the PRE-eviction element count to both
            // evictBefore and evictAfter (Flink WindowOperator captures the count once
            // before evictBefore). Passing a shrunk count to evictAfter skewed every
            // size-aware evictor's decision.
            int preEvictionSize = wrapped.size();
            evictor.evictBefore(wrapped, preEvictionSize, window, evictorContext);
            List<IN> evictedElements = new ArrayList<>();
            for (TimestampedValue<IN> tv : wrapped) {
                evictedElements.add(tv.getValue());
            }
            userFunction.process(
                    key, window, processContext, (ACC) (Iterable<IN>) evictedElements, timestampedCollector);
            evictor.evictAfter(wrapped, preEvictionSize, window, evictorContext);
            // AR-2: eviction must physically shrink the window state (Flink's
            // iterator.remove() on the pane list). Previously only the local `wrapped`
            // copy was trimmed — evicted elements returned on every subsequent fire and
            // GlobalWindows+evictor (countWindow(size, slide)) grew without bound.
            writeBackEvictedWindow(key, stateWindow, wrapped);
        } else {
            userFunction.process(
                    key, window, processContext, contents, timestampedCollector);
        }

        if (accumulationMode == AccumulationMode.DISCARDING) {
            // AR-19 (顺手修复, recorded in plan 1326-2): DISCARDING under a merging
            // assigner must clear the STATE window namespace (where contents live),
            // not the actual window (previously a silent no-op clear).
            clearWindowContents(key, window, stateWindow);
        }
    }

    /**
     * AR-2: writes the surviving elements (post-evictAfter) back to the window-contents
     * state and trims the element-timestamps side store in lockstep so index alignment
     * between the two survives eviction.
     */
    @SuppressWarnings("unchecked")
    private void writeBackEvictedWindow(K key, W stateWindow, List<TimestampedValue<IN>> survivors) throws Exception {
        List<IN> survivingElements = new ArrayList<>(survivors.size());
        for (TimestampedValue<IN> tv : survivors) {
            survivingElements.add(tv.getValue());
        }

        if (newListWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newListWindowState.setCurrentNamespace(stateWindow);
            try {
                newListWindowState.update(survivingElements);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to write back evicted window contents");
            }
        } else {
            setWindowContents(key, stateWindow, (ACC) survivingElements);
        }

        if (elementTimestampsState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            typedBackend.setCurrentNamespace(windowNamespace(stateWindow));
            List<Long> survivingTimestamps = new ArrayList<>(survivors.size());
            for (TimestampedValue<IN> tv : survivors) {
                survivingTimestamps.add(tv.getTimestamp());
            }
            elementTimestampsState.put(ELEMENT_TIMESTAMPS_KEY, survivingTimestamps);
        }
    }

    private PaneInfo computePaneInfo(K key, W window) {
        String paneKey = paneKey(key, window);
        PaneTrackingInfo tracking = paneTracking.get(paneKey);
        if (tracking == null) {
            tracking = new PaneTrackingInfo();
            paneTracking.put(paneKey, tracking);
        }

        long watermark = internalTimerService.currentWatermark();
        PaneInfo.PaneTiming timing;
        boolean isOnTimeOrLate = watermark >= window.maxTimestamp();

        if (isOnTimeOrLate && !tracking.onTimeEmitted) {
            timing = PaneInfo.PaneTiming.ON_TIME;
            tracking.onTimeEmitted = true;
        } else if (isOnTimeOrLate && tracking.onTimeEmitted) {
            timing = PaneInfo.PaneTiming.LATE;
        } else {
            timing = PaneInfo.PaneTiming.EARLY;
        }

        boolean isFirst = tracking.paneIndex == 0;
        int index = tracking.paneIndex;
        tracking.paneIndex++;

        return new PaneInfo(index, isFirst, false, timing);
    }

    private String paneKey(K key, W window) {
        return key + STATE_KEY_SEPARATOR + windowNamespace(window);
    }

    /**
     * Returns true if the pane key corresponds to a {@link TimeWindow}-scoped pane. Only such
     * panes participate in checkpoint/restore because {@link #windowNamespace} is reversible
     * (stable, unique {@code TW:start,end}) for TimeWindow but irreversible
     * ({@code className#toString}) for other window types.
     */
    private static boolean isTimeWindowPaneKey(String paneKey) {
        return paneKey != null && paneKey.contains(STATE_KEY_SEPARATOR + "TW:");
    }

    /**
     * Snapshots the TimeWindow-scoped pane-tracking entries into a serializable DTO.
     */
    private PaneTrackingSnapshot snapshotPaneTracking() {
        List<PaneTrackingSnapshot.PaneTrackingEntry> entries = new ArrayList<>();
        for (Map.Entry<String, PaneTrackingInfo> e : paneTracking.entrySet()) {
            if (!isTimeWindowPaneKey(e.getKey())) {
                continue;
            }
            PaneTrackingInfo info = e.getValue();
            entries.add(new PaneTrackingSnapshot.PaneTrackingEntry(
                    e.getKey(), info.paneIndex, info.onTimeEmitted));
        }
        return new PaneTrackingSnapshot(entries);
    }

    private static class PaneTrackingInfo {
        int paneIndex = 0;
        boolean onTimeEmitted = false;
    }

    /**
     * Serializable snapshot DTO of the pane-tracking map (G48). Only TimeWindow-scoped
     * entries are stored (see {@link #isTimeWindowPaneKey}).
     *
     * <p>The JSON checkpoint persist path ({@code CheckpointSerDe}) converts this DTO
     * to a plain JSON-safe map form via {@link #toSerializableForm()} / {@link
     * #fromSerializableForm(Map)} — the DTO itself is not a Nop {@code @DataBean}.
     */
    public static final class PaneTrackingSnapshot implements java.io.Serializable {
        private static final long serialVersionUID = 1L;

        private static final String FORM_TYPE_PANE_TRACKING = "PaneTrackingSnapshot";

        private final List<PaneTrackingEntry> entries;

        public PaneTrackingSnapshot(List<PaneTrackingEntry> entries) {
            this.entries = entries != null ? entries : new ArrayList<>();
        }

        public List<PaneTrackingEntry> getEntries() {
            return entries;
        }

        /**
         * JSON-safe map form used by the checkpoint persist path. Self-describing via
         * {@code "@type"}.
         */
        @SuppressWarnings("unchecked")
        public Map<String, Object> toSerializableForm() {
            java.util.LinkedHashMap<String, Object> form = new java.util.LinkedHashMap<>();
            form.put("@type", FORM_TYPE_PANE_TRACKING);
            List<Object> entryForms = new ArrayList<>();
            for (PaneTrackingEntry entry : entries) {
                entryForms.add(entry.toSerializableForm());
            }
            form.put("entries", entryForms);
            return form;
        }

        /**
         * Rebuilds a {@link PaneTrackingSnapshot} from the JSON-safe form produced by
         * {@link #toSerializableForm()}. Returns {@code null} for non-pane-tracking maps.
         */
        @SuppressWarnings("unchecked")
        public static PaneTrackingSnapshot fromSerializableForm(Map<String, Object> form) {
            if (form == null || !FORM_TYPE_PANE_TRACKING.equals(form.get("@type"))) {
                return null;
            }
            List<PaneTrackingEntry> result = new ArrayList<>();
            List<Object> entryForms = (List<Object>) form.get("entries");
            if (entryForms != null) {
                for (Object f : entryForms) {
                    if (f instanceof Map) {
                        result.add(PaneTrackingEntry.fromSerializableForm((Map<String, Object>) f));
                    }
                }
            }
            return new PaneTrackingSnapshot(result);
        }

        public static final class PaneTrackingEntry implements java.io.Serializable {
            private static final long serialVersionUID = 1L;

            private final String paneKey;
            private final int paneIndex;
            private final boolean onTimeEmitted;

            public PaneTrackingEntry(String paneKey, int paneIndex, boolean onTimeEmitted) {
                this.paneKey = paneKey;
                this.paneIndex = paneIndex;
                this.onTimeEmitted = onTimeEmitted;
            }

            public String getPaneKey() {
                return paneKey;
            }

            public int getPaneIndex() {
                return paneIndex;
            }

            public boolean isOnTimeEmitted() {
                return onTimeEmitted;
            }

            public Map<String, Object> toSerializableForm() {
                java.util.LinkedHashMap<String, Object> form = new java.util.LinkedHashMap<>();
                form.put("paneKey", paneKey);
                form.put("paneIndex", paneIndex);
                form.put("onTimeEmitted", onTimeEmitted);
                return form;
            }

            public static PaneTrackingEntry fromSerializableForm(Map<String, Object> form) {
                return new PaneTrackingEntry(
                        (String) form.get("paneKey"),
                        form.get("paneIndex") instanceof Number ? ((Number) form.get("paneIndex")).intValue() : 0,
                        Boolean.TRUE.equals(form.get("onTimeEmitted")));
            }
        }
    }

    /**
     * Write skipped late arriving element to SideOutput.
     *
     * @param element skipped late arriving element to side output
     */
    protected void sideOutput(StreamRecord<IN> element) {
        output.collect(lateDataOutputTag, element);
    }

    /**
     * Retrieves the {@link MergingWindowSet} for the currently active key. The caller must ensure
     * that the correct key is set in the state backend.
     *
     * <p>The caller must also ensure to properly persist changes to state using {@link
     * MergingWindowSet#persist()}.
     */
    protected MergingWindowSet<W> getMergingWindowSet() throws Exception {
        @SuppressWarnings("unchecked")
        MergingWindowAssigner<? super IN, W> mergingAssigner =
                (MergingWindowAssigner<? super IN, W>) windowAssigner;
        return new MergingWindowSet<>(mergingAssigner, mergingSetsState);
    }

    /**
     * Returns {@code true} if the watermark is after the end timestamp plus the allowed lateness of
     * the given window.
     */
    protected boolean isWindowLate(W window) {
        return (windowAssigner.isEventTime()
                && (cleanupTime(window) <= internalTimerService.currentWatermark()));
    }

    /**
     * Decide if a record is currently late, based on current watermark and allowed lateness.
     *
     * @param element The element to check
     * @return The element for which should be considered when sideoutputs
     */
    protected boolean isElementLate(StreamRecord<IN> element) {
        return (windowAssigner.isEventTime())
                && (element.getTimestamp() + allowedLateness
                <= internalTimerService.currentWatermark());
    }

    /**
     * Registers a timer to cleanup the content of the window.
     *
     * @param window the window whose state to discard
     */
    protected void registerCleanupTimer(W window) {
        long cleanupTime = cleanupTime(window);
        if (cleanupTime == Long.MAX_VALUE) {
            // don't set a GC timer for "end of time"
            return;
        }

        if (windowAssigner.isEventTime()) {
            triggerContext.registerEventTimeTimer(cleanupTime);
        } else {
            triggerContext.registerProcessingTimeTimer(cleanupTime);
        }
    }

    /**
     * Deletes the cleanup timer set for the contents of the provided window.
     *
     * @param window the window whose state to discard
     */
    protected void deleteCleanupTimer(W window) {
        long cleanupTime = cleanupTime(window);
        if (cleanupTime == Long.MAX_VALUE) {
            // no need to clean up because we didn't set one
            return;
        }
        if (windowAssigner.isEventTime()) {
            triggerContext.deleteEventTimeTimer(cleanupTime);
        } else {
            triggerContext.deleteProcessingTimeTimer(cleanupTime);
        }
    }

    /**
     * Returns the cleanup time for a window, which is {@code window.maxTimestamp +
     * allowedLateness}. In case this leads to a value greater than {@link Long#MAX_VALUE} then a
     * cleanup time of {@link Long#MAX_VALUE} is returned.
     *
     * @param window the window whose cleanup time we are computing.
     */
    private long cleanupTime(W window) {
        if (windowAssigner.isEventTime()) {
            long cleanupTime = window.maxTimestamp() + allowedLateness;
            return cleanupTime >= window.maxTimestamp() ? cleanupTime : Long.MAX_VALUE;
        } else {
            return window.maxTimestamp();
        }
    }

    /**
     * Returns {@code true} if the given time is the cleanup time for the given window.
     */
    protected final boolean isCleanupTime(W window, long time) {
        return time == cleanupTime(window);
    }

    @SuppressWarnings("unchecked")
    private void addWindowElement(K key, W window, IN value, long elementTimestamp) {
        if (newAppendingWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newAppendingWindowState.setCurrentNamespace(window);
            try {
                newAppendingWindowState.add(value);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to add element to appending window state");
            }
            return;
        }

        if (newListWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newListWindowState.setCurrentNamespace(window);
            try {
                newListWindowState.add(value);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to add element to list window state");
            }
            // AR-3 (plan 1326-2 Phase 1): the descriptor (internal-backend) path
            // previously never stored element timestamps, so the evictor branch saw
            // null storedTimestamps and stamped every element with the current
            // watermark. Store in lockstep with the list append (index-aligned).
            storeElementTimestamp(key, window, elementTimestamp);
            return;
        }

        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);
        typedBackend.setCurrentNamespace(windowNamespace(window));

        ACC current = windowContentsState.get(WINDOW_VALUE_KEY);
        if (current == null) {
            if (evictor != null) {
                List<IN> list = new ArrayList<>();
                list.add(value);
                setWindowContents(key, window, (ACC) list);
            } else {
                SimpleAccumulator<IN> accumulator = createAccumulatorForWindow();
                if (accumulator != null) {
                    accumulator.add(value);
                    setWindowContents(key, window, (ACC) accumulator);
                } else {
                    try {
                        setWindowContents(key, window, (ACC) value);
                    } catch (ClassCastException e) {
                        throw new StreamException(ERR_STREAM_TYPE_MISMATCH, e)
                                .param(ARG_EXPECTED_TYPE, accClass.getName())
                                .param(ARG_ACTUAL_TYPE, value.getClass().getName());
                    }
                }
            }
            storeElementTimestamp(key, window, elementTimestamp);
            return;
        }

        if (current instanceof SimpleAccumulator) {
            SimpleAccumulator<IN> accumulator = (SimpleAccumulator<IN>) current;
            accumulator.add(value);
            setWindowContents(key, window, (ACC) accumulator);
            storeElementTimestamp(key, window, elementTimestamp);
            return;
        }

        if (current instanceof List) {
            @SuppressWarnings("unchecked")
            List<IN> list = (List<IN>) current;
            list.add(value);
            storeElementTimestamp(key, window, elementTimestamp);
            return;
        }

        if (evictor != null) {
            List<IN> list = new ArrayList<>();
            list.add((IN) current);
            list.add(value);
            setWindowContents(key, window, (ACC) list);
            storeElementTimestamp(key, window, elementTimestamp);
            return;
        }

        try {
            setWindowContents(key, window, (ACC) value);
        } catch (ClassCastException e) {
            throw new StreamException(ERR_STREAM_TYPE_MISMATCH, e)
                    .param(ARG_EXPECTED_TYPE, accClass.getName())
                    .param(ARG_ACTUAL_TYPE, value.getClass().getName());
        }
        storeElementTimestamp(key, window, elementTimestamp);
    }

    /**
     * Creates a new SimpleAccumulator for a window.
     * Returns null if no accumulator factory is available.
     * Subclasses can override to provide custom accumulator creation logic.
     */
    @SuppressWarnings("unchecked")
    protected SimpleAccumulator<IN> createAccumulatorForWindow() {
        return null;
    }

    private void storeElementTimestamp(K key, W window, long timestamp) {
        if (elementTimestampsState == null || evictor == null) {
            return;
        }
        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);
        typedBackend.setCurrentNamespace(windowNamespace(window));
        List<Long> timestamps = elementTimestampsState.get(ELEMENT_TIMESTAMPS_KEY);
        if (timestamps == null) {
            timestamps = new ArrayList<>();
        }
        timestamps.add(timestamp);
        elementTimestampsState.put(ELEMENT_TIMESTAMPS_KEY, timestamps);
    }

    private List<Long> getElementTimestamps(K key, W window) {
        if (elementTimestampsState == null) {
            return null;
        }
        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);
        typedBackend.setCurrentNamespace(windowNamespace(window));
        return elementTimestampsState.get(ELEMENT_TIMESTAMPS_KEY);
    }

    @SuppressWarnings("unchecked")
    private ACC getWindowContents(K key, W window) {
        if (newAppendingWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newAppendingWindowState.setCurrentNamespace(window);
            try {
                ACC acc = newAppendingWindowState.getAccumulator();
                return acc;
            } catch (Exception e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to get window contents from appending state");
            }
        }

        if (newListWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newListWindowState.setCurrentNamespace(window);
            try {
                Iterable<IN> elements = newListWindowState.get();
                return (ACC) elements;
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to get window contents from list state");
            }
        }

        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);
        typedBackend.setCurrentNamespace(windowNamespace(window));
        return windowContentsState.get(WINDOW_VALUE_KEY);
    }

    /**
     * AR-4 (plan 1326-2 Phase 1): pane-tracking entries are registered by the ACTUAL
     * window ({@link #computePaneInfo} is called with the window the user function sees),
     * while window contents/timestamps live under the STATE window namespace (differs
     * after a merging-assigner merge). Both keys are now removed explicitly: previously
     * this method keyed everything by a single window, so under a merging assigner the
     * pane entry (registered by actualWindow, deleted by stateWindow) never died and
     * leaked into every checkpoint.
     */
    private void clearWindowContents(K key, W actualWindow, W stateWindow) {
        String paneKey = paneKey(key, actualWindow);
        if (paneTracking != null) {
            paneTracking.remove(paneKey);
        }
        if (newAppendingWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newAppendingWindowState.setCurrentNamespace(stateWindow);
            newAppendingWindowState.clear();
            return;
        }

        if (newListWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);
            newListWindowState.setCurrentNamespace(stateWindow);
            newListWindowState.clear();
            return;
        }

        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);
        typedBackend.setCurrentNamespace(windowNamespace(stateWindow));
        windowContentsState.remove(WINDOW_VALUE_KEY);
        if (elementTimestampsState != null) {
            elementTimestampsState.remove(ELEMENT_TIMESTAMPS_KEY);
        }
    }

    private void setWindowContents(K key, W window, ACC value) {
        IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
        typedBackend.setCurrentKey(key);

        if (newAppendingWindowState != null) {
            newAppendingWindowState.setCurrentNamespace(window);
            try {
                newAppendingWindowState.add((IN) value);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to set window contents in appending state");
            }
            return;
        }

        if (newListWindowState != null) {
            newListWindowState.setCurrentNamespace(window);
            try {
                newListWindowState.add((IN) value);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to set window contents in list state");
            }
            return;
        }

        typedBackend.setCurrentNamespace(windowNamespace(window));
        windowContentsState.put(WINDOW_VALUE_KEY, value);
    }

    @SuppressWarnings("unchecked")
    private void mergeWindowContents(K key, W targetWindow, Collection<W> sourceWindows) {
        if (sourceWindows == null || sourceWindows.isEmpty()) {
            return;
        }

        if (newAppendingWindowState != null && mergeFunction != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);

            newAppendingWindowState.setCurrentNamespace(targetWindow);
            ACC targetValue;
            try {
                targetValue = newAppendingWindowState.getAccumulator();
            } catch (Exception e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to get target accumulator during merge");
            }

            for (W sourceWindow : sourceWindows) {
                if (sourceWindow == null || sourceWindow.equals(targetWindow)) {
                    continue;
                }

                newAppendingWindowState.setCurrentNamespace(sourceWindow);
                ACC sourceValue;
                try {
                    sourceValue = newAppendingWindowState.getAccumulator();
                } catch (Exception e) {
                    throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                            .param(ARG_DETAIL, "Failed to get source accumulator during merge");
                }

                if (sourceValue == null) {
                    continue;
                }

                if (targetValue == null) {
                    targetValue = sourceValue;
                } else {
                    targetValue = mergeFunction.apply(targetValue, sourceValue);
                }

                newAppendingWindowState.setCurrentNamespace(sourceWindow);
                newAppendingWindowState.clear();
            }

            if (targetValue != null) {
                newAppendingWindowState.setCurrentNamespace(targetWindow);
                try {
                    newAppendingWindowState.setAccumulator(targetValue);
                } catch (Exception e) {
                    throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                            .param(ARG_DETAIL, "Failed to set merged accumulator");
                }
            }
            return;
        }

        if (newListWindowState != null) {
            IKeyedStateBackend<K> typedBackend = this.getKeyedStateBackend();
            typedBackend.setCurrentKey(key);

            newListWindowState.setCurrentNamespace(targetWindow);
            List<IN> targetElements = new ArrayList<>();
            try {
                Iterable<IN> existing = newListWindowState.get();
                if (existing != null) {
                    for (IN e : existing) {
                        targetElements.add(e);
                    }
                }
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to get target list during merge");
            }

            for (W sourceWindow : sourceWindows) {
                if (sourceWindow == null || sourceWindow.equals(targetWindow)) {
                    continue;
                }

                newListWindowState.setCurrentNamespace(sourceWindow);
                try {
                    Iterable<IN> sourceElements = newListWindowState.get();
                    if (sourceElements != null) {
                        for (IN e : sourceElements) {
                            targetElements.add(e);
                        }
                    }
                } catch (java.io.IOException e) {
                    throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                            .param(ARG_DETAIL, "Failed to get source list during merge");
                }

                newListWindowState.clear();
            }

            newListWindowState.setCurrentNamespace(targetWindow);
            try {
                newListWindowState.update(targetElements);
            } catch (java.io.IOException e) {
                throw new StreamException(ERR_STREAM_STATE_ERROR, e)
                        .param(ARG_DETAIL, "Failed to update target list during merge");
            }
            return;
        }

        ACC targetValue = getWindowContents(key, targetWindow);
        for (W sourceWindow : sourceWindows) {
            if (sourceWindow == null || sourceWindow.equals(targetWindow)) {
                continue;
            }

            ACC sourceValue = getWindowContents(key, sourceWindow);
            if (sourceValue == null) {
                continue;
            }

            if (targetValue == null) {
                targetValue = sourceValue;
            } else if (targetValue instanceof SimpleAccumulator) {
                SimpleAccumulator<ACC> accumulator = (SimpleAccumulator<ACC>) targetValue;
                if (sourceValue instanceof SimpleAccumulator) {
                    accumulator.merge((SimpleAccumulator<ACC>) sourceValue);
                } else {
                    throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                            "Cannot merge non-accumulator value into accumulator target. " +
                            "targetType=" + targetValue.getClass().getName() +
                            ", sourceType=" + sourceValue.getClass().getName());
                }
                targetValue = (ACC) accumulator;
            } else {
                throw new StreamException(ERR_STREAM_WINDOW_NON_ACCUMULATOR_MERGE_CONFLICT)
                        .param(ARG_DETAIL,
                                "Cannot merge multiple non-accumulator values. targetType="
                                + targetValue.getClass().getName());
            }

            clearWindowContents(key, sourceWindow, sourceWindow);
        }

        if (targetValue != null) {
            setWindowContents(key, targetWindow, targetValue);
        }
    }

    private String windowNamespace(W window) {
        if (window == null) {
            return "_null_window_";
        }
        if (window instanceof TimeWindow) {
            TimeWindow tw = (TimeWindow) window;
            return "TW:" + tw.getStart() + "," + tw.getEnd();
        }
        return window.getClass().getName() + "#" + window.toString();
    }

    public class PerWindowKeyedStateStore implements KeyedStateStore {
        private final IKeyedStateBackend<K> backend;
        private final String namespace;

        PerWindowKeyedStateStore(IKeyedStateBackend<K> backend, String namespace) {
            this.backend = backend;
            this.namespace = namespace;
        }

        private void setNamespace() {
            backend.setCurrentNamespace(namespace);
        }

        @Override
        public <T> ValueState<T> getState(ValueStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareValueState<>(namespace, backend.getState(stateProperties), backend);
        }

        @Override
        public <T> ListState<T> getListState(ListStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareListState<>(namespace, backend.getListState(stateProperties), backend);
        }

        @Override
        public <T> ReducingState<T> getReducingState(ReducingStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareReducingState<>(namespace, backend.getReducingState(stateProperties), backend);
        }

        @Override
        public <IN, ACC, OUT> AggregatingState<IN, OUT> getAggregatingState(
                AggregatingStateDescriptor<IN, ACC, OUT> stateProperties) {
            setNamespace();
            return new NamespaceAwareAggregatingState<>(namespace, backend.getAggregatingState(stateProperties), backend);
        }

        @Override
        public <UK, UV> MapState<UK, UV> getMapState(MapStateDescriptor<UK, UV> stateProperties) {
            setNamespace();
            return new NamespaceAwareMapState<>(namespace, backend.getMapState(stateProperties), backend);
        }
    }

    public class GlobalKeyedStateStore implements KeyedStateStore {
        private final IKeyedStateBackend<K> backend;

        GlobalKeyedStateStore(IKeyedStateBackend<K> backend) {
            this.backend = backend;
        }

        private void setNamespace() {
            backend.setCurrentNamespace(IKeyedStateBackend.DEFAULT_NAMESPACE);
        }

        @Override
        public <T> ValueState<T> getState(ValueStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareValueState<>(IKeyedStateBackend.DEFAULT_NAMESPACE, backend.getState(stateProperties), backend);
        }

        @Override
        public <T> ListState<T> getListState(ListStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareListState<>(IKeyedStateBackend.DEFAULT_NAMESPACE, backend.getListState(stateProperties), backend);
        }

        @Override
        public <T> ReducingState<T> getReducingState(ReducingStateDescriptor<T> stateProperties) {
            setNamespace();
            return new NamespaceAwareReducingState<>(IKeyedStateBackend.DEFAULT_NAMESPACE, backend.getReducingState(stateProperties), backend);
        }

        @Override
        public <IN, ACC, OUT> AggregatingState<IN, OUT> getAggregatingState(
                AggregatingStateDescriptor<IN, ACC, OUT> stateProperties) {
            setNamespace();
            return new NamespaceAwareAggregatingState<>(IKeyedStateBackend.DEFAULT_NAMESPACE, backend.getAggregatingState(stateProperties), backend);
        }

        @Override
        public <UK, UV> MapState<UK, UV> getMapState(MapStateDescriptor<UK, UV> stateProperties) {
            setNamespace();
            return new NamespaceAwareMapState<>(IKeyedStateBackend.DEFAULT_NAMESPACE, backend.getMapState(stateProperties), backend);
        }
    }

    private static class NamespaceAwareValueState<T> implements ValueState<T> {
        private final String namespace;
        private final ValueState<T> delegate;
        private final IKeyedStateBackend<?> backend;

        NamespaceAwareValueState(String namespace, ValueState<T> delegate, IKeyedStateBackend<?> backend) {
            this.namespace = namespace;
            this.delegate = delegate;
            this.backend = backend;
        }

        @Override
        public T value() throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            return delegate.value();
        }

        @Override
        public void update(T value) throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            delegate.update(value);
        }

        @Override
        public void clear() {
            backend.setCurrentNamespace(namespace);
            delegate.clear();
        }
    }

    private static class NamespaceAwareListState<T> implements ListState<T> {
        private final String namespace;
        private final ListState<T> delegate;
        private final IKeyedStateBackend<?> backend;

        NamespaceAwareListState(String namespace, ListState<T> delegate, IKeyedStateBackend<?> backend) {
            this.namespace = namespace;
            this.delegate = delegate;
            this.backend = backend;
        }

        @Override
        public Iterable<T> get() throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            return delegate.get();
        }

        @Override
        public void add(T value) throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            delegate.add(value);
        }

        @Override
        public void update(Iterable<T> values) throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            delegate.update(values);
        }

        @Override
        public void addAll(Iterable<T> values) throws java.io.IOException {
            backend.setCurrentNamespace(namespace);
            delegate.addAll(values);
        }

        @Override
        public void clear() {
            backend.setCurrentNamespace(namespace);
            delegate.clear();
        }
    }

    private static class NamespaceAwareReducingState<T> implements ReducingState<T> {
        private final String namespace;
        private final ReducingState<T> delegate;
        private final IKeyedStateBackend<?> backend;

        NamespaceAwareReducingState(String namespace, ReducingState<T> delegate, IKeyedStateBackend<?> backend) {
            this.namespace = namespace;
            this.delegate = delegate;
            this.backend = backend;
        }

        @Override
        public T get() throws Exception {
            backend.setCurrentNamespace(namespace);
            return delegate.get();
        }

        @Override
        public void add(T value) throws Exception {
            backend.setCurrentNamespace(namespace);
            delegate.add(value);
        }

        @Override
        public void clear() {
            backend.setCurrentNamespace(namespace);
            delegate.clear();
        }
    }

    private static class NamespaceAwareAggregatingState<IN, OUT> implements AggregatingState<IN, OUT> {
        private final String namespace;
        private final AggregatingState<IN, OUT> delegate;
        private final IKeyedStateBackend<?> backend;

        NamespaceAwareAggregatingState(String namespace, AggregatingState<IN, OUT> delegate, IKeyedStateBackend<?> backend) {
            this.namespace = namespace;
            this.delegate = delegate;
            this.backend = backend;
        }

        @Override
        public OUT get() throws Exception {
            backend.setCurrentNamespace(namespace);
            return delegate.get();
        }

        @Override
        public void add(IN value) throws Exception {
            backend.setCurrentNamespace(namespace);
            delegate.add(value);
        }

        @Override
        public void clear() {
            backend.setCurrentNamespace(namespace);
            delegate.clear();
        }
    }

    private static class NamespaceAwareMapState<UK, UV> implements MapState<UK, UV> {
        private final String namespace;
        private final MapState<UK, UV> delegate;
        private final IKeyedStateBackend<?> backend;

        NamespaceAwareMapState(String namespace, MapState<UK, UV> delegate, IKeyedStateBackend<?> backend) {
            this.namespace = namespace;
            this.delegate = delegate;
            this.backend = backend;
        }

        @Override
        public UV get(UK key) {
            backend.setCurrentNamespace(namespace);
            return delegate.get(key);
        }

        @Override
        public void put(UK key, UV value) {
            backend.setCurrentNamespace(namespace);
            delegate.put(key, value);
        }

        @Override
        public void putAll(Map<UK, UV> map) {
            backend.setCurrentNamespace(namespace);
            delegate.putAll(map);
        }

        @Override
        public void remove(UK key) {
            backend.setCurrentNamespace(namespace);
            delegate.remove(key);
        }

        @Override
        public boolean contains(UK key) {
            backend.setCurrentNamespace(namespace);
            return delegate.contains(key);
        }

        @Override
        public Iterable<Map.Entry<UK, UV>> entries() {
            backend.setCurrentNamespace(namespace);
            return delegate.entries();
        }

        @Override
        public Iterable<UK> keys() {
            backend.setCurrentNamespace(namespace);
            return delegate.keys();
        }

        @Override
        public Iterable<UV> values() {
            backend.setCurrentNamespace(namespace);
            return delegate.values();
        }

        @Override
        public java.util.Iterator<Map.Entry<UK, UV>> iterator() {
            backend.setCurrentNamespace(namespace);
            return delegate.iterator();
        }

        @Override
        public boolean isEmpty() {
            backend.setCurrentNamespace(namespace);
            return delegate.isEmpty();
        }

        @Override
        public void clear() {
            backend.setCurrentNamespace(namespace);
            delegate.clear();
        }
    }

    /**
     * A utility class for handling {@code ProcessWindowFunction} invocations. This can be reused by
     * setting the {@code key} and {@code window} fields. No internal state must be kept in the
     * {@code WindowContext}.
     */
    public class WindowContext implements InternalWindowFunction.InternalWindowContext {
        protected W window;
        protected PaneInfo currentPaneInfo;

        public WindowContext(W window) {
            this.window = window;
        }

        @Override
        public String toString() {
            return "WindowContext{Window = " + window.toString() + "}";
        }

        public void clear() throws Exception {
            userFunction.clear(window, this);
        }

        @Override
        public long currentProcessingTime() {
            return internalTimerService.currentProcessingTime();
        }

        @Override
        public long currentWatermark() {
            return internalTimerService.currentWatermark();
        }

        @Override
        public KeyedStateStore windowState() {
            IKeyedStateBackend<K> backend = WindowOperator.this.getKeyedStateBackend();
            if (backend == null) {
                return null;
            }
            return new PerWindowKeyedStateStore(backend, windowNamespace(window));
        }

        @Override
        public KeyedStateStore globalState() {
            IKeyedStateBackend<K> backend = WindowOperator.this.getKeyedStateBackend();
            if (backend == null) {
                return null;
            }
            return new GlobalKeyedStateStore(backend);
        }

        @Override
        public <X> void output(OutputTag<X> outputTag, X value) {
            if (outputTag == null) {
                throw new StreamException(ERR_STREAM_NULL_ARG).param(ARG_ARG_NAME, "outputTag");
            }
            output.collect(outputTag, new StreamRecord<>(value, window.maxTimestamp()));
        }

        @Override
        public PaneInfo getPaneInfo() {
            return currentPaneInfo;
        }
    }

    /**
     * {@code Context} is a utility for handling {@code Trigger} invocations. It can be reused by
     * setting the {@code key} and {@code window} fields. No internal state must be kept in the
     * {@code Context}
     */
    public class Context implements Trigger.OnMergeContext {
        protected K key;
        protected W window;

        protected Collection<W> mergedWindows;

        public Context(K key, W window) {
            this.key = key;
            this.window = window;
        }

        public long getCurrentWatermark() {
            return internalTimerService.currentWatermark();
        }

        @Override
        public long getCurrentProcessingTime() {
            return internalTimerService.currentProcessingTime();
        }

        @Override
        public void registerProcessingTimeTimer(long time) {
            internalTimerService.registerProcessingTimeTimer(window, time);
        }

        @Override
        public void registerEventTimeTimer(long time) {
            internalTimerService.registerEventTimeTimer(window, time);
        }

        @Override
        public void deleteProcessingTimeTimer(long time) {
            internalTimerService.deleteProcessingTimeTimer(window, time);
        }

        @Override
        public void deleteEventTimeTimer(long time) {
            internalTimerService.deleteEventTimeTimer(window, time);
        }

        public TriggerResult onElement(StreamRecord<IN> element) throws Exception {
            return trigger.onElement(element.getValue(), element.getTimestamp(), window, this);
        }

        public TriggerResult onProcessingTime(long time) throws Exception {
            return trigger.onProcessingTime(time, window, this);
        }

        public TriggerResult onEventTime(long time) throws Exception {
            return trigger.onEventTime(time, window, this);
        }

        public void onMerge(Collection<W> mergedWindows) throws Exception {
            this.mergedWindows = mergedWindows;
            trigger.onMerge(window, this);
        }

        public void clear() throws Exception {
            trigger.clear(window, this);
        }

        @Override
        @SuppressWarnings("unchecked")
        public <T> SimpleAccumulator<T> getSimpleAccumulator(StateDescriptor<T> descriptor) {
            Map<String, SimpleAccumulator<?>> accums = triggerAccumulators;
            if (accums == null) {
                throw new StreamException(ERR_STREAM_INVALID_STATE)
                        .param(ARG_DETAIL, "triggerAccumulators already cleared (operator closed)");
            }

            String stateKey = "trigger_" + key + STATE_KEY_SEPARATOR + window + STATE_KEY_SEPARATOR + descriptor.getName();

            SimpleAccumulator<T> existing = (SimpleAccumulator<T>) accums.get(stateKey);
            if (existing != null) {
                return existing;
            }

            // Create new accumulator from ReducingStateDescriptor if applicable
            if (descriptor instanceof ReducingStateDescriptor) {
                ReducingStateDescriptor<T> rsd = (ReducingStateDescriptor<T>) descriptor;
                try {
                    SimpleAccumulator<T> acc = rsd.getAccumulatorType().getDeclaredConstructor().newInstance();
                    accums.put(stateKey, acc);
                    return acc;
                } catch (Exception e) {
                    throw new StreamException(ERR_STREAM_WINDOW_TRIGGER_STATE_ACCUMULATOR_FAILED, e)
                            .param(ARG_DESCRIPTOR_NAME, "trigger-state");
                }
            }
            throw new StreamException(ERR_STREAM_UNSUPPORTED)
                    .param(ARG_OPERATION, "getSimpleAccumulator for descriptor: " + descriptor.getName());
        }

        @Override
        public String toString() {
            return "Context{" + "key=" + key + ", window=" + window + '}';
        }
    }

    /**
     * Internal class for keeping track of in-flight timers.
     */
    protected static class Timer<K, W extends Window> implements Comparable<Timer<K, W>> {
        protected long timestamp;
        protected K key;
        protected W window;

        public Timer(long timestamp, K key, W window) {
            this.timestamp = timestamp;
            this.key = key;
            this.window = window;
        }

        @Override
        public int compareTo(Timer<K, W> o) {
            return Long.compare(this.timestamp, o.timestamp);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            Timer<?, ?> timer = (Timer<?, ?>) o;

            return timestamp == timer.timestamp
                    && key.equals(timer.key)
                    && window.equals(timer.window);
        }

        @Override
        public int hashCode() {
            int result = (int) (timestamp ^ (timestamp >>> 32));
            result = 31 * result + key.hashCode();
            result = 31 * result + window.hashCode();
            return result;
        }

        @Override
        public String toString() {
            return "Timer{"
                    + "timestamp="
                    + timestamp
                    + ", key="
                    + key
                    + ", window="
                    + window
                    + '}';
        }
    }

    // ------------------------------------------------------------------------
    // Getters for testing
    // ------------------------------------------------------------------------

    public KeySelector<IN, K> getKeySelector() {
        return keySelector;
    }

    public WindowAssigner<? super IN, W> getWindowAssigner() {
        return windowAssigner;
    }

    /**
     * AR-4 (plan 1326-2 Phase 1): test accessor for the pane-tracking map. The returned
     * map is the live instance — assertions should only read it.
     */
    Map<String, PaneTrackingInfo> paneTrackingForTest() {
        return paneTracking;
    }

    /**
     * AR-2/AR-3 (plan 1326-2 Phase 1): test accessor for the descriptor-path list
     * window state (boundedness / eviction write-back assertions).
     */
    InternalListState<K, W, IN> newListWindowStateForTest() {
        return newListWindowState;
    }

    /**
     * AR-3 (plan 1326-2 Phase 1): test accessor for the element-timestamps side store.
     */
    MapState<String, List<Long>> elementTimestampsStateForTest() {
        return elementTimestampsState;
    }
}
