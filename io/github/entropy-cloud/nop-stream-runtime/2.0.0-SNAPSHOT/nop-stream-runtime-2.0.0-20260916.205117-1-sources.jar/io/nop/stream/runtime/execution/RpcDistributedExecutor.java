/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://github.com/entropy-cloud/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.execution;

import io.nop.api.core.time.CoreMetrics;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.message.IMessageService;
import io.nop.stream.core.checkpoint.CheckpointConfig;
import io.nop.stream.core.checkpoint.CheckpointIDCounter;
import io.nop.stream.core.environment.StreamExecutionResult;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.execution.DeploymentMode;
import io.nop.stream.core.execution.GraphExecutionPlan;
import io.nop.stream.core.execution.IStreamExecutionDispatcher;
import io.nop.stream.core.execution.task.Subtask;
import io.nop.stream.core.execution.plan.DeploymentPlan;
import io.nop.stream.core.execution.plan.PartitionedPlan;
import io.nop.stream.core.execution.transport.TypeRegistry;
import io.nop.stream.core.jobgraph.JobGraph;
import io.nop.stream.runtime.checkpoint.CheckpointCoordinator;
import io.nop.stream.runtime.checkpoint.storage.LocalFileCheckpointStorage;
import io.nop.stream.runtime.cluster.ClusterRegistry;
import io.nop.stream.runtime.cluster.InMemoryClusterRegistry;
import io.nop.stream.runtime.cluster.TaskAssignment;
import io.nop.stream.runtime.coordinator.JobCoordinator;
import io.nop.stream.runtime.rpc.IStreamCoordinatorRpcService;
import io.nop.stream.runtime.rpc.IStreamTaskRpcService;
import io.nop.stream.runtime.rpc.StreamControlRpcProxyFactory;
import io.nop.stream.runtime.rpc.StreamControlRpcServer;
import io.nop.stream.runtime.rpc.StreamControlRpcTopics;
import io.nop.stream.runtime.taskmanager.TaskManager;
import io.nop.stream.runtime.transport.DataPlaneMessageServiceAdapter;
import io.nop.stream.runtime.transport.IDataPlaneWireCodec;
import io.nop.stream.runtime.transport.IdentityWireCodec;
import io.nop.stream.runtime.transport.RemoteGraphExecutionPlanBuilder;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;

/**
 * Stage 39 Phase 2: distributed execution dispatcher whose control plane traverses
 * the platform RPC framework ({@link StreamControlRpcServer} +
 * {@link StreamControlRpcProxyFactory} over {@link IMessageService}) rather than direct
 * Java references.
 *
 * <p>Unlike {@link EmbeddedDistributedExecutor} (which injects in-process
 * {@code TaskManager} references directly into the {@link JobCoordinator}), this
 * dispatcher:
 * <ul>
 *   <li>exposes each {@code TaskManager} as a remote {@link IStreamTaskRpcService} on
 *       {@code nop-stream.rpc.task.{nodeId}} via a {@link StreamControlRpcServer};</li>
 *   <li>exposes the {@code JobCoordinator} as a remote
 *       {@link IStreamCoordinatorRpcService} on
 *       {@code nop-stream.rpc.coordinator.{jobId}};</li>
 *   <li>hands the coordinator a {@code Map<String, IStreamTaskRpcService>} of RPC
 *       proxies (one per nodeId), and each TaskManager an RPC proxy to the
 *       coordinator — so every control call crosses the RPC boundary;</li>
 *   <li>keeps the coordinator <b>long-lived</b>: {@link #startJob} returns a
 *       {@link DistributedJobHandle} that owns the coordinator + servers + proxies
 *       and must be {@link DistributedJobHandle#close() closed} to release them.
 *       This honours the {@code IStreamExecutionDispatcher} deferred contract
 *       ("async submit + poll dispatcher deferred to Stage 39").</li>
 * </ul>
 *
 * <p>The data plane stays in-JVM (Stage 40 wires cross-JVM data transport); the RPC
 * control-plane wiring here is what Stage 39 Phase 2 verifies.
 */
public class RpcDistributedExecutor implements IStreamExecutionDispatcher {

    private static final Logger LOG = LoggerFactory.getLogger(RpcDistributedExecutor.class);

    private final IMessageService messageService;
    private final int defaultNodeCount;
    private final long completionTimeoutSeconds;

    /**
     * Stage 40: wire-format codec applied to the data-plane view of {@link #messageService}.
     * Default identity ({@code LocalMessageService}); deployments injecting a cross-JVM
     * backend (DB / Pulsar) set the matching codec so envelopes traverse the real backend.
     */
    private IDataPlaneWireCodec dataPlaneWireCodec = IdentityWireCodec.INSTANCE;

    /**
     * Stage 42 Phase 0: when {@code true}, the coordinator deploys task logic via
     * the {@code deployTask} RPC (each TaskManager rebuilds its own invokable locally
     * from a {@link io.nop.stream.runtime.rpc.TaskDeploymentDescriptor}) instead of
     * the executor's direct {@code TaskManager.installInvokable} Java call. Default
     * {@code false} preserves the in-process fast-path; the Stage 42 multi-JVM test
     * harness and the in-process remote-deploy E2E test flip this to {@code true}.
     */
    private boolean remoteDeployMode = false;

    public RpcDistributedExecutor(IMessageService messageService) {
        this(messageService, 2, 60);
    }

    public RpcDistributedExecutor(IMessageService messageService, int defaultNodeCount, long completionTimeoutSeconds) {
        this.messageService = messageService;
        this.defaultNodeCount = defaultNodeCount;
        this.completionTimeoutSeconds = completionTimeoutSeconds;
    }

    /**
     * Stage 40: selects the wire-format codec for the data-plane backend. Use
     * {@code SysDaoWireCodec.INSTANCE} for the DB backend, {@code PulsarStringWireCodec.INSTANCE}
     * for Pulsar; the default {@code IdentityWireCodec} suits {@code LocalMessageService}.
     */
    public void setDataPlaneWireCodec(IDataPlaneWireCodec dataPlaneWireCodec) {
        this.dataPlaneWireCodec = dataPlaneWireCodec == null
                ? IdentityWireCodec.INSTANCE : dataPlaneWireCodec;
    }

    /**
     * Stage 42 Phase 0: toggles remote-deploy mode. When {@code true}, the
     * coordinator's {@code assignTasks()} calls {@code deployTask} RPC instead of
     * {@code receiveAssignment} + direct {@code installInvokable}, and
     * {@link DistributedJobHandle#installInvokablesAndRun(long)} becomes a no-op
     * for the install step (the coordinator already deployed via RPC). Used by
     * the Stage 42 in-process remote-deploy E2E test as the cross-JVM analog.
     */
    public void setRemoteDeployMode(boolean remoteDeployMode) {
        this.remoteDeployMode = remoteDeployMode;
    }

    public boolean isRemoteDeployMode() {
        return remoteDeployMode;
    }

    @Override
    public boolean supportsDeploymentMode(DeploymentMode mode) {
        return mode == DeploymentMode.DISTRIBUTED;
    }

    @Override
    public List<String> getExpectedNodeIds(PartitionedPlan partitionedPlan) {
        int nodeCount = determineNodeCount(partitionedPlan);
        List<String> nodeIds = new ArrayList<>(nodeCount);
        for (int i = 0; i < nodeCount; i++) {
            nodeIds.add("node-" + i);
        }
        return nodeIds;
    }

    /**
     * Synchronous convenience entry that runs a job to completion over the RPC control
     * plane and tears the topology down. For long-lived / control-plane-driven
     * execution use {@link #startJob} and drive the returned handle.
     */
    @Override
    public StreamExecutionResult execute(JobGraph jobGraph, PartitionedPlan partitionedPlan,
                                         DeploymentPlan deploymentPlan) throws Exception {
        long startTime = CoreMetrics.currentTimeMillis();
        String jobId = partitionedPlan.getJobId();
        DistributedJobHandle handle = startJob(jobGraph, partitionedPlan, deploymentPlan);
        try {
            handle.installInvokablesAndRun(completionTimeoutSeconds);
            long executionTime = CoreMetrics.currentTimeMillis() - startTime;
            LOG.info("RPC distributed execution completed for job {} in {}ms", jobId, executionTime);
            return new StreamExecutionResult(jobId, executionTime);
        } finally {
            handle.close();
        }
    }

    /**
     * Builds and starts the RPC control-plane topology for a job. The returned handle
     * owns the long-lived coordinator, the per-node task RPC servers, the coordinator
     * RPC server, and all RPC proxies. The coordinator is ACTIVE and ready for control
     * calls (assignments / checkpoints / fencing rotation) which traverse real RPC.
     */
    public DistributedJobHandle startJob(JobGraph jobGraph, PartitionedPlan partitionedPlan,
                                         DeploymentPlan deploymentPlan) {
        long startTime = CoreMetrics.currentTimeMillis();
        String jobId = partitionedPlan.getJobId();
        long fencingEpoch = JobCoordinator.deriveHaFencingEpoch(0L, 1L);
        LOG.info("Starting RPC distributed topology for job {} (fencing epoch {})", jobId, fencingEpoch);

        int nodeCount = determineNodeCount(partitionedPlan);
        ClusterRegistry clusterRegistry = new InMemoryClusterRegistry();

        List<TaskManager> taskManagers = new ArrayList<>(nodeCount);
        List<StreamControlRpcServer> taskServers = new ArrayList<>(nodeCount);
        List<StreamControlRpcProxyFactory> coordinatorProxies = new ArrayList<>(nodeCount);
        // coordinator → task RPC proxies (one per nodeId)
        Map<String, IStreamTaskRpcService> taskRpcProxies = new LinkedHashMap<>();

        // Everything below can fail (node startup, coordinator construction,
        // data-plane plan build, server/coordinator start, initial assignment).
        // Without teardown on failure the already-started TaskManagers / RPC
        // servers / proxies would leak (threads, subscriptions, registry
        // entries) — mirroring the try/finally discipline of
        // EmbeddedDistributedExecutor.execute.
        StreamControlRpcServer coordinatorServer = null;
        StreamControlRpcProxyFactory coordinatorProxy = null;
        JobCoordinator coordinator = null;
        try {
            startTaskNodes(jobId, fencingEpoch, nodeCount, clusterRegistry,
                    taskManagers, taskServers, coordinatorProxies, taskRpcProxies);

            CheckpointIDCounter idCounter = new CheckpointIDCounter();
            CheckpointConfig checkpointConfig = new CheckpointConfig();
            LocalFileCheckpointStorage checkpointStorage = new LocalFileCheckpointStorage(
                    GraphModelCheckpointExecutor.defaultStorageBaseDir() + "/" + jobId);
            CheckpointCoordinator checkpointCoordinator = new CheckpointCoordinator(
                    jobId, "pipeline-0", idCounter, checkpointStorage, checkpointConfig);

            coordinator = new JobCoordinator(
                    jobId, "coordinator-" + jobId, deploymentPlan,
                    clusterRegistry, checkpointCoordinator, taskRpcProxies);
            configureCoordinator(coordinator, jobGraph, fencingEpoch, checkpointStorage);

            // Coordinator side: expose IStreamCoordinatorRpcService over RPC.
            coordinatorServer = new StreamControlRpcServer(
                    "streamCoordinatorRpc@" + jobId, IStreamCoordinatorRpcService.class, coordinator,
                    messageService, StreamControlRpcTopics.coordinatorTopic(jobId));

            // Each task gets an RPC proxy to the coordinator.
            coordinatorProxy = new StreamControlRpcProxyFactory(
                    "streamCoordinatorRpc@" + jobId, IStreamCoordinatorRpcService.class,
                    messageService, StreamControlRpcTopics.coordinatorTopic(jobId));
            IStreamCoordinatorRpcService coordinatorProxyIf = coordinatorProxy.getProxy();
            for (TaskManager tm : taskManagers) {
                tm.setCoordinatorRpcService(coordinatorProxyIf);
            }

            GraphExecutionPlan plan = buildDataPlanePlan(jobGraph, deploymentPlan, fencingEpoch);

            // Start servers + coordinator (non-HA: derives epoch, goes ACTIVE).
            coordinatorServer.start();
            coordinatorProxy.start();
            coordinator.start();
            coordinator.assignTasks();

            LOG.info("RPC distributed topology ready for job {} (fencing epoch {}) in {}ms",
                    jobId, fencingEpoch, CoreMetrics.currentTimeMillis() - startTime);

            return new DistributedJobHandle(jobId, coordinator, taskManagers, taskServers,
                    coordinatorServer, coordinatorProxies, coordinatorProxy, plan, startTime, remoteDeployMode);
        } catch (RuntimeException | Error e) {
            LOG.error("RPC distributed topology startup failed for job {}; tearing down partially started "
                    + "topology", jobId, e);
            teardownOnStartupFailure(jobId, coordinator, coordinatorProxy, coordinatorServer,
                    coordinatorProxies, taskServers, taskManagers);
            throw e;
        }
    }

    /**
     * Starts one TaskManager per node and its per-node RPC wiring: the task-side
     * {@link IStreamTaskRpcService} server plus the coordinator-side proxy to it. Each
     * started component is tracked in the corresponding collector list BEFORE the next
     * start call so the failure teardown in {@link #startJob} always sees (and stops)
     * everything already started.
     */
    private void startTaskNodes(String jobId, long fencingEpoch, int nodeCount,
                                ClusterRegistry clusterRegistry,
                                List<TaskManager> taskManagers,
                                List<StreamControlRpcServer> taskServers,
                                List<StreamControlRpcProxyFactory> coordinatorProxies,
                                Map<String, IStreamTaskRpcService> taskRpcProxies) {
        for (int i = 0; i < nodeCount; i++) {
            String nodeId = "node-" + i;
            String endpoint = "rpc:" + nodeId;
            String controlTopic = "nop-stream.control." + jobId;
            TaskManager tm = new TaskManager(nodeId, endpoint, 16, messageService, clusterRegistry, controlTopic);
            // Track before start: if a later start in this iteration throws,
            // the failure teardown below must still see (and stop) this TM.
            taskManagers.add(tm);
            tm.updateFencingToken(fencingEpoch);
            tm.start();

            // Task side: expose IStreamTaskRpcService over RPC.
            StreamControlRpcServer taskServer = new StreamControlRpcServer(
                    "streamTaskRpc@" + nodeId, IStreamTaskRpcService.class, tm,
                    messageService, StreamControlRpcTopics.taskTopic(nodeId));
            taskServer.start();
            taskServers.add(taskServer);

            // Coordinator side: build an RPC proxy to this task node.
            StreamControlRpcProxyFactory taskProxy = new StreamControlRpcProxyFactory(
                    "streamTaskRpc@" + nodeId, IStreamTaskRpcService.class,
                    messageService, StreamControlRpcTopics.taskTopic(nodeId));
            taskProxy.start();
            coordinatorProxies.add(taskProxy);

            taskRpcProxies.put(nodeId, taskProxy.getProxy());
        }
    }

    /**
     * Configures an already-constructed {@link JobCoordinator}: fencing epoch, the
     * executor's auto-recovery disable, optional remote-deploy configuration, and the
     * DISTRIBUTED abort handler. Called right after construction so a throw inside still
     * leaves the caller's coordinator reference assigned for failure teardown.
     */
    private void configureCoordinator(JobCoordinator coordinator, JobGraph jobGraph, long fencingEpoch,
                                      LocalFileCheckpointStorage checkpointStorage) {
        coordinator.setFencingEpoch(fencingEpoch);
        coordinator.setAutoRecoverOnFailedReport(false);
        // Stage 42 Phase 0: when remoteDeployMode is active, inject the JobGraph
        // and checkpoint storage path so assignTasks() can build
        // TaskDeploymentDescriptors and the TaskManagers rebuild their own
        // invokables locally via deployTask RPC.
        if (remoteDeployMode) {
            coordinator.setRemoteDeployMode(true);
            coordinator.setJobGraph(jobGraph);
            coordinator.setCheckpointStoragePath(checkpointStorage.getBaseDir());
        }
        // Stage 39 Phase 3: the RPC-distributed form uses the DISTRIBUTED abort
        // path (coordinator abort handler → cancelTask RPC → remote task). The
        // embedded GraphModelCheckpointExecutor uses its LOCAL abort handler; the
        // two coexist (Phase 3 Decision).
        coordinator.registerDistributedAbortHandler();
    }

    /**
     * Builds the (in-JVM) data-plane plan keyed on the fencing epoch. Stage 40: the
     * builder gets the backend-adapted view so envelopes traverse the real backend
     * (DB / Pulsar) rather than being lost to its serialization contract. The RPC
     * control plane keeps the raw service — only the data plane is adapted.
     *
     * <p>Items 28+31 (D1(f), adjudicated IN-SCOPE): in remoteDeployMode the
     * coordinator runs ZERO subtasks — the full-matrix plan built here
     * subscribed every channel with nobody consuming it (same defect
     * family as the TM all-pair subscription). The plan is still built
     * (structure preserved), but with a ZERO subscription scope: no
     * input channel subscribes. In the in-process fast-path
     * (remoteDeployMode=false) the full-subscription semantics is
     * preserved — all subtasks run in this JVM and consume the matrix.
     */
    private GraphExecutionPlan buildDataPlanePlan(JobGraph jobGraph, DeploymentPlan deploymentPlan,
                                                  long fencingEpoch) {
        RemoteGraphExecutionPlanBuilder planBuilder = new RemoteGraphExecutionPlanBuilder(
                new DataPlaneMessageServiceAdapter(messageService, dataPlaneWireCodec),
                new TypeRegistry(), fencingEpoch);
        return planBuilder.buildRemoteOnly(jobGraph, deploymentPlan, true,
                remoteDeployMode ? java.util.Collections.emptySet() : null);
    }

    /**
     * Failure teardown of a partially started topology (mirrors the close order of
     * {@link DistributedJobHandle#close()}): coordinator, coordinator RPC proxy/server,
     * per-node task RPC proxies/servers, then the TaskManagers. Every stop is
     * individually contained so one failing stop cannot skip the rest.
     */
    private static void teardownOnStartupFailure(String jobId, JobCoordinator coordinator,
                                                 StreamControlRpcProxyFactory coordinatorProxy,
                                                 StreamControlRpcServer coordinatorServer,
                                                 List<StreamControlRpcProxyFactory> coordinatorProxies,
                                                 List<StreamControlRpcServer> taskServers,
                                                 List<TaskManager> taskManagers) {
        if (coordinator != null) {
            try {
                coordinator.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop coordinator during failure teardown for job {}", jobId, stopEx);
            }
        }
        if (coordinatorProxy != null) {
            try {
                coordinatorProxy.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop coordinator RPC proxy during failure teardown", stopEx);
            }
        }
        if (coordinatorServer != null) {
            try {
                coordinatorServer.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop coordinator RPC server during failure teardown", stopEx);
            }
        }
        for (StreamControlRpcProxyFactory p : coordinatorProxies) {
            try {
                p.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop task RPC proxy during failure teardown", stopEx);
            }
        }
        for (StreamControlRpcServer srv : taskServers) {
            try {
                srv.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop task RPC server during failure teardown", stopEx);
            }
        }
        for (TaskManager tm : taskManagers) {
            try {
                tm.stop();
            } catch (Exception stopEx) {
                LOG.error("Failed to stop task manager {} during failure teardown", tm.getNodeId(), stopEx);
            }
        }
    }

    private int determineNodeCount(PartitionedPlan partitionedPlan) {
        int maxParallelism = 1;
        for (PartitionedPlan.VertexPlan vp : partitionedPlan.getVertexPlans().values()) {
            maxParallelism = Math.max(maxParallelism, vp.getParallelism());
        }
        return Math.max(1, Math.min(defaultNodeCount, maxParallelism));
    }

    /**
     * Owns the long-lived coordinator + RPC servers + proxies for one job. Control
     * calls on {@link #getCoordinator()} traverse real RPC to the remote task nodes
     * (the coordinator's {@code IStreamTaskRpcService} map holds RPC proxies).
     */
    public static final class DistributedJobHandle implements AutoCloseable {
        private final String jobId;
        private final JobCoordinator coordinator;
        private final List<TaskManager> taskManagers;
        private final List<StreamControlRpcServer> taskServers;
        private final StreamControlRpcServer coordinatorServer;
        private final List<StreamControlRpcProxyFactory> taskProxies;
        private final StreamControlRpcProxyFactory coordinatorProxy;
        private final GraphExecutionPlan plan;
        private final long startTime;
        private final boolean remoteDeployMode;

        DistributedJobHandle(String jobId, JobCoordinator coordinator, List<TaskManager> taskManagers,
                             List<StreamControlRpcServer> taskServers, StreamControlRpcServer coordinatorServer,
                             List<StreamControlRpcProxyFactory> taskProxies,
                             StreamControlRpcProxyFactory coordinatorProxy, GraphExecutionPlan plan,
                             long startTime, boolean remoteDeployMode) {
            this.jobId = jobId;
            this.coordinator = coordinator;
            this.taskManagers = taskManagers;
            this.taskServers = taskServers;
            this.coordinatorServer = coordinatorServer;
            this.taskProxies = taskProxies;
            this.coordinatorProxy = coordinatorProxy;
            this.plan = plan;
            this.startTime = startTime;
            this.remoteDeployMode = remoteDeployMode;
        }

        public String getJobId() {
            return jobId;
        }

        public JobCoordinator getCoordinator() {
            return coordinator;
        }

        public List<TaskManager> getTaskManagers() {
            return taskManagers;
        }

        public GraphExecutionPlan getPlan() {
            return plan;
        }

        /**
         * Installs the data-plane invokables on the (RPC-reached) task nodes based on
         * the coordinator's assignments, then waits for the pipeline to drain.
         *
         * <p>Stage 42 Phase 0: when remote-deploy mode is active, the coordinator's
         * {@code assignTasks()} has already deployed task logic via {@code deployTask}
         * RPC — each TaskManager built its own invokable locally. This method skips
         * the direct {@code TaskManager.installInvokable} loop in that case and only
         * waits for completion. When remote-deploy mode is off (the in-process
         * fast-path), the legacy direct-install loop runs unchanged.
         */
        public void installInvokablesAndRun(long timeoutSeconds) throws Exception {
            if (!remoteDeployMode) {
                Map<String, List<TaskAssignment>> assignments = coordinator.getTaskAssignments();
                for (String vertexId : plan.getSortedVertexIds()) {
                    List<Subtask> subtasks = plan.getSubtasks(vertexId);
                    List<TaskAssignment> vertexAssignments = assignments.get(vertexId);
                    for (Subtask subtask : subtasks) {
                        TaskAssignment ta = findAssignment(vertexAssignments, subtask.getTaskIndex());
                        if (ta == null) {
                            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                                    "No assignment found for vertex=" + vertexId
                                            + " subtaskIndex=" + subtask.getTaskIndex()
                                            + " after coordinator.assignTasks()");
                        }
                        TaskManager targetTm = findTaskManager(taskManagers, ta.getNodeId());
                        if (targetTm == null) {
                            throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL,
                                    "No TaskManager for nodeId=" + ta.getNodeId());
                        }
                        targetTm.installInvokable(jobId, vertexId, subtask.getTaskIndex(), subtask.getInvokable());
                    }
                }
            } else {
                LOG.info("remoteDeployMode active for job {} — coordinator.assignTasks() already deployed "
                        + "task logic via deployTask RPC; skipping direct installInvokable loop", jobId);
            }
            waitForCompletion(taskManagers, timeoutSeconds);
        }

        @Override
        public void close() {
            try {
                coordinator.stop();
            } catch (Exception e) {
                LOG.error("Failed to stop coordinator for job {}", jobId, e);
            }
            for (StreamControlRpcServer srv : taskServers) {
                try {
                    srv.stop();
                } catch (Exception e) {
                    LOG.error("Failed to stop task RPC server", e);
                }
            }
            for (StreamControlRpcProxyFactory p : taskProxies) {
                try {
                    p.stop();
                } catch (Exception e) {
                    LOG.error("Failed to stop task RPC proxy", e);
                }
            }
            try {
                coordinatorServer.stop();
            } catch (Exception e) {
                LOG.error("Failed to stop coordinator RPC server", e);
            }
            try {
                coordinatorProxy.stop();
            } catch (Exception e) {
                LOG.error("Failed to stop coordinator RPC proxy", e);
            }
            for (TaskManager tm : taskManagers) {
                try {
                    tm.stop();
                } catch (Exception e) {
                    LOG.error("Failed to stop task manager {}", tm.getNodeId(), e);
                }
            }
        }

        private TaskAssignment findAssignment(List<TaskAssignment> assignments, int subtaskIndex) {
            if (assignments == null) {
                return null;
            }
            for (TaskAssignment ta : assignments) {
                if (ta.getSubtaskIndex() == subtaskIndex) {
                    return ta;
                }
            }
            return null;
        }

        private TaskManager findTaskManager(List<TaskManager> taskManagers, String nodeId) {
            for (TaskManager tm : taskManagers) {
                if (tm.getNodeId().equals(nodeId)) {
                    return tm;
                }
            }
            return null;
        }

        private void waitForCompletion(List<TaskManager> taskManagers, long timeoutSeconds) throws InterruptedException {
            long deadline = CoreMetrics.currentTimeMillis() + timeoutSeconds * 1000;
            while (CoreMetrics.currentTimeMillis() < deadline) {
                int totalRunning = 0;
                for (TaskManager tm : taskManagers) {
                    totalRunning += tm.getRunningTaskCount();
                }
                if (totalRunning == 0) {
                    return;
                }
                Thread.sleep(100);
            }
            throw new StreamException(ERR_STREAM_INVALID_STATE)
                    .param(ARG_DETAIL, "Timed out waiting for tasks to complete. Still running: "
                            + taskManagers.stream().mapToInt(TaskManager::getRunningTaskCount).sum());
        }
    }
}
