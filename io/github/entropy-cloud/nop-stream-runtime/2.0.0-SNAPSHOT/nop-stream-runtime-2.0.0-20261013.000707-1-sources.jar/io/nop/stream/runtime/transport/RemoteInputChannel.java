/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.transport;

import io.nop.api.core.time.CoreMetrics;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.message.IMessageConsumeContext;
import io.nop.api.core.message.IMessageConsumer;
import io.nop.api.core.message.IMessageService;
import io.nop.api.core.message.IMessageSubscription;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.execution.InputChannel;
import io.nop.stream.core.execution.ResultPartition;
import io.nop.stream.core.execution.transport.StreamElementCodec;
import io.nop.stream.core.execution.transport.StreamMessageEnvelope;
import io.nop.stream.core.streamrecord.StreamElement;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_TOPIC;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_TIMEOUT_MS;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CHANNEL_OVERFLOW;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CHANNEL_TIMEOUT;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_STATE_ERROR;

/**
 * Consumer-side channel that receives data from a {@link RemoteResultPartition}
 * via {@link IMessageService}.
 *
 * <p>Subscribes to a message service topic and decodes incoming
 * {@link StreamMessageEnvelope} instances back into {@link StreamElement}.
 * Decoded elements are placed into a local {@link LinkedBlockingQueue} for
 * consumption by the task thread.
 *
 * <p><strong>Fencing:</strong> Only envelopes whose monotonic fencing epoch
 * ({@code epochId}) matches the expected value are accepted. Stale messages are
 * discarded with a debug log (explicit, observable — not silently swallowed).
 * The single long epoch key
 * encodes both leadership switch and same-leader recovery (see
 * {@code JobCoordinator.deriveHaFencingEpoch}), so both fencing invariants hold.
 *
 * <p><strong>Buffer pool exclusion (intentional)</strong>: this class constructs
 * a dummy {@code super(new ResultPartition(1))} and uses its own local
 * {@link LinkedBlockingQueue}. It does not consume the per-job {@code IBufferPool}.
 * Cross-JVM producer-side bound is the responsibility of the {@code IMessageService}
 * backend. This exclusion is by design and documented in
 * {@code 01-architecture-baseline.md} §六, not an accidental omission.
 *
 * <p><strong>Lifecycle:</strong>
 * <ol>
 *   <li>Constructor subscribes to the topic (or constructs without subscribing —
 *       subscription-scope convergence: reading such a channel fails fast as a wiring error)</li>
 *   <li>{@link #read()} / {@link #read(long, TimeUnit)} consume from the local queue</li>
 *   <li>When an END_OF_STREAM control message is received, the channel is marked as finished</li>
 *   <li>A full queue with zero consumer progress for the
 *       bounded enqueue window fails the channel typed
 *       (ERR_STREAM_CHANNEL_OVERFLOW) — the dispatch thread is never blocked
 *       indefinitely and the failure is observable/recoverable</li>
 *   <li>{@link #close()} cancels the subscription</li>
 * </ol>
 */
public class RemoteInputChannel extends InputChannel implements WireDecodeFailureAware {

    private static final Logger LOG = LoggerFactory.getLogger(RemoteInputChannel.class);

    private static final int DEFAULT_QUEUE_CAPACITY = 1024;

    /**
     * Default bounded enqueue wait. A full queue with ZERO
     * consumer progress for this whole window is a stalled downstream — the
     * channel fails typed (ERR_STREAM_CHANNEL_OVERFLOW) instead of blocking the
     * message-backend dispatch thread forever. Healthy slow consumers never hit
     * it: any slot freed within the window lets the offer succeed (bounded wait
     * degenerates to per-record short waits = dispatch-level backpressure).
     * 10s keeps a safety margin against the 60s per-task liveness timeout and
     * the 30s lease expiry threshold (lease renewal itself runs on a dedicated
     * thread that does not traverse the message backend).
     */
    static final long DEFAULT_ENQUEUE_OFFER_TIMEOUT_MS = 10_000L;

    /** Sentinel placed into the queue to signal end-of-stream. */
    private static final StreamElement END_OF_STREAM = new StreamElement() {};

    private final LinkedBlockingQueue<StreamElement> queue;
    private final String topic;
    private final long expectedEpochId;
    private final IMessageSubscription subscription;
    private volatile boolean finished;
    private volatile Throwable decodeError;

    /**
     * Bounded enqueue wait in ms (see
     * {@link #DEFAULT_ENQUEUE_OFFER_TIMEOUT_MS}). A full queue with zero
     * consumer progress for this whole window trips the typed overflow
     * failure instead of blocking the dispatch thread indefinitely.
     */
    private final long enqueueOfferTimeoutMs;

    /**
     * Typed overflow failure set when a bounded enqueue wait
     * expired with zero consumer progress. Same observability pattern as
     * {@link #decodeError}: the reader thread surfaces it as a typed
     * StreamException (it must NEVER be surfaced as a normal end-of-stream —
     * that would silently acknowledge truncated data).
     */
    private volatile Throwable overflowError;

    /**
     * Whether this channel's subscription was activated at
     * construction. Scope-converged (per-subtask / zero-scope)
     * builds construct channels WITHOUT subscribing; they exist only to
     * mirror the full plan structure. Reading such a channel is a wiring error
     * and fails fast with a typed error instead of blocking forever.
     */
    private final boolean subscriptionActive;

    /**
     * Channel liveness (inactivity) timeout in ms. When {@code > 0}, {@link #read()}
     * / {@link #read(long, TimeUnit)} check that <em>some</em> accepted message
     * (data, barrier, watermark, or control) has arrived within this window; otherwise
     * the producer is presumed dead / partitioned and the channel fails fast with
     * {@link ERR_STREAM_CHANNEL_TIMEOUT}. {@code <= 0} disables timeout detection
     * (back-compat default). This is faster than the coarse lease timeout
     * (~15-20s).
     */
    private final long channelTimeoutMs;

    /**
     * Monotonic timestamp of the last <em>accepted</em> message of any
     * kind. Updated by {@link EnvelopeConsumer} only AFTER the fencing-epoch
     * filter passes, so a wrong-epoch message never refreshes liveness. Volatile:
     * writer is the message-service dispatch thread, reader is the task thread.
     */
    private volatile long lastReceivedTime;

    /**
     * The queue-depth gauge holder this channel is bound to
     * (nullable — construct-only channels never bind). Package-private: owned by
     * {@link ChannelQueueGauges}; {@link #close()} releases the binding so the
     * gauge reads 0 instead of freezing on a closed channel's residual queue.
     */
    volatile AtomicReference<RemoteInputChannel> queueGaugeHolder;

    /**
     * Creates a RemoteInputChannel that subscribes to the given topic.
     *
     * @param messageService  the message service to subscribe to
     * @param topic           the topic to subscribe to
     * @param expectedEpochId expected monotonic fencing epoch for message filtering
     *                        (the single long fencing key)
     */
    public RemoteInputChannel(IMessageService messageService,
                              String topic,
                              long expectedEpochId) {
        this(messageService, topic, expectedEpochId, DEFAULT_QUEUE_CAPACITY, 0L);
    }

    /**
     * Creates a RemoteInputChannel with a custom queue capacity.
     *
     * @param messageService  the message service to subscribe to
     * @param topic           the topic to subscribe to
     * @param expectedEpochId expected monotonic fencing epoch for message filtering
     * @param queueCapacity   capacity of the local element queue
     */
    public RemoteInputChannel(IMessageService messageService,
                              String topic,
                              long expectedEpochId,
                              int queueCapacity) {
        this(messageService, topic, expectedEpochId, queueCapacity, 0L);
    }

    /**
     * Creates a RemoteInputChannel with liveness timeout detection.
     *
     * <p>When {@code channelTimeoutMs > 0}, {@link #read()} / {@link #read(long,
     * TimeUnit)} fail fast with {@link ERR_STREAM_CHANNEL_TIMEOUT} if no message
     * (data, barrier, watermark, or control) is accepted within the window.
     * The liveness clock starts at subscription time, so a producer that never
     * sends anything is detected within one window.
     *
     * @param messageService   the message service to subscribe to
     * @param topic            the topic to subscribe to
     * @param expectedEpochId  expected monotonic fencing epoch for message filtering
     * @param queueCapacity    capacity of the local element queue
     * @param channelTimeoutMs channel heartbeat timeout in ms; {@code <= 0} disables
     */
    public RemoteInputChannel(IMessageService messageService,
                              String topic,
                              long expectedEpochId,
                              int queueCapacity,
                              long channelTimeoutMs) {
        this(messageService, topic, expectedEpochId, queueCapacity, channelTimeoutMs,
                DEFAULT_ENQUEUE_OFFER_TIMEOUT_MS, true);
    }

    /**
     * Full-form constructor with subscription activation
     * control and bounded enqueue wait.
     *
     * @param messageService         the message service to subscribe to (when
     *                               {@code subscribe} is {@code true})
     * @param topic                  the topic this channel maps to
     * @param expectedEpochId        expected monotonic fencing epoch for message filtering
     * @param queueCapacity          capacity of the local element queue
     * @param channelTimeoutMs       channel heartbeat timeout in ms; {@code <= 0} disables
     * @param enqueueOfferTimeoutMs  bounded enqueue wait in ms; a full queue with zero
     *                               consumer progress for this window trips the typed
     *                               overflow failure
     * @param subscribe              {@code true} = subscribe at construction (existing
     *                               full-subscription semantics); {@code false} = construct
     *                               WITHOUT subscribing (subscription-scope convergence:
     *                               the channel only mirrors the plan structure; reading it
     *                               fails fast as a wiring error)
     */
    public RemoteInputChannel(IMessageService messageService,
                              String topic,
                              long expectedEpochId,
                              int queueCapacity,
                              long channelTimeoutMs,
                              long enqueueOfferTimeoutMs,
                              boolean subscribe) {
        // Pass a dummy partition to the parent; we override all read methods
        super(new ResultPartition(1));
        this.queue = new LinkedBlockingQueue<>(queueCapacity);
        this.topic = topic;
        this.expectedEpochId = expectedEpochId;
        this.finished = false;
        this.channelTimeoutMs = channelTimeoutMs;
        this.enqueueOfferTimeoutMs = enqueueOfferTimeoutMs;
        this.lastReceivedTime = CoreMetrics.currentTimeMillis();
        this.subscriptionActive = subscribe;

        if (subscribe) {
            this.subscription = messageService.subscribe(topic, new EnvelopeConsumer());
        } else {
            // Constructed-but-not-subscribed channel. Producers keep their
            // fan-out capability (the send side never subscribes); this channel
            // simply never joins the delivery surface.
            this.subscription = null;
            LOG.info("RemoteInputChannel constructed WITHOUT subscription (scope-converged) "
                    + "for topic={}, epochId={}", topic, expectedEpochId);
            return;
        }
        LOG.info("RemoteInputChannel subscribed to topic={}, epochId={}, channelTimeoutMs={}, "
                + "enqueueOfferTimeoutMs={}", topic, expectedEpochId, channelTimeoutMs, enqueueOfferTimeoutMs);
    }

    /**
     * Whether this channel is an active subscriber. Test and
     * diagnostic hook for subscription-scope assertions.
     */
    public boolean isSubscriptionActive() {
        return subscriptionActive;
    }

    /**
     * Reads the next element from the local queue (blocking).
     *
     * @return the next element, or null if end-of-stream
     * @throws InterruptedException if interrupted while waiting
     */
    @Override
    public StreamElement read() throws InterruptedException {
        checkReadable();
        checkChannelError();
        // Liveness-timeout detection (piggybacks on the read
        // path — no dedicated timer thread per channel).
        checkChannelTimeout();
        StreamElement element = queue.take();
        // An overflow/decode failure may have been flagged
        // while this reader was blocked in take(); the EOS sentinel placed by
        // the failure path wakes us up — surface the typed error, never a
        // clean end-of-stream.
        checkChannelError();
        if (element == END_OF_STREAM) {
            return null;
        }
        return element;
    }

    /**
     * Reads the next element with a timeout.
     *
     * @param timeout maximum wait time
     * @param unit    time unit
     * @return the next element, or null on timeout / end-of-stream
     * @throws InterruptedException if interrupted while waiting
     */
    @Override
    public StreamElement read(long timeout, TimeUnit unit) throws InterruptedException {
        checkReadable();
        checkChannelError();
        // Liveness-timeout detection (piggybacks on the read path).
        checkChannelTimeout();
        StreamElement element = queue.poll(timeout, unit);
        // See read() — a flagged failure must surface as the
        // typed error even when the wake-up element is the EOS sentinel.
        checkChannelError();
        if (element == null) {
            return null;
        }
        if (element == END_OF_STREAM) {
            return null;
        }
        return element;
    }

    /**
     * Returns whether the upstream producer has finished sending.
     */
    @Override
    public boolean isFinished() {
        return finished;
    }

    /**
     * Has the channel exceeded its liveness timeout? {@code true} when
     * detection is enabled ({@code channelTimeoutMs > 0}), the channel is not
     * finished, no decode error has occurred, and no accepted message has arrived
     * within {@code channelTimeoutMs}. An explicit {@link
     * StreamMessageEnvelope#CONTROL_END_OF_STREAM} sets {@code finished=true} and
     * therefore suppresses timeout (EOS is a normal, distinguishable completion).
     */
    public boolean isChannelTimedOut() {
        if (channelTimeoutMs <= 0 || finished || decodeError != null) {
            return false;
        }
        return (CoreMetrics.currentTimeMillis() - lastReceivedTime) > channelTimeoutMs;
    }

    /**
     * Throws {@link ERR_STREAM_CHANNEL_TIMEOUT} if {@link
     * #isChannelTimedOut()} holds. Invoked at the top of every {@link #read()}
     * / {@link #read(long, TimeUnit)} so the task thread fails fast instead of
     * blocking on an empty queue forever.
     */
    private void checkChannelTimeout() {
        if (isChannelTimedOut()) {
            throw new StreamException(ERR_STREAM_CHANNEL_TIMEOUT)
                    .param(ARG_TIMEOUT_MS, channelTimeoutMs);
        }
    }

    private void checkDecodeError() {
        if (decodeError != null) {
            throw new StreamException(ERR_STREAM_STATE_ERROR, decodeError)
                    .param(ARG_DETAIL, "Decode error in RemoteInputChannel");
        }
    }

    /**
     * Surfaces the first flagged channel failure (decode or
     * overflow) as a typed StreamException. Overflow carries its own error
     * code so recovery/ops can distinguish "downstream stalled" from "decode
     * corruption".
     */
    private void checkChannelError() {
        if (overflowError != null) {
            throw new StreamException(ERR_STREAM_CHANNEL_OVERFLOW, overflowError)
                    .param(ARG_TIMEOUT_MS, enqueueOfferTimeoutMs)
                    .param(ARG_TOPIC, topic);
        }
        checkDecodeError();
    }

    /**
     * Reading a channel that was constructed without a
     * subscription is a wiring error (scope-converged channels exist only to
     * mirror the plan structure). Fail fast with a typed error instead of
     * blocking on an empty queue forever (guide #24 — no silent no-op).
     */
    private void checkReadable() {
        if (!subscriptionActive) {
            throw new StreamException(ERR_STREAM_INVALID_STATE)
                    .param(ARG_DETAIL, "RemoteInputChannel is not subscribed (scope-converged, "
                            + "construct-only) — reading it is a wiring error");
        }
    }

    /**
     * Returns the configured channel liveness timeout in ms
     * ({@code <= 0} means disabled).
     */
    public long getChannelTimeoutMs() {
        return channelTimeoutMs;
    }

    /**
     * Returns the monotonic timestamp of the last accepted message.
     * Test/diagnostic hook.
     */
    public long getLastReceivedTime() {
        return lastReceivedTime;
    }

    /**
     * Drains this channel's local
     * {@link LinkedBlockingQueue} (excluding the end-of-stream sentinel) and
     * returns the in-flight records. Override of {@link InputChannel#captureInFlightData}
     * because {@code RemoteInputChannel} does not consume its dummy
     * {@link ResultPartition}'s queue.
     *
     * @param barrierReceived whether this channel has delivered its barrier
     * @return the drained in-flight elements (possibly empty); never null
     */
    @Override
    public java.util.List<StreamElement> captureInFlightData(boolean barrierReceived) {
        java.util.List<StreamElement> drained = new java.util.ArrayList<>();
        StreamElement e;
        while ((e = queue.poll()) != null) {
            if (e == END_OF_STREAM) {
                // Re-place the sentinel so a subsequent read still observes EOS.
                // At least one slot was freed by the poll above, but a concurrent
                // producer may have refilled it: verify the offer landed so the
                // sentinel is never silently lost.
                if (!queue.offer(END_OF_STREAM)) {
                    flagOverflow("captureInFlightData could not re-place the EOS sentinel (queue full)");
                }
                break;
            }
            drained.add(e);
        }
        return drained;
    }

    /**
     * Injects previously captured
     * in-flight records at the front of the local queue so they are processed
     * before any newly delivered upstream records. Override of
     * {@link InputChannel#injectElements} for the remote channel's local queue.
     *
     * <p>Every enqueue is verified: recovery data that does not fit the queue is
     * NEVER silently dropped — the channel is flagged with a typed overflow
     * failure (observable at the next {@link #read()} entry) and a typed
     * exception is thrown so the recovery path fails loudly.
     */
    @Override
    public void injectElements(java.util.List<StreamElement> elements) {
        if (elements == null || elements.isEmpty()) {
            return;
        }
        // Drain current contents (preserve EOS sentinel if present).
        java.util.List<StreamElement> existing = new java.util.ArrayList<>();
        boolean sawEos = false;
        StreamElement e;
        while ((e = queue.poll()) != null) {
            if (e == END_OF_STREAM) {
                sawEos = true;
                break;
            }
            existing.add(e);
        }
        // Replayed in-flight records first, then existing content, then EOS.
        // Each offer is checked: dropping recovery data silently would corrupt
        // exactly-once replay semantics (guide #24 — no silent no-op).
        for (StreamElement injected : elements) {
            if (!queue.offer(injected)) {
                flagOverflow("injectElements could not enqueue a replayed in-flight record (queue full)");
                throw new StreamException(ERR_STREAM_CHANNEL_OVERFLOW)
                        .param(ARG_TOPIC, topic)
                        .param(ARG_DETAIL, "Recovery injection exceeded the channel queue capacity");
            }
        }
        for (StreamElement old : existing) {
            if (!queue.offer(old)) {
                flagOverflow("injectElements could not re-enqueue existing buffered content (queue full)");
                throw new StreamException(ERR_STREAM_CHANNEL_OVERFLOW)
                        .param(ARG_TOPIC, topic)
                        .param(ARG_DETAIL, "Recovery injection exceeded the channel queue capacity");
            }
        }
        if (sawEos && !queue.offer(END_OF_STREAM)) {
            flagOverflow("injectElements could not re-place the EOS sentinel (queue full)");
        }
    }

    /**
     * Cancels the message subscription and releases resources. Idempotent.
     *
     * <p>If the EOS sentinel cannot be enqueued because the queue is full, the
     * channel is flagged with a typed overflow failure so a reader that is still
     * draining buffered content fails typed at its next {@link #read()} entry
     * instead of blocking forever on a finished, permanently empty queue.
     */
    public void close() {
        if (subscription != null && !subscription.isCancelled()) {
            subscription.cancel();
        }
        // Release the queue-gauge binding FIRST so the gauge stops
        // reporting this channel's residual queue (holder → null ⇒ 0), never a
        // frozen post-close value.
        ChannelQueueGauges.release(this);
        // Ensure readers can unblock
        if (!finished) {
            finished = true;
            enqueueTerminalSentinel();
        }
    }

    /**
     * Offers the end-of-stream sentinel and guarantees the outcome is observed:
     * when the queue is momentarily full, the channel is flagged with a typed
     * overflow failure so the reader surfaces it at its next {@link #read()}
     * entry (it must never wait forever on a finished channel).
     */
    private void enqueueTerminalSentinel() {
        if (queue.offer(END_OF_STREAM)) {
            return;
        }
        flagOverflow("could not enqueue the EOS sentinel (queue full) - reader unblocked via typed failure");
    }

    /**
     * Flags a typed overflow failure (once) so the next {@link #read()} entry
     * throws {@link ERR_STREAM_CHANNEL_OVERFLOW} instead of the channel silently
     * losing data or a reader blocking forever. Never throws by itself.
     */
    private void flagOverflow(String detail) {
        if (overflowError == null) {
            overflowError = new IllegalStateException(detail + " on topic=" + topic);
        }
        LOG.error("RemoteInputChannel overflow on topic={}: {}", topic, detail);
    }

    /**
     * Returns the current number of elements waiting in the local queue.
     */
    public int queueSize() {
        return queue.size();
    }

    /**
     * Binds this channel to its queue-depth gauge holder (see
     * {@link ChannelQueueGauges}). Package-private — invoked only by the gauge
     * registry helper at subscription time.
     */
    void bindQueueGaugeHolder(AtomicReference<RemoteInputChannel> holder) {
        this.queueGaugeHolder = holder;
    }

    /**
     * Whether the bounded enqueue wait expired with zero
     * consumer progress (typed overflow failure flagged). Observable
     * diagnostic hook — the failure is never silent.
     */
    public boolean isOverflowed() {
        return overflowError != null;
    }

    /**
     * The configured bounded enqueue wait in ms.
     */
    public long getEnqueueOfferTimeoutMs() {
        return enqueueOfferTimeoutMs;
    }

    /**
     * {@inheritDoc}
     *
     * <p>A wire-level decode failure (the {@code DataPlaneMessageServiceAdapter}
     * could not reconstruct the envelope at all) is corruption or version skew,
     * not fencing — stale-epoch messages are valid envelopes filtered by the
     * epoch check above. The channel therefore fails typed exactly like an
     * element-level decode failure: the reader must never observe a silent gap
     * in its data stream.
     */
    @Override
    public void onWireDecodeFailure(String topic, Object message, Throwable cause) {
        if (finished) {
            return;
        }
        decodeError = (cause != null) ? cause
                : new IllegalStateException("Undecodable wire message on topic=" + topic + ": " + message);
        finished = true;
        enqueueTerminalSentinel();
        LOG.error("Wire-level decode failure on topic={} - failing channel typed "
                + "(a data-plane consumer must never silently lose a record)", topic, cause);
    }

    /**
     * IMessageConsumer that decodes envelopes and puts elements into the local queue.
     * Implements {@link WireDecodeFailureAware} (delegating to the channel) so the
     * {@link DataPlaneMessageServiceAdapter} can surface wire-level decode failures
     * as typed channel failures.
     */
    private class EnvelopeConsumer implements IMessageConsumer, WireDecodeFailureAware {

        @Override
        public void onWireDecodeFailure(String topic, Object message, Throwable cause) {
            RemoteInputChannel.this.onWireDecodeFailure(topic, message, cause);
        }

        @Override
        public Object onMessage(String topic, Object message, IMessageConsumeContext context) {
            if (finished) {
                return null;
            }

            if (!(message instanceof StreamMessageEnvelope)) {
                LOG.warn("Ignoring non-envelope message on topic={}: {}", topic, message);
                return null;
            }

            StreamMessageEnvelope envelope = (StreamMessageEnvelope) message;

            // Single monotonic long epoch fencing comparison: the one long key
            // encodes both leadership switch and same-leader recovery, so both
            // fencing invariants hold.
            if (envelope.getEpochId() != expectedEpochId) {
                LOG.debug("Discarding stale message: expected epochId={}, got={}",
                        expectedEpochId, envelope.getEpochId());
                return null;
            }

            // Any message that passed the fencing filter counts as
            // producer liveness. Refresh BEFORE branching on type so data,
            // barrier, watermark and control messages all reset the timeout
            // window. A wrong-epoch message (handled above) never reaches here,
            // so stale traffic does NOT count as liveness (fencing invariant).
            lastReceivedTime = CoreMetrics.currentTimeMillis();

            // Handle control messages
            if (StreamMessageEnvelope.TYPE_CONTROL.equals(envelope.getType())) {
                Object payload = envelope.getPayload();
                if (StreamMessageEnvelope.CONTROL_END_OF_STREAM.equals(payload)) {
                    finished = true;
                    enqueueTerminalSentinel();
                    return null;
                }
                // Unknown control payload: explicit, observable — not silently swallowed.
                LOG.warn("Ignoring unknown control payload on topic={}: {}", topic, payload);
                return null;
            }

            // Decode the element
            try {
                StreamElement element = StreamElementCodec.decode(envelope);
                // re-check finished flag after decode to avoid race with close()
                if (!finished) {
                    // Bounded enqueue wait: a plain
                    // queue.put(element) blocks FOREVER once the queue is
                    // full — under a shared dispatch loop (e.g. the polling
                    // JDBC backend's 2-thread pool serving data AND control
                    // topics) two dead channels stalled every delivery on the
                    // TaskManager. A full queue with zero consumer progress
                    // for the whole window is a stalled downstream: fail the
                    // channel typed (observable, recoverable) instead. Healthy
                    // slow consumers never trip this — any freed slot within
                    // the window lets the offer succeed (dispatch-level
                    // backpressure is preserved).
                    if (!queue.offer(element, enqueueOfferTimeoutMs, TimeUnit.MILLISECONDS)) {
                        overflowError = new IllegalStateException(
                                "Enqueue offer timed out after " + enqueueOfferTimeoutMs
                                        + "ms with a full queue (no consumer progress) on topic=" + topic);
                        finished = true;
                        enqueueTerminalSentinel();
                        LOG.error("RemoteInputChannel enqueue overflow on topic={}: queue full with no "
                                + "consumer progress for {}ms — failing channel typed (downstream stalled); "
                                + "recovery re-subscription replays from the backend", topic,
                                enqueueOfferTimeoutMs);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                decodeError = e;
                finished = true;
                enqueueTerminalSentinel();
                LOG.warn("Interrupted while enqueueing decoded element", e);
            } catch (Exception e) {
                decodeError = e;
                finished = true;
                enqueueTerminalSentinel();
                LOG.error("Failed to decode envelope on topic={}", topic, e);
            }

            return null;
        }
    }
}
