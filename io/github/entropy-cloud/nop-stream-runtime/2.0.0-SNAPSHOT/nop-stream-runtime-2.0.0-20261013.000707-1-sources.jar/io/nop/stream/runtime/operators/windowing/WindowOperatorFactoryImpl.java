/*
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.operators.windowing;

import io.nop.stream.core.common.functions.AggregateFunction;
import io.nop.stream.core.common.functions.KeySelector;
import io.nop.stream.core.common.functions.ProcessWindowFunction;
import io.nop.stream.core.common.functions.ReduceFunction;
import io.nop.stream.core.common.functions.WindowFunction;
import io.nop.stream.core.common.typeutils.TypeSerializer;
import io.nop.stream.core.util.OutputTag;
import io.nop.stream.core.exceptions.NopStreamErrors;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.operators.IWindowOperatorFactory;
import io.nop.stream.core.operators.OneInputStreamOperator;
import io.nop.stream.core.windowing.assigners.WindowAssigner;
import io.nop.stream.core.windowing.evictors.Evictor;
import io.nop.stream.core.windowing.triggers.Trigger;
import io.nop.stream.core.windowing.windows.GlobalWindow;
import io.nop.stream.core.windowing.windows.TimeWindow;
import io.nop.stream.core.windowing.windows.Window;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_SERIALIZATION;

public class WindowOperatorFactoryImpl implements IWindowOperatorFactory {

    private static final long serialVersionUID = 1L;

    private static final org.slf4j.Logger LOG =
            org.slf4j.LoggerFactory.getLogger(WindowOperatorFactoryImpl.class);

    @Override
    public <IN, ACC, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createAggregateOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            AggregateFunction<IN, ACC, OUT> aggregateFunction,
            Class<ACC> accumulatorType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass) {
        return createAggregateOperator(windowAssigner, trigger, evictor, allowedLateness,
                aggregateFunction, accumulatorType, (Class<IN>) (Class<?>) Object.class,
                keySelector, keyClass);
    }

    /**
     * F-05 (plan 1326-2 Phase 1): aggregate with explicit IN element type. The evictor
     * branch buffers raw IN elements in a ListState; the element type flows into the
     * descriptor so the RocksDB backend and Memory-JSON restore materialize real beans
     * instead of LinkedHashMaps.
     */
    @Override
    public <IN, ACC, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createAggregateOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            AggregateFunction<IN, ACC, OUT> aggregateFunction,
            Class<ACC> accumulatorType,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass, null);
        warnIfUninferableElementType("aggregate", elementType, evictor != null);
        return builder.aggregate(aggregateFunction, inferAccumulatorType(aggregateFunction, accumulatorType),
                elementType);
    }

    /**
     * The aggregate API passes {@code Object.class} as the accumulator type
     * (generic erasure at the WindowedStreamImpl call-site). A generic
     * Object-typed accumulator breaks the RocksDB state read path (the DB value
     * round-trip deserializes via the descriptor's valueType: a {@code long[]}
     * accumulator comes back as an ArrayList and the user function's {@code add}
     * ClassCastExceptions) and records an unusable snapshot valueType/schema
     * checksum. Infer the real accumulator type from the live function's
     * {@code createAccumulator()} when the recorded type is the generic
     * {@code Object}; functions that return {@code null} (e.g. the
     * reduce-function wrapper) keep the recorded type (JSON-native accumulators
     * work either way).
     */
    @SuppressWarnings("unchecked")
    private static <ACC> Class<ACC> inferAccumulatorType(AggregateFunction<?, ACC, ?> function, Class<ACC> recordedType) {
        if (recordedType != Object.class || function == null) {
            return recordedType;
        }
        try {
            ACC accumulator = function.createAccumulator();
            if (accumulator != null) {
                return (Class<ACC>) accumulator.getClass();
            }
        } catch (Exception e) {
            // Keep the recorded (generic) type.
        }
        return recordedType;
    }

    @Override
    public <IN, K, W extends Window>
    OneInputStreamOperator<IN, IN> createReduceOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            ReduceFunction<IN> reduceFunction,
            Class<IN> valueType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass, null);
        warnIfUninferableElementType("reduce", valueType, evictor != null);
        return builder.reduce(reduceFunction, valueType);
    }

    @Override
    public <IN, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createApplyOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            WindowFunction<IN, OUT, K, W> windowFunction,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass, null);
        warnIfUninferableElementType("apply", elementType, true);
        return builder.apply(windowFunction, elementType);
    }

    @Override
    public <IN, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createProcessOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            ProcessWindowFunction<IN, OUT, K, W> processWindowFunction,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass, null);
        warnIfUninferableElementType("process", elementType, true);
        return builder.process(processWindowFunction, elementType);
    }

    // ------------------------------------------------------------------
    // G-2+09e① (plan 369 Phase 2): late-data side output aware variants —
    // the OutputTag configured via WindowedStream#sideOutputLateData reaches
    // WindowOperatorBuilder.lateDataOutputTag (previously an orphan setter)
    // and from there the WindowOperator's late-data emission branch.
    // ------------------------------------------------------------------

    @Override
    public <IN, ACC, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createAggregateOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            AggregateFunction<IN, ACC, OUT> aggregateFunction,
            Class<ACC> accumulatorType,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass,
            OutputTag<IN> lateDataOutputTag) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass,
                lateDataOutputTag);
        warnIfUninferableElementType("aggregate", elementType, evictor != null);
        return builder.aggregate(aggregateFunction, inferAccumulatorType(aggregateFunction, accumulatorType),
                elementType);
    }

    @Override
    public <IN, K, W extends Window>
    OneInputStreamOperator<IN, IN> createReduceOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            ReduceFunction<IN> reduceFunction,
            Class<IN> valueType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass,
            OutputTag<IN> lateDataOutputTag) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass,
                lateDataOutputTag);
        warnIfUninferableElementType("reduce", valueType, evictor != null);
        return builder.reduce(reduceFunction, valueType);
    }

    @Override
    public <IN, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createApplyOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            WindowFunction<IN, OUT, K, W> windowFunction,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass,
            OutputTag<IN> lateDataOutputTag) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass,
                lateDataOutputTag);
        warnIfUninferableElementType("apply", elementType, true);
        return builder.apply(windowFunction, elementType);
    }

    @Override
    public <IN, OUT, K, W extends Window>
    OneInputStreamOperator<IN, OUT> createProcessOperator(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            ProcessWindowFunction<IN, OUT, K, W> processWindowFunction,
            Class<IN> elementType,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass,
            OutputTag<IN> lateDataOutputTag) {
        WindowOperatorBuilder<IN, K, W> builder = configureBuilder(
                windowAssigner, trigger, evictor, allowedLateness, keySelector, keyClass,
                lateDataOutputTag);
        warnIfUninferableElementType("process", elementType, true);
        return builder.process(processWindowFunction, elementType);
    }

    /**
     * Shared builder setup for all create* variants (element/aggregate paths differ
     * only in the builder chain head): assigns assigner/trigger/evictor/lateness/key
     * configuration plus the inferred serializers, and (tag-aware variants only) the
     * late-data output tag.
     */
    private <IN, K, W extends Window> WindowOperatorBuilder<IN, K, W> configureBuilder(
            WindowAssigner<? super IN, W> windowAssigner,
            Trigger<? super IN, ? super W> trigger,
            Evictor<? super IN, W> evictor,
            long allowedLateness,
            KeySelector<IN, K> keySelector,
            Class<K> keyClass,
            OutputTag<IN> lateDataOutputTag) {
        WindowOperatorBuilder<IN, K, W> builder = new WindowOperatorBuilder<>();
        builder.windowAssigner(windowAssigner)
               .trigger(trigger)
               .evictor(evictor)
               .allowedLateness(allowedLateness)
               .keySelector(keySelector)
               .keyClass(keyClass)
               .keySerializer(createDummySerializer(keyClass))
               .windowSerializer(inferWindowSerializer(windowAssigner));
        if (lateDataOutputTag != null) {
            builder.lateDataOutputTag(lateDataOutputTag);
        }
        return builder;
    }

    /**
     * F-05 No-Silent guard (plan 1326-2 Phase 1): when the window element type stays
     * {@code Object.class} (stream built with {@code UnknownTypeInformation}), bean
     * elements come back as LinkedHashMap on the RocksDB backend and after a
     * Memory-JSON checkpoint restore. Warn instead of failing silently.
     */
    private static void warnIfUninferableElementType(String operation, Class<?> elementType,
                                                     boolean listStateBacked) {
        if (listStateBacked && elementType == Object.class) {
            LOG.warn("Window {} operator created with an uninferable element type (Object.class): "
                            + "bean elements will deserialize as LinkedHashMap on the RocksDB backend "
                            + "and after Memory-JSON checkpoint restore. Provide a typed stream "
                            + "(TypeInformation) upstream to fix this.",
                    operation);
        }
    }

    /**
     * Placeholder key serializer used only when no real
     * {@link TypeSerializer} is registered for the key class. The current
     * production paths never invoke copy/createInstance on it (the audit found
     * zero live call sites), and the contract is now honest so a future caller
     * cannot be silently corrupted:
     * <ul>
     *   <li>{@code copy} returns the argument but the serializer no longer
     *       claims immutability it cannot guarantee — {@code isImmutableType()}
     *       reports {@code false} so defensive-copy paths stay defensive.</li>
     *   <li>{@code createInstance} throws a typed exception on a non-default-
     *       constructible class instead of returning {@code null} (no-silent-
     *       no-op, guide #24).</li>
     * </ul>
     */
    @SuppressWarnings("unchecked")
    private <T> TypeSerializer<T> createDummySerializer(Class<T> typeClass) {
        return new TypeSerializer<T>() {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isImmutableType() {
                // unknown class: cannot promise immutability — keep defensive
                // copies defensive instead of aliasing mutable keys
                return false;
            }

            @Override
            public TypeSerializer<T> duplicate() {
                return this;
            }

            @Override
            public T createInstance() {
                try {
                    return typeClass.getDeclaredConstructor().newInstance();
                } catch (Exception e) {
                    throw new StreamException(ERR_STREAM_SERIALIZATION, e)
                            .param(ARG_DETAIL, "Dummy key serializer cannot create an instance of "
                                    + typeClass.getName()
                                    + " (class has no accessible default constructor)");
                }
            }

            @Override
            public T copy(T from) {
                return from;
            }

            @Override
            public T copy(T from, T reuse) {
                return from;
            }

            @Override
            public int getLength() {
                return -1;
            }
        };
    }

    @SuppressWarnings("unchecked")
    private <W extends Window> TypeSerializer<W> inferWindowSerializer(WindowAssigner<?, W> windowAssigner) {
        if (windowAssigner.isEventTime()) {
            return (TypeSerializer<W>) new TimeWindowSerializer();
        }
        return (TypeSerializer<W>) new GlobalWindowSerializer();
    }

    static class TimeWindowSerializer implements TypeSerializer<TimeWindow> {
        private static final long serialVersionUID = 1L;

        @Override
        public boolean isImmutableType() {
            return true;
        }

        @Override
        public TypeSerializer<TimeWindow> duplicate() {
            return this;
        }

        @Override
        public TimeWindow createInstance() {
            return new TimeWindow(0, 0);
        }

        @Override
        public TimeWindow copy(TimeWindow from) {
            return new TimeWindow(from.getStart(), from.getEnd());
        }

        @Override
        public TimeWindow copy(TimeWindow from, TimeWindow reuse) {
            return new TimeWindow(from.getStart(), from.getEnd());
        }

        @Override
        public int getLength() {
            return -1;
        }
    }

    static class GlobalWindowSerializer implements TypeSerializer<GlobalWindow> {
        private static final long serialVersionUID = 1L;

        @Override
        public boolean isImmutableType() {
            return true;
        }

        @Override
        public TypeSerializer<GlobalWindow> duplicate() {
            return this;
        }

        @Override
        public GlobalWindow createInstance() {
            return GlobalWindow.get();
        }

        @Override
        public GlobalWindow copy(GlobalWindow from) {
            return GlobalWindow.get();
        }

        @Override
        public GlobalWindow copy(GlobalWindow from, GlobalWindow reuse) {
            return GlobalWindow.get();
        }

        @Override
        public int getLength() {
            return -1;
        }
    }
}
