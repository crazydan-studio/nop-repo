/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.stream.runtime.checkpoint;

import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_DETAIL;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_OPERATION;
import static io.nop.stream.core.exceptions.NopStreamErrors.ARG_REASON;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_CHECKPOINT_FAILED;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_INVALID_STATE;
import static io.nop.stream.core.exceptions.NopStreamErrors.ERR_STREAM_UNSUPPORTED;
import io.nop.api.core.time.CoreMetrics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.nop.api.core.annotations.core.Internal;
import io.nop.stream.core.checkpoint.CheckpointConfig;
import io.nop.stream.core.checkpoint.CheckpointIDCounter;
import io.nop.stream.core.checkpoint.CheckpointType;
import io.nop.stream.core.checkpoint.CompletedCheckpoint;
import io.nop.stream.core.checkpoint.EpochManifest;
import io.nop.stream.core.checkpoint.EpochState;
import io.nop.stream.core.checkpoint.StateSegmentDescriptor;
import io.nop.stream.core.checkpoint.TaskLocation;
import io.nop.stream.core.checkpoint.TaskStateSnapshot;
import io.nop.stream.core.checkpoint.incremental.IncrementalSnapshotResult;
import io.nop.stream.core.checkpoint.incremental.SharedStateHandle;
import io.nop.stream.core.checkpoint.incremental.SharedStateRegistry;
import io.nop.stream.core.checkpoint.incremental.SharedStateRegistryImpl;
import io.nop.stream.core.checkpoint.participant.CheckpointParticipant;
import io.nop.stream.core.checkpoint.storage.ICheckpointStorage;
import io.nop.stream.core.checkpoint.storage.ISegmentStore;
import io.nop.stream.core.common.state.CheckpointListener;
import io.nop.stream.core.exceptions.StreamException;
import io.nop.stream.core.model.StreamModelFingerprint;
import io.nop.stream.core.util.NopStreamThreadFactory;
import io.nop.stream.runtime.checkpoint.metrics.CheckpointMetrics;

@Internal
public class CheckpointCoordinator {

    private static final Logger LOG = LoggerFactory.getLogger(CheckpointCoordinator.class);

    /**
     * Reason a {@link #tryTriggerPendingCheckpoint(CheckpointType)} call did not produce a
     * new {@link PendingCheckpoint}. Exposed via {@link TriggerOutcome} so that the external
     * periodic driver (e.g. {@code JobCoordinator#startPeriodicCheckpoints}) can distinguish
     * back-pressure (throttle / concurrent-limit rejection) from real
     * failures, ensuring {@link #consecutiveTriggerFailures} only inflates on genuine
     * trigger errors (the failure counter must not be polluted by throttling or
     * concurrent-limit rejection).
     */
    public enum TriggerRejectionReason {
        /** A new PendingCheckpoint was created. Only valid when paired with a non-null pending. */
        TRIGGERED,
        /**
         * Rejected because the wall-clock gap since the last checkpoint completion is shorter
         * than {@link CheckpointConfig#getMinPause()} (last-completed semantics). This is
         * expected back-pressure — NOT a failure.
         */
        THROTTLED_MIN_PAUSE,
        /**
         * Rejected because {@code numPendingCheckpoints >= config.getMaxConcurrentCheckpoints()}.
         * Expected back-pressure — NOT a failure.
         */
        REJECTED_MAX_CONCURRENT,
        /**
         * Rejected because there are no registered tasks to acknowledge. A genuine trigger
         * failure (the coordinator is misconfigured or all tasks have unregistered).
         */
        NO_TASKS_TO_ACK
    }

    /**
     * Result of a trigger attempt. {@link #pending()} is non-null iff {@link #reason()} is
     * {@link TriggerRejectionReason#TRIGGERED}.
     */
    public static final class TriggerOutcome {
        private final TriggerRejectionReason reason;
        private final PendingCheckpoint pending;

        private TriggerOutcome(TriggerRejectionReason reason, PendingCheckpoint pending) {
            this.reason = reason;
            this.pending = pending;
        }

        static TriggerOutcome triggered(PendingCheckpoint pending) {
            return new TriggerOutcome(TriggerRejectionReason.TRIGGERED, pending);
        }

        static TriggerOutcome rejected(TriggerRejectionReason reason) {
            return new TriggerOutcome(reason, null);
        }

        public TriggerRejectionReason reason() {
            return reason;
        }

        public PendingCheckpoint pending() {
            return pending;
        }

        /** Convenience: true when this is a back-pressure rejection, not a real failure. */
        public boolean isBackPressure() {
            return reason == TriggerRejectionReason.THROTTLED_MIN_PAUSE
                    || reason == TriggerRejectionReason.REJECTED_MAX_CONCURRENT;
        }
    }

    private final String jobId;
    private final String pipelineId;
    private final CheckpointIDCounter checkpointIdCounter;
    private final ICheckpointStorage checkpointStorage;
    private final CheckpointConfig config;

    /**
     * Content-addressed side-channel store for shared SST segments. May be
     * {@code null} for non-incremental jobs. When {@link #incrementalCheckpointEnabled}
     * is {@code true}, this MUST be non-null (enforced by {@link #validateIncrementalConfig()}).
     */
    // Package-private: read live by RetentionCleaner (wired after construction).
    ISegmentStore segmentStore;

    /**
     * Enables incremental (segment-based) checkpoint processing on the
     * coordinator side. Requires {@link #segmentStore} to be set and
     * {@code asyncSnapshotEnabled=true} (see {@link #validateIncrementalConfig()}).
     */
    private boolean incrementalCheckpointEnabled;

    /**
     * Reference-counting registry for shared SST segments. Job-scoped lifetime.
     * Lazily initialized on first use; null when incremental is disabled.
     */
    // Package-private: read live by RetentionCleaner (wired after construction).
    SharedStateRegistry sharedStateRegistry;

    /**
     * In-memory GC map (checkpointId → segments materialized for that checkpoint).
     * Used by {@link RetentionCleaner#cleanupOldCheckpoints()} to drive {@code sharedStateRegistry.unregister}
     * + {@code segmentStore.discardSegment} on subsumption. Guarded by the coordinator monitor.
     */
    private final Map<Long, List<StateSegmentDescriptor>> checkpointSegments = new ConcurrentHashMap<>();

    private final ConcurrentHashMap<Long, PendingCheckpoint> pendingCheckpoints;
    private final AtomicInteger numPendingCheckpoints;
    private volatile CompletedCheckpoint latestCompletedCheckpoint;
    private volatile Set<TaskLocation> tasksToAcknowledge;

    /**
     * C3 (plan 369): tasks that reported a terminal (COMPLETED) state and were
     * contracted out of the checkpoint participant set. Their state is
     * INHERITED into every subsequently triggered checkpoint from
     * {@link #latestCompletedCheckpoint} so each new epoch still carries the
     * full task-state set (restore semantics unchanged). The set is
     * generation-scoped: {@link #setTasksToAcknowledge(Collection)} (the
     * DISTRIBUTED re-assignment path) clears it together with the ACK set.
     */
    private final Set<TaskLocation> completedTasks = ConcurrentHashMap.newKeySet();

    /**
     * Wall-clock timestamp (ms) at which the most recent checkpoint entered the COMPLETED
     * durable state via {@link #onCompletePersistSuccess}. Used to enforce last-completed
     * {@code minPause} gating in {@link #tryTriggerPendingCheckpoint}: the next trigger is
     * allowed only after {@code now - lastCompletedTimestamp >= config.getMinPause()}.
     *
     * <p>Semantics rationale: the anchor is the
     * <em>completion</em> instant, not the trigger instant, matching
     * {@code checkpoint-design.md} config table ("minimum interval between two
     * checkpoints") and Flink's
     * {@code minPauseBetweenCheckpoints}. The first trigger after coordinator construction
     * (no prior completion) is never throttled; if a prior checkpoint is still in-flight,
     * {@code maxConcurrentCheckpoints} gating decides — minPause does not duplicate that
     * decision.
     *
     * <p>Volatile because the field is written under the coordinator monitor inside
     * {@code onCompletePersistSuccess} but may be read from {@code tryTriggerPendingCheckpoint}
     * (also under the monitor) and from observers. Writes happen-before the matching monitor
     * exit, so volatile-read here is sufficient for visibility without re-acquiring the lock.
     */
    private volatile long lastCompletedTimestamp = 0L;

    private final ScheduledExecutorService timeoutScheduler;

    /**
     * Dedicated executor for checkpoint persistence (storeCheckPoint + storeEpochManifest).
     * Lazily created on first use (see {@link #getOrCreatePersistExecutor()}) so that
     * coordinator instances which never complete a checkpoint do not spawn extra threads.
     * Lifecycle is tied to the terminal {@link #shutdown()} only (per N2: the coordinator
     * does not own a restartable trigger loop — periodic triggering is driven externally,
     * e.g. by {@code JobCoordinator#startPeriodicCheckpoints}),
     * and {@link RejectedExecutionException} submitted after shutdown is handled inline.
     */
    private ExecutorService persistExecutor;

    /**
     * R6 CC-01 (plan 2326): single-thread executor for participant commit/abort
     * fan-out (sink finishCommit file/JDBC I/O, distributed RPC) and failed-commit
     * retries — previously run inline UNDER the coordinator monitor, serializing
     * the whole control plane behind slow sinks/nodes. Serial (single thread)
     * preserves the retry→current-epoch commit order and the cross-epoch ordering
     * of the queue; bounded queue + CallerRuns mirror the tm-commit-* precedent
     * (TaskManager commit executor).
     */
    private ExecutorService commitFanoutExecutor;    private volatile boolean isShutdown = false;

    /**
     * Dedicated single-thread executor for
     * retention storage I/O ({@code getAllCheckpoints} + {@code deleteCheckpoint}).
     * Deliberately NOT the persist executor: with the default
     * {@code asyncSnapshotThreadPoolSize=1}, sharing the pool would turn a slow
     * retention run into head-of-line blocking of subsequent storage-I/O persists — defeating
     * the Goal that checkpoint completion must not be blocked by retention I/O.
     * Lazily created on first retention schedule (always under the coordinator
     * monitor, see {@link RetentionCleaner#scheduleRetentionCleanup()}); torn down by the terminal
     * {@link #shutdown()} only.
     */
    private ExecutorService retentionExecutor;

    /**
     * Retention collaborator: owns the retention serialization state and the
     * dual-plane cleanup ({@link RetentionCleaner#scheduleRetentionCleanup()} /
     * {@link RetentionCleaner#cleanupOldCheckpoints()}).
     */
    private final RetentionCleaner retentionCleaner;

    private final List<CheckpointListener> listeners = new CopyOnWriteArrayList<>();
    private final List<CheckpointParticipant> participants = new CopyOnWriteArrayList<>();
    private final CheckpointMetrics metrics = new CheckpointMetrics();

    /**
     * Job event bus fired at the real checkpoint
     * completion/failure/abort paths. Defaults to an internal bus (no
     * listeners); {@code JobCoordinator} injects the job-level bus so its
     * listeners observe checkpoint progress events too.
     */
    private volatile io.nop.stream.runtime.event.StreamJobEventBus jobEventBus =
            new io.nop.stream.runtime.event.StreamJobEventBus();

    /**
     * Micrometer bindings for the real
     * completion/failure/abort paths. Lazily resolved per jobId against the
     * process composite registry.
     */
    private volatile io.nop.stream.runtime.metrics.EngineMetrics engineMetrics;

    /**
     * Bounded checkpoint observation history, recorded at
     * the same real completion/failure/abort paths that fire job events.
     * Newest first; capacity governed by the governance config (default 100).
     */
    private final CheckpointHistory checkpointHistory = new CheckpointHistory();

    // Package-private for tests: the A2 regression pins the bounded lifecycle of
    // the failed-commit retry bookkeeping.
    final ConcurrentSkipListMap<Long, Set<CheckpointParticipant>> failedCommitParticipants = new ConcurrentSkipListMap<>();
    // Package-private for tests: the A2 regression pins the bounded-lifecycle of
    // this map (abort must drop the terminal marker).
    final ConcurrentHashMap<Long, Boolean> checkpointSuccessMap = new ConcurrentHashMap<>();

    private final AtomicInteger consecutiveTriggerFailures = new AtomicInteger(0);

    /**
     * Abort callback carrying the abort
     * REASON so handlers can distinguish routine timeouts from snapshot failures.
     * A checkpoint TIMEOUT is a normal back-pressure event (discard the epoch,
     * keep the tasks running — the next trigger retries); an operator SNAPSHOT
     * FAILURE abort indicates possibly-inconsistent task state (the recovery
     * design's cancel-and-recover path).
     */
    private volatile java.util.function.BiConsumer<Long, String> abortHandler;

    public CheckpointCoordinator(
            String jobId,
            String pipelineId,
            CheckpointIDCounter checkpointIdCounter,
            ICheckpointStorage checkpointStorage,
            CheckpointConfig config) {
        this.jobId = jobId;
        this.pipelineId = pipelineId;
        this.checkpointIdCounter = checkpointIdCounter;
        this.checkpointStorage = checkpointStorage;
        this.config = config;
        this.pendingCheckpoints = new ConcurrentHashMap<>();
        this.numPendingCheckpoints = new AtomicInteger(0);
        this.tasksToAcknowledge = ConcurrentHashMap.newKeySet();
        // The Coordinator layer honors the configured
        // maxConcurrentCheckpoints value directly (see tryTriggerPendingCheckpoint gating):
        // the
        // Coordinator, CheckpointBarrierTracker, and InputGate each honor
        // maxConcurrentCheckpoints consistently (see checkpoint-design.md §2.8.1).
        // This log line confirms the configured concurrency is honored end-to-end.
        if (config.getMaxConcurrentCheckpoints() > 1) {
            LOG.info("maxConcurrentCheckpoints={} configured for job {}: honored end-to-end "
                            + "(Coordinator + CheckpointBarrierTracker + InputGate multi-epoch; "
                            + "see checkpoint-design.md §2.8.1).",
                    config.getMaxConcurrentCheckpoints(), jobId);
        }
        this.timeoutScheduler = Executors.newSingleThreadScheduledExecutor(
                NopStreamThreadFactory.named("checkpoint-timeout-" + jobId));
        this.retentionCleaner = new RetentionCleaner(this, config, checkpointStorage, jobId, pipelineId,
                checkpointSegments);
    }

    public void addListener(CheckpointListener listener) {
        listeners.add(listener);
    }

    public void removeListener(CheckpointListener listener) {
        listeners.remove(listener);
    }

    public void addParticipant(CheckpointParticipant participant) {
        participants.add(participant);
    }

    public void removeParticipant(CheckpointParticipant participant) {
        participants.remove(participant);
    }

    public List<CheckpointParticipant> getParticipants() {
        return Collections.unmodifiableList(participants);
    }

    /** Legacy abort callback without the reason (see {@link #setAbortHandler(BiConsumer)}). */
    public void setAbortHandler(java.util.function.Consumer<Long> handler) {
        this.abortHandler = (checkpointId, reason) -> handler.accept(checkpointId);
    }

    /**
     * Abort callback with the abort reason — lets handlers differentiate
     * routine timeout aborts from snapshot-failure aborts.
     */
    public void setAbortHandler(java.util.function.BiConsumer<Long, String> handler) {
        this.abortHandler = handler;
    }

    public synchronized PendingCheckpoint tryTriggerPendingCheckpoint(CheckpointType checkpointType) {
        return tryTriggerCheckpointWithReason(checkpointType).pending();
    }

    /**
     * C2 (plan 369): trigger a checkpoint of the given type with BOUNDED retry
     * so a terminal/savepoint action survives a collision with in-flight
     * periodic work. The pre-fix call shape
     * {@code tryTriggerPendingCheckpoint → null → silently skip} let a DRAIN /
     * SUSPEND / COMPLETED termination "finish" a job without its durable
     * terminal savepoint whenever a periodic checkpoint was still in flight
     * (maxConcurrent=1 default). This method implements the adjudicated
     * typed-reason disposition:
     * <ul>
     *   <li>{@link TriggerRejectionReason#REJECTED_MAX_CONCURRENT} /
     *       {@link TriggerRejectionReason#THROTTLED_MIN_PAUSE} (back-pressure):
     *       bounded polling retry until {@code timeoutMs} elapses — the caller
     *       waits for the in-flight checkpoint to complete, mirroring Flink's
     *       {@code CheckpointRequestDecider} queueing of savepoint requests;</li>
     *   <li>{@link TriggerRejectionReason#NO_TASKS_TO_ACK}: short-circuit
     *       SUCCESS ({@code null} return). With the C3 participant contraction,
     *       an empty ACK set on a trigger means every task has reached a
     *       terminal state — there is nothing live to snapshot and treating
     *       that as a failure would turn a normal shutdown into a job failure
     *       (the C2×C3 interaction). For EXPLICIT (non-periodic) types with
     *       terminal tombstones present the coordinator does not reject at all:
     *       it assembles the epoch entirely from the inherited terminal states
     *       and completes it inline (see
     *       {@link #tryTriggerCheckpointWithReason}), so the durable artifact
     *       the caller waits on still exists. NO_TASKS_TO_ACK therefore only
     *       reaches this method for periodic ticks after full drain or for a
     *       coordinator with no registered tasks;</li>
     *   <li>retry budget exhausted: loud typed failure
     *       ({@code ERR_STREAM_CHECKPOINT_FAILED}).</li>
     * </ul>
     *
     * <p>Blocking: sleeps between retries OUTSIDE the coordinator monitor (each
     * retry re-enters the synchronized trigger). Interruption propagates as
     * {@link InterruptedException} so callers keep their recorded interrupt
     * semantics (plan 368 CC-11).
     *
     * @param checkpointType the checkpoint type to trigger (any)
     * @param timeoutMs      total retry budget in ms (the caller's checkpoint
     *                       timeout); values &le; 0 get one attempt
     * @return the triggered {@link PendingCheckpoint}, or {@code null} when the
     *         trigger was short-circuited as success (nothing to acknowledge)
     * @throws StreamException ERR_STREAM_CHECKPOINT_FAILED when no trigger
     *                         succeeded within the budget
     * @throws InterruptedException if the retry sleep was interrupted
     */
    public PendingCheckpoint triggerCheckpointBounded(CheckpointType checkpointType, long timeoutMs)
            throws InterruptedException {
        long deadline = CoreMetrics.currentTimeMillis() + Math.max(1L, timeoutMs);
        long backoffMs = C2_RETRY_INITIAL_BACKOFF_MS;
        while (true) {
            TriggerOutcome outcome = tryTriggerCheckpointWithReason(checkpointType);
            if (outcome.reason() == TriggerRejectionReason.TRIGGERED) {
                return outcome.pending();
            }
            if (outcome.reason() == TriggerRejectionReason.NO_TASKS_TO_ACK) {
                LOG.info("Checkpoint trigger of type {} short-circuited as success for job {}: "
                        + "no tasks to acknowledge (all participants terminal; C2/C3 lifecycle endpoint)",
                        checkpointType, jobId);
                return null;
            }
            // Back-pressure rejection (in-flight periodic checkpoint / minPause):
            // wait for it to clear and retry until the budget is exhausted. The
            // sleep is clamped to the remaining budget so the full timeout window
            // is actually used before giving up.
            long now = CoreMetrics.currentTimeMillis();
            if (now >= deadline) {
                throw new StreamException(ERR_STREAM_CHECKPOINT_FAILED).param(ARG_REASON,
                        "Could not trigger " + checkpointType + " checkpoint for job " + jobId
                                + " within " + timeoutMs + "ms: " + outcome.reason()
                                + " (in-flight checkpoint did not clear in time)");
            }
            Thread.sleep(Math.min(backoffMs, deadline - now));
            backoffMs = Math.min(backoffMs * 2, C2_RETRY_MAX_BACKOFF_MS);
        }
    }

    /** C2: initial retry backoff for {@link #triggerCheckpointBounded}. */
    private static final long C2_RETRY_INITIAL_BACKOFF_MS = 50L;
    /** C2: maximum retry backoff for {@link #triggerCheckpointBounded}. */
    private static final long C2_RETRY_MAX_BACKOFF_MS = 500L;

    /**
     * Trigger a new pending checkpoint and report the precise outcome. The external periodic
     * driver (e.g. {@code JobCoordinator#startPeriodicCheckpoints})
     * uses this method so that {@code THROTTLED_MIN_PAUSE} and {@code REJECTED_MAX_CONCURRENT}
     * back-pressure does NOT inflate {@link #consecutiveTriggerFailures}.
     * Callers that only need the PendingCheckpoint reference can use
     * {@link #tryTriggerPendingCheckpoint(CheckpointType)} instead.
     *
     * <p>Gating order: (1) maxConcurrent → (2) minPause (last-completed) → (3) tasks-to-ack.
     * Each rejection is observable (DEBUG/WARN log + distinct {@link TriggerRejectionReason})
     * so callers can distinguish back-pressure from genuine failures — there is no silent
     * {@code continue} / null-as-default.
     */
    public synchronized TriggerOutcome tryTriggerCheckpointWithReason(CheckpointType checkpointType) {
        int effectiveMaxConcurrent = config.getMaxConcurrentCheckpoints();
        if (numPendingCheckpoints.get() >= effectiveMaxConcurrent) {
            LOG.debug("Cannot trigger checkpoint: too many pending checkpoints ({}/{})",
                    numPendingCheckpoints.get(), effectiveMaxConcurrent);
            return TriggerOutcome.rejected(TriggerRejectionReason.REJECTED_MAX_CONCURRENT);
        }

        // minPause(last-completed): once at least one checkpoint has completed, the
        // next trigger is allowed only after `now - lastCompletedTimestamp >= minPause`.
        // First-ever trigger (no prior completion) is never throttled. minPause == 0 disables
        // the gate. The anchor is completion (not trigger) to match checkpoint-design.md
        // config table and Flink minPauseBetweenCheckpoints.
        //
        // Scope: only the regular periodic CHECKPOINT type is throttled. Savepoints and
        // terminal checkpoints (COMPLETED_POINT_TYPE / TERMINAL_SAVEPOINT / EXPORTED_SAVEPOINT)
        // are explicit user- or job-driven actions and must not be delayed by minPause —
        // matching Flink semantics where minPauseBetweenCheckpoints applies only to periodic
        // checkpoints, not savepoints. The maxConcurrent gate above continues to apply to all
        // types so that terminal / savepoint snapshots still serialize against in-flight work.
        long minPause = config.getMinPause();
        long lastCompletedAt = lastCompletedTimestamp;
        if (minPause > 0 && lastCompletedAt > 0 && checkpointType == CheckpointType.CHECKPOINT) {
            long now = CoreMetrics.currentTimeMillis();
            long elapsed = now - lastCompletedAt;
            if (elapsed < minPause) {
                LOG.debug("Cannot trigger checkpoint: minPause throttle (elapsed={}ms < minPause={}ms since last completion {})",
                        elapsed, minPause, lastCompletedAt);
                return TriggerOutcome.rejected(TriggerRejectionReason.THROTTLED_MIN_PAUSE);
            }
        }

        long checkpointId = checkpointIdCounter.getAndIncrement();
        long timestamp = CoreMetrics.currentTimeMillis();

        Set<TaskLocation> tasksToAck = getTasksToAcknowledge();
        // C2×C3 lifecycle endpoint (plan 369): an empty ACK set means every
        // participant was contracted out as terminal (or none was ever
        // registered). Disposition by trigger kind:
        // <ul>
        //   <li>Periodic CHECKPOINT: NO_TASKS_TO_ACK rejection — the periodic
        //       driver skips the tick; assembling a synthetic epoch every
        //       interval after the job fully drained would spam empty
        //       checkpoints.</li>
        //   <li>Explicit actions (SAVEPOINT / TERMINAL_SAVEPOINT /
        //       EXPORTED_SAVEPOINT / COMPLETED_POINT_TYPE) with terminal
        //       tombstones present: the epoch is assembled ENTIRELY from the
        //       inherited terminal states (empty snapshot where nothing durable
        //       exists — see {@link #inheritTerminalTaskState}), completed
        //       inline, and published durably. This is the materialized form of
        //       the C2 "short-circuit as success": zero waiting (no live
        //       participant can hang the trigger), zero job-fail, AND the
        //       durable artifact the explicit action promises (a savepoint file
        //       / final manifest) still exists — a DRAIN must not bypass its
        //       terminal savepoint (§2.9) even when every task already
        //       finished.</li>
        //   <li>Explicit action with NO terminal tombstone either (nothing was
        //       ever registered): NO_TASKS_TO_ACK — genuinely nothing to
        //       assemble.</li>
        // </ul>
        boolean allTerminalEpoch = false;
        if (tasksToAck.isEmpty()) {
            if (completedTasks.isEmpty() || checkpointType == CheckpointType.CHECKPOINT) {
                LOG.debug("No tasks to acknowledge for checkpoint {}", checkpointId);
                return TriggerOutcome.rejected(TriggerRejectionReason.NO_TASKS_TO_ACK);
            }
            allTerminalEpoch = true;
            LOG.info("Assembling {} epoch {} for job {} entirely from inherited terminal states "
                    + "({} contracted task(s), no live participants)", checkpointType, checkpointId,
                    jobId, completedTasks.size());
        }

        PendingCheckpoint pending = new PendingCheckpoint(
                jobId, pipelineId, checkpointId, timestamp,
                checkpointType, tasksToAck);

        // C3 (plan 369): inherit the state of terminal (completed) tasks and
        // pre-acknowledge them, so the new epoch's participant set excludes
        // tasks that can never ACK again while the resulting CompletedCheckpoint
        // still contains the FULL task-state set (restore semantics unchanged).
        //
        // Reference-count migration (incremental mode): the inherited snapshots
        // are part of completed.getTaskStates(), so the incremental persist path
        // (buildAndMaterializeSegments) re-registers every inherited SST handle
        // against the SharedStateRegistry under THIS checkpoint's id and records
        // the segments in this checkpoint's GC map. When the older checkpoint is
        // later retention-pruned, its unregister only drops its own reference —
        // the segments stay alive for this epoch (Flink SharedStateRegistry
        // CLAIM semantics). No raw reference sharing for incremental state.
        // Non-incremental (JSON) state shares the snapshot reference directly,
        // which is acceptable (adjudicated in plan 369 C3).
        if (!completedTasks.isEmpty()) {
            for (TaskLocation completed : completedTasks) {
                if (tasksToAck.contains(completed)) {
                    // A re-registered (new-generation) live task wins over the
                    // terminal tombstone.
                    continue;
                }
                pending.acknowledgeTask(completed,
                        inheritTerminalTaskState(completed, checkpointId));
                LOG.debug("Inherited state of completed task {} into checkpoint {} of job {}",
                        completed, checkpointId, jobId);
            }
        }

        pendingCheckpoints.put(checkpointId, pending);
        numPendingCheckpoints.incrementAndGet();

        if (allTerminalEpoch && pending.isFullyAcknowledged()) {
            // No live participants: the epoch is complete as soon as it exists.
            // Complete inline (we hold the monitor; the persist path hands I/O
            // to the persist executor in async mode) instead of scheduling a
            // timeout that could only abort an already-fully-acknowledged
            // pending. The caller's future.get() therefore returns as soon as
            // the durable persist finishes.
            completePendingCheckpoint(pending.toCompletedCheckpoint());
        } else {
            scheduleTimeout(pending);
        }

        LOG.info("Triggered checkpoint {} for job {}", checkpointId, jobId);
        return TriggerOutcome.triggered(pending);
    }

    public synchronized boolean acknowledgeTask(TaskLocation taskLocation, long checkpointId, TaskStateSnapshot state) {
        PendingCheckpoint pending = pendingCheckpoints.get(checkpointId);
        if (pending == null) {
            LOG.warn("Received ACK for unknown checkpoint {} from task {}", checkpointId, taskLocation);
            return false;
        }

        // N1: status guard. In async-snapshot mode there is a window between
        // CAS(RUNNING->COMPLETED) (the manifest-snapshot step) and pendingCheckpoints.remove
        // (the side-effect steps) during
        // which the pending entry is still registered with status COMPLETED. A duplicate
        // or stale ACK arriving in that window must return false (matching the sync-mode
        // semantics where a duplicate ACK finds the entry already removed) instead of
        // throwing from PendingCheckpoint.acknowledgeTask.
        if (pending.getStatus().get() != PendingCheckpoint.Status.RUNNING) {
            LOG.debug("Received ACK for checkpoint {} in non-RUNNING state {}, ignoring",
                    checkpointId, pending.getStatus().get());
            return false;
        }

        pending.acknowledgeTask(taskLocation, state);
        LOG.debug("Task {} acknowledged checkpoint {}, pending tasks: {}",
                taskLocation, checkpointId, pending.getNumberOfNotAcknowledgedTasks());

        if (pending.isFullyAcknowledged()) {
            completePendingCheckpoint(pending.toCompletedCheckpoint());
        }

        return true;
    }

    public synchronized void completePendingCheckpoint(CompletedCheckpoint completed) {
        long checkpointId = completed.getCheckpointId();
        PendingCheckpoint pending = pendingCheckpoints.get(checkpointId);
        if (pending == null) {
            LOG.debug("Skip completing checkpoint {} because it is no longer pending", checkpointId);
            return;
        }

        if (!pending.getStatus().compareAndSet(PendingCheckpoint.Status.RUNNING, PendingCheckpoint.Status.COMPLETED)) {
            LOG.debug("Skip completing checkpoint {} because status is {}", checkpointId, pending.getStatus().get());
            return;
        }

        // Manifest-snapshot step: build immutable manifest snapshot while holding monitor. buildEpochManifest
        // captures currentFingerprint; building it here (under monitor) preserves the same
        // fingerprint-observation ordering as the pre-async implementation. The manifest and
        // the completed checkpoint are immutable, so they can be safely handed to the persist
        // executor without holding the monitor during I/O.
        //
        // Incremental mode: segments computation involves RocksDB file I/O + registry
        // register + segment store copy and MUST NOT run under the monitor. For incremental
        // mode we capture the fingerprint here (under monitor) and defer manifest
        // construction (with segments) to the persist executor. See checkpoint-design.md
        // §2.2 async persist timing.
        if (incrementalCheckpointEnabled && sharedStateRegistry != null && segmentStore != null) {
            final StreamModelFingerprint capturedFingerprint = currentFingerprint;
            ExecutorService executor = getOrCreatePersistExecutor();
            try {
                executor.submit(() -> executeIncrementalPersistAsync(completed, pending, capturedFingerprint));
            } catch (RejectedExecutionException ree) {
                LOG.warn("Persist executor rejected incremental checkpoint {}, failing inline", checkpointId, ree);
                onCompletePersistFailure(completed, pending, "submit incremental persist task", ree);
            }
            return;
        }

        final EpochManifest manifest = buildEpochManifest(completed);

        if (!config.isAsyncSnapshotEnabled()) {
            // sync fallback: storage I/O + completion side effects execute inline
            // on the ACK caller thread under the monitor — pre-async behavior preserved.
            completePersistSynchronously(completed, pending, manifest);
            return;
        }

        // async path: hand storage I/O + completion side effects to the dedicated persist executor. The ACK caller thread
        // returns as soon as the task is queued, so storage I/O no longer blocks the
        // coordinator's responsiveness (abort registration, timeout scheduling, trigger
        // bookkeeping).
        ExecutorService executor = getOrCreatePersistExecutor();
        try {
            executor.submit(() -> executePersistAsync(completed, pending, manifest));
        } catch (RejectedExecutionException ree) {
            // Executor was shut down (terminal shutdown racing with a final ACK). Execute
            // failure side effects inline — we still hold the monitor from this synchronized method.
            LOG.warn("Persist executor rejected checkpoint {}, failing inline", checkpointId, ree);
            onCompletePersistFailure(completed, pending, "submit persist task", ree);
        }
    }

    /**
     * Sync-fallback path: runs entirely on the ACK caller thread under the coordinator
     * monitor. Equivalent to the pre-async implementation of {@code completePendingCheckpoint}.
     */
    private synchronized void completePersistSynchronously(
            CompletedCheckpoint completed, PendingCheckpoint pending, EpochManifest manifest) {
        long checkpointId = completed.getCheckpointId();

        try {
            checkpointStorage.storeCheckPoint(completed);
        } catch (Exception e) {
            onCompletePersistFailure(completed, pending, "Failed to store checkpoint", e);
            return;
        }

        try {
            checkpointStorage.storeEpochManifest(jobId, pipelineId, manifest);
            LOG.debug("Stored EpochManifest for epoch {}", checkpointId);
        } catch (Exception e) {
            onCompletePersistFailure(completed, pending,
                    "Failed to store EpochManifest for checkpoint " + checkpointId, e);
            return;
        }

        onCompletePersistSuccess(completed, pending, false);
    }

    /**
     * Async path body, executed on a {@code checkpoint-persist-<jobId>-<n>} thread.
     * The storage-I/O step performs storage I/O WITHOUT holding the monitor (operating on immutable snapshot
     * data). The side-effect steps re-acquire the monitor so that decrementPendingCheckpointCount stays
     * atomic with tryTriggerPendingCheckpoint's concurrent-check (§13.2).
     */
    private void executePersistAsync(
            CompletedCheckpoint completed, PendingCheckpoint pending, EpochManifest manifest) {
        long checkpointId = completed.getCheckpointId();

        try {
            checkpointStorage.storeCheckPoint(completed);
        } catch (Exception e) {
            synchronized (this) {
                onCompletePersistFailure(completed, pending, "Failed to store checkpoint", e);
            }
            return;
        }

        try {
            checkpointStorage.storeEpochManifest(jobId, pipelineId, manifest);
            LOG.debug("Stored EpochManifest for epoch {}", checkpointId);
        } catch (Exception e) {
            synchronized (this) {
                onCompletePersistFailure(completed, pending,
                        "Failed to store EpochManifest for checkpoint " + checkpointId, e);
            }
            return;
        }

        synchronized (this) {
            onCompletePersistSuccess(completed, pending, true);
        }
    }

    /**
     * Incremental async persist path (the storage-I/O step for incremental). Builds the content-
     * addressed segments (registry register + segment store materialization — I/O, no
     * monitor), constructs the EpochManifest with those segments, persists, then the success callback
     * records the GC-map entry under monitor and runs success side effects.
     */
    private void executeIncrementalPersistAsync(
            CompletedCheckpoint completed, PendingCheckpoint pending, StreamModelFingerprint fingerprint) {
        long checkpointId = completed.getCheckpointId();

        final List<StateSegmentDescriptor> segments;
        try {
            segments = buildAndMaterializeSegments(completed);
        } catch (Exception e) {
            LOG.error("Failed to build incremental segments for checkpoint {}", checkpointId, e);
            synchronized (this) {
                onCompletePersistFailure(completed, pending, "incremental segment build", e);
            }
            return;
        }

        final EpochManifest manifest = buildEpochManifest(completed, fingerprint, segments);

        try {
            checkpointStorage.storeCheckPoint(completed);
        } catch (Exception e) {
            // Storage failed after segments were registered + materialized:
            // roll back the ref-counts and discard zero-ref SST files so they
            // are not stranded (the success-branch GC map was never populated).
            releaseIncrementalSegments(segments);
            synchronized (this) {
                onCompletePersistFailure(completed, pending, "Failed to store checkpoint", e);
            }
            return;
        }

        try {
            checkpointStorage.storeEpochManifest(jobId, pipelineId, manifest);
            LOG.debug("Stored incremental EpochManifest for epoch {} ({} segments)",
                    checkpointId, segments.size());
        } catch (Exception e) {
            // Same rollback as the storeCheckPoint failure: the checkpoint row
            // may have landed but the manifest did not, so this checkpoint is
            // aborted and its newly-registered segments must be released.
            releaseIncrementalSegments(segments);
            synchronized (this) {
                onCompletePersistFailure(completed, pending,
                        "Failed to store EpochManifest for checkpoint " + checkpointId, e);
            }
            return;
        }

        synchronized (this) {
            // GC map update happens under monitor after storage persist success (§ design).
            checkpointSegments.put(checkpointId, segments);
            onCompletePersistSuccess(completed, pending, true);
        }
    }

    /**
     * Walk all task snapshots in the completed checkpoint, extract every
     * {@link IncrementalSnapshotResult} marker, register each shared SST handle against
     * {@link #sharedStateRegistry} (de-duplication), materialize new handles into
     * {@link #segmentStore} (content-addressed copy), and build the
     * {@link StateSegmentDescriptor} list for the EpochManifest. Per the design decision
     * "the coordinator never operates the RocksDB instance directly" — the coordinator only consumes the raw
     * handles carried in the ACK; the task produced them.
     *
     * <p>Single-JVM model: the handle's {@code filePath} points at the task-local native
     * checkpoint dir, which the coordinator (same JVM) reads and copies into the shared
     * store. Cross-JVM transfer is out of scope.
     */
    private List<StateSegmentDescriptor> buildAndMaterializeSegments(CompletedCheckpoint completed) throws java.io.IOException {
        List<StateSegmentDescriptor> segments = new java.util.ArrayList<>();
        if (completed.getTaskStates() == null) {
            return segments;
        }
        for (TaskStateSnapshot taskSnap : completed.getTaskStates().values()) {
            if (taskSnap == null || taskSnap.getKeyedStates() == null) {
                continue;
            }
            for (Object value : taskSnap.getKeyedStates().values()) {
                IncrementalSnapshotResult result = extractIncrementalResult(value);
                if (result == null) {
                    continue;
                }
                for (SharedStateHandle handle : result.getSstHandles()) {
                    SharedStateHandle canonical = sharedStateRegistry.register(handle);
                    String hash = canonical.getStateObjectId();
                    // Materialize into the shared store only when not already present
                    // (content-addressed reuse — avoids redundant copies of shared SSTs).
                    if (!segmentStore.segmentExists(hash)) {
                        segmentStore.storeSegment(java.nio.file.Path.of(handle.getFilePath()), hash);
                    }
                    segments.add(new StateSegmentDescriptor(
                            StateSegmentDescriptor.SEGMENT_TYPE_ROCKSDB_SST,
                            hash,
                            StateSegmentDescriptor.CODEC_IDENTITY,
                            hash,
                            StateSegmentDescriptor.SCHEMA_VERSION_ROCKSDB_SST));
                }
            }
        }
        return segments;
    }

    /**
     * Roll back the in-memory reference counts and physical SST materialization
     * performed by {@link #buildAndMaterializeSegments} when the subsequent
     * storage persists fail. The success path records the segments in
     * {@link #checkpointSegments} so {@link #gcSegmentsForCheckpoint} reclaims
     * them later; the failure path never reaches that put, so without this
     * rollback the registered ref-counts would be stranded and the
     * content-addressed SST files would never be discarded (disk growth until
     * coordinator restart rebuilds the registry).
     *
     * <p>Only physically discards segments whose ref-count actually drops to
     * zero (content-addressed de-duplication: a segment shared with another
     * live checkpoint must not be deleted). Failures to discard a file are
     * logged and do not abort the rollback — the in-memory leak is already
     * undone, and a stranded file is strictly better than a stranded ref-count.
     */
    private void releaseIncrementalSegments(List<StateSegmentDescriptor> segments) {
        if (sharedStateRegistry == null || segmentStore == null) {
            return;
        }
        if (segments == null || segments.isEmpty()) {
            return;
        }
        for (StateSegmentDescriptor seg : segments) {
            List<SharedStateHandle> zeroRef = sharedStateRegistry.unregister(seg.getPath());
            for (SharedStateHandle handle : zeroRef) {
                try {
                    segmentStore.discardSegment(handle.getStateObjectId());
                } catch (Exception dex) {
                    LOG.warn("Failed to discard segment {} after failed persist for job {}",
                            handle.getStateObjectId(), jobId, dex);
                }
            }
        }
    }
    @SuppressWarnings("unchecked")
    private IncrementalSnapshotResult extractIncrementalResult(Object value) {
        if (value instanceof IncrementalSnapshotResult) {
            return (IncrementalSnapshotResult) value;
        }
        if (value instanceof io.nop.stream.core.common.state.backend.StateSnapshot) {
            io.nop.stream.core.common.state.backend.StateSnapshot ss =
                    (io.nop.stream.core.common.state.backend.StateSnapshot) value;
            Object marker = ss.getStateData().get(IncrementalSnapshotResult.MARKER_KEY);
            if (marker instanceof IncrementalSnapshotResult) {
                return (IncrementalSnapshotResult) marker;
            }
            if (marker instanceof Map) {
                return reconstructFromMap((Map<String, Object>) marker);
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private IncrementalSnapshotResult reconstructFromMap(Map<String, Object> map) {
        // Best-effort reconstruction of a JSON-deserialized marker (cross-JVM / restored path).
        Object cpId = map.get("checkpointId");
        long checkpointId = cpId instanceof Number ? ((Number) cpId).longValue() : -1;
        Object total = map.get("totalSize");
        long totalSize = total instanceof Number ? ((Number) total).longValue() : 0L;
        String nonSstDir = (String) map.get("nonSstDir");
        List<String> nonSstNames = (List<String>) map.get("nonSstFileNames");
        List<SharedStateHandle> handles = new java.util.ArrayList<>();
        Object handlesRaw = map.get("sstHandles");
        if (handlesRaw instanceof List) {
            for (Object h : (List<Object>) handlesRaw) {
                if (h instanceof Map) {
                    Map<String, Object> hm = (Map<String, Object>) h;
                    String hash = (String) hm.get("contentHash");
                    String path = (String) hm.get("filePath");
                    Object sz = hm.get("size");
                    long size = sz instanceof Number ? ((Number) sz).longValue() : 0L;
                    if (hash != null) {
                        handles.add(new SharedStateHandle(hash, path, size));
                    }
                }
            }
        }
        return new IncrementalSnapshotResult(checkpointId, handles, nonSstDir, nonSstNames, totalSize);
    }

    /**
     * Success callback. Caller MUST hold the coordinator monitor.
     *
     * <p>Preserves the exact side-effect ordering of the pre-async implementation:
     * pendingCheckpoints.remove → forceComplete (DURABLE) → latestCompletedCheckpoint →
     * decrementPendingCheckpointCount → metrics → cleanup → retryFailedCommits →
     * notifyParticipantsFinishCommit(true) (commit, after forceComplete per §12 invariant 5)
     * → notifyCheckpointCompleted → checkpointSuccessMap.remove → consecutiveTriggerFailures.reset.
     *
     * <p>Retention handling is selected by
     * {@code asyncRetention}. The async completion paths (executePersistAsync /
     * executeIncrementalPersistAsync) pass {@code true} — retention storage I/O is
     * scheduled onto the dedicated retention executor (non-blocking CAS + submit,
     * no I/O under the monitor). The sync-fallback path
     * ({@code completePersistSynchronously}, {@code asyncSnapshotEnabled=false})
     * passes {@code false} — {@code cleanupOldCheckpoints()} runs inline under the
     * monitor, preserving that mode's pinned pre-async semantics (all I/O on the
     * ACK caller thread). Ordering w.r.t. the subsequent success-callback steps is dependency-free
     * either way: retention only deletes the OLDEST rows (never the just-completed
     * epoch, whose id is strictly the newest) and touches disjoint state (old storage
     * rows + old segments), while retryFailedCommits / notifyParticipantsFinishCommit /
     * notifyCheckpointCompleted only touch the current epoch and participant
     * registries (D1(e)).
     */
    private void onCompletePersistSuccess(CompletedCheckpoint completed, PendingCheckpoint pending,
                                          boolean asyncRetention) {
        long checkpointId = completed.getCheckpointId();

        if (!pendingCheckpoints.remove(checkpointId, pending)) {
            LOG.debug("Skip completing checkpoint {} because pending state changed", checkpointId);
            return;
        }

        // Complete the future only after successful storage, so storage failure
        // does not leave a ghost checkpoint that callers already acted on.
        pending.forceComplete();

        latestCompletedCheckpoint = completed;
        // minPause(last-completed): anchor the next-trigger throttle clock at the
        // instant this checkpoint became durable. Set before decrement so a racing trigger
        // (also under monitor) sees the new anchor when numPending drops to 0.
        lastCompletedTimestamp = CoreMetrics.currentTimeMillis();
        decrementPendingCheckpointCount();

        metrics.incrementCompletedCheckpoints();
        metrics.updateLatestCheckpoint(completed.estimateSize(), completed.getDuration());

        // Engine-layer meters + job progress event at the real
        // completion path (fires on every durable checkpoint, LOCAL and
        // DISTRIBUTED).
        engineMetrics().checkpointCompleted(completed.estimateSize(), completed.getDuration());
        jobEventBus.fire(new io.nop.stream.runtime.event.StreamJobEvent(
                jobId, io.nop.stream.runtime.event.StreamJobEvent.EventType.CHECKPOINT_COMPLETED,
                CoreMetrics.currentTimeMillis(), checkpointId, completed.getDuration(),
                completed.estimateSize(), null));
        recordHistory(new io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry(
                checkpointId, io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry.Status.COMPLETED,
                pending.getTriggerTimestamp(), completed.getDuration(), completed.estimateSize(),
                null, CoreMetrics.currentTimeMillis()));

        if (asyncRetention) {
            // Retention I/O off the monitor — non-blocking schedule
            // (CAS guard + submit); the storage reads/deletes run on the dedicated
            // retention executor thread without holding this monitor.
            retentionCleaner.scheduleRetentionCleanup();
        } else {
            // Sync-fallback (D1(d)): inline under the monitor — pre-async semantics.
            retentionCleaner.cleanupOldCheckpoints();
        }

        // R6 CC-01 (plan 2326): participant commit fan-out (sink finishCommit
        // file/JDBC I/O, distributed RPC) and failed-commit retries run on the
        // dedicated commit-fanout executor — NOT under this monitor. Serial
        // execution preserves retry→current-epoch order; the epoch's success
        // marker is recorded before scheduling and removed in the task after
        // notify (the abort-path gating reads failedCommitParticipants, which the
        // task itself may populate).
        final long fanoutCheckpointId = checkpointId;
        getOrCreateCommitFanoutExecutor().execute(() -> {
            try {
                retryFailedCommits();

                // §12 invariant 5: commit happens only after manifest is durable (forceComplete above).
                notifyParticipantsFinishCommit(fanoutCheckpointId, true);

                checkpointSuccessMap.remove(fanoutCheckpointId);
            } catch (Exception e) {
                LOG.error("Commit fan-out for checkpoint {} failed", fanoutCheckpointId, e);
            }
        });

        notifyCheckpointCompleted(checkpointId);

        consecutiveTriggerFailures.set(0);

        LOG.info("Completed checkpoint {} for job {}, duration: {}ms",
                checkpointId, jobId, completed.getDuration());
    }

    /**
     * Failure callback. Caller MUST hold the coordinator monitor.
     *
     * <p>The pending checkpoint is force-failed (NOT aborted via
     * {@link #abortPendingCheckpoint}, whose RUNNING→ABORTED CAS would fail because the manifest-snapshot step
     * already transitioned to COMPLETED). finishCommit(false) keeps prepared sink
     * transactions for subsuming, matching the pre-async failure semantics.
     *
     * <p>The pending's future is completed
     * exceptionally via {@link PendingCheckpoint#forceFail(String, Throwable)} —
     * bookkeeping first (remove / decrement / notify), future completion LAST, so
     * waiters released by the future wake into a consistent coordinator state and the
     * exception they observe carries the real storage-failure root cause (previously the
     * future was never completed and savepoint/DRAIN/SUSPEND/EXPORT waiters blocked for
     * the full {@code checkpointTimeout}, default 600s, then saw a misleading
     * TimeoutException).
     */
    private void onCompletePersistFailure(CompletedCheckpoint completed, PendingCheckpoint pending,
                                          String failMessage, Exception cause) {
        long checkpointId = completed.getCheckpointId();
        LOG.error("Failed checkpoint {} for job {}: {}", checkpointId, jobId, failMessage, cause);
        metrics.recordFailure(failMessage);
        // Engine-layer meter + job event (failureCause carried).
        engineMetrics().checkpointFailed();
        jobEventBus.fire(new io.nop.stream.runtime.event.StreamJobEvent(
                jobId, io.nop.stream.runtime.event.StreamJobEvent.EventType.CHECKPOINT_FAILED,
                CoreMetrics.currentTimeMillis(), checkpointId, null, null, failMessage));
        recordHistory(new io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry(
                checkpointId, io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry.Status.FAILED,
                pending.getTriggerTimestamp(), 0L, 0L, failMessage, CoreMetrics.currentTimeMillis()));
        pendingCheckpoints.remove(checkpointId, pending);
        decrementPendingCheckpointCount();
        // R6 CC-01 (plan 2326): abort fan-out off the monitor (mirrors the success
        // path). The terminal-marker removal rides in the task AFTER notify (the
        // task may populate failedCommitParticipants).
        final long fanoutAbortId = checkpointId;
        getOrCreateCommitFanoutExecutor().execute(() -> {
            try {
                notifyParticipantsFinishCommit(fanoutAbortId, false);
                // A2' (plan 366): a persist-failed epoch is terminal, same as an
                // aborted one — the terminal marker must not linger in
                // checkpointSuccessMap once failed-commit retries no longer need
                // it (removing it early would default the replay to success=true).
                if (!failedCommitParticipants.containsKey(fanoutAbortId)) {
                    checkpointSuccessMap.remove(fanoutAbortId);
                }
            } catch (Exception e) {
                LOG.error("Abort fan-out for checkpoint {} failed", fanoutAbortId, e);
            }
        });
        notifyCheckpointAborted(checkpointId);
        pending.forceFail(failMessage, cause);
    }

    // Package-private: invoked by RetentionCleaner for segment-discard offloading.
    ExecutorService getOrCreatePersistExecutor() {
        if (persistExecutor == null) {
            persistExecutor = createPersistExecutor();
        }
        return persistExecutor;
    }

    /** R6 CC-01 (plan 2326): lazy single-thread fan-out executor (tm-commit shape). */
    private ExecutorService getOrCreateCommitFanoutExecutor() {
        if (commitFanoutExecutor == null) {
            commitFanoutExecutor = new java.util.concurrent.ThreadPoolExecutor(1, 1,
                    0L, java.util.concurrent.TimeUnit.MILLISECONDS,
                    new java.util.concurrent.LinkedBlockingQueue<>(1000),
                    NopStreamThreadFactory.named("checkpoint-commit-fwd-" + jobId),
                    new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy());
        }
        return commitFanoutExecutor;
    }

    private ExecutorService createPersistExecutor() {
        int poolSize = Math.max(1, config.getAsyncSnapshotThreadPoolSize());
        return Executors.newFixedThreadPool(poolSize,
                NopStreamThreadFactory.named("checkpoint-persist-" + jobId));
    }

    public synchronized void abortPendingCheckpoint(PendingCheckpoint pending, String reason) {
        long checkpointId = pending.getCheckpointId();

        if (!pending.getStatus().compareAndSet(PendingCheckpoint.Status.RUNNING, PendingCheckpoint.Status.ABORTED)) {
            LOG.debug("Skip aborting checkpoint {} because status is {}", checkpointId, pending.getStatus().get());
            return;
        }

        PendingCheckpoint removed = pendingCheckpoints.remove(checkpointId);
        if (removed == null) {
            LOG.debug("Skip aborting checkpoint {} because it is no longer pending", checkpointId);
            return;
        }

        removed.abort(reason);
        decrementPendingCheckpointCount();

        metrics.recordAborted("Aborted: " + reason);

        // Engine-layer meter + job event (abort reason carried).
        engineMetrics().checkpointAborted();
        jobEventBus.fire(new io.nop.stream.runtime.event.StreamJobEvent(
                jobId, io.nop.stream.runtime.event.StreamJobEvent.EventType.CHECKPOINT_ABORTED,
                CoreMetrics.currentTimeMillis(), checkpointId, null, null, reason));
        recordHistory(new io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry(
                checkpointId, io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry.Status.ABORTED,
                pending.getTriggerTimestamp(), 0L, 0L, reason, CoreMetrics.currentTimeMillis()));

        // Notify participants about abort: finishCommit(false) keeps prepared
        // transactions for subsuming.
        // R6 CC-01 (plan 2326, closure audit M1b): the participant abort fan-out
        // (sink abort I/O) runs on the commit-fanout executor, NOT under this
        // monitor.
        final long fanoutAbortCheckpointId = checkpointId;
        getOrCreateCommitFanoutExecutor().execute(() -> {
            try {
                notifyParticipantsFinishCommit(fanoutAbortCheckpointId, false);

                // An aborted epoch is terminal — nothing will ever complete it,
                // so the terminal marker must not linger. Drop it unless
                // failed-commit retries still need it (they replay finishCommit
                // for this epoch using the recorded flag; removing it early would
                // make getOrDefault default the replay to success=true,
                // subsuming an aborted epoch as committed).
                if (!failedCommitParticipants.containsKey(fanoutAbortCheckpointId)) {
                    checkpointSuccessMap.remove(fanoutAbortCheckpointId);
                }
            } catch (Exception e) {
                LOG.error("Abort fan-out for checkpoint {} failed", fanoutAbortCheckpointId, e);
            }
        });

        notifyCheckpointAborted(checkpointId);

        java.util.function.BiConsumer<Long, String> handler = this.abortHandler;
        if (handler != null) {
            try {
                handler.accept(checkpointId, reason);
            } catch (Exception e) {
                LOG.error("Abort handler failed for checkpoint {}", checkpointId, e);
            }
        }

        LOG.warn("Aborted checkpoint {} for job {}: {}", checkpointId, jobId, reason);
    }

    public CompletedCheckpoint restoreFromCheckpoint() throws Exception {
        CompletedCheckpoint checkpoint = checkpointStorage.getLatestCheckpoint(jobId, pipelineId);
        if (checkpoint != null) {
            checkpoint.setRestored(true);
            latestCompletedCheckpoint = checkpoint;
            // Advance the ID counter past the restored durable
            // epoch so the next triggered checkpoint produces a strictly greater
            // epoch id. The monotonic-only advance logic is shared with the
            // EpochManifest-recovery path — delegate to avoid drift.
            advanceCheckpointIdCounterAfterRestore(checkpoint.getCheckpointId());
            LOG.info("Restored checkpoint {} for job {}", checkpoint.getCheckpointId(), jobId);
        }
        return checkpoint;
    }

    /**
     * Monotonic advance of the checkpoint ID counter past a restored epoch id
     * (EpochManifest-recovery path). Mirrors the counter-advance logic in
     * {@link #restoreFromCheckpoint()}: a counter already beyond {@code restoredId}
     * (e.g. an in-process coordinator that already triggered newer checkpoints) is
     * left untouched; otherwise the next triggered checkpoint produces a strictly
     * greater epoch id.
     *
     * <p>Without this advance, a manifest restore followed by new checkpoints would
     * restart the counter at 0, and every new checkpoint id would fall below the
     * restored epoch — {@code loadLatestEpochManifest} / {@code getLatestCheckpoint}
     * select by max id, so a crash in that window would roll the job back to the
     * stale epoch and silently lose the "completed" checkpoints.
     *
     * @param restoredId the epoch id recovered from the latest EpochManifest
     */
    public void advanceCheckpointIdCounterAfterRestore(long restoredId) {
        long currentCounter = checkpointIdCounter.get();
        if (restoredId >= currentCounter) {
            checkpointIdCounter.set(restoredId + 1);
        }
        LOG.info("Advanced checkpoint id counter for job {} to >= {} (restored epoch {})",
                jobId, restoredId + 1, restoredId);
    }

    public CompletedCheckpoint getLatestCheckpoint() {
        return latestCompletedCheckpoint;
    }

    public PendingCheckpoint getPendingCheckpoint(long checkpointId) {
        return pendingCheckpoints.get(checkpointId);
    }

    /**
     * Reports a task-level snapshot failure for the given {@code checkpointId} and
     * routes it to {@link #abortPendingCheckpoint(PendingCheckpoint, String)} so that
     * the matching {@link PendingCheckpoint} is aborted (rather than being silently
     * marked complete by a later successful ACK).
     *
     * <p>{@code GraphModelCheckpointExecutor}
     * wires the tracker's abort callback to this method so a failed operator
     * snapshot aborts the matching checkpoint instead of being mistaken for a
     * successful ACK.
     *
     * @param taskLocation the task that reported the snapshot failure (for diagnostics)
     * @param checkpointId the checkpoint whose operator snapshot failed
     * @param error        the snapshot error
     */
    public void reportTaskCheckpointFailure(TaskLocation taskLocation, long checkpointId, Exception error) {
        PendingCheckpoint pending = getPendingCheckpoint(checkpointId);
        if (pending == null) {
            LOG.debug("reportTaskCheckpointFailure: no pending checkpoint {} (already completed/aborted?) for task {}",
                    checkpointId, taskLocation);
            return;
        }
        String reason = "Operator snapshot failure reported by task " + taskLocation
                + ": " + (error == null ? "(no cause)" : error.getMessage());
        LOG.error("Aborting checkpoint {} due to task snapshot failure from {}",
                checkpointId, taskLocation, error);
        abortPendingCheckpoint(pending, reason);
    }

    /**
     * Aborts every currently-pending
     * checkpoint. Invoked by the coordinator's global-recovery path: a pending
     * checkpoint triggered under the dead generation can never complete — its
     * barrier/in-flight registrations are spread across task attempts that
     * recovery just replaced, so ACKs for at least some vertices will never
     * arrive and the pending would stall the checkpoint loop (maxConcurrent=1)
     * until its full timeout, starving post-recovery commits in bounded runs.
     * Aborting releases the loop immediately; the next periodic trigger runs
     * fresh under the new epoch on the stable post-recovery task set, and the
     * sinks' prepared transactions are preserved for subsuming
     * ({@code notifyParticipantsFinishCommit(false)} per checkpoint — same
     * semantics as a timeout abort).
     *
     * @param reason the abort reason recorded per checkpoint (observability)
     */
    public synchronized void abortAllPendingCheckpoints(String reason) {
        if (pendingCheckpoints.isEmpty()) {
            return;
        }
        for (PendingCheckpoint pending : new ArrayList<>(pendingCheckpoints.values())) {
            abortPendingCheckpoint(pending, reason);
        }
    }

    public int getNumberOfPendingCheckpoints() {
        return numPendingCheckpoints.get();
    }

    public void incrementTriggerFailures() {
        int failures = consecutiveTriggerFailures.incrementAndGet();
        int threshold = config.getMaxConsecutiveCheckpointFailures();
        if (failures >= threshold) {
            LOG.error("Checkpoint trigger failed {} consecutive times for job {} (threshold={})",
                    failures, jobId, threshold);
        } else {
            LOG.warn("Checkpoint trigger failed for job {} (consecutive failures={})", jobId, failures);
        }
    }

    public int getConsecutiveTriggerFailures() {
        return consecutiveTriggerFailures.get();
    }

    public CheckpointMetrics getMetrics() {
        return metrics;
    }

    public String getJobId() {
        return jobId;
    }

    /**
     * Injects the job-level event bus. Checkpoint
     * progress events (COMPLETED/FAILED/ABORTED) are then dispatched to the
     * job's listeners in addition to the internal CheckpointListener
     * notifications.
     */
    public void setJobEventBus(io.nop.stream.runtime.event.StreamJobEventBus bus) {
        if (bus != null) {
            this.jobEventBus = bus;
        }
    }

    public io.nop.stream.runtime.event.StreamJobEventBus getJobEventBus() {
        return jobEventBus;
    }

    private io.nop.stream.runtime.metrics.EngineMetrics engineMetrics() {
        io.nop.stream.runtime.metrics.EngineMetrics m = engineMetrics;
        if (m == null) {
            m = io.nop.stream.runtime.metrics.EngineMetrics.forJob(jobId);
            engineMetrics = m;
        }
        return m;
    }

    private void recordHistory(io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry entry) {
        checkpointHistory.recordHistory(entry);
    }

    /**
     * Snapshot of the bounded checkpoint observation
     * history (newest first). Each entry carries status/duration/size and,
     * for FAILED/ABORTED entries, the failure cause.
     */
    public java.util.List<io.nop.stream.runtime.checkpoint.metrics.CheckpointHistoryEntry> getCheckpointHistory() {
        return checkpointHistory.getCheckpointHistory();
    }

    public void setCheckpointHistoryMaxEntries(int maxEntries) {
        checkpointHistory.setCheckpointHistoryMaxEntries(maxEntries);
    }

    public int getCheckpointHistoryMaxEntries() {
        return checkpointHistory.getCheckpointHistoryMaxEntries();
    }

    /**
     * Drops the {@code count} OLDEST entries from the
     * observation history (governance sweep). Returns the number of entries
     * actually removed.
     */
    public int pruneOldestCheckpointHistory(int count) {
        return checkpointHistory.pruneOldestCheckpointHistory(count);
    }

    protected Set<TaskLocation> getTasksToAcknowledge() {
        return new HashSet<>(tasksToAcknowledge);
    }

    public void setTasksToAcknowledge(Collection<TaskLocation> taskLocations) {
        Set<TaskLocation> newSet = ConcurrentHashMap.newKeySet();
        if (taskLocations != null) {
            for (TaskLocation loc : taskLocations) {
                if (loc != null) {
                    newSet.add(loc);
                }
            }
        }
        this.tasksToAcknowledge = newSet;
        // C3: a (re-)assignment installs a NEW task generation. Terminal
        // tombstones from the previous generation are generation-scoped (the
        // DISTRIBUTED completedSubtaskKeys tombstones are cleared the same way
        // on fencing rotation) — every subtask is re-attempted, so its terminal
        // state must be re-reported before it is contracted out again.
        this.completedTasks.clear();
    }

    public synchronized void registerTask(TaskLocation taskLocation) {
        this.tasksToAcknowledge.add(taskLocation);
    }

    public synchronized void unregisterTask(TaskLocation taskLocation) {
        this.tasksToAcknowledge.remove(taskLocation);
    }

    /**
     * C3 (plan 369): contracts a task that reached its terminal COMPLETED state
     * out of the checkpoint participant set. A completed task can never ACK a
     * later epoch, so leaving it registered kept every subsequent checkpoint
     * waiting for its full {@code checkpointTimeout} and aborting (the bounded
     * job 600s timeout-abort loop). The contracted task's state is inherited
     * into subsequent checkpoints from {@link #latestCompletedCheckpoint} at
     * trigger time (see {@link #tryTriggerCheckpointWithReason}), so each new
     * epoch still carries the full task-state set.
     *
     * <p>In-flight epochs are RESCUED immediately: every pending checkpoint that
     * was triggered before the contraction and still waits for this task's ACK
     * is acknowledged on the task's behalf (inherited state, or an empty
     * snapshot when no durable prior state exists) — the Flink
     * {@code onExecutionVertexFinished} analog. Without the sweep, an epoch
     * racing the terminal notification (LOCAL poll tick / DISTRIBUTED tombstone
     * RPC) could only end in the checkpoint-timeout abort.
     *
     * <p>Callers: the DISTRIBUTED {@code JobCoordinator.reportTaskStatus}
     * COMPLETED tombstone path and the LOCAL {@code SupervisionLoop} terminal
     * scan. Idempotent. Unknown (never-registered) locations are ignored so a
     * stale report cannot inject a phantom tombstone.
     *
     * @param taskLocation the task that reached COMPLETED (same location family
     *                     as the registered ACK set)
     */
    public synchronized void markTaskCompleted(TaskLocation taskLocation) {
        if (taskLocation == null) {
            return;
        }
        if (!tasksToAcknowledge.contains(taskLocation)) {
            LOG.debug("Ignoring markTaskCompleted for unknown/unregistered task {}", taskLocation);
            return;
        }
        if (tasksToAcknowledge.remove(taskLocation)) {
            LOG.info("Task {} reached terminal state: contracted out of checkpoint ACK set "
                    + "({} participant(s) remaining) for job {}", taskLocation,
                    tasksToAcknowledge.size(), jobId);
        }
        completedTasks.add(taskLocation);

        // C3 rescue: resolve the terminal task's outstanding ACK obligation on
        // every in-flight epoch so a pending checkpoint that raced the terminal
        // notification completes instead of timing out.
        for (PendingCheckpoint pending : pendingCheckpoints.values()) {
            if (pending.getStatus().get() != PendingCheckpoint.Status.RUNNING
                    || !pending.getNotYetAcknowledgedTasks().contains(taskLocation)) {
                continue;
            }
            try {
                pending.acknowledgeTask(taskLocation,
                        inheritTerminalTaskState(taskLocation, pending.getCheckpointId()));
                LOG.info("Rescued in-flight checkpoint {} of job {}: acknowledged terminal task {} "
                        + "with inherited state", pending.getCheckpointId(), jobId, taskLocation);
            } catch (Exception e) {
                LOG.warn("Failed to rescue in-flight checkpoint {} for terminal task {} of job {}",
                        pending.getCheckpointId(), taskLocation, jobId, e);
                continue;
            }
            if (pending.isFullyAcknowledged()) {
                completePendingCheckpoint(pending.toCompletedCheckpoint());
            }
        }
    }

    /**
     * C3: the state a terminal (COMPLETED) task contributes to an epoch — its
     * snapshot from the latest completed checkpoint when one exists, otherwise
     * an EMPTY snapshot (the Flink {@code FinishedOperatorState} analog: a task
     * that finished before any epoch turned durable has nothing durable to
     * inherit, and an empty snapshot is the truthful contribution). A terminal
     * participant must never leave an epoch un-ACK-able.
     */
    private TaskStateSnapshot inheritTerminalTaskState(TaskLocation location, long checkpointId) {
        CompletedCheckpoint latest = latestCompletedCheckpoint;
        TaskStateSnapshot inherited = latest != null ? latest.getTaskState(location) : null;
        if (inherited != null) {
            return inherited;
        }
        LOG.debug("Terminal task {} of job {} has no durable prior state for checkpoint {} — "
                + "contributing an empty snapshot", location, jobId, checkpointId);
        return new TaskStateSnapshot(location, checkpointId);
    }

    private void scheduleTimeout(PendingCheckpoint pending) {
        if (timeoutScheduler.isShutdown()) {
            return;
        }

        timeoutScheduler.schedule(() -> {
            if (!pending.getCompletableFuture().isDone()) {
                abortPendingCheckpoint(pending, "Timeout");
            }
        }, config.getCheckpointTimeout(), TimeUnit.MILLISECONDS);
    }

    private void decrementPendingCheckpointCount() {
        numPendingCheckpoints.updateAndGet(count -> count > 0 ? count - 1 : 0);
    }

    // Package-private: invoked by RetentionCleaner (executor lifecycle stays on the host).
    ExecutorService getOrCreateRetentionExecutor() {
        // Lazy init is monitor-safe: only called (transitively) from success-callback call sites
        // which all hold the coordinator monitor.
        if (retentionExecutor == null) {
            retentionExecutor = createRetentionExecutor();
        }
        return retentionExecutor;
    }

    ExecutorService createRetentionExecutor() {
        return Executors.newSingleThreadExecutor(
                NopStreamThreadFactory.named("checkpoint-retention-" + jobId));
    }

    private void notifyCheckpointCompleted(long checkpointId) {
        for (CheckpointListener listener : listeners) {
            try {
                listener.notifyCheckpointComplete(checkpointId);
            } catch (Exception e) {
                LOG.error("Failed to notify checkpoint completion to listener", e);
            }
        }
    }

    private void notifyCheckpointAborted(long checkpointId) {
        for (CheckpointListener listener : listeners) {
            try {
                listener.notifyCheckpointAborted(checkpointId);
            } catch (Exception e) {
                LOG.error("Failed to notify checkpoint abortion to listener", e);
            }
        }
    }

    private void notifyParticipantsFinishCommit(long checkpointId, boolean success) {
        checkpointSuccessMap.put(checkpointId, success);
        for (int i = participants.size() - 1; i >= 0; i--) {
            CheckpointParticipant participant = participants.get(i);
            try {
                participant.finishCommit(checkpointId, success);
            } catch (Exception e) {
                LOG.error("finishCommit({}) failed for participant {} on checkpoint {}, deferring to retry cycle",
                        success, i, checkpointId, e);
                failedCommitParticipants.computeIfAbsent(checkpointId, k -> ConcurrentHashMap.newKeySet()).add(participant);
            }
        }
    }

    private void retryFailedCommits() {
        if (failedCommitParticipants.isEmpty()) return;

        Iterator<Map.Entry<Long, Set<CheckpointParticipant>>> it = failedCommitParticipants.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Long, Set<CheckpointParticipant>> entry = it.next();
            long failedEpoch = entry.getKey();
            Set<CheckpointParticipant> failedParts = entry.getValue();
            Set<CheckpointParticipant> stillFailing = ConcurrentHashMap.newKeySet();
            boolean originalSuccess = checkpointSuccessMap.getOrDefault(failedEpoch, true);

            for (CheckpointParticipant participant : failedParts) {
                if (participants.contains(participant)) {
                    try {
                        participant.finishCommit(failedEpoch, originalSuccess);
                        LOG.info("Retried finishCommit for participant on epoch {} with success={} succeeded", failedEpoch, originalSuccess);
                    } catch (Exception e) {
                        LOG.warn("Retry finishCommit for participant on epoch {} still failing", failedEpoch, e);
                        stillFailing.add(participant);
                    }
                }
            }

            if (stillFailing.isEmpty()) {
                it.remove();
                checkpointSuccessMap.remove(failedEpoch);
            } else {
                it.remove();
                failedCommitParticipants.put(failedEpoch, stillFailing);
            }
        }
    }

    public void shutdown() {
        isShutdown = true;

        // Final synchronous retention cleanup: the async chain (scheduleRetentionCleanup
        // coalescing) may not have fully converged before shutdown, especially when the
        // retention executor is terminated while a re-submission is pending in the finally
        // block. Running one last cleanup here guarantees both checkpoint and manifest
        // planes converge to <= maxRetained after shutdown returns.
        try {
            retentionCleaner.cleanupOldCheckpoints();
        } catch (Exception e) {
            LOG.warn("Failed to run final retention cleanup during shutdown for job {}", jobId, e);
        }

        // N2/N3: persist executor lifecycle is tied to terminal shutdown() only. The
        // awaitTermination grace window mirrors the standard executor shutdown
        // discipline so in-flight persist tasks (storage writes) get a brief
        // grace window to finish before shutdownNow interrupts them.
        ExecutorService pe = persistExecutor;
        if (pe != null) {
            pe.shutdown();
            try {
                if (!pe.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                    pe.shutdownNow();
                }
            } catch (InterruptedException e) {
                pe.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        // R6 CC-01 (plan 2326): participant commit/abort fan-out executor shares
        // the terminal-only lifecycle (grace window drains queued fan-outs so a
        // shutdown racing a completion still delivers the epoch's commits).
        ExecutorService fe = commitFanoutExecutor;
        if (fe != null) {
            fe.shutdown();
            try {
                if (!fe.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                    fe.shutdownNow();
                }
            } catch (InterruptedException e) {
                fe.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        // Retention executor gets the same terminal-shutdown discipline
        // as the persist executor (grace window for the in-flight retention run, then
        // interrupt). A run interrupted here is logged inside cleanupOldCheckpoints;
        // rows beyond maxRetained converge on the next coordinator's first completion.
        ExecutorService re = retentionExecutor;
        if (re != null) {
            re.shutdown();
            try {
                if (!re.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                    re.shutdownNow();
                }
            } catch (InterruptedException e) {
                re.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        timeoutScheduler.shutdownNow();
        try {
            if (!timeoutScheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                LOG.warn("Timeout scheduler did not terminate within 5 seconds for job {}", jobId);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        for (PendingCheckpoint pending : pendingCheckpoints.values()) {
            long checkpointId = pending.getCheckpointId();
            notifyParticipantsFinishCommit(checkpointId, false);
            notifyCheckpointAborted(checkpointId);
            pending.dispose();
        }
        pendingCheckpoints.clear();
        numPendingCheckpoints.set(0);
        listeners.clear();
        participants.clear();
        failedCommitParticipants.clear();
        checkpointSuccessMap.clear();
        abortHandler = null;

        LOG.info("Checkpoint coordinator shutdown for job {}", jobId);
    }

    /**
     * Build an EpochManifest from a CompletedCheckpoint (non-incremental: segments empty).
     */
    private EpochManifest buildEpochManifest(CompletedCheckpoint completed) {
        return buildEpochManifest(completed, currentFingerprint, null);
    }

    /**
     * Build an EpochManifest, optionally carrying incremental segments and an
     * explicitly-captured fingerprint (manifest-snapshot → storage-I/O handoff for incremental mode).
     */
    private EpochManifest buildEpochManifest(CompletedCheckpoint completed,
                                             StreamModelFingerprint fingerprint,
                                             List<StateSegmentDescriptor> segments) {
        // Snapshot all registered source enumerator states into the manifest's
        // sourceEnumeratorSnapshots section. Empty map if no source-api coordinators
        // registered (non-source-api jobs / legacy checkpoints remain unaffected).
        Map<String, io.nop.stream.core.checkpoint.SourceEnumeratorSnapshot> enumeratorSnapshots =
                snapshotSourceEnumerators(completed.getCheckpointId());

        return new EpochManifest(
                completed.getCheckpointId(),
                completed.getJobId(),
                completed.getPipelineId(),
                completed.getCompletedTimestamp(),
                completed.getCheckpointType(),
                EpochState.COMMITTED,
                completed.getTaskStates(),
                fingerprint,
                segments,  // null → empty list inside EpochManifest constructor
                enumeratorSnapshots
        );
    }

    /**
     * Snapshots every registered {@code LocalSourceCoordinator} into a manifest
     * entry keyed by source vertex id. Returns an empty map when no source-api coordinators
     * are registered (the common case for non-split-source jobs).
     *
     * <p>Coordinators register themselves into {@code SourceCoordinatorRegistry} lazily on
     * first subtask open; here we look them up by vertex id and ask each for its serialized
     * enumerator state. Failures are logged and skipped (a missing enumerator entry on
     * restore is recoverable — the source will rediscover splits from scratch).
     */
    private Map<String, io.nop.stream.core.checkpoint.SourceEnumeratorSnapshot> snapshotSourceEnumerators(
            long checkpointId) {
        Map<String, io.nop.stream.core.checkpoint.SourceEnumeratorSnapshot> result = new java.util.LinkedHashMap<>();
        for (Integer vertexId : registeredSourceVertexIds) {
            io.nop.stream.core.source.coordinator.LocalSourceCoordinator<? extends io.nop.stream.core.source.SourceSplit, ?> coord =
                    io.nop.stream.core.source.coordinator.SourceCoordinatorRegistry.get(vertexId);
            if (coord == null) {
                continue;
            }
            try {
                io.nop.stream.core.source.coordinator.SourceEnumeratorSerializedState snap =
                        coord.snapshotState(checkpointId);
                if (snap != null) {
                    result.put(String.valueOf(vertexId),
                            new io.nop.stream.core.checkpoint.SourceEnumeratorSnapshot(
                                    snap.getVersion(), snap.getStateBytes()));
                }
            } catch (Exception e) {
                LOG.warn("Failed to snapshot source enumerator state for vertex {} (skipped)",
                        vertexId, e);
            }
        }
        return result;
    }

    /**
     * Registers a source vertex id whose coordinator's enumerator state should
     * be snapshotted into the manifest on each checkpoint. Called by the execution layer
     * when a source-api vertex is deployed.
     */
    public void registerSourceEnumeratorVertex(int vertexId) {
        registeredSourceVertexIds.add(vertexId);
    }

    private final java.util.Set<Integer> registeredSourceVertexIds =
            java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());

    /**
     * Try to restore from EpochManifest first, fall back to CompletedCheckpoint.
     */
    public EpochManifest restoreLatestEpochManifest() throws Exception {
        return checkpointStorage.loadLatestEpochManifest(jobId, pipelineId);
    }

    // --- Fingerprint management ---

    private volatile StreamModelFingerprint currentFingerprint;

    public void setCurrentFingerprint(StreamModelFingerprint fingerprint) {
        this.currentFingerprint = fingerprint;
    }

    public StreamModelFingerprint getCurrentFingerprint() {
        return currentFingerprint;
    }

    // --- Incremental checkpoint (segment store) wiring ---

    public ISegmentStore getSegmentStore() {
        return segmentStore;
    }

    public void setSegmentStore(ISegmentStore segmentStore) {
        this.segmentStore = segmentStore;
    }

    public boolean isIncrementalCheckpointEnabled() {
        return incrementalCheckpointEnabled;
    }

    public void setIncrementalCheckpointEnabled(boolean incrementalCheckpointEnabled) {
        this.incrementalCheckpointEnabled = incrementalCheckpointEnabled;
        if (incrementalCheckpointEnabled && sharedStateRegistry == null) {
            this.sharedStateRegistry = new SharedStateRegistryImpl();
        }
    }

    /**
     * Diagnostic accessor. Returns
     * the job-scoped shared-state registry, or {@code null} when incremental is disabled.
     */
    public SharedStateRegistry getSharedStateRegistry() {
        return sharedStateRegistry;
    }

    /**
     * Diagnostic accessor: the segments recorded for a checkpoint (for GC), or
     * empty if none.
     */
    public List<StateSegmentDescriptor> getCheckpointSegments(long checkpointId) {
        return checkpointSegments.getOrDefault(checkpointId, Collections.emptyList());
    }

    /**
     * Validate the incremental-checkpoint configuration so a misconfigured job fails fast
     * instead of silently degrading. Per the No-Silent-No-Op
     * rule: {@code incrementalCheckpointEnabled=true} with no {@code segmentStore}
     * throws {@link UnsupportedOperationException} rather than silently falling back to the
     * non-incremental path. The sync/incremental mutex (incremental requires async snapshot)
     * is also enforced here (Design Decision: sync and incremental modes are mutually exclusive).
     */
    public void validateIncrementalConfig() {
        if (incrementalCheckpointEnabled) {
            if (segmentStore == null) {
                throw new StreamException(ERR_STREAM_UNSUPPORTED).param(ARG_OPERATION, "incrementalCheckpointEnabled=true but segmentStore is null for job " + jobId
                                + " — incremental checkpoints require an ISegmentStore (no silent fallback)");
            }
            if (!config.isAsyncSnapshotEnabled()) {
                throw new StreamException(ERR_STREAM_INVALID_STATE).param(ARG_DETAIL, "incrementalCheckpointEnabled=true but asyncSnapshotEnabled=false for job " + jobId
                                + " — incremental checkpoints require async snapshot (segments computation "
                                + "involves RocksDB I/O + SHA-256 and cannot run under the sync monitor path)");
            }
        }
    }

    /**
     * Restart recovery: rebuild the {@link SharedStateRegistry} reference counts
     * and the {@link #checkpointSegments} GC map from the retained EpochManifests, then
     * run a one-time orphan-segment cleanup so files left dangling by a crash are removed.
     * Idempotent: safe to call on every coordinator (re)start. No-op when incremental is
     * disabled. Errors are logged and swallowed so a recovery failure does not prevent the
     * coordinator from starting (segments can be re-materialized on the next checkpoint).
     */
    public synchronized void restoreSharedStateRegistry() {
        if (!incrementalCheckpointEnabled || sharedStateRegistry == null || segmentStore == null) {
            return;
        }
        checkpointSegments.clear();
        try {
            List<EpochManifest> retained = checkpointStorage.loadRetainedEpochManifests(
                    jobId, pipelineId, config.getMaxRetainedCheckpoints());
            Set<String> referenced = new HashSet<>();
            for (EpochManifest manifest : retained) {
                List<StateSegmentDescriptor> segs = manifest.getSegments();
                if (segs == null || segs.isEmpty()) {
                    continue;
                }
                List<StateSegmentDescriptor> registered = new java.util.ArrayList<>();
                for (StateSegmentDescriptor seg : segs) {
                    seg.validateCodec();
                    String hash = seg.getPath();
                    sharedStateRegistry.register(new SharedStateHandle(hash, null, 0L));
                    referenced.add(hash);
                    registered.add(seg);
                }
                checkpointSegments.put(manifest.getEpochId(), registered);
            }
            LOG.info("Restored shared-state registry for job {}: {} retained manifests, {} distinct segments",
                    jobId, retained.size(), referenced.size());
            cleanupOrphanSegments(referenced);
        } catch (Exception e) {
            LOG.warn("Failed to restore shared-state registry for job {} — segments may be re-materialized on next checkpoint",
                    jobId, e);
        }
    }

    /**
     * One-time orphan cleanup: scan the {@link ISegmentStore}'s shared-state area
     * and discard any segment file not currently referenced by the registry. Called after
     * {@link #restoreSharedStateRegistry()} rebuilds the reference set.
     */
    private void cleanupOrphanSegments(Set<String> referencedHashes) {
        if (!(segmentStore instanceof io.nop.stream.core.checkpoint.storage.LocalFileSegmentStore)) {
            // Only the local-file store exposes a scanable base directory; remote/JDBC stores
            // would need their own enumeration. LocalFile is the supported store.
            return;
        }
        io.nop.stream.core.checkpoint.storage.LocalFileSegmentStore localStore =
                (io.nop.stream.core.checkpoint.storage.LocalFileSegmentStore) segmentStore;
        java.nio.file.Path sharedDir = localStore.getBaseDir().resolve("shared-state");
        if (!java.nio.file.Files.exists(sharedDir)) {
            return;
        }
        try (java.util.stream.Stream<java.nio.file.Path> walk = java.nio.file.Files.walk(sharedDir)) {
            walk.filter(java.nio.file.Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().endsWith(".sst"))
                    .forEach(p -> {
                        String name = p.getFileName().toString();
                        String hash = name.substring(0, name.length() - ".sst".length());
                        if (!referencedHashes.contains(hash)) {
                            try {
                                java.nio.file.Files.deleteIfExists(p);
                                LOG.debug("Deleted orphan segment {} during restart cleanup", hash);
                            } catch (Exception dex) {
                                LOG.warn("Failed to delete orphan segment {} for job {}", hash, jobId, dex);
                            }
                        }
                    });
        } catch (Exception e) {
            LOG.warn("Orphan segment cleanup scan failed for job {}", jobId, e);
        }
    }
}