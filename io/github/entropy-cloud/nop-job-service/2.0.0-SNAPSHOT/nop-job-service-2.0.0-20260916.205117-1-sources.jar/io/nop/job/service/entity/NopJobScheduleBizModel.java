
package io.nop.job.service.entity;

import io.nop.api.core.annotations.biz.BizMutation;
import io.nop.api.core.annotations.biz.BizModel;
import io.nop.api.core.annotations.core.Name;
import io.nop.api.core.config.AppConfig;
import io.nop.api.core.exceptions.NopException;
import io.nop.biz.crud.CrudBizModel;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.json.JsonTool;
import io.nop.job.api.spec.TriggerSpec;
import io.nop.job.biz.INopJobScheduleBiz;
import io.nop.job.core.ITriggerEvalContext;
import io.nop.job.core._NopJobCoreConstants;
import io.nop.job.core.trigger.JobTriggerCalculator;
import io.nop.job.dao.entity.NopJobFire;
import io.nop.job.dao.entity.NopJobSchedule;
import io.nop.job.dao.helper.JobScheduleStateMachine;
import io.nop.job.dao.helper.TriggerSpecHelper;
import io.nop.job.dao.store.IJobScheduleStore;
import io.nop.job.service.JobContextHelper;
import io.nop.orm.dao.IOrmEntityDao;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Map;
import java.util.function.IntPredicate;

import static io.nop.job.service.NopJobErrors.ERR_JOB_SCHEDULE_ALREADY_ARCHIVED;
import static io.nop.job.service.NopJobErrors.ERR_JOB_SCHEDULE_DELETE_NOT_ALLOWED;
import static io.nop.job.service.NopJobErrors.ERR_JOB_SCHEDULE_INVALID_STATUS_TRANSITION;
import static io.nop.job.service.NopJobErrors.ERR_JOB_SCHEDULE_MANUAL_TRIGGER_NOT_ALLOWED;
import static io.nop.job.service.NopJobErrors.ERR_JOB_SCHEDULE_MANUAL_TRIGGER_DISCARDED;

@BizModel("NopJobSchedule")
public class NopJobScheduleBizModel extends CrudBizModel<NopJobSchedule> implements INopJobScheduleBiz{
    static final Logger LOG = LoggerFactory.getLogger(NopJobScheduleBizModel.class);

    protected IJobScheduleStore scheduleStore;

    public NopJobScheduleBizModel(){
        setEntityName(NopJobSchedule.class.getName());
    }

    @Override
    public boolean delete(String id, IServiceContext context) {
        throw new NopException(ERR_JOB_SCHEDULE_DELETE_NOT_ALLOWED)
                .param("jobScheduleId", id);
    }

    @Inject
    public void setScheduleStore(IJobScheduleStore scheduleStore) {
        this.scheduleStore = scheduleStore;
    }

    @Override
    @BizMutation
    public void enableSchedule(@Name("id") String id, IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "enableSchedule", context);
        validateScheduleStatus(schedule, "enableSchedule", JobScheduleStateMachine::canEnable);
        persistSchedule(schedule, () -> {
            schedule.setScheduleStatus(_NopJobCoreConstants.SCHEDULE_STATUS_ENABLED);
            schedule.setNextFireTime(recalculateNextFireTime(schedule));
        }, "enableSchedule", context);
    }

    @Override
    @BizMutation
    public void disableSchedule(@Name("id") String id, IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "disableSchedule", context);
        if (JobScheduleStateMachine.isDisabled(schedule.getScheduleStatus())) {
            return;
        }

        validateScheduleStatus(schedule, "disableSchedule", JobScheduleStateMachine::canDisable);
        persistSchedule(schedule,
                () -> schedule.setScheduleStatus(_NopJobCoreConstants.SCHEDULE_STATUS_DISABLED),
                "disableSchedule", context);
    }

    @Override
    @BizMutation
    public void pauseSchedule(@Name("id") String id, IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "pauseSchedule", context);
        if (JobScheduleStateMachine.isPaused(schedule.getScheduleStatus())) {
            return;
        }

        validateScheduleStatus(schedule, "pauseSchedule", JobScheduleStateMachine::canPause);
        persistSchedule(schedule,
                () -> schedule.setScheduleStatus(_NopJobCoreConstants.SCHEDULE_STATUS_PAUSED),
                "pauseSchedule", context);
    }

    @Override
    @BizMutation
    public void resumeSchedule(@Name("id") String id, IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "resumeSchedule", context);
        validateScheduleStatus(schedule, "resumeSchedule", JobScheduleStateMachine::canResume);
        persistSchedule(schedule, () -> {
            schedule.setScheduleStatus(_NopJobCoreConstants.SCHEDULE_STATUS_ENABLED);
            schedule.setNextFireTime(recalculateNextFireTime(schedule));
        }, "resumeSchedule", context);
    }

    @Override
    @BizMutation
    public void triggerNow(@Name("id") String id, @Name("overrideParams") Map<String, Object> overrideParams,
                           IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "triggerNow", context);
        validateManualTriggerSchedule(schedule, "triggerNow");

        NopJobFire fire = buildManualFire(schedule, overrideParams, context);
        boolean created = scheduleStore.insertManualFire(schedule, fire);
        if (!created) {
            throw new NopException(ERR_JOB_SCHEDULE_MANUAL_TRIGGER_DISCARDED)
                    .param("jobScheduleId", schedule.getJobScheduleId())
                    .param("jobName", schedule.getJobName());
        }
        afterEntityChange(schedule, "triggerNow", context);
    }

    @Override
    @BizMutation
    public void archiveSchedule(@Name("id") String id, IServiceContext context) {
        NopJobSchedule schedule = requireEntity(id, "archiveSchedule", context);
        if (JobScheduleStateMachine.isArchived(schedule.getScheduleStatus())) {
            return;
        }

        validateScheduleStatus(schedule, "archiveSchedule", JobScheduleStateMachine::canArchive);
        persistSchedule(schedule, () -> {
            schedule.setScheduleStatus(_NopJobCoreConstants.SCHEDULE_STATUS_ARCHIVED);
            schedule.setNextFireTime(null);
        }, "archiveSchedule", context);
    }

    @SuppressWarnings("unchecked")
    private void persistSchedule(NopJobSchedule schedule, Runnable fieldSetter, String action, IServiceContext context) {
        IOrmEntityDao<NopJobSchedule> ormDao = (IOrmEntityDao<NopJobSchedule>) daoProvider().daoFor(NopJobSchedule.class);

        if (!ormDao.updateWithRetry(schedule, 5, fieldSetter)) {
            LOG.warn("nop.job.schedule.persist-optimistic-lock-exhausted:scheduleId={}", schedule.getJobScheduleId());
            throw new NopException(ERR_JOB_SCHEDULE_INVALID_STATUS_TRANSITION)
                    .param("jobScheduleId", schedule.getJobScheduleId())
                    .param("action", action)
                    .param("reason", "Optimistic lock exhausted after 5 retries");
        }

        afterEntityChange(schedule, action, context);
    }

    private void validateManualTriggerSchedule(NopJobSchedule schedule, String action) {
        if (JobScheduleStateMachine.canTriggerNow(schedule.getScheduleStatus())) {
            return;
        }

        throw new NopException(ERR_JOB_SCHEDULE_MANUAL_TRIGGER_NOT_ALLOWED)
                .param("jobScheduleId", schedule.getJobScheduleId())
                .param("jobName", schedule.getJobName())
                .param("scheduleStatus", schedule.getScheduleStatus())
                .param("action", action);
    }

    private void validateScheduleStatus(NopJobSchedule schedule, String action, IntPredicate canTransition) {
        Integer scheduleStatus = schedule.getScheduleStatus();
        if (JobScheduleStateMachine.isArchived(scheduleStatus)) {
            throw new NopException(ERR_JOB_SCHEDULE_ALREADY_ARCHIVED)
                    .param("jobScheduleId", schedule.getJobScheduleId())
                    .param("jobName", schedule.getJobName())
                    .param("action", action);
        }

        if (scheduleStatus != null && canTransition.test(scheduleStatus)) {
            return;
        }

        throw new NopException(ERR_JOB_SCHEDULE_INVALID_STATUS_TRANSITION)
                .param("jobScheduleId", schedule.getJobScheduleId())
                .param("jobName", schedule.getJobName())
                .param("scheduleStatus", schedule.getScheduleStatus())
                .param("action", action);
    }

    private NopJobFire buildManualFire(NopJobSchedule schedule, Map<String, Object> overrideParams,
                                       IServiceContext context) {
        long now = scheduleStore.getCurrentTime();
        Timestamp fireTime = new Timestamp(now);

        NopJobFire fire = daoProvider().daoFor(NopJobFire.class).newEntity();
        fire.setJobScheduleId(schedule.getJobScheduleId());
        fire.setNamespaceId(schedule.getNamespaceId());
        fire.setGroupId(schedule.getGroupId());
        fire.setJobName(schedule.getJobName());
        fire.setTriggerSource(_NopJobCoreConstants.TRIGGER_SOURCE_MANUAL);
        fire.setScheduledFireTime(fireTime);
        fire.setFireStatus(_NopJobCoreConstants.FIRE_STATUS_WAITING);
        fire.setPlannerInstanceId(AppConfig.hostId());
        fire.setTriggeredBy(JobContextHelper.resolveTriggeredBy(context));
        fire.setPartitionIndex(schedule.getPartitionIndex());
        fire.setJobParamsSnapshot(JsonTool.stringify(resolveJobParams(schedule, overrideParams)));
        fire.setExecutorKind(schedule.getExecutorKind());
        fire.setDispatchMode(schedule.getDispatchMode());
        return fire;
    }

    private Map<String, Object> resolveJobParams(NopJobSchedule schedule, Map<String, Object> overrideParams) {
        if (overrideParams != null) {
            return overrideParams;
        }

        Map<String, Object> scheduleParams = schedule.getJobParamsComponent().get_jsonMap();
        return scheduleParams != null ? scheduleParams : Collections.emptyMap();
    }

    private Timestamp recalculateNextFireTime(NopJobSchedule schedule) {
        long now = scheduleStore.getCurrentTime();
        long next = JobTriggerCalculator.calculateNextFireTime(
                toTriggerSpec(schedule),
                toEvalContext(schedule),
                now
        );
        return next <= 0 ? null : new Timestamp(next);
    }

    private TriggerSpec toTriggerSpec(NopJobSchedule schedule) {
        return TriggerSpecHelper.toTriggerSpec(schedule);
    }

    private ITriggerEvalContext toEvalContext(NopJobSchedule schedule) {
        return TriggerSpecHelper.toEvalContext(schedule);
    }
}
