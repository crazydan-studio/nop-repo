/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.sys.dao;

public interface NopSysDaoConstants extends _NopSysDaoConstants {
    String SYS_DICT_PREFIX = "sys/";

    int SYS_EVENT_STATUS_CLAIMED = 5;

    String SEQ_DEFAULT = "default";

    String SEQ_TYPE_SNOWFLAKE = "snowflake";

    String RESOURCE_GROUP_DEFAULT = "default";

    String PROP_DELETED = "deleted";

    String OPERATION_SAVE = "save";

    String OPERATION_UPDATE = "update";

    String OPERATION_DELETE = "delete";
}
