/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.ooxml.xlsx.model.drawing;

import io.nop.core.lang.xml.XNode;
import io.nop.excel.model.ExcelChartModel;
import io.nop.excel.model.ExcelClientAnchor;
import io.nop.excel.model.ExcelImage;
import io.nop.excel.util.UnitsHelper;
import io.nop.ooxml.xlsx.chart.DrawingChartBuilder;

import java.util.List;

public class DrawingBuilder {
    
    // Chart builder instance for chart support
    private final DrawingChartBuilder chartBuilder = DrawingChartBuilder.INSTANCE;
    public XNode build(List<ExcelImage> images) {
        XNode node = XNode.makeDocNode("xdr:wsDr");
        node.setAttr("xmlns:xdr", "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing");
        node.setAttr("xmlns:a", "http://schemas.openxmlformats.org/drawingml/2006/main");

        for (int i = 0, n = images.size(); i < n; i++) {
            XNode anchor = buildImageAnchor(images.get(i), i);
            node.appendChild(anchor);
        }
        return node;
    }
    
    /**
     * Build drawing with charts support.
     * This method supports both images and charts in the same drawing.
     */
    public XNode buildWithCharts(List<ExcelImage> images, List<ExcelChartModel> charts) {
        XNode node = XNode.makeDocNode("xdr:wsDr");
        node.setAttr("xmlns:xdr", "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing");
        node.setAttr("xmlns:a", "http://schemas.openxmlformats.org/drawingml/2006/main");

        int index = 0;
        
        // Add images
        if (images != null) {
            for (ExcelImage image : images) {
                XNode anchor = buildImageAnchor(image, index++);
                node.appendChild(anchor);
            }
        }
        
        // Add charts
        if (charts != null) {
            for (ExcelChartModel chart : charts) {
                XNode anchor = buildChartAnchor(chart, index++);
                node.appendChild(anchor);
            }
        }
        
        return node;
    }
    
    /**
     * Build chart anchor using DrawingChartBuilder.
     */
    public XNode buildChartAnchor(ExcelChartModel chart, int index) {
        // Build the basic anchor structure
        XNode anchor = buildAnchor0(chart.getAnchor());
        
        // Generate relationship ID for chart (this would be set by the calling context)
        String relationshipId = "rId" + (index + 1);
        
        // Create graphic frame for chart
        XNode graphicFrame = anchor.addChild("xdr:graphicFrame");

        // Non-visual properties
        XNode nvGraphicFramePr = graphicFrame.addChild("xdr:nvGraphicFramePr");
        XNode cNvPr = nvGraphicFramePr.addChild("xdr:cNvPr");
        cNvPr.setAttr("id", index + 1);
        cNvPr.setAttr("name", chart.getName() != null ? chart.getName() : "Chart " + (index + 1));
        
        // Set description if available
        if (chart.getDescription() != null && !chart.getDescription().trim().isEmpty()) {
            cNvPr.setAttr("descr", chart.getDescription());
        }
        
        XNode cNvGraphicFramePr = nvGraphicFramePr.addChild("xdr:cNvGraphicFramePr");
        cNvGraphicFramePr.addChild("a:graphicFrameLocks").setAttr("noGrp", "1");
        
        // Transform properties
        XNode xfrm = graphicFrame.addChild("xdr:xfrm");
        XNode off = xfrm.addChild("a:off");
        off.setAttr("x", "0");
        off.setAttr("y", "0");
        XNode ext = xfrm.addChild("a:ext");
        ext.setAttr("cx", "0");
        ext.setAttr("cy", "0");
        
        // Graphic element with chart reference
        XNode graphic = graphicFrame.addChild("a:graphic");
        XNode graphicData = graphic.addChild("a:graphicData");
        graphicData.setAttr("uri", "http://schemas.openxmlformats.org/drawingml/2006/chart");
        
        // Chart reference
        XNode chartRef = chartBuilder.buildChartReference(chart, relationshipId);
        graphicData.appendChild(chartRef);
        
        // Client data
        XNode clientData = anchor.addChild("xdr:clientData");
        
        return anchor;
    }

    public XNode buildImageAnchor(ExcelImage image, int index) {
        XNode anchor = buildAnchor0(image.getAnchor());
        if (image.getShape() != null) {
            XNode shape = image.getShape().cloneInstance();
            anchor.appendChild(shape);
            shape.setTagName("xdr:sp");
            XNode clientData = anchor.addChild("xdr:clientData");
            clientData.setAttr("fPrintsWithSheet", image.isPrint() ? 1 : 0);
            return anchor;
        }

        XNode pic = anchor.addChild("xdr:pic");
        XNode nvPicPr = pic.addChild("xdr:nvPicPr");
        XNode cNvPr = nvPicPr.addChild("xdr:cNvPr");
        cNvPr.setAttr("id", index);
        cNvPr.setAttr("name", image.getName());
        cNvPr.setAttr("descr", image.getDescription());

        XNode cNvPicPr = nvPicPr.addChild("xdr:cNvPicPr");
        cNvPicPr.addChild("a:picLocks").setAttr("noChangeAspect", image.isNoChangeAspect() ? 1 : 0);

        int rot = (int) (image.getRotateDegree() * 60000);
        XNode blipFill = pic.addChild("xdr:blipFill");
        if (rot > 0) {
            blipFill.setAttr("rotWithShape", 1);
        }
        XNode blip = blipFill.addChild("a:blip");
        blip.setAttr("xmlns:r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
        blip.setAttr("r:embed", image.getEmbedId());
        blipFill.addChild("a:stretch");

        XNode spPr = pic.addChild("xdr:spPr");
        XNode xfrm = spPr.addChild("a:xfrm");
        if (rot > 0) {
            xfrm.setAttr("rot", rot);
        }
        /*
        XNode off = xfrm.addChild("a:off");
        off.setAttr("x", 0);
        off.setAttr("y", 0);
        XNode ext = xfrm.addChild("a:ext");
        ext.setAttr("cx", 0);
        ext.setAttr("cy", 0);
        */


        XNode prstGeom = spPr.addChild("a:prstGeom");
        prstGeom.setAttr("prst", "rect");
        prstGeom.addChild("a:avLst");

        XNode clientData = anchor.addChild("xdr:clientData");
        clientData.setAttr("fPrintsWithSheet", image.isPrint() ? 1 : 0);
        return anchor;
    }

    private XNode buildAnchor0(ExcelClientAnchor anchor) {
        XNode node = XNode.make("xdr:twoCellAnchor");
        node.setAttr("editAs", anchor.getType());

        XNode from = XNode.make("xdr:from");
        from.addChild("xdr:col").content(anchor.getCol1());
        from.addChild("xdr:colOff").content(UnitsHelper.pointsToEMU(anchor.getDx1()));
        from.addChild("xdr:row").content(anchor.getRow1());
        from.addChild("xdr:rowOff").content(UnitsHelper.pointsToEMU(anchor.getDy1()));

        node.appendChild(from);

        XNode to = XNode.make("xdr:to");
        to.addChild("xdr:col").content(anchor.getCol2());
        to.addChild("xdr:colOff").content(UnitsHelper.pointsToEMU(anchor.getDx2()));
        to.addChild("xdr:row").content(anchor.getRow2());
        to.addChild("xdr:rowOff").content(UnitsHelper.pointsToEMU(anchor.getDy2()));
        node.appendChild(to);
        return node;
    }
}