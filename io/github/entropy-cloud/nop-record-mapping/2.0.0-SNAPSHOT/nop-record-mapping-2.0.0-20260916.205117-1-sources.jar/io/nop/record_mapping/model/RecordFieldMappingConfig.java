package io.nop.record_mapping.model;

import io.nop.api.core.exceptions.NopException;
import io.nop.commons.collections.KeyedList;
import io.nop.core.lang.json.JObject;
import io.nop.core.reflect.IClassModel;
import io.nop.core.reflect.ReflectionManager;
import io.nop.core.reflect.bean.BeanTool;
import io.nop.core.type.IGenericType;
import io.nop.core.type.PredefinedGenericTypes;
import io.nop.record_mapping.RecordMappingContext;
import io.nop.record_mapping.model._gen._RecordFieldMappingConfig;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.function.Supplier;

import static io.nop.record_mapping.RecordMappingErrors.*;

public class RecordFieldMappingConfig extends _RecordFieldMappingConfig implements IRecordFieldMappingConfig {
    private RecordMappingConfig resolvedMapping;
    private RecordMappingConfig resolvedItemMapping;
    private IClassModel itemClassModel;
    private IClassModel classModel;

    private Object normalizedDefaultValue;

    public RecordFieldMappingConfig() {

    }


    public void setItemClassModel(IClassModel itemClassModel) {
        this.itemClassModel = itemClassModel;
    }

    public void setClassModel(IClassModel classModel) {
        this.classModel = classModel;
    }

    public IClassModel getItemClassModel() {
        return itemClassModel;
    }

    public IClassModel getClassModel() {
        return classModel;
    }

    public Object getNormalizedDefaultValue() {
        return normalizedDefaultValue;
    }

    public void setNormalizedDefaultValue(Object normalizedDefaultValue) {
        this.normalizedDefaultValue = normalizedDefaultValue;
    }

    public String getFromOrName() {
        String from = getFrom();
        if (from != null)
            return from;
        return getName();
    }

    public RecordMappingConfig getResolvedMapping() {
        return resolvedMapping;
    }

    public void setResolvedMapping(RecordMappingConfig resolvedMapping) {
        this.resolvedMapping = resolvedMapping;
    }

    public RecordMappingConfig getResolvedItemMapping() {
        return resolvedItemMapping;
    }

    public void setResolvedItemMapping(RecordMappingConfig resolvedItemMapping) {
        this.resolvedItemMapping = resolvedItemMapping;
    }

    public void init(RecordMappingDefinitions mappings) {
        if (this.getMapping() != null) {
            RecordMappingConfig mapping = mappings.getMapping(this.getMapping());
            if (mapping == null)
                throw new NopException(ERR_RECORD_FIELD_MAPPING_NOT_FOUND).source(this).param(ARG_MAPPING_NAME, this.getMapping())
                        .param(ARG_FIELD_NAME, getName());
            setResolvedMapping(mapping);
        }

        if (this.getItemMapping() != null) {
            RecordMappingConfig mapping = mappings.getMapping(this.getItemMapping());
            if (mapping == null)
                throw new NopException(ERR_RECORD_FIELD_MAPPING_NOT_FOUND).source(this).param(ARG_MAPPING_NAME, this.getItemMapping())
                        .param(ARG_FIELD_NAME, getName());
            setResolvedItemMapping(mapping);
        }

        IGenericType type = getType();
        if (type != null) {
            if (type.isMapLike() || type.isCollectionLike()) {
                IGenericType componentType = type.getComponentType();
                if (componentType != PredefinedGenericTypes.ANY_TYPE) {
                    this.itemClassModel = ReflectionManager.instance().getClassModelForType(componentType);
                }
            }
            classModel = ReflectionManager.instance().getClassModelForType(type);
            if (this.getDefaultValue() != null)
                this.normalizedDefaultValue = type.getStdDataType().convert(this.getDefaultValue());
        }
    }

    public Supplier<Object> getItemConstructor(Object source, Object target, RecordMappingContext ctx) {
        if (ctx.isForceUseMap())
            return JObject::new;

        if (getNewItemExpr() != null)
            return () -> getNewItemExpr().call3(null, source, target, ctx, ctx.getEvalScope());

        if (itemClassModel != null)
            return itemClassModel::newInstance;

        return LinkedHashMap::new;
    }

    public Supplier<Object> getObjectConstructor(boolean collection, Object source, Object target, RecordMappingContext ctx) {
        if (ctx.isForceUseMap()) {
            if (collection)
                return ArrayList::new;
            return JObject::new;
        }

        if (getNewInstanceExpr() != null)
            return () -> getNewInstanceExpr().call3(null, source, target, ctx, ctx.getEvalScope());

        if (collection && getKeyProp() != null) {
            String keyProp = getKeyProp();
            return () -> new KeyedList<>(item -> BeanTool.getProperty(item, keyProp));
        }

        if (classModel != null)
            return classModel::newInstance;

        if (collection)
            return ArrayList::new;
        // 与 getItemConstructor/newTarget 的兜底一致：未声明 type 时以 Map 承载子映射，
        // 避免 makeTargetObject 对 null constructor 抛出无法定位字段配置的 NPE
        return LinkedHashMap::new;
    }
}