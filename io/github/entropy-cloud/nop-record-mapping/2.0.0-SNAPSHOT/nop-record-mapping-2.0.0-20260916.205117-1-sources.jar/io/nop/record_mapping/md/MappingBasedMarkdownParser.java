package io.nop.record_mapping.md;

import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.text.SourceCodeBlock;
import io.nop.commons.util.StringHelper;
import io.nop.commons.util.objects.Pair;
import io.nop.commons.util.objects.ValueWithLocation;
import io.nop.core.lang.json.JObject;
import io.nop.core.model.object.DynamicObject;
import io.nop.core.model.table.impl.BaseTable;
import io.nop.markdown.model.MarkdownDocument;
import io.nop.markdown.model.MarkdownListItem;
import io.nop.markdown.model.MarkdownSection;
import io.nop.markdown.simple.MarkdownCodeBlockParser;
import io.nop.markdown.simple.MarkdownListParser;
import io.nop.markdown.table.MarkdownTableParser;
import io.nop.markdown.utils.MarkdownHelper;
import io.nop.record_mapping.IRecordMapping;
import io.nop.record_mapping.RecordMappingContext;
import io.nop.record_mapping.impl.ModelBasedRecordMapping;
import io.nop.record_mapping.impl.RecordMappingTool;
import io.nop.record_mapping.model.RecordFieldMappingConfig;
import io.nop.record_mapping.model.RecordMappingConfig;

import java.util.*;

import static io.nop.record_mapping.RecordMappingConstants.*;
import static io.nop.record_mapping.RecordMappingErrors.*;

public class MappingBasedMarkdownParser implements IRecordMapping {
    private final RecordMappingConfig mapping;
    private final RecordMappingTool tool;

    public MappingBasedMarkdownParser(RecordMappingConfig mapping) {
        this.mapping = mapping;
        this.tool = RecordMappingTool.DEFAULT;
    }

    public Object parseMarkdown(MarkdownSection doc) {
        return map(doc, new RecordMappingContext());
    }

    @Override
    public Object newTarget(RecordMappingContext ctx) {
        return mapping.newTarget(ctx);
    }

    @Override
    public void map(Object source, Object target, RecordMappingContext ctx) {
        mapSectionAsObject(mapping, getSection(source), target, ctx);
    }

    protected MarkdownSection getSection(Object source) {
        if (source instanceof MarkdownDocument)
            return ((MarkdownDocument) source).getRootSection();
        return (MarkdownSection) source;
    }

    protected void mapSectionAsObject(RecordMappingConfig mapping, MarkdownSection section,
                                      Object target, RecordMappingContext ctx) {
        Set<String> processedFields = new HashSet<>();
        tool.executeForObject(mapping, section, target, ctx, () -> {
            // 设置标题字段
            mapTitleField(mapping, section, target, ctx, processedFields);

            // 处理内容
            mapSectionContent(mapping, section, target, ctx, processedFields);
        });
        checkComplete(mapping, target, processedFields, ctx);
    }

    protected void mapTitleField(RecordMappingConfig mapping, MarkdownSection section,
                                 Object target, RecordMappingContext ctx, Set<String> processedFields) {
        RecordFieldMappingConfig titleField = getTitleField(mapping);
        if (titleField != null) {
            processedFields.add(titleField.getName());
            tool.executeForField(mapping, titleField, section, target, ctx, field -> {
                Object titleValue = tool.processFieldValue(mapping, field, field.getName(), section.getTitle(), ctx);
                if (target instanceof JObject)
                    titleValue = ValueWithLocation.of(section.getLocation(), titleValue);

                tool.setTargetValue(field, target, field.getName(), titleValue, ctx);
            });
        }
    }

    protected void mapSectionContent(RecordMappingConfig mapping, MarkdownSection section,
                                     Object target, RecordMappingContext ctx,
                                     Set<String> processedFields) {
        // 处理列表项
        List<MarkdownListItem> items = MarkdownListParser.NESTED.parseAllListItems(
                section.getContentLocation(), section.getContent());
        if (items != null && !items.isEmpty()) {
            mapListItems(mapping, items, target, ctx, processedFields);
        }

        // 处理子章节
        if (section.hasChild()) {
            mapSectionChildren(mapping, section.getChildren(), target, ctx, processedFields);
        }
    }

    protected void mapListItems(RecordMappingConfig mapping, List<MarkdownListItem> items,
                                Object target, RecordMappingContext ctx, Set<String> processedFields) {
        for (MarkdownListItem item : items) {
            Pair<String, String> pair = parseNameValuePair(item.getContent());
            String fromName = pair.getKey();

            // 查找匹配的字段配置
            RecordFieldMappingConfig field = mapping.getFieldByFrom(fromName);
            if (field == null) {
                if (mapping.isIgnoreUnknownFields())
                    continue;
                field = mapping.requireFieldByFrom(item.getLocation(), fromName);
            }
            processedFields.add(field.getName());
            tool.executeForField(mapping, field, item, target, ctx, f -> {
                mapListItemField(mapping, f, item, pair, target, ctx);
            });
        }
    }

    protected void mapListItemField(RecordMappingConfig mapping,
                                    RecordFieldMappingConfig field, MarkdownListItem item,
                                    Pair<String, String> pair, Object target, RecordMappingContext ctx) {
        if (field.getResolvedMapping() != null) {
            // 映射到对象
            Object fieldValue = tool.makeTargetObject(field, item, target, ctx);
            Set<String> processedFields = new HashSet<>();
            mapListItems(field.getResolvedMapping(), item.getChildren(), fieldValue, ctx, processedFields);
            checkComplete(field.getResolvedMapping(), fieldValue, processedFields, ctx);
        } else if (field.getResolvedItemMapping() != null) {
            // 映射到列表
            Object fieldValue = tool.makeTargetCollection(field, item, target, ctx);
            mapListItemCollection(field, item.getChildren(), item, fieldValue, ctx);
        } else {
            // 简单值映射
            if (item.hasChildren()) {
                throw new NopException(ERR_RECORD_MD_LIST_ITEM_NOT_SIMPLE_VALUE)
                        .source(item)
                        .param(ARG_FIELD_NAME, field.getName())
                        .param(ARG_FROM_NAME, pair.getKey());
            }

            Object value = tool.processFieldValue(mapping, field, field.getName(), pair.getValue(), ctx);
            if (target instanceof JObject)
                value = ValueWithLocation.of(item.getLocation(), value);
            tool.setTargetValue(field, target, field.getName(), value, ctx);
        }
    }

    void checkComplete(RecordMappingConfig mapping, Object obj, Set<String> processedFields,
                       RecordMappingContext ctx) {
        if (ctx.isSkipValidation())
            return;

        for (RecordFieldMappingConfig field : mapping.getFields()) {
            if (field.isMandatory() && !processedFields.contains(field.getName())) {
                throw new NopException(ERR_RECORD_MD_MISSING_FIELD)
                        .source(mapping)
                        .param(ARG_FIELD_NAME, field.getName())
                        .param(ARG_FROM_NAME, field.getFrom())
                        .param(ARG_MAPPING_NAME, mapping.getName());
            }
        }

        if (obj instanceof DynamicObject) {
            DynamicObject dynObj = (DynamicObject) obj;
            for (RecordFieldMappingConfig field : mapping.getFields()) {
                if (!processedFields.contains(field.getName())) {
                    dynObj.addPropDefault(field.getName(), field.getNormalizedDefaultValue());
                }
            }
        }
    }

    protected void mapListItemCollection(RecordFieldMappingConfig field, List<MarkdownListItem> items,
                                         Object source, Object target, RecordMappingContext ctx) {
        tool.mapCollectionField(field, items, source, target, ctx, (fromItem, toItem) -> {
            mapListItemAsObject(field.getResolvedItemMapping(), (MarkdownListItem) fromItem, toItem, ctx);
        });
    }

    protected void mapListItemAsObject(RecordMappingConfig itemMapping, MarkdownListItem item,
                                       Object target, RecordMappingContext ctx) {
        Set<String> processedFields = new HashSet<>();

        tool.executeForObject(itemMapping, item, target, ctx, () -> {
            // 设置标题字段
            RecordFieldMappingConfig titleField = getTitleField(itemMapping);
            if (titleField != null) {
                processedFields.add(titleField.getName());
                tool.executeForField(itemMapping, titleField, item, target, ctx, field -> {
                    Object titleValue = tool.processFieldValue(itemMapping, field, field.getName(), item.getContent(), ctx);

                    if (target instanceof JObject)
                        titleValue = ValueWithLocation.of(item.getLocation(), titleValue);
                    tool.setTargetValue(field, target, field.getName(), titleValue, ctx);
                });
            }

            // 处理子项
            mapListItems(itemMapping, item.getChildren(), target, ctx, processedFields);
        });

        checkComplete(itemMapping, target, processedFields, ctx);
    }

    protected void mapSectionChildren(RecordMappingConfig mapping, List<MarkdownSection> children,
                                      Object target, RecordMappingContext ctx, Set<String> processedFields) {
        if (children == null || children.isEmpty()) return;

        for (MarkdownSection child : children) {
            String key = decodeKey(child.getTitle());

            // 查找匹配的字段配置
            RecordFieldMappingConfig field = mapping.getFieldByFrom(key);
            if (field == null) {
                if (mapping.isIgnoreUnknownFields())
                    continue;
                field = mapping.requireFieldByFrom(child.getLocation(), key);
            }
            processedFields.add(field.getName());
            tool.executeForField(mapping, field, child, target, ctx, f -> {
                mapSectionField(mapping, f, child, target, ctx);
            });
        }
    }

    protected void mapSectionField(RecordMappingConfig mapping,
                                   RecordFieldMappingConfig field, MarkdownSection section,
                                   Object target, RecordMappingContext ctx) {
        String format = (String) field.prop_get(VAR_MD_FORMAT);

        if (FORMAT_TABLE.equals(format)) {
            mapTableField(mapping, field, section, target, ctx);
        } else if (field.getResolvedMapping() != null) {
            mapObjectField(field, section, target, ctx);
        } else if (field.getResolvedItemMapping() != null) {
            mapCollectionField(field, section, target, ctx);
        } else {
            mapSimpleField(mapping, field, section, format, target, ctx);
        }
    }

    protected void mapTableField(RecordMappingConfig mapping,
                                 RecordFieldMappingConfig field, MarkdownSection section,
                                 Object target, RecordMappingContext ctx) {
        if (section.hasChild()) {
            throw new NopException(ERR_RECORD_MD_SECTION_NOT_ALLOW_SUB_SECTION)
                    .source(section)
                    .param(ARG_MD_FORMAT, FORMAT_TABLE);
        }

        Object tableData = parseContentTable(field, section, target, ctx);
        if (!ctx.isSkipValidation())
            tool.validateMandatoryField(mapping.getName(), field, field.getName(), tableData);

        tool.setTargetValue(field, target, field.getName(), tableData, ctx);
    }

    protected void mapObjectField(RecordFieldMappingConfig field, MarkdownSection section,
                                  Object target, RecordMappingContext ctx) {
        Object fieldValue = tool.makeTargetObject(field, section, target, ctx);
        mapSectionAsObject(field.getResolvedMapping(), section, fieldValue, ctx);
    }

    protected void mapCollectionField(RecordFieldMappingConfig field, MarkdownSection section,
                                      Object target, RecordMappingContext ctx) {
        Collection<?> fieldValue = tool.makeTargetCollection(field, section, target, ctx);
        mapSectionCollection(field, section, target, fieldValue, ctx);
    }

    protected void mapSectionCollection(RecordFieldMappingConfig field, MarkdownSection section,
                                        Object target, Collection<?> coll, RecordMappingContext ctx) {
        List<MarkdownListItem> items = MarkdownListParser.NESTED.parseAllListItems(
                section.getContentLocation(), section.getContent());

        if (items != null && !items.isEmpty()) {
            if (section.hasChild()) {
                throw new NopException(ERR_RECORD_MD_SECTION_NOT_ALLOW_SUB_SECTION)
                        .source(section);
            }
            mapListItemCollection(field, items, null, target, ctx);
            return;
        }

        RecordMappingConfig itemMapping = field.getResolvedItemMapping();
        tool.mapCollectionField(field, section.getChildren(), section, target, ctx, (fromItem, toItem) -> {
            mapSectionAsObject(itemMapping, (MarkdownSection) fromItem, toItem, ctx);
        });
    }

    protected void mapSimpleField(RecordMappingConfig mapping,
                                  RecordFieldMappingConfig field, MarkdownSection section,
                                  String format, Object target, RecordMappingContext ctx) {
        if (section.hasChild()) {
            throw new NopException(ERR_RECORD_MD_SECTION_NOT_ALLOW_SUB_SECTION)
                    .source(section)
                    .param(ARG_MD_FORMAT, format);
        }

        Object contentValue = parseSectionContent(field, format, section);
        Object value = tool.processFieldValue(mapping, field, field.getName(), contentValue, ctx);
        if (field.isIgnoreWhenEmpty() && StringHelper.isEmptyObject(value))
            return;

        if (target instanceof JObject)
            value = ValueWithLocation.of(section.getContentLocation(), value);

        tool.setTargetValue(field, target, field.getName(), value, ctx);
    }

    RecordFieldMappingConfig getTitleField(RecordMappingConfig mapping) {
        String titleField = (String) mapping.prop_get(VAR_MD_TITLE_FIELD);
        if (titleField != null) {
            return mapping.requireField(titleField);
        }
        return null;
    }

    Pair<String, String> parseNameValuePair(String text) {
        String key, value;
        // 生成端 encodeKey 对含 : " | 换行的键加引号，引号内的 : 不是键值分隔符，
        // 必须先定位结束引号再切分，否则含 : 的键 roundtrip 后被截断为带残留引号的错误键
        if (text.startsWith("\"")) {
            int keyEnd = findQuotedStringEnd(text);
            if (keyEnd > 0) {
                key = text.substring(0, keyEnd);
                int pos = text.indexOf(':', keyEnd);
                value = pos >= 0 ? text.substring(pos + 1) : null;
                return Pair.of(decodeKey(key), decodeValue(value));
            }
        }
        int pos = text.indexOf(':');
        if (pos >= 0) {
            key = text.substring(0, pos);
            value = text.substring(pos + 1);
        } else {
            key = text;
            value = null;
        }
        return Pair.of(decodeKey(key), decodeValue(value));
    }

    /**
     * text 以引号开头时，返回结束引号之后的位置下标；引号内处理 java 转义（与
     * MappingBasedMarkdownGenerator.encodeKey 使用的 StringHelper.quote 对称）。
     * 找不到结束引号返回 -1
     */
    static int findQuotedStringEnd(String text) {
        int i = 1;
        int len = text.length();
        while (i < len) {
            char c = text.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == '"')
                return i + 1;
            if (c == '\n')
                return -1;
            i++;
        }
        return -1;
    }

    protected Object parseSectionContent(RecordFieldMappingConfig field,
                                         String format, MarkdownSection section) {
        if (StringHelper.isBlank(section.getContent()))
            return null;

        if (FORMAT_CODE.equals(format)) {
            SourceCodeBlock block = MarkdownCodeBlockParser.INSTANCE.parseCodeBlockForLang(section.getContentLocation(),
                    section.getContent(), null);
            if (block == null)
                return null;
            return block.getSource();
        } else {
            return section.getContent();
        }
    }

    protected Object parseContentTable(RecordFieldMappingConfig field, MarkdownSection section, Object target, RecordMappingContext ctx) {
        if (StringHelper.isBlank(section.getContent()))
            return null;

        RecordMappingConfig itemMapping = field.getResolvedItemMapping();
        if (itemMapping == null)
            throw new NopException(ERR_RECORD_MD_TABLE_FIELD_NO_ITEM_MAPPING).loc(field.getLocation())
                    .param(ARG_FIELD_NAME, field.getName());

        int pos = MarkdownHelper.findTable(section.getContent());
        if (pos < 0 || !StringHelper.isBlank(section.getContent().substring(0, pos)))
            throw new NopException(ERR_RECORD_MD_SECTION_CONTENT_NOT_TABLE)
                    .loc(section.getContentLocation())
                    .param(ARG_CONTENT, StringHelper.limitLen(section.getContent(), 100));

        SourceLocation loc = section.getContentLocation();
        BaseTable table = MarkdownTableParser.parseTable(loc, section.getContent());
        List<Map<String, Object>> ret = MarkdownHelper.toRecordList(table, null);

        ModelBasedRecordMapping helper = new ModelBasedRecordMapping(mapping, tool);
        return helper.mapCollectionField(field, ret, section, target, ctx);
    }

    String decodeKey(String key) {
        key = key.trim();
        // 与 encodeKey 的引号包裹对称；非引号包裹的键 unquote 原样返回
        key = StringHelper.unquote(key);
        key = MarkdownHelper.removeStyle(key);
        return key;
    }

    String decodeValue(String text) {
        if (text == null || text.isEmpty())
            return null;
        text = text.trim();
        return StringHelper.unquote(text);
    }
}