package io.nop.jq.ast;

public final class CommaNode implements JqAstNode {
    private final JqAstNode left;
    private final JqAstNode right;

    public CommaNode(JqAstNode left, JqAstNode right) {
        this.left = left;
        this.right = right;
    }

    public JqAstNode left() { return left; }
    public JqAstNode right() { return right; }

    @Override public <T> T accept(JqAstVisitor<T> v) { return v.visitComma(this); }
    @Override public String toString() { return left + ", " + right; }
}
