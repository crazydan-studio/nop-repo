# 测试用例列表

## 1 <<测试用例名>>

[TAGS]: DYNAMIC,CASE
<<简单描述>>

```json5
{
  "caseName": "TC-XXX",
  "priority": "P0-P3",
  "input": {
    "request": {
      // 请求参数（对应方法入参）
    },
    "entities": {
      // 实体数据按照表结构平铺，不允许嵌套关联对象
      "实体名": [
        {
          "id": "abc",
          "属性名": "属性值"
        }
      ]
    }
  },
  "output": {
    // 预期返回
    "response": {
      // 0表示成功，-1表示失败
      "status": 0,
      // 如果失败，对应于异常码， 如果成功则为null
      "code": "返回码",
      // 任务返回的结果对象
      "data": {}
    },
    "entities": {
      "实体名": [
        {
          "_chgType": "enum:A|U|D",
          "id": "abc",
          "属性名": "属性值"
        }
      ]
    }
  }
}
```

# 测试说明

<<测试覆盖分析等>>
