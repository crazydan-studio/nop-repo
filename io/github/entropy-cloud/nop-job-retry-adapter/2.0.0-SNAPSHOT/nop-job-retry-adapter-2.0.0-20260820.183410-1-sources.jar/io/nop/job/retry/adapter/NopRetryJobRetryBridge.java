package io.nop.job.retry.adapter;

import io.nop.api.core.beans.ApiRequest;
import io.nop.job.api.retry.IJobRetryBridge;
import io.nop.job.api.retry.JobFireFailedEvent;
import io.nop.retry.api.IRetryEngine;
import io.nop.retry.api.IRetryTask;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

public class NopRetryJobRetryBridge implements IJobRetryBridge {

    static final Logger LOG = LoggerFactory.getLogger(NopRetryJobRetryBridge.class);

    static final String SERVICE_NAME = "nop-job-service";
    static final String SERVICE_METHOD = "NopJobFire__rerunFire";

    private IRetryEngine retryEngine;

    @Inject
    public void setRetryEngine(IRetryEngine retryEngine) {
        this.retryEngine = retryEngine;
    }

    @Override
    public void onFireFailed(JobFireFailedEvent event) {
        if (retryEngine == null) {
            LOG.warn("nop.job.retry.engine-not-available:fireId={}", event.getJobFireId());
            return;
        }

        try {
            IRetryTask task = retryEngine.newRetryTask(SERVICE_NAME, SERVICE_METHOD)
                    .withPolicyId(event.getRetryPolicyId())
                    .withIdempotentId(event.getJobFireId())
                    .withNamespaceId(event.getNamespaceId())
                    .withGroupId(event.getGroupId());

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("id", event.getJobFireId());

            ApiRequest<Map<String, Object>> request = new ApiRequest<>();
            request.setData(data);

            task.callAsync(request, null)
                    .whenComplete((resp, err) -> {
                        if (err != null) {
                            LOG.error("nop.job.retry.submit-failed:fireId={}", event.getJobFireId(), err);
                        } else if (resp != null && !resp.isOk()) {
                            LOG.warn("nop.job.retry.submit-error:fireId={},code={}", event.getJobFireId(),
                                    resp.getCode());
                        }
                    });
        } catch (Exception e) {
            LOG.error("nop.job.retry.bridge-error:fireId={}", event.getJobFireId(), e);
        }
    }
}
