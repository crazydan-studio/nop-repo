/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.ai.core.mock;

import io.nop.ai.core.NopAiCoreException;
import static io.nop.ai.core.NopAiCoreErrors.ERR_AI_CORE_INVALID_STATE;
import static io.nop.ai.core.NopAiCoreErrors.ERR_AI_CORE_INVALID_STATE;
import static io.nop.ai.core.NopAiCoreErrors.ARG_DETAIL;
import io.nop.ai.api.chat.ChatRequest;
import io.nop.ai.api.chat.ChatResponse;
import io.nop.ai.api.chat.IChatService;
import io.nop.ai.api.chat.messages.ChatAssistantMessage;
import io.nop.ai.api.chat.messages.ChatMessage;
import io.nop.ai.api.chat.messages.ChatReasoningMessage;
import io.nop.ai.api.chat.stream.ChatStreamChunk;
import io.nop.ai.api.chat.stream.StreamItemPhase;
import io.nop.ai.api.chat.stream.StreamItemType;
import io.nop.api.core.time.CoreMetrics;
import io.nop.api.core.util.ICancelToken;
import io.nop.commons.concurrent.executor.GlobalExecutors;
import jakarta.inject.Inject;

import java.util.concurrent.CompletionStage;
import java.util.concurrent.Flow;
import java.util.List;
import java.util.concurrent.SubmissionPublisher;

import static io.nop.ai.core.mock.MockChatConfigs.CFG_AI_MOCK_ENABLE_STREAM;
import static io.nop.ai.core.mock.MockChatConfigs.CFG_AI_MOCK_STREAM_DELAY_MS;

/**
 * Mock实现的IChatService。
 * 通过IResponseProvider获取响应，支持文件系统和内存两种模式。
 */
public class MockChatService implements IChatService {

    private IResponseProvider responseProvider;

    public MockChatService() {
    }

    @Inject
    public void setResponseProvider(IResponseProvider responseProvider) {
        this.responseProvider = responseProvider;
    }

    @Override
    public CompletionStage<ChatResponse> callAsync(ChatRequest request, ICancelToken cancelToken) {
        if (responseProvider == null) {
            throw new NopAiCoreException(ERR_AI_CORE_INVALID_STATE).param(ARG_DETAIL, "ResponseProvider is not set");
        }
        return responseProvider.awaitResponse(request, cancelToken);
    }

    @Override
    public Flow.Publisher<ChatStreamChunk> callStream(ChatRequest request, ICancelToken cancelToken) {
        boolean enableStream = CFG_AI_MOCK_ENABLE_STREAM.get();
        long streamDelayMs = CFG_AI_MOCK_STREAM_DELAY_MS.get();

        SubmissionPublisher<ChatStreamChunk> publisher = new SubmissionPublisher<>();

        responseProvider.awaitResponse(request, cancelToken).whenComplete((response, error) -> {
            if (error != null) {
                publisher.closeExceptionally(error);
                return;
            }

            String assistantContent = response.outputText();
            if (!enableStream || assistantContent == null) {
                // 非流式模式，直接发送完整响应
                ChatStreamChunk chunk = createChunk(response, true);
                publisher.submit(chunk);
                publisher.close();
                return;
            }

            // 流式模式，逐字符发送
            String content = assistantContent;
            if (content == null || content.isEmpty()) {
                ChatStreamChunk chunk = createChunk(response, true);
                publisher.submit(chunk);
                publisher.close();
                return;
            }

            // 在后台线程中模拟流式输出
            GlobalExecutors.cachedThreadPool().execute(() -> {
                try {
                    StringBuilder built = new StringBuilder();
                    for (int i = 0; i < content.length(); i++) {
                        if (cancelToken != null && cancelToken.isCancelled()) {
                            publisher.close();
                            return;
                        }

                        built.append(content.charAt(i));

                        ChatAssistantMessage msg = new ChatAssistantMessage();
                        msg.setContent(built.toString());

                        ChatStreamChunk chunk = new ChatStreamChunk();
                        chunk.setItemType(StreamItemType.text);
                        chunk.setItemIndex(0);
                        chunk.setPhase(StreamItemPhase.DELTA);
                        chunk.setDelta(String.valueOf(content.charAt(i)));

                        boolean isLast = (i == content.length() - 1);
                        if (isLast) {
                            chunk.setFinishReason(response.getFinishReason());
                        }

                        publisher.submit(chunk);

                        if (streamDelayMs > 0 && !isLast) {
                            Thread.sleep(streamDelayMs);
                        }
                    }
                    publisher.close();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    publisher.closeExceptionally(e);
                }
            });
        });

        return publisher;
    }

    protected ChatStreamChunk createChunk(ChatResponse response, boolean isLast) {
        ChatStreamChunk chunk = new ChatStreamChunk();

        // Plan 329：从规范消息序列读取推理与 assistant 文本（单一拆分模型）。
        String reasoning = null;
        String text = null;
        List<ChatMessage> messages = response.getMessages();
        if (messages != null) {
            for (ChatMessage msg : messages) {
                if (msg instanceof ChatReasoningMessage && reasoning == null) {
                    reasoning = msg.getContent();
                } else if (msg instanceof ChatAssistantMessage && text == null) {
                    text = msg.getContent();
                }
            }
        }

        if (reasoning != null) {
            // 推理 item
            chunk.setItemType(StreamItemType.reasoning);
            chunk.setItemIndex(0);
            chunk.setPhase(StreamItemPhase.DELTA);
            chunk.setDelta(reasoning);
        } else if (text != null) {
            // 文本 item
            chunk.setItemType(StreamItemType.text);
            chunk.setItemIndex(0);
            chunk.setPhase(StreamItemPhase.DELTA);
            chunk.setDelta(text);
        }

        if (isLast) {
            chunk.setFinishReason(response.getFinishReason());
        }
        return chunk;
    }
}
