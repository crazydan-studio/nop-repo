package io.nop.ai.core.reliability;

import static io.nop.ai.core.NopAiCoreErrors.ERR_AI_CORE_INVALID_STATE;
import static io.nop.ai.core.NopAiCoreErrors.ARG_DETAIL;
import io.nop.api.core.time.CoreMetrics;
import io.nop.ai.core.NopAiCoreErrors;
import io.nop.ai.core.NopAiCoreException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Functional {@link ICircuitBreaker} implementing the three-state
 * consecutive-failure circuit-breaker state machine (design
 * {@code nop-ai-agent-reliability.md} §5.1 / plan 210 / L3-1).
 *
 * <p>Per model identity (the {@code provider:model} composite key built by
 * {@code ModelKeys.buildModelKey}) the breaker maintains an
 * independent state machine:
 * <ul>
 *   <li><b>CLOSED</b> (initial) — all calls allowed. Each recorded failure
 *       increments a consecutive-failure counter; when the counter reaches
 *       {@code failureThreshold} the breaker transitions to <b>OPEN</b>.</li>
 *   <li><b>OPEN</b> — all calls rejected ({@code allowCall} returns false).
 *       The transition is lazy: no background timer is started. The next
 *       {@link #allowCall(String)} after {@code cooldownMs} has elapsed since
 *       the OPEN transition transitions the breaker to <b>HALF_OPEN</b> and
 *       admits that caller as the single probe.</li>
 *   <li><b>HALF_OPEN</b> — exactly one probe call is admitted (the first
 *       caller that wins the probe slot); concurrent callers are rejected as
 *       if still OPEN. A successful probe ({@link #recordSuccess})
 *       transitions back to CLOSED and clears the failure counter; a failed
 *       probe ({@link #recordFailure}) transitions back to OPEN and restarts
 *       the cooldown clock. <b>Probe timeout escape (P2-REL)</b>: if the
 *       probe never reports back (cancelled / hung / thread killed) within
 *       {@code probeTimeoutMs} of being admitted, the next {@link #allowCall}
 *       re-takes the probe slot and admits that caller as the new probe
 *       (logged) — a stuck probe can no longer wedge the breaker in
 *       HALF_OPEN forever.</li>
 * </ul>
 *
 * <p><b>Thread safety</b>: state is tracked per model-key in a
 * {@link ConcurrentHashMap}. All state-machine transitions and entry removal
 * happen inside per-key {@code entries.compute} critical sections (the same
 * per-key serialization pattern as {@code ConcurrencyRegistry}), so
 * concurrent callers to the <i>same</i> model-key see consistent state, while
 * concurrent callers to <i>different</i> model-keys proceed in parallel.
 * {@link #getState} reads the {@code volatile} state field without locking
 * for diagnostics (a slightly-stale snapshot of just the state is acceptable;
 * the decision-making methods {@link #allowCall} / {@link #recordSuccess} /
 * {@link #recordFailure} always run inside the per-key critical section and
 * see a consistent snapshot).
 *
 * <p><b>Invariants</b>:
 * <ul>
 *   <li>A breaker that has never recorded any outcome for a model-key
 *       reports CLOSED and allows calls (the healthy default).</li>
 *   <li>The failure counter only counts <i>consecutive</i> failures: a
 *       success at any point resets it to zero. Therefore a retry cycle
 *       that ultimately succeeds (transient failures followed by success)
 *       does not accumulate debt — the breaker only trips on failures with
 *       no intervening success.</li>
 *   <li>The {@link CircuitState} public enum stays at three states. The
 *       probe-in-flight exclusivity of HALF_OPEN is enforced by an internal
 *       boolean flag per entry, not by a fourth public state.</li>
 * </ul>
 *
 * <p><b>Entry-table shrink (P2 round-4)</b>: a <i>pristine</i> entry —
 * state CLOSED, zero consecutive failures, no probe in flight — is
 * semantically identical to an absent entry (the healthy default), so it is
 * dropped from the map inside the same per-key critical section that
 * returned it to the pristine state. An entry that carries failure memory
 * (CLOSED with failures &gt; 0), an OPEN entry, or an entry with a probe in
 * flight is never dropped. This matches the zero-count shrink semantics of
 * {@code ConcurrencyRegistry}: the table only holds entries that remember
 * something, so gateways routing to arbitrary model keys do not grow the
 * table without bound.
 *
 * <p>State is in-memory only (per breaker instance). Persistence /
 * cross-process sharing is a Non-Goal successor (design §11 deferred).
 */
public final class ThresholdBreaker implements ICircuitBreaker {

    private static final Logger LOG = LoggerFactory.getLogger(ThresholdBreaker.class);

    /** Default consecutive-failure threshold before the breaker trips. */
    public static final int DEFAULT_FAILURE_THRESHOLD = 3;
    /** Default cooldown in milliseconds before a tripped breaker probes. */
    public static final long DEFAULT_COOLDOWN_MS = 60_000L;
    /**
     * Default probe timeout in milliseconds (same order of magnitude as the
     * default cooldown): a HALF_OPEN probe that never reports back within
     * this window is treated as stuck and its slot is re-taken by the next
     * {@link #allowCall} caller.
     */
    public static final long DEFAULT_PROBE_TIMEOUT_MS = 30_000L;

    private final int failureThreshold;
    private final long cooldownMs;
    private final long probeTimeoutMs;
    private final ConcurrentMap<String, BreakerEntry> entries = new ConcurrentHashMap<>();

    /**
     * Construct a breaker with the default threshold (3), cooldown (60s) and
     * probe timeout (30s).
     */
    public ThresholdBreaker() {
        this(DEFAULT_FAILURE_THRESHOLD, DEFAULT_COOLDOWN_MS, DEFAULT_PROBE_TIMEOUT_MS);
    }

    /**
     * @param failureThreshold consecutive failures required to trip the
     *                         breaker (must be &gt;= 1)
     * @param cooldownMs      milliseconds the breaker stays OPEN before
     *                        admitting a HALF_OPEN probe (must be &gt;= 0;
     *                        0 = probe on the very next call after tripping)
     */
    public ThresholdBreaker(int failureThreshold, long cooldownMs) {
        this(failureThreshold, cooldownMs, DEFAULT_PROBE_TIMEOUT_MS);
    }

    /**
     * @param failureThreshold consecutive failures required to trip the
     *                         breaker (must be &gt;= 1)
     * @param cooldownMs      milliseconds the breaker stays OPEN before
     *                        admitting a HALF_OPEN probe (must be &gt;= 0;
     *                        0 = probe on the very next call after tripping)
     * @param probeTimeoutMs  milliseconds a HALF_OPEN probe may stay in flight
     *                        before it is considered stuck and its slot is
     *                        re-taken by the next {@link #allowCall} caller
     *                        (must be &gt;= 0; 0 = escape disabled)
     */
    public ThresholdBreaker(int failureThreshold, long cooldownMs, long probeTimeoutMs) {
        if (failureThreshold < 1) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG,
                    "ThresholdBreaker failureThreshold must be >= 1: " + failureThreshold);
        }
        if (cooldownMs < 0) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG,
                    "ThresholdBreaker cooldownMs must be >= 0: " + cooldownMs);
        }
        if (probeTimeoutMs < 0) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG,
                    "ThresholdBreaker probeTimeoutMs must be >= 0: " + probeTimeoutMs);
        }
        this.failureThreshold = failureThreshold;
        this.cooldownMs = cooldownMs;
        this.probeTimeoutMs = probeTimeoutMs;
    }

    public int getFailureThreshold() {
        return failureThreshold;
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public long getProbeTimeoutMs() {
        return probeTimeoutMs;
    }

    @Override
    public boolean allowCall(String modelKey) {
        if (modelKey == null) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG, "modelKey must not be null");
        }
        boolean[] holder = new boolean[1];
        entries.compute(modelKey, (k, existing) -> {
            BreakerEntry entry = existing != null ? existing : new BreakerEntry();
            long now = CoreMetrics.currentTimeMillis();
            switch (entry.state) {
                case CLOSED:
                    holder[0] = true;
                    // Shrink: a pristine CLOSED entry is semantically identical to
                    // absence (healthy default) → drop it so arbitrary model-key
                    // routing does not grow the table without bound.
                    return removeIfPristine(entry) ? null : entry;
                case OPEN:
                    // Lazy cooldown check: no background timer. If the cooldown
                    // has elapsed, transition to HALF_OPEN and admit this caller
                    // as the single probe.
                    if (now - entry.openedAt >= cooldownMs) {
                        entry.state = CircuitState.HALF_OPEN;
                        entry.probeInFlight = true;
                        entry.probeStartedAt = now;
                        holder[0] = true;
                    }
                    return entry;
                case HALF_OPEN:
                    // A probe is in flight: only the probe caller is admitted;
                    // concurrent callers are rejected as if still OPEN.
                    if (!entry.probeInFlight) {
                        entry.probeInFlight = true;
                        entry.probeStartedAt = now;
                        holder[0] = true;
                    } else {
                        // Probe-timeout escape (P2-REL): a probe that never reports
                        // back (cancelled / hung / thread killed) would otherwise
                        // wedge the breaker in HALF_OPEN forever, rejecting every
                        // subsequent call. Once probeTimeoutMs has elapsed, treat
                        // the probe as stuck and re-take its slot for this caller.
                        if (probeTimeoutMs > 0 && now - entry.probeStartedAt >= probeTimeoutMs) {
                            LOG.warn("ThresholdBreaker HALF_OPEN probe for model {} did not report within {} ms; "
                                            + "re-taking the probe slot (escape from a stuck probe). state stays HALF_OPEN.",
                                    modelKey, probeTimeoutMs);
                            entry.probeStartedAt = now;
                            holder[0] = true;
                        }
                    }
                    return entry;
                default:
                    throw new NopAiCoreException(ERR_AI_CORE_INVALID_STATE).param(ARG_DETAIL, "Unknown circuit state: " + entry.state);
            }
        });
        return holder[0];
    }

    @Override
    public CircuitState getState(String modelKey) {
        if (modelKey == null) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG, "modelKey must not be null");
        }
        BreakerEntry entry = entries.get(modelKey);
        // An untracked model-key has never recorded any outcome → CLOSED.
        return entry != null ? entry.state : CircuitState.CLOSED;
    }

    @Override
    public void recordSuccess(String modelKey) {
        if (modelKey == null) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG, "modelKey must not be null");
        }
        entries.compute(modelKey, (k, existing) -> {
            BreakerEntry entry = existing;
            if (entry == null) {
                // Success on an untracked key: nothing to reset (already CLOSED).
                return null;
            }
            switch (entry.state) {
                case CLOSED:
                    entry.consecutiveFailures = 0;
                    // Shrink: counter reset to the healthy default → pristine entry
                    // is semantically identical to absence → drop it.
                    return removeIfPristine(entry) ? null : entry;
                case HALF_OPEN:
                    // Probe succeeded → reset to CLOSED, clear the counter,
                    // release the probe slot. The entry is now pristine → drop it
                    // (absence = CLOSED healthy default).
                    entry.state = CircuitState.CLOSED;
                    entry.consecutiveFailures = 0;
                    entry.probeInFlight = false;
                    return null;
                case OPEN:
                    // Defensive: a success was reported while OPEN (the call
                    // should have been rejected). Reset the counter; leave the
                    // state as OPEN — the operator-configured cooldown still
                    // gates the next probe.
                    entry.consecutiveFailures = 0;
                    return entry;
                default:
                    throw new NopAiCoreException(ERR_AI_CORE_INVALID_STATE).param(ARG_DETAIL, "Unknown circuit state: " + entry.state);
            }
        });
    }

    @Override
    public void recordFailure(String modelKey) {
        if (modelKey == null) {
            throw new NopAiCoreException(NopAiCoreErrors.ERR_AI_AGENT_INVALID_ARG).param(NopAiCoreErrors.ARG_MSG, "modelKey must not be null");
        }
        entries.compute(modelKey, (k, existing) -> {
            BreakerEntry entry = existing != null ? existing : new BreakerEntry();
            long now = CoreMetrics.currentTimeMillis();
            switch (entry.state) {
                case CLOSED:
                    entry.consecutiveFailures++;
                    if (entry.consecutiveFailures >= failureThreshold) {
                        entry.state = CircuitState.OPEN;
                        entry.openedAt = now;
                    }
                    // Failure memory must survive → entry stays (never dropped
                    // while it remembers failures below the threshold).
                    return entry;
                case HALF_OPEN:
                    // Probe failed → back to OPEN, restart the cooldown clock,
                    // release the probe slot.
                    entry.state = CircuitState.OPEN;
                    entry.openedAt = now;
                    entry.probeInFlight = false;
                    return entry;
                case OPEN:
                    // Defensive: a failure was reported while OPEN (the call
                    // should have been rejected). Leave the state as OPEN;
                    // do not extend the cooldown (the failure is spurious).
                    return entry;
                default:
                    throw new NopAiCoreException(ERR_AI_CORE_INVALID_STATE).param(ARG_DETAIL, "Unknown circuit state: " + entry.state);
            }
        });
    }

    /**
     * A <i>pristine</i> entry — CLOSED, zero consecutive failures, no probe in
     * flight — is semantically identical to an absent entry (the healthy
     * default), so it may be dropped from the table (entry-table shrink,
     * matching the {@code ConcurrencyRegistry} zero-count shrink semantics).
     */
    private static boolean removeIfPristine(BreakerEntry entry) {
        return entry.state == CircuitState.CLOSED && entry.consecutiveFailures == 0 && !entry.probeInFlight;
    }

    /**
     * Per-model-key mutable state holder. All fields are mutated under the
     * entry's monitor (synchronized on the entry instance). The
     * {@code volatile state} field is also read lock-free by
     * {@link #getState} for diagnostics.
     */
    private static final class BreakerEntry {
        volatile CircuitState state = CircuitState.CLOSED;
        int consecutiveFailures = 0;
        long openedAt = 0L;
        boolean probeInFlight = false;
        // Timestamp (CoreMetrics.currentTimeMillis) of the last probe-slot
        // (re)taking; the HALF_OPEN probe-timeout escape compares against it.
        long probeStartedAt = 0L;
    }
}
