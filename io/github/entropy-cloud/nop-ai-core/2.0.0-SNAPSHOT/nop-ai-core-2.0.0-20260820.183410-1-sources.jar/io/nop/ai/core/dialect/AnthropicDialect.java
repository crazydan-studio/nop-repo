package io.nop.ai.core.dialect;

import io.nop.ai.api.chat.ChatOptions;
import io.nop.ai.api.chat.ChatRequest;
import io.nop.ai.api.chat.ChatResponse;
import io.nop.ai.api.chat.messages.ChatAssistantMessage;
import io.nop.ai.api.chat.messages.ChatMessage;
import io.nop.ai.api.chat.messages.ChatReasoningMessage;
import io.nop.ai.api.chat.messages.ChatSystemMessage;
import io.nop.ai.api.chat.messages.ChatToolCall;
import io.nop.ai.api.chat.messages.ChatToolCallMessage;
import io.nop.ai.api.chat.messages.ChatToolResponseMessage;
import io.nop.ai.api.chat.messages.ChatToolDefinition;
import io.nop.ai.api.chat.messages.ChatUserMessage;
import io.nop.ai.api.chat.messages.ChatUsage;
import io.nop.ai.core.model.LlmModel;
import io.nop.ai.core.model.LlmModelModel;
import io.nop.ai.core.model.LlmResponseModel;
import io.nop.ai.api.chat.stream.ChatStreamChunk;
import io.nop.ai.api.chat.stream.StreamItemPhase;
import io.nop.ai.api.chat.stream.StreamItemType;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.json.JSON;
import io.nop.commons.util.StringHelper;
import io.nop.core.lang.json.JsonTool;
import io.nop.http.api.client.HttpRequest;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static io.nop.ai.core.NopAiCoreErrors.ERR_AI_INVALID_RESPONSE;

/**
 * Anthropic (Claude) 方言实现。
 * <p>
 * 处理 Claude API 格式：
 * <pre>
 * Request:
 * {
 *   "model": "claude-3-5-sonnet",
 *   "system": "You are a helpful assistant",
 *   "messages": [{"role": "user", "content": [{"type": "text", "text": "..."}]}],
 *   "max_tokens": 4096,
 *   "temperature": 0.7,
 *   "stream": true
 * }
 *
 * Response:
 * {
 *   "id": "msg_...",
 *   "content": [{"type": "text", "text": "..."}],
 *   "role": "assistant",
 *   "stop_reason": "end_turn",
 *   "usage": {"input_tokens": 10, "output_tokens": 20}
 * }
 * </pre>
 */
public class AnthropicDialect extends AbstractLlmDialect implements ILlmDialect {

    @Override
    public String getName() {
        return "anthropic";
    }

    @Override
    @SuppressWarnings("unchecked")
    public ChatRequest parseRequestBody(Map<String, Object> body) {
        ChatRequest request = new ChatRequest();
        List<ChatMessage> messages = new ArrayList<>();

        // 顶层 system 字段 → 首位 ChatSystemMessage（与 buildBody 的 system 分离逆向）
        Object system = body.get("system");
        if (system != null) {
            messages.add(new ChatSystemMessage(system.toString()));
        }

        List<Map<String, Object>> rawMessages = (List<Map<String, Object>>) body.get("messages");
        if (rawMessages != null) {
            for (Map<String, Object> raw : rawMessages) {
                String role = (String) raw.get("role");
                List<Map<String, Object>> blocks = (List<Map<String, Object>>) raw.get("content");
                if (blocks == null) {
                    // 极简格式：content 为纯文本（部分兼容实现）
                    if ("assistant".equals(role) || "model".equals(role)) {
                        messages.add(new ChatAssistantMessage(raw.get("content") != null
                                ? raw.get("content").toString() : null));
                    } else {
                        messages.add(new ChatUserMessage(raw.get("content") != null
                                ? raw.get("content").toString() : null));
                    }
                    continue;
                }
                // content blocks：text/thinking/tool_use/tool_result
                StringBuilder textBuilder = new StringBuilder();
                String reasoning = null;
                List<ChatToolCall> toolUses = new ArrayList<>();
                String toolResultId = null;
                StringBuilder toolResultContent = new StringBuilder();
                boolean hasToolResult = false;
                for (Map<String, Object> block : blocks) {
                    if (!(block instanceof Map)) {
                        continue;
                    }
                    String type = (String) block.get("type");
                    if ("text".equals(type)) {
                        String text = block.get("text") != null ? block.get("text").toString() : null;
                        if (text != null) {
                            if (textBuilder.length() > 0) {
                                textBuilder.append("\n");
                            }
                            textBuilder.append(text);
                        }
                    } else if ("thinking".equals(type)) {
                        if (block.get("thinking") != null) {
                            if (reasoning == null) {
                                reasoning = block.get("thinking").toString();
                            } else {
                                reasoning += "\n" + block.get("thinking");
                            }
                        }
                    } else if ("tool_use".equals(type)) {
                        ChatToolCall call = new ChatToolCall();
                        call.setId((String) block.get("id"));
                        call.setName((String) block.get("name"));
                        Object input = block.get("input");
                        if (input instanceof Map) {
                            call.setArguments((Map<String, Object>) input);
                        } else if (input instanceof String) {
                            // 字符串形态（部分兼容实现）→ 解析为 Map，畸形时 fail-fast
                            call.setArguments(parseToolInput(input));
                        }
                        toolUses.add(call);
                    } else if ("tool_result".equals(type)) {
                        hasToolResult = true;
                        toolResultId = (String) block.get("tool_use_id");
                        Object content = block.get("content");
                        if (content != null) {
                            if (toolResultContent.length() > 0) {
                                toolResultContent.append("\n");
                            }
                            toolResultContent.append(content.toString());
                        }
                    }
                }
                if (hasToolResult) {
                    // tool_result 是 user 角色的工具结果消息
                    messages.add(new ChatToolResponseMessage(toolResultId, null, toolResultContent.toString()));
                } else {
                    if (reasoning != null) {
                        messages.add(new ChatReasoningMessage(reasoning));
                    }
                    if ("assistant".equals(role) || "model".equals(role)) {
                        // convertMessage 伪影检测：ChatToolCallMessage.getContent()=arguments JSON，
                        // 与 tool_use 同发的 text block 若等于某 tool_use input 的 JSON 序列化则丢弃
                        boolean textIsToolCallArtifact = false;
                        if (textBuilder.length() > 0 && !toolUses.isEmpty()) {
                            String text = textBuilder.toString();
                            for (ChatToolCall call : toolUses) {
                                if (call.getArgumentsText() != null && call.getArgumentsText().equals(text)) {
                                    textIsToolCallArtifact = true;
                                    break;
                                }
                            }
                        }
                        if (!textIsToolCallArtifact && (toolUses.isEmpty() || textBuilder.length() > 0)) {
                            messages.add(new ChatAssistantMessage(
                                    textBuilder.length() > 0 ? textBuilder.toString() : null));
                        }
                        for (ChatToolCall call : toolUses) {
                            messages.add(ChatToolCallMessage.fromChatToolCall(call));
                        }
                    } else {
                        messages.add(new ChatUserMessage(textBuilder.length() > 0 ? textBuilder.toString() : null));
                    }
                }
            }
        }
        if (!messages.isEmpty()) {
            request.setMessages(messages);
        }

        // 顶层 options：max_tokens/temperature/top_p/top_k/stop_sequences
        ChatOptions options = new ChatOptions();
        if (body.get("max_tokens") instanceof Number) {
            options.setMaxTokens(((Number) body.get("max_tokens")).intValue());
        }
        if (body.get("temperature") instanceof Number) {
            options.setTemperature(((Number) body.get("temperature")).floatValue());
        }
        if (body.get("top_p") instanceof Number) {
            options.setTopP(((Number) body.get("top_p")).floatValue());
        }
        if (body.get("top_k") instanceof Number) {
            options.setTopK(((Number) body.get("top_k")).intValue());
        }
        if (body.get("stop_sequences") instanceof List) {
            options.setStop((List<String>) body.get("stop_sequences"));
        }
        request.setOptions(options);

        // tools：Anthropic 扁平格式（name/description/input_schema）
        List<Map<String, Object>> rawTools = (List<Map<String, Object>>) body.get("tools");
        if (rawTools != null && !rawTools.isEmpty()) {
            List<ChatToolDefinition> tools = new ArrayList<>();
            for (Map<String, Object> raw : rawTools) {
                ChatToolDefinition def = new ChatToolDefinition();
                def.setName((String) raw.get("name"));
                def.setDescription((String) raw.get("description"));
                if (raw.get("input_schema") instanceof Map) {
                    def.setParameters((Map<String, Object>) raw.get("input_schema"));
                }
                tools.add(def);
            }
            request.setTools(tools);
        }
        return request;
    }

    @Override
    public String buildUrl(String baseUrl, String chatUrl, String apiKey) {
        return StringHelper.appendPath(baseUrl, chatUrl);
    }

    @Override
    public void setHeaders(HttpRequest httpRequest, String apiKey, String apiKeyHeader) {
        httpRequest.setHeader("Content-Type", "application/json");
        if (!StringHelper.isEmpty(apiKey)) {
            if (apiKeyHeader != null) {
                httpRequest.setHeader(apiKeyHeader, apiKey);
            } else {
                httpRequest.setHeader("x-api-key", apiKey);  // Claude 使用 x-api-key
                httpRequest.setHeader("anthropic-version", "2023-06-01");
            }
        }
    }

    @Override
    public Map<String, Object> buildBody(ChatRequest request, LlmModel config,
                                          LlmModelModel modelConfig, String model, boolean stream) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("stream", stream);

        // Claude 要求必须指定 max_tokens
        Integer maxTokens = resolveMaxTokens(request.getOptions(), modelConfig);
        if (maxTokens == null) {
            maxTokens = 4096; // Claude 默认值
        }
        body.put("max_tokens", maxTokens);

        ChatOptions options = request.getOptions();
        if (options != null) {
            addOptionIfNotNull(body, "temperature", options.getTemperature());
            addOptionIfNotNull(body, "top_p", options.getTopP());
            addOptionIfNotNull(body, "top_k", options.getTopK());
            addOptionIfNotNull(body, "stop_sequences", options.getStop());

            if (options.getTools() != null && !options.getTools().isEmpty()) {
                body.put("tools", convertToolDefinitions(options.getTools()));
            }
        }

        // 分离 system 消息到单独字段
        List<Map<String, Object>> messages = new ArrayList<>();
        ChatMessage lastMessage = request.getLastMessage();
        for (ChatMessage msg : request.getMessages()) {
            if (msg instanceof io.nop.ai.api.chat.messages.ChatSystemMessage) {
                body.put("system", msg.getContent());
            } else {
                Map<String, Object> msgMap = convertMessage(msg, modelConfig, options);
                if (msg == lastMessage && modelConfig != null) {
                    applyThinkingToContentBlocks(msgMap, modelConfig, options);
                }
                messages.add(msgMap);
            }
        }

        if (!messages.isEmpty()) {
            body.put("messages", messages);
        }

        return body;
    }

    @Override
    public ChatResponse parseResponse(String responseBody, LlmModel config) {
        if (StringHelper.isEmpty(responseBody)) {
            return ChatResponse.error("NULL_RESPONSE", "Empty response body");
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> responseMap = (Map<String, Object>) JSON.parse(responseBody);
        LlmResponseModel responseConfig = config.getResponse();

        ChatResponse response = new ChatResponse();

        // 解析内容块（可能包含 text, thinking, tool_use）
        StringBuilder contentBuilder = new StringBuilder();
        StringBuilder thinkingBuilder = new StringBuilder();
        List<ChatToolCall> toolCalls = new ArrayList<>();

        Object contentObj = responseMap.get("content");
        if (contentObj instanceof List) {
            for (Object block : (List<?>) contentObj) {
                if (block instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> blockMap = (Map<String, Object>) block;
                    String type = (String) blockMap.get("type");

                    if ("text".equals(type)) {
                        String text = (String) blockMap.get("text");
                        if (text != null) {
                            if (contentBuilder.length() > 0) {
                                contentBuilder.append("\n");
                            }
                            contentBuilder.append(text);
                        }
                    } else if ("thinking".equals(type)) {
                        // Extended Thinking 模式的思考内容
                        String thinking = (String) blockMap.get("thinking");
                        if (thinking != null) {
                            if (thinkingBuilder.length() > 0) {
                                thinkingBuilder.append("\n");
                            }
                            thinkingBuilder.append(thinking);
                        }
                    } else if ("tool_use".equals(type)) {
                        ChatToolCall toolCall = new ChatToolCall();
                        toolCall.setId((String) blockMap.get("id"));
                        toolCall.setName((String) blockMap.get("name"));
                        toolCall.setArguments(parseToolInput(blockMap.get("input")));
                        toolCalls.add(toolCall);
                    }
                }
            }
        }

        ChatAssistantMessage message = new ChatAssistantMessage();
        message.setContent(contentBuilder.length() > 0 ? contentBuilder.toString() : null);

        // Plan 329：单一拆分模型产出。reasoning → ChatReasoningMessage、assistant 文本 → ChatAssistantMessage、
        // 每个 tool_use block → 独立 ChatToolCallMessage。
        List<ChatMessage> messages = new ArrayList<>();
        if (thinkingBuilder.length() > 0) {
            messages.add(new ChatReasoningMessage(thinkingBuilder.toString()));
        }
        messages.add(message);
        for (ChatToolCall toolCall : toolCalls) {
            messages.add(ChatToolCallMessage.fromChatToolCall(toolCall));
        }
        response.setMessages(messages);

        // 解析元数据
        response.setId(getStringByPath(responseMap, "id"));
        response.setModel(getStringByPath(responseMap, "model"));

        // 解析结束原因
        String statusPath = responseConfig != null && responseConfig.getStatusPath() != null
                ? responseConfig.getStatusPath() : "stop_reason";
        response.setFinishReason(normalizeFinishReason(getStringByPath(responseMap, statusPath)));

        // 解析 Usage（使用基类通用方法，支持缓存 token）
        ChatUsage usage = parseUsage(responseMap, responseConfig,
                "usage.input_tokens", "usage.output_tokens", null);

        // Anthropic Prompt Caching 专用字段
        // cache_creation_input_tokens: 创建缓存时消耗的 token
        // cache_read_input_tokens: 从缓存读取的 token（缓存命中）
        Integer cacheCreationTokens = getIntByPath(responseMap, "usage.cache_creation_input_tokens");
        Integer cacheReadTokens = getIntByPath(responseMap, "usage.cache_read_input_tokens");

        // 将 Anthropic 的字段映射到通用字段
        // cache_read_input_tokens -> cacheHitTokens (缓存命中)
        // cache_creation_input_tokens -> cacheCreationTokens (创建缓存时消耗)
        if (cacheReadTokens != null) {
            usage.setCacheHitTokens(cacheReadTokens);
        }
        if (cacheCreationTokens != null) {
            usage.setCacheCreationTokens(cacheCreationTokens);
        }

        response.setUsage(usage);

        return response;
    }

    /**
     * 解析 Anthropic API tool_use 块的 input 字段。
     * <p>
     * input 的合法形态为 JSON object；部分兼容实现以 JSON 字符串形式返回 input，
     * 与 {@code DefaultAiChatService.parseToolCalls} 使用相同的 String → parseMap 降级规则。
     * input 缺失或形态不符时显式抛错，避免把畸形响应静默降级为空 Map。
     */
    private Map<String, Object> parseToolInput(Object input) {
        if (input instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> inputMap = (Map<String, Object>) input;
            return inputMap;
        }

        if (input instanceof String) {
            Map<String, Object> inputMap = JsonTool.parseMap(input.toString());
            if (inputMap == null)
                throw new NopException(ERR_AI_INVALID_RESPONSE);
            return inputMap;
        }

        throw new NopException(ERR_AI_INVALID_RESPONSE);
    }

    @Override
    public ChatStreamChunk parseStreamChunk(String data) {
        if (data == null || data.isEmpty() || "[DONE]".equals(data)) {
            return null;
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> dataMap = (Map<String, Object>) JSON.parse(data);
        String eventType = (String) dataMap.get("type");

        ChatStreamChunk chunk = new ChatStreamChunk();

        switch (eventType) {
            case "message_start":
                // 消息开始，可以获取模型信息
                Object message = dataMap.get("message");
                if (message instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> messageMap = (Map<String, Object>) message;
                    chunk.setModel((String) messageMap.get("model"));
                }
                break;

            case "content_block_start":
                // 内容块声明（ADDED）：thinking/text/tool_use
                Object contentBlock = dataMap.get("content_block");
                Integer blockIndex = toInt(dataMap.get("index"));
                if (contentBlock instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> blockMap = (Map<String, Object>) contentBlock;
                    String blockType = (String) blockMap.get("type");
                    if ("thinking".equals(blockType)) {
                        chunk.setItemType(StreamItemType.reasoning);
                        chunk.setItemIndex(blockIndex);
                        chunk.setPhase(StreamItemPhase.ADDED);
                        chunk.setDelta((String) blockMap.get("thinking"));
                    } else if ("text".equals(blockType)) {
                        chunk.setItemType(StreamItemType.text);
                        chunk.setItemIndex(blockIndex);
                        chunk.setPhase(StreamItemPhase.ADDED);
                        chunk.setDelta((String) blockMap.get("text"));
                    } else if ("tool_use".equals(blockType)) {
                        chunk.setItemType(StreamItemType.tool_call);
                        chunk.setItemIndex(blockIndex);
                        chunk.setCallId((String) blockMap.get("id"));
                        chunk.setPhase(StreamItemPhase.ADDED);
                        chunk.setDelta((String) blockMap.get("name"));
                    }
                }
                break;

            case "content_block_delta":
                // 内容增量（DELTA）
                Object delta = dataMap.get("delta");
                Integer deltaIndex = toInt(dataMap.get("index"));
                if (delta instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> deltaMap = (Map<String, Object>) delta;
                    String deltaType = (String) deltaMap.get("type");
                    if ("text_delta".equals(deltaType)) {
                        chunk.setItemType(StreamItemType.text);
                        chunk.setItemIndex(deltaIndex);
                        chunk.setPhase(StreamItemPhase.DELTA);
                        chunk.setDelta((String) deltaMap.get("text"));
                    } else if ("thinking_delta".equals(deltaType)) {
                        chunk.setItemType(StreamItemType.reasoning);
                        chunk.setItemIndex(deltaIndex);
                        chunk.setPhase(StreamItemPhase.DELTA);
                        chunk.setDelta((String) deltaMap.get("thinking"));
                    } else if ("input_json_delta".equals(deltaType)) {
                        // 工具调用参数增量（partial_json）
                        String partialJson = (String) deltaMap.get("partial_json");
                        if (partialJson != null) {
                            chunk.setItemType(StreamItemType.tool_call);
                            chunk.setItemIndex(deltaIndex);
                            chunk.setPhase(StreamItemPhase.DELTA);
                            chunk.setDelta(partialJson);
                        }
                    }
                }
                break;

            case "content_block_stop":
                // 内容块结束：无 payload，跳过（item 收尾由 message_stop 的 DONE 标记）
                break;

            case "message_delta":
                // 消息增量，包含停止原因和 usage
                Object usage = dataMap.get("usage");
                if (usage instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> usageMap = (Map<String, Object>) usage;
                    ChatUsage chunkUsage = new ChatUsage();
                    chunkUsage.setPromptTokens(getIntByPath(usageMap, "input_tokens"));
                    chunkUsage.setCompletionTokens(getIntByPath(usageMap, "output_tokens"));
                    chunkUsage.setCacheHitTokens(getIntByPath(usageMap, "cache_read_input_tokens"));
                    chunkUsage.setCacheCreationTokens(getIntByPath(usageMap, "cache_creation_input_tokens"));
                    chunk.setUsage(chunkUsage);
                }
                Object deltaObj = dataMap.get("delta");
                if (deltaObj instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> deltaMap = (Map<String, Object>) deltaObj;
                    String stopReason = (String) deltaMap.get("stop_reason");
                    if (stopReason != null) {
                        chunk.setPhase(StreamItemPhase.DONE);
                        chunk.setFinishReason(normalizeFinishReason(stopReason));
                    }
                }
                break;

            case "message_stop":
                // 消息结束
                chunk.setPhase(StreamItemPhase.DONE);
                chunk.setFinishReason("stop");
                break;

            case "ping":
                // 心跳消息，忽略
                return null;

            case "error":
                // 错误消息：作为 text item 的错误文本（快速暴露，不静默）
                Object error = dataMap.get("error");
                if (error instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> errorMap = (Map<String, Object>) error;
                    String errorMsg = (String) errorMap.get("message");
                    if (errorMsg == null) {
                        errorMsg = errorMap.toString();
                    }
                    chunk.setItemType(StreamItemType.text);
                    chunk.setItemIndex(0);
                    chunk.setPhase(StreamItemPhase.DELTA);
                    chunk.setDelta("[ERROR] " + errorMsg);
                }
                break;
        }

        return chunk;
    }

    private Integer toInt(Object value) {
        if (value instanceof Number) return ((Number) value).intValue();
        return null;
    }

    @Override
    public Map<String, Object> convertMessage(ChatMessage message, LlmModelModel modelConfig,
                                               ChatOptions options) {
        Map<String, Object> msgMap = new LinkedHashMap<>();
        
        msgMap.put("role", getRole(message));

        List<Map<String, Object>> contentBlocks = new ArrayList<>();

        String textContent = message.getContent();
        if (textContent != null && !textContent.isEmpty()) {
            Map<String, Object> textBlock = new LinkedHashMap<>();
            textBlock.put("type", "text");
            textBlock.put("text", textContent);
            contentBlocks.add(textBlock);
        }

        if (message instanceof ChatReasoningMessage) {
            Map<String, Object> thinkingBlock = new LinkedHashMap<>();
            thinkingBlock.put("type", "thinking");
            thinkingBlock.put("thinking", message.getContent());
            contentBlocks.add(thinkingBlock);
        }

        if (message instanceof ChatToolCallMessage) {
            ChatToolCallMessage toolCallMsg = (ChatToolCallMessage) message;
            Map<String, Object> toolBlock = new LinkedHashMap<>();
            toolBlock.put("type", "tool_use");
            toolBlock.put("id", toolCallMsg.getCallId());
            toolBlock.put("name", toolCallMsg.getName());
            toolBlock.put("input", toolCallMsg.getArguments());
            contentBlocks.add(toolBlock);
        }

        if (message instanceof ChatToolResponseMessage) {
            ChatToolResponseMessage toolMsg = (ChatToolResponseMessage) message;
            Map<String, Object> toolResultBlock = new LinkedHashMap<>();
            toolResultBlock.put("type", "tool_result");
            toolResultBlock.put("tool_use_id", toolMsg.getCallId());
            toolResultBlock.put("content", toolMsg.getContent());
            contentBlocks.add(toolResultBlock);
        }

        if (message.getProviderHints() != null && message.getProviderHints().containsKey("cache_control")) {
            msgMap.put("cache_control", message.getProviderHints().get("cache_control"));
        }

        msgMap.put("content", contentBlocks);
        return msgMap;
    }

    @SuppressWarnings("unchecked")
    private void applyThinkingToContentBlocks(Map<String, Object> msgMap,
                                               LlmModelModel modelConfig, ChatOptions options) {
        List<Map<String, Object>> contentBlocks = (List<Map<String, Object>>) msgMap.get("content");
        if (contentBlocks != null) {
            for (Map<String, Object> block : contentBlocks) {
                if ("text".equals(block.get("type"))) {
                    String text = (String) block.get("text");
                    block.put("text", applyThinkingPrompt(text, modelConfig, options));
                    break;
                }
            }
        }
    }

    @Override
    public String getRole(ChatMessage message) {
        String role = getBaseRole(message);
        // Claude 使用 model 而不是 assistant
        return "assistant".equals(role) ? "model" : role;
    }

    /**
     * 转换工具定义为 Anthropic 格式
     * <p>
     * Anthropic 使用 input_schema 而不是 parameters：
     * <pre>
     * {
     *   "name": "get_weather",
     *   "description": "获取天气",
     *   "input_schema": {
     *     "type": "object",
     *     "properties": {...}
     *   }
     * }
     * </pre>
     */
    @Override
    public List<Map<String, Object>> convertToolDefinitions(List<ChatToolDefinition> tools) {
        if (tools == null || tools.isEmpty()) {
            return null;
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (ChatToolDefinition tool : tools) {
            Map<String, Object> toolMap = new LinkedHashMap<>();
            toolMap.put("name", tool.getName());
            toolMap.put("description", tool.getDescription());
            // Anthropic 使用 input_schema 而不是 parameters
            if (tool.getParameters() != null) {
                toolMap.put("input_schema", tool.getParameters());
            }
            result.add(toolMap);
        }
        return result;
    }

    // ==================== 反向转换：ChatResponse → Provider 响应 Map ====================

    @Override
    public Map<String, Object> buildResponse(ChatResponse response) {
        Map<String, Object> result = new LinkedHashMap<>();
        if (response.getId() != null) {
            result.put("id", response.getId());
        }
        if (response.getModel() != null) {
            result.put("model", response.getModel());
        }
        result.put("role", "assistant");

        // messages 序列 → content blocks（reasoning→thinking / assistant→text / tool_call→tool_use）
        List<Map<String, Object>> blocks = new ArrayList<>();
        if (response.getMessages() != null) {
            for (ChatMessage msg : response.getMessages()) {
                if (msg instanceof ChatReasoningMessage) {
                    Map<String, Object> block = new LinkedHashMap<>();
                    block.put("type", "thinking");
                    block.put("thinking", msg.getContent());
                    blocks.add(block);
                } else if (msg instanceof ChatToolCallMessage) {
                    ChatToolCallMessage tcm = (ChatToolCallMessage) msg;
                    Map<String, Object> block = new LinkedHashMap<>();
                    block.put("type", "tool_use");
                    if (tcm.getCallId() != null) {
                        block.put("id", tcm.getCallId());
                    }
                    block.put("name", tcm.getName());
                    if (tcm.getArguments() != null) {
                        block.put("input", tcm.getArguments());
                    }
                    blocks.add(block);
                } else if (msg instanceof ChatAssistantMessage && msg.getContent() != null) {
                    Map<String, Object> block = new LinkedHashMap<>();
                    block.put("type", "text");
                    block.put("text", msg.getContent());
                    blocks.add(block);
                }
            }
        }
        result.put("content", blocks);

        // finish_reason（归一化值）→ Anthropic 原生 stop_reason
        if (response.getFinishReason() != null) {
            result.put("stop_reason", reverseFinishReason(response.getFinishReason()));
        }

        // usage → Anthropic usage（含 cache 字段）
        if (response.getUsage() != null) {
            Map<String, Object> usage = new LinkedHashMap<>();
            if (response.getUsage().getPromptTokens() != null) {
                usage.put("input_tokens", response.getUsage().getPromptTokens());
            }
            if (response.getUsage().getCompletionTokens() != null) {
                usage.put("output_tokens", response.getUsage().getCompletionTokens());
            }
            if (response.getUsage().getCacheCreationTokens() != null) {
                usage.put("cache_creation_input_tokens", response.getUsage().getCacheCreationTokens());
            }
            if (response.getUsage().getCacheHitTokens() != null) {
                usage.put("cache_read_input_tokens", response.getUsage().getCacheHitTokens());
            }
            result.put("usage", usage);
        }
        return result;
    }

    /**
     * 归一化 finish_reason → Anthropic 原生 stop_reason（normalizeFinishReason 的逆映射）。
     * 归一化有损点 (a) 裁定：roundtrip 样本仅使用归一化目标值；未知值原样透传。
     */
    private String reverseFinishReason(String reason) {
        switch (reason) {
            case "stop":
                return "end_turn";
            case "length":
                return "max_tokens";
            case "tool_calls":
                return "tool_use";
            default:
                return reason;
        }
    }

    @Override
    public Map<String, Object> buildStreamChunk(ChatStreamChunk chunk) {
        Map<String, Object> result = new LinkedHashMap<>();
        Integer index = chunk.getItemIndex() != null ? chunk.getItemIndex() : 0;

        StreamItemType type = chunk.getItemType();
        if (type == StreamItemType.text) {
            if (chunk.getPhase() == StreamItemPhase.ADDED) {
                Map<String, Object> block = new LinkedHashMap<>();
                block.put("type", "text");
                block.put("text", chunk.getDelta());
                result.put("type", "content_block_start");
                result.put("index", index);
                result.put("content_block", block);
            } else {
                Map<String, Object> delta = new LinkedHashMap<>();
                delta.put("type", "text_delta");
                if (chunk.getDelta() != null) {
                    delta.put("text", chunk.getDelta());
                }
                result.put("type", "content_block_delta");
                result.put("index", index);
                result.put("delta", delta);
            }
        } else if (type == StreamItemType.reasoning) {
            if (chunk.getPhase() == StreamItemPhase.ADDED) {
                Map<String, Object> block = new LinkedHashMap<>();
                block.put("type", "thinking");
                block.put("thinking", chunk.getDelta());
                result.put("type", "content_block_start");
                result.put("index", index);
                result.put("content_block", block);
            } else {
                Map<String, Object> delta = new LinkedHashMap<>();
                delta.put("type", "thinking_delta");
                if (chunk.getDelta() != null) {
                    delta.put("thinking", chunk.getDelta());
                }
                result.put("type", "content_block_delta");
                result.put("index", index);
                result.put("delta", delta);
            }
        } else if (type == StreamItemType.tool_call) {
            if (chunk.getPhase() == StreamItemPhase.ADDED) {
                Map<String, Object> block = new LinkedHashMap<>();
                block.put("type", "tool_use");
                if (chunk.getCallId() != null) {
                    block.put("id", chunk.getCallId());
                }
                block.put("name", chunk.getDelta());
                result.put("type", "content_block_start");
                result.put("index", index);
                result.put("content_block", block);
            } else {
                Map<String, Object> delta = new LinkedHashMap<>();
                delta.put("type", "input_json_delta");
                if (chunk.getDelta() != null) {
                    delta.put("partial_json", chunk.getDelta());
                }
                result.put("type", "content_block_delta");
                result.put("index", index);
                result.put("delta", delta);
            }
        } else if (chunk.getPhase() == StreamItemPhase.DONE) {
            // 终止信号 → message_delta（stop_reason + usage）
            Map<String, Object> delta = new LinkedHashMap<>();
            if (chunk.getFinishReason() != null) {
                delta.put("stop_reason", reverseFinishReason(chunk.getFinishReason()));
            }
            result.put("type", "message_delta");
            result.put("delta", delta);
            if (chunk.getUsage() != null) {
                Map<String, Object> usage = new LinkedHashMap<>();
                if (chunk.getUsage().getPromptTokens() != null) {
                    usage.put("input_tokens", chunk.getUsage().getPromptTokens());
                }
                if (chunk.getUsage().getCompletionTokens() != null) {
                    usage.put("output_tokens", chunk.getUsage().getCompletionTokens());
                }
                if (chunk.getUsage().getCacheHitTokens() != null) {
                    usage.put("cache_read_input_tokens", chunk.getUsage().getCacheHitTokens());
                }
                if (chunk.getUsage().getCacheCreationTokens() != null) {
                    usage.put("cache_creation_input_tokens", chunk.getUsage().getCacheCreationTokens());
                }
                result.put("usage", usage);
            }
        } else {
            // 无 item 载荷（id/model 元数据块）→ message_start
            Map<String, Object> message = new LinkedHashMap<>();
            if (chunk.getId() != null) {
                message.put("id", chunk.getId());
            }
            if (chunk.getModel() != null) {
                message.put("model", chunk.getModel());
            }
            result.put("type", "message_start");
            result.put("message", message);
        }
        return result;
    }
}
