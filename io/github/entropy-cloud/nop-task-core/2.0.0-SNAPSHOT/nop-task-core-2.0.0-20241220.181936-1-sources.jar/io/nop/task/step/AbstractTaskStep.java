/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.task.step;

import io.nop.api.core.util.SourceLocation;
import io.nop.commons.util.StringHelper;
import io.nop.task.ITaskStep;
import io.nop.task.TaskStepReturn;
import io.nop.task.model.ITaskInputModel;
import io.nop.task.model.ITaskOutputModel;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletionStage;

public abstract class AbstractTaskStep implements ITaskStep {
    private SourceLocation location;
    private String stepType;

    private Set<String> persistVars;
    private String returnAs;

    private boolean concurrent;

    private List<? extends ITaskInputModel> inputs = Collections.emptyList();

    private List<? extends ITaskOutputModel> outputs = Collections.emptyList();

    public String getReturnAs() {
        return returnAs;
    }

    public void setReturnAs(String returnAs) {
        this.returnAs = returnAs;
    }

    @Override
    public SourceLocation getLocation() {
        return location;
    }

    public void setLocation(SourceLocation location) {
        this.location = location;
    }

    @Override
    public String getStepType() {
        return stepType;
    }

    public void setStepType(String stepType) {
        this.stepType = stepType;
    }

    @Override
    public boolean isConcurrent() {
        return concurrent;
    }

    public void setConcurrent(boolean concurrent) {
        this.concurrent = concurrent;
    }

    @Override
    public Set<String> getPersistVars() {
        return persistVars;
    }

    public void setPersistVars(Set<String> persistVars) {
        this.persistVars = persistVars;
    }

    @Override
    public List<? extends ITaskInputModel> getInputs() {
        return inputs;
    }

    public void setInputs(List<? extends ITaskInputModel> inputs) {
        this.inputs = inputs;
    }

    @Override
    public List<? extends ITaskOutputModel> getOutputs() {
        return outputs;
    }

    public void setOutputs(List<? extends ITaskOutputModel> outputs) {
        this.outputs = outputs;
    }

    protected TaskStepReturn makeReturn(String nextStepName, Object returnValue) {
        if (StringHelper.isEmpty(returnAs)) {
            return TaskStepReturn.of(nextStepName, returnValue);
        } else {
            if (returnValue instanceof CompletionStage) {
                return TaskStepReturn.of(nextStepName, ((CompletionStage) returnValue).thenApply(
                        v -> Collections.singletonMap(returnAs, v)));
            } else {
                return TaskStepReturn.RETURN(nextStepName, Collections.singletonMap(returnAs, returnValue));
            }
        }
    }

    protected TaskStepReturn makeReturn(Object returnValue) {
        return makeReturn(null, returnValue);
    }
}