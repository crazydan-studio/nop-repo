package io.nop.task.step;

import io.nop.api.core.beans.ErrorBean;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.time.CoreMetrics;
import io.nop.api.core.util.Guard;
import io.nop.api.core.util.SourceLocation;
import io.nop.commons.util.StringHelper;
import io.nop.core.exceptions.ErrorMessageManager;
import io.nop.core.lang.eval.IEvalAction;
import io.nop.core.lang.eval.IEvalPredicate;
import io.nop.core.lang.eval.IEvalScope;
import io.nop.task.ITaskRuntime;
import io.nop.task.ITaskStep;
import io.nop.task.ITaskStepExecution;
import io.nop.task.ITaskStepFlagOperation;
import io.nop.task.ITaskStepRuntime;
import io.nop.task.ITaskStepState;
import io.nop.task.TaskConstants;
import io.nop.task.TaskErrors;
import io.nop.task.TaskStepReturn;
import io.nop.task.core._NopTaskCoreConstants;
import io.nop.task.metrics.ITaskFlowMetrics;
import io.nop.task.utils.TaskStepHelper;
import jakarta.annotation.Nonnull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static io.nop.task.TaskErrors.ARG_INPUT_NAME;
import static io.nop.task.TaskErrors.ARG_STEP_PATH;
import static io.nop.task.TaskErrors.ERR_TASK_MANDATORY_INPUT_NOT_ALLOW_EMPTY;
import static io.nop.task.TaskErrors.ERR_TASK_STEP_ALREADY_FAILED;

public class TaskStepExecution implements ITaskStepExecution {
    static final Logger LOG = LoggerFactory.getLogger(TaskStepExecution.class);

    public static class InputConfig {
        private final SourceLocation location;
        private final String name;
        private final IEvalAction expr;
        private final boolean fromTaskScope;
        private final boolean mandatory;
        private final boolean dump;

        public InputConfig(SourceLocation loc, String name, IEvalAction expr,
                           boolean fromTaskScope, boolean mandatory, boolean dump) {
            this.location = loc;
            this.name = name;
            this.expr = expr;
            this.fromTaskScope = fromTaskScope;
            this.mandatory = mandatory;
            this.dump = dump;
        }

        public boolean isDump() {
            return dump;
        }

        public boolean isMandatory() {
            return mandatory;
        }

        public SourceLocation getLocation() {
            return location;
        }

        public String getName() {
            return name;
        }

        public IEvalAction getExpr() {
            return expr;
        }

        public boolean isFromTaskScope() {
            return fromTaskScope;
        }
    }

    public static class OutputConfig {
        private final SourceLocation location;
        private final String exportName;
        private final String name;
        private final boolean toTaskScope;
        private final boolean dump;

        public OutputConfig(SourceLocation location,
                            String exportName, String name, boolean toTaskScope, boolean dump) {
            this.exportName = Guard.notEmpty(exportName, "exportName");
            this.name = Guard.notEmpty(name, "name");
            this.toTaskScope = toTaskScope;
            this.location = location;
            this.dump = dump;
        }

        public boolean isDump() {
            return dump;
        }

        public SourceLocation getLocation() {
            return location;
        }

        public String getExportName() {
            return exportName;
        }

        public String getName() {
            return name;
        }

        public boolean isToTaskScope() {
            return toTaskScope;
        }
    }

    private final SourceLocation location;

    private final String stepName;
    private final List<InputConfig> inputConfigs;

    private final List<OutputConfig> outputConfigs;

    private final Set<String> outputVars;

    private final ITaskStepFlagOperation flagOperation;
    private final IEvalPredicate when;
    private final ITaskStep step;
    private final String nextStepName;
    private final String nextStepNameOnError;

    private final boolean recordMetrics;

    private final String errorName;
    private final boolean useParentScope;

    /**
     * plan 364 [维度03-05]：消费 xdef 声明的 per-step saveState 契约（此前全仓零消费者，
     * xdef 头注释的"配置 saveState 可从任意步骤中断恢复"承诺未兑现）。
     * 显式 FALSE 的步骤跳过自身状态行的全部生命周期落盘（ACTIVE/挂起/终态）；
     * null（未配置）保持既有行为。任务级持久化开关仍是 {@code defaultSaveState}。
     */
    private final Boolean persistState;

    public TaskStepExecution(SourceLocation location, String stepName,
                             List<InputConfig> inputConfigs,
                             List<OutputConfig> outputConfigs, Set<String> outputVars,
                             ITaskStepFlagOperation flagOperation, IEvalPredicate when,
                             ITaskStep step, String nextStepName, String nextStepNameOnError,
                             boolean recordMetrics, String errorName,
                             boolean useParentScope
    ) {
        this(location, stepName, inputConfigs, outputConfigs, outputVars, flagOperation, when, step,
                nextStepName, nextStepNameOnError, recordMetrics, errorName, useParentScope, null);
    }

    public TaskStepExecution(SourceLocation location, String stepName,
                             List<InputConfig> inputConfigs,
                             List<OutputConfig> outputConfigs, Set<String> outputVars,
                             ITaskStepFlagOperation flagOperation, IEvalPredicate when,
                             ITaskStep step, String nextStepName, String nextStepNameOnError,
                             boolean recordMetrics, String errorName,
                             boolean useParentScope, Boolean persistState
    ) {
        this.location = location;
        this.stepName = stepName;
        this.inputConfigs = inputConfigs;
        this.step = step;
        this.flagOperation = flagOperation;
        this.when = when;
        this.outputConfigs = outputConfigs;
        this.outputVars = outputVars;
        this.nextStepName = nextStepName;
        this.nextStepNameOnError = nextStepNameOnError;
        this.recordMetrics = recordMetrics;
        this.errorName = errorName == null ? TaskConstants.VAR_ERROR : errorName;
        this.useParentScope = useParentScope;
        this.persistState = persistState;
    }

    /**
     * xdef saveState 契约消费点：仅显式 false 跳过落盘，未配置（null）保持既有行为。
     */
    private boolean persistStepState() {
        return !Boolean.FALSE.equals(persistState);
    }

    @Override
    public SourceLocation getLocation() {
        return location;
    }

    @Override
    public String getStepName() {
        return stepName;
    }

    @Nonnull
    @Override
    public TaskStepReturn executeWithParentRt(ITaskStepRuntime parentRt) {
        IEvalScope parentScope = parentRt.getEvalScope();

        long beginTime = CoreMetrics.currentTimeMillis();

        ITaskRuntime taskRt = parentRt.getTaskRuntime();
        ITaskStepRuntime stepRt = parentRt.newStepRuntime(stepName, step.getStepType(),
                step.getPersistVars(), useParentScope, step.isConcurrent());

        stepRt.setOutputNames(outputVars);

        LOG.debug("nop.task.step.run:taskName={},taskInstanceId={},stepPath={},runId={},loc={}",
                taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                stepRt.getStepPath(), stepRt.getRunId(), step.getLocation());

        // plan 257: continuation-skip reader —— resume/re-execution 时检查 state.isDone()。
        // 终态 COMPLETED → 返回缓存 result（step body 不被调用）；终态 FAILED → 重抛 exception。
        // 这是 plans 252-256 状态机 write-side（succeed/COMPLETED + FAILED driver）的 read-side 消费方，
        // 使 ITaskStepState.isDone()/result() 首次被 production 消费。
        ITaskStepState stepState = stepRt.getState();
        if (stepRt.isRecoverMode()) {
            // persistVars 恢复（plan 349 Phase 6）：xdef 声明的持久化变量快照回写步骤 scope，
            // 使"标记为 persist 的变量支持中断后恢复执行"契约成立
            restorePersistVars(step, stepState, stepRt);
        }
        if (stepState != null && stepState.isDone()) {
            if (stepState.isSuccess()) {
                TaskStepReturn cached = stepState.result();
                LOG.info("nop.task.step.continuation-skip:taskName={},taskInstanceId={},stepPath={},runId={},loc={}",
                        taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                        stepRt.getStepPath(), stepRt.getRunId(), step.getLocation());
                if (cached != null) {
                    parentScope.setLocalValue(TaskConstants.VAR_RESULT, cached.getResult());
                    // 重放持久化的 outputs（plan 349 Phase 6）：exportAs/toTaskScope 导出变量
                    // 在恢复后不再丢失（修复 check/check2 的 continuation-skip outputs 暂缓项）
                    replayPersistedOutputs(stepState, stepRt, parentScope);
                    String savedNext = stepState.getSavedNextStepName();
                    if (savedNext != null) {
                        cached = TaskStepReturn.RETURN(savedNext, cached.get());
                    } else if (cached.getNextStepName() == null && nextStepName != null) {
                        cached = TaskStepReturn.RETURN(nextStepName, cached.get());
                    }
                    return cached;
                }
                return TaskStepReturn.CONTINUE;
            } else {
                // 终态失败（FAILED/EXPIRED/KILLED）→ 默认重抛 exception（非静默跳过，设计裁定 4）
                Throwable exp = stepState.exception();
                if (exp == null) {
                    exp = new NopException(ERR_TASK_STEP_ALREADY_FAILED)
                            .param(TaskErrors.ARG_TASK_NAME, taskRt.getTaskName())
                            .param(TaskErrors.ARG_STEP_PATH, stepRt.getStepPath());
                }
                if (nextStepNameOnError != null) {
                    // 配置了 nextOnError（plan 349 Phase 5）：失败已被错误分支消费，恢复执行时
                    // 经错误分支续跑而非重抛——重抛会令错误分支永不可达（resume 语义断裂，
                    // 与 plan 254 FAILED driver + nextOnError 的组合矛盾）
                    return buildErrorResult(stepRt, parentScope, exp);
                }
                if (exp instanceof NopException)
                    ((NopException) exp).addXplStack(stepRt.getStepPath() + '@' + this.getLocation());
                throw NopException.adapt(exp);
            }
        }

        TaskStepHelper.checkNotCancelled(parentRt);

        if (!stepRt.isRecoverMode()) {
            if (!allowExecute(parentRt)) {
                LOG.info("nop.task.step.skip-when-condition-not-satisfied:taskName={},taskInstanceId={},"
                                + "stepPath={},runId={},loc={}", taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                        stepRt.getStepPath(), stepRt.getRunId(), step.getLocation());

                return TaskStepReturn.CONTINUE;
            }

            initInputs(stepRt, parentScope, taskRt);

            if (persistStepState()) {
                capturePersistVars(stepRt);
                stepRt.saveState();
            }
        }

        if (flagOperation != null) {
            stepRt.setTagSet(flagOperation.buildChildFlags(parentRt.getTagSet()));
        } else {
            stepRt.setTagSet(parentRt.getTagSet());
        }

        ITaskFlowMetrics metrics = parentRt.getTaskRuntime().getMetrics();
        Object meter = recordMetrics ? metrics.beginStep(stepRt.getStepPath(), step.getStepType()) : null;

        try {
            TaskStepReturn stepResult = step.execute(stepRt);
            if (stepResult.isSuspend()) {
                // 判空对齐 :257/:330 出口（check2 P0-1）：步骤级 recordMetrics 缺省为 false 时 meter 为 null，
                // 缺守卫会把挂起动作变成 NPE、挂起语义完全失效
                if (meter != null)
                    metrics.endStep(meter, false);
                // 挂起点状态保存（plan 349 Phase 6）：stateBean（如 suspend 的 first 标记、loop 的迭代位置）
                // 与 bodyStepIndex 必须落盘，resume 才能从挂起点续跑而非重新挂起。
                // saveState=false 的步骤不落盘（plan 364 [03-05]）：挂起恢复对其退化为重新执行
                if (persistStepState()) {
                    capturePersistVars(stepRt);
                    stepRt.saveState();
                }
                return stepResult;
            }

            return stepResult.thenCompose((ret, err) -> {
                if (meter != null)
                    metrics.endStep(meter, err != null);

                if (err != null) {
                    LOG.info("nop.task.step.run-fail:usedTime={},taskName={},taskInstanceId={},stepPath={},runId={},nextStepNameOnError={},loc={}",
                            CoreMetrics.currentTimeMillis() - beginTime, taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                            stepRt.getStepPath(), stepRt.getRunId(), nextStepNameOnError, step.getLocation(), err);

                    // plan 364 [维度02-02]：失败驱动统一到单一实现（async 出口此前 addXplStack 位于
                    // nextOnError 分支之后永不可达——nextOnError 配置下同步失败带 XPL 栈、异步失败不带）
                    return driveStepFailure(stepRt, taskRt, parentScope, err);
                } else {
                    if (ret.isSuspend())
                        return ret;

                    Guard.checkState(!ret.isAsync());

                    parentScope.setLocalValue(TaskConstants.VAR_RESULT, ret.getResult());

                    if (!outputConfigs.isEmpty()) {
                        initOutputs(ret, stepRt, parentScope);
                    }

                    // 如果ret中明确指定了nextStepName，则以指定的值为准
                    if (ret.getNextStepName() == null && nextStepName != null)
                        ret = TaskStepReturn.RETURN(nextStepName, ret.get());

                    LOG.debug("nop.task.step.run-ok:usedTime={},taskName={},taskInstanceId={},stepPath={},runId={}," +
                                    "nextStepName={},outputs={},loc={}",
                            CoreMetrics.currentTimeMillis() - beginTime, taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                            stepRt.getStepPath(), stepRt.getRunId(), ret.getNextStepName(), ret.getOutputs(),
                            step.getLocation());
                    stepRt.getState().succeed(ret.getResult(), ret.getNextStepName(), taskRt);
                    // 持久化终态 outputs 与动态跳转（plan 349 Phase 6）：供 continuation-skip 重放导出变量
                    stepRt.getState().setOutputs(ret.getOutputs());
                    stepRt.getState().setSavedNextStepName(ret.getNextStepName());
                    capturePersistVars(stepRt);
                    // plan 258: 终态 saveStepState wiring —— succeed-driver 设置 COMPLETED 终态后追加 save，
                    // 使 DB snapshot 反映终态（非停留在 ACTIVE-time save 的 ACTIVE 行）。
                    saveTerminalStateIfDone(stepRt);
                    return ret;
                }
            });
        } catch (Exception e) {
            LOG.info("nop.task.step.run-fail:usedTime={},taskName={},taskInstanceId={},stepPath={},runId={},nextStepNameOnError={},loc={}",
                    CoreMetrics.currentTimeMillis() - beginTime, taskRt.getTaskName(), taskRt.getTaskInstanceId(),
                    stepRt.getStepPath(), stepRt.getRunId(), nextStepNameOnError, step.getLocation(), e);

            if (meter != null)
                metrics.endStep(meter, false);

            // plan 364 [维度02-02]：sync 出口失败驱动统一（与 async 出口共用 driveStepFailure）
            return driveStepFailure(stepRt, taskRt, parentScope, e);
        }
    }

    /**
     * plan 364 [维度02-02]：sync/async 两个出口共用的步骤失败驱动（原两份约 35 行实现已发生
     * 可观测语义漂移——async 出口的 addXplStack 位于 nextOnError 分支之后永不可达）。
     * 统一后对齐 sync 出口原语义：cancel 分支映射 EXPIRED/KILLED；非取消失败先 addXplStack
     * 再进 FAILED driver（fail → setStepStatus(FAILED) → capture → saveTerminalStateIfDone），
     * 配置 nextOnError 时返回 error-handoff 结果，否则 rethrow。
     */
    private TaskStepReturn driveStepFailure(ITaskStepRuntime stepRt, ITaskRuntime taskRt,
                                            IEvalScope parentScope, Throwable err) {
        if (TaskStepHelper.isCancelledException(err)) {
            // plan 260 设计裁定 1: step 层 EXPIRED/KILLED driver wiring（对称 plan 254 FAILED-driver）。
            // reason 来源：exception cause chain（已编码）优先，回退 step token（step seam 可靠）
            String reason = TaskStepHelper.resolveStepCancelReason(stepRt, err);
            stepRt.getState().fail(err, taskRt);
            stepRt.getState().setStepStatus(TaskStepHelper.isTimeoutReason(reason)
                    ? _NopTaskCoreConstants.TASK_STEP_STATUS_EXPIRED
                    : _NopTaskCoreConstants.TASK_STEP_STATUS_KILLED);
            saveTerminalStateIfDone(stepRt);
            throw NopException.adapt(TaskStepHelper.encodeCancelReason(err, reason));
        }

        if (err instanceof NopException)
            ((NopException) err).addXplStack(stepRt.getStepPath() + '@' + this.getLocation());

        // plan 254: 终态失败 FAILED driver wiring。fail() 仅保存 exception（plan 247 裁定），
        // setStepStatus(FAILED) 标记终态；plan 258: 终态追加 saveStepState 使 DB snapshot 反映终态。
        stepRt.getState().fail(err, taskRt);
        stepRt.getState().setStepStatus(_NopTaskCoreConstants.TASK_STEP_STATUS_FAILED);
        capturePersistVars(stepRt);
        saveTerminalStateIfDone(stepRt);

        if (nextStepNameOnError != null)
            return buildErrorResult(stepRt, parentScope, err);
        throw NopException.adapt(err);
    }

    boolean allowExecute(ITaskStepRuntime parentRt) {
        if (flagOperation != null && !flagOperation.checkMatchFlag(parentRt.getTagSet())) {
            return false;
        }
        if (when != null && !when.passConditions(parentRt))
            return false;
        return true;
    }

    /**
     * plan 258: succeed/FAILED 终态 driver 设置终态 stepStatus（COMPLETED/FAILED）后，追加 saveStepState
     * 使 DB snapshot 反映终态，而非停留在 ACTIVE-time save（{@code stepRt.saveState()} at ACTIVE 创建时）的 ACTIVE 行。
     * 条件于 {@code isDone()==true}（设计裁定 3，仅持久化终态，不持久化 ACTIVE/SUSPENDED 中间态）。
     * 幂等 upsert 同一行（设计裁定 2，{@link io.nop.task.dao.store.DaoTaskStateStore#saveStepState} 按
     * taskInstanceId + stepPath upsert）。使 DB-backed resume（cross-process / crash-restart）经 loadStepState
     * 取回终态 snapshot → reader 命中 isDone → 跳过 step body / 重抛 exception。
     */
    void saveTerminalStateIfDone(ITaskStepRuntime stepRt) {
        // saveState=false 的步骤跳过终态落盘（plan 364 [03-05]）
        if (!persistStepState())
            return;
        ITaskStepState state = stepRt.getState();
        if (state != null && state.isDone()) {
            stepRt.saveState();
        }
    }

    /**
     * persistVars 捕获（plan 349 Phase 6）：xdef 声明 persistVars 的步骤在 saveState 前
     * 捕获 scope 变量快照，与状态一并持久化，恢复时经 {@link #restorePersistVars} 回写。
     */
    private void capturePersistVars(ITaskStepRuntime stepRt) {
        Set<String> vars = step.getPersistVars();
        if (vars == null || vars.isEmpty())
            return;
        ITaskStepState state = stepRt.getState();
        if (state == null)
            return;
        Map<String, Object> captured = new LinkedHashMap<>();
        for (String var : vars) {
            captured.put(var, stepRt.getEvalScope().getLocalValue(var));
        }
        state.setPersistVarsSnapshot(captured);
    }

    private void restorePersistVars(ITaskStep step, ITaskStepState stepState, ITaskStepRuntime stepRt) {
        Set<String> vars = step.getPersistVars();
        if (vars == null || vars.isEmpty() || stepState == null)
            return;
        Map<String, Object> persisted = stepState.getPersistVarsSnapshot();
        if (persisted == null || persisted.isEmpty())
            return;
        for (String var : vars) {
            if (persisted.containsKey(var))
                stepRt.getEvalScope().setLocalValue(var, persisted.get(var));
        }
    }

    /**
     * continuation-skip 的 outputs 重放（plan 349 Phase 6）：按持久化的 outputs 映射
     * 恢复 exportAs/toTaskScope 导出变量，修复恢复后下游步骤读到 null 的问题。
     */
    private void replayPersistedOutputs(ITaskStepState stepState, ITaskStepRuntime stepRt, IEvalScope parentScope) {
        Map<String, Object> persisted = stepState.getOutputs();
        if (persisted == null || persisted.isEmpty() || outputConfigs.isEmpty())
            return;
        for (OutputConfig config : outputConfigs) {
            if (!persisted.containsKey(config.getName()))
                continue;
            Object value = persisted.get(config.getName());
            if (config.isToTaskScope())
                stepRt.getTaskRuntime().getEvalScope().setLocalValue(config.getExportName(), value);
            else
                parentScope.setLocalValue(config.getExportName(), value);
        }
    }

    TaskStepReturn buildErrorResult(ITaskStepRuntime stepRt, IEvalScope parentScope, Throwable e) {
        ErrorBean errorBean = ErrorMessageManager.instance().buildErrorMessage(stepRt.getLocale(), e, false, false);
        Map<String, Object> data = Collections.singletonMap(TaskConstants.VAR_ERROR, errorBean);
        parentScope.setLocalValue(errorName, errorBean);
        return TaskStepReturn.of(nextStepNameOnError, data);
    }

    private void initInputs(ITaskStepRuntime stepRt, IEvalScope parentScope, ITaskRuntime taskRt) {
        inputConfigs.forEach(inputConfig -> {
            String name = inputConfig.getName();
            IEvalScope scope = inputConfig.isFromTaskScope() ? taskRt.getEvalScope() : parentScope;
            IEvalAction expr = inputConfig.getExpr();
            Object value = expr == null ? parentScope.getValue(name) : expr.invoke(scope);
            if (inputConfig.isMandatory() && StringHelper.isEmptyObject(value))
                throw new NopException(ERR_TASK_MANDATORY_INPUT_NOT_ALLOW_EMPTY)
                        .param(ARG_STEP_PATH, stepRt.getStepPath())
                        .param(ARG_INPUT_NAME, name);
            stepRt.setValue(name, value);

            if (inputConfig.isDump()) {
                Object dumpValue = TaskStepHelper.getDumpValue(value);
                LOG.info("nop.task.step-input:step={},name={},value={}", getStepName(), name, dumpValue);
            }
        });
    }

    private void initOutputs(TaskStepReturn result, ITaskStepRuntime stepRt, IEvalScope parentScope) {
        outputConfigs.forEach(config -> {
            String exportName = config.getExportName();
            Object value = result.getOutput(config.getName());
            if (config.isToTaskScope()) {
                stepRt.getTaskRuntime().getEvalScope().setLocalValue(exportName, value);
            } else {
                parentScope.setLocalValue(exportName, value);
            }

            if (config.isDump()) {
                Object dumpValue = TaskStepHelper.getDumpValue(value);
                LOG.info("nop.task.step-output:name={},value={}", exportName, dumpValue);
            }
        });
    }
}
