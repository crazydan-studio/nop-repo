package io.nop.task.impl;

import io.nop.api.core.context.ContextProvider;
import io.nop.api.core.context.IContext;
import io.nop.api.core.util.Guard;
import io.nop.commons.concurrent.semaphore.ISemaphore;
import io.nop.commons.concurrent.executor.IScheduledExecutor;
import io.nop.commons.concurrent.executor.IThreadPoolExecutor;
import io.nop.commons.concurrent.ratelimit.IRateLimiter;
import io.nop.commons.lang.impl.Cancellable;
import io.nop.commons.util.CollectionHelper;
import io.nop.core.CoreConstants;
import io.nop.core.context.IServiceContext;
import io.nop.core.lang.eval.IEvalScope;
import io.nop.task.ITask;
import io.nop.task.ITaskFlowManager;
import io.nop.task.ITaskRuntime;
import io.nop.task.ITaskState;
import io.nop.task.ITaskStateStore;
import io.nop.task.ITaskStepRuntime;
import io.nop.task.ITaskStepState;
import io.nop.task.TaskConstants;
import io.nop.task.metrics.EmptyTaskFlowMetrics;
import io.nop.task.metrics.ITaskFlowMetrics;
import io.nop.xlang.api.XLang;
import jakarta.annotation.Nonnull;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;

public class TaskRuntimeImpl extends Cancellable implements ITaskRuntime {
    private final Map<String, Object> attrs = new ConcurrentHashMap<>();

    private final ITaskFlowManagerImplementor taskManager;

    private final ITaskStateStore stateStore;

    private final IServiceContext svcCtx;

    private final IContext context;

    private final IEvalScope scope;

    private final boolean recoverMode;

    private Set<String> enabledFlags = Collections.emptySet();

    private ITaskState taskState;

    private ITaskFlowMetrics metrics = EmptyTaskFlowMetrics.INSTANCE;

    private final Cancellable cleanups = new Cancellable();

    private final Consumer<String> onCancel = this::cancel;

    public TaskRuntimeImpl(ITaskFlowManagerImplementor taskManager,
                           ITaskStateStore stateStore,
                           IServiceContext svcCtx, IEvalScope scope, boolean recoverMode) {
        this.taskManager = taskManager;
        this.stateStore = stateStore;
        this.svcCtx = svcCtx;
        this.recoverMode = recoverMode;
        if (scope == null) {
            scope = svcCtx != null ? svcCtx.getEvalScope().newChildScope(true, true)
                    : XLang.newEvalScope(CollectionHelper.newConcurrentMap(4));
        } else {
            scope = scope.newChildScope(true, true);
        }
        // taskRt可能会被多线程访问，所以这里scope线程安全
        this.scope = scope;
        this.scope.setLocalValue(CoreConstants.VAR_SVC_CTX, svcCtx);
        this.scope.setLocalValue(TaskConstants.VAR_TASK_RT, this);
        this.context = svcCtx == null ? ContextProvider.getOrCreateContext() : svcCtx.getContext();

        if (svcCtx != null) {
            svcCtx.appendOnCancel(onCancel);
        }
    }

    @Override
    public void cancel(String reason) {
        super.cancel(reason);
        if (svcCtx != null)
            svcCtx.cancel(reason);

        // plan 364 [维度05-03]：SUSPENDED（挂起、无驱动在飞）的任务被 cancel 时，
        // 此前仅设置 cancel token 即返回——KILLED 转移要等到任意久之后的 resume 才发生，
        // 运维 kill 挂起任务后状态面板失真。此处直接驱动 KILLED 终态并落盘。
        // ACTIVE 任务的取消仍走既有路径（执行中的步骤经 cancel token 由 step driver 收敛）。
        ITaskState state = getTaskState();
        if (state == null)
            return;
        synchronized (state) {
            Integer status = state.getTaskStatus();
            if (status != null && status == TaskConstants.TASK_STATUS_SUSPENDED && !state.isTerminal()) {
                state.exception(new io.nop.api.core.exceptions.NopException(
                        io.nop.task.TaskErrors.ERR_TASK_CANCELLED));
                state.setTaskStatus(TaskConstants.TASK_STATUS_KILLED);
                saveTaskState();
            }
        }
    }

    public boolean isRecoverMode() {
        return recoverMode;
    }

    @Override
    public IEvalScope getEvalScope() {
        return scope;
    }

    @Override
    public IServiceContext getSvcCtx() {
        return svcCtx;
    }

    @Override
    public IContext getContext() {
        return context;
    }

    @Override
    public ITaskState getTaskState() {
        return taskState;
    }

    public void setTaskState(ITaskState taskState) {
        this.taskState = Guard.notNull(taskState, "taskState");
    }

    @Override
    public ITaskFlowMetrics getMetrics() {
        return metrics;
    }

    public void setMetrics(ITaskFlowMetrics metrics) {
        this.metrics = Guard.notNull(metrics, "metrics");
    }

    @Override
    public ITaskFlowManager getTaskManager() {
        return taskManager;
    }

    @Nonnull
    @Override
    public Set<String> getTagSet() {
        return enabledFlags;
    }

    @Override
    public void setTagSet(Set<String> enabledFlags) {
        this.enabledFlags = enabledFlags == null ? Collections.emptySet() : enabledFlags;
    }

    @Override
    public int newRunId() {
        return taskState.newRunId();
    }

    @Override
    public ITaskRuntime newChildRuntime(ITask task, boolean saveState) {
        ITaskRuntime taskRt = taskManager.newTaskRuntime(task, saveState, getSvcCtx());
        // 父取消必须传播到子 runtime（plan 349 Phase 5，修复 check2 P2 自引用）：
        // 原 this::cancel 注册到自身监听器（重入直接返回，无效果），svcCtx=null 时
        // 子任务在父取消后失控继续运行。对照 ITask.asExecution 的正确模式
        Consumer<String> onCancel = taskRt::cancel;
        this.appendOnCancel(onCancel);
        taskRt.addTaskCleanup(() -> removeOnCancel(onCancel));
        return taskRt;
    }

    @Override
    public Object getAttribute(String name) {
        return attrs.get(name);
    }

    @Override
    public void setAttribute(String name, Object value) {
        if (value == null) {
            attrs.remove(name);
        } else {
            attrs.put(name, value);
        }
    }

    @Override
    public void removeAttribute(String name) {
        attrs.remove(name);
    }

    @Override
    public Set<String> getAttributeKeys() {
        return attrs.keySet();
    }

    @Override
    public Object computeAttributeIfAbsent(String name, Function<String, Object> action) {
        return attrs.computeIfAbsent(name, action);
    }

    @Override
    public IScheduledExecutor getScheduledExecutor() {
        return taskManager.getScheduledExecutor();
    }

    @Override
    public IThreadPoolExecutor getThreadPoolExecutor(String executorBean) {
        return taskManager.getThreadPoolExecutor(getEvalScope().getBeanProvider(), executorBean);
    }

    @Override
    public ITaskStepRuntime newMainStepRuntime() {
        // plan 263: resume 路径（recoverMode=true）优先加载持久化 mainStep 状态（stepPath=`@main`）。
        // composite mainStep（Sequential/Selector/Loop/LoopN/Graph）执行中经 stepRt.saveState() 把自身 bodyStepIndex
        // （flow 位置）持久化到 DB；命中则用之使 mainStep 从已持久化的中间位置续跑（前置已完成子步骤不被重复执行）。
        // 未命中（fresh execute / in-memory store / 无持久化行 / 终态 task 已被 TaskImpl.execute:98 短路）回退
        // newMainStepState（fresh ACTIVE，零回归）。fresh execute（recoverMode=false）恒走 newMainStepState（门控与
        // TaskImpl.execute:98 终态短路条件 isRecoverMode() 对称）。
        ITaskStepState state = null;
        if (recoverMode) {
            state = stateStore.loadMainStepState(this.getTaskState(), this);
        }
        if (state == null) {
            state = stateStore.newMainStepState(this.getTaskState());
        }
        // 使用taskRt的scope
        TaskStepRuntimeImpl stepRt = new TaskStepRuntimeImpl(this, stateStore, getEvalScope());
        stepRt.setCancelToken(getSvcCtx());
        stepRt.setState(state);
        stepRt.setRecoverMode(recoverMode);
        return stepRt;
    }

    @Override
    public void saveTaskState() {
        stateStore.saveTaskState(this);
    }

    @Override
    public IRateLimiter getRateLimiter(String key, double requestsPerSecond, boolean global) {
        return taskManager.getRateLimiter(this, key, requestsPerSecond, global);
    }

    @Override
    public ISemaphore getSemaphore(String key, int maxPermits, boolean global) {
        return taskManager.getSemaphore(this, key, maxPermits, global);
    }

    @Override
    public String getTaskDescription() {
        return getTaskState().getDescription();
    }

    @Override
    public void setTaskDescription(String description) {
        getTaskState().setDescription(description);
    }

    @Override
    public void addTaskCleanup(Runnable cleanup) {
        cleanups.appendOnCancelTask(cleanup);
    }

    @Override
    public void runCleanup() {
        if (svcCtx != null)
            svcCtx.removeOnCancel(onCancel);
        cleanups.cancel(TaskConstants.REASON_TASK_COMPLETE);
    }
}