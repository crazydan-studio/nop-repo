/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.api.core.beans;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.nop.api.core.ApiConstants;
import io.nop.api.core.annotations.data.DataBean;
import io.nop.api.core.exceptions.NopRebuildException;
import io.nop.api.core.util.ApiHeaders;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 当成功返回时，status=0，一般仅data设置值
 * 当调用失败，需要返回异常时，status不为0，code和msg不为空。code为错误码，而msg为错误消息。
 * 返回消息结果与前台amis框架要求的基本保持一致
 */
@DataBean
public final class ApiResponse<T> extends ApiMessage {
    private static final long serialVersionUID = 7169855012236177821L;
    /**
     * httpStatus仅在后台创建http响应包时使用，它的信息不返回到前台
     */
    private int httpStatus;

    private int status;
    private String code;
    private String msg;
    private Integer msgTimeout;
    private Boolean bizFatal;

    private Map<String, String> errors;

    private T data;

    /**
     * maker checker对应的tryMethod的返回结果
     */
    private Object tryResponse;

    /**
     * 标记response的data才是实际返回的数据，ApiResponse完全是为了满足接口要求创造的一个包装对象
     */
    private boolean wrapper;

    @Deprecated
    public static <T> ApiResponse<T> buildSuccess(T data) {
        return success(data);
    }

    public static <T> ApiResponse<T> success(T data) {
        ApiResponse<T> ret = new ApiResponse<>();
        ret.setStatus(ApiConstants.API_STATUS_OK);
        ret.setData(data);
        return ret;
    }

    @Deprecated
    public static <T> ApiResponse<T> buildError(ErrorBean error) {
        return error(error);
    }

    public static <T> ApiResponse<T> error(ErrorBean error) {
        ApiResponse<T> ret = new ApiResponse<>();
        ret.setStatus(ApiConstants.API_STATUS_FAIL);
        ret.setError(error);
        return ret;
    }

    public static ApiResponse<?> wrap(Object data) {
        if (data instanceof ApiResponse)
            return (ApiResponse<?>) data;
        return success(data);
    }

    public T get() {
        if (isOk()) {
            return getData();
        }
        throw NopRebuildException.rebuild(this);
    }

    @JsonIgnore
    public boolean isHttp2XX() {
        return this.httpStatus >= 200 && this.httpStatus < 300;
    }

    @JsonIgnore
    public boolean isHttp3XX() {
        return this.httpStatus >= 300 && this.httpStatus < 400;
    }

    @JsonIgnore
    public boolean isHttp4XX() {
        return this.httpStatus >= 400 && this.httpStatus < 500;
    }

    @JsonIgnore
    public boolean isHttp5XX() {
        return this.httpStatus >= 500 && this.httpStatus < 600;
    }

    @Override
    public ApiResponse<T> cloneInstance() {
        return cloneInstance(true);
    }

    @Override
    public ApiResponse<T> cloneInstance(boolean includeHeaders) {
        ApiResponse<T> ret = new ApiResponse<>();
        if (hasHeaders()) {
            Map<String, Object> headers = getHeaders();
            if (headers != null) {
                headers = new TreeMap<>(headers);
            }
            ret.setHeaders(headers);
        }
        ret.setHttpStatus(httpStatus);
        ret.setStatus(status);
        ret.setCode(code);
        ret.setMsg(msg);
        ret.setMsgTimeout(msgTimeout);
        ret.setErrors(errors);
        ret.setData(data);
        ret.setWrapper(wrapper);
        // 克隆体常被作为对外序列化对象，bizFatal/tryResponse不能丢失
        ret.setBizFatal(bizFatal);
        ret.setTryResponse(tryResponse);
        return ret;
    }

    public ApiResponse<T> withHeader(String name, Object value) {
        setHeader(name, value);
        return this;
    }

    @JsonInclude(Include.NON_DEFAULT)
    public int getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(int httpStatus) {
        this.httpStatus = httpStatus;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @JsonIgnore
    public boolean isOk() {
        return status == 0;
    }

    @JsonIgnore
    public boolean isBizSuccess() {
        return isOk() && !ApiHeaders.isBizFail(this);
    }

    @JsonInclude(Include.NON_NULL)
    public Boolean getBizFatal() {
        return bizFatal;
    }

    public void setError(ErrorBean error) {
        if (error != null) {
            this.setStatus(error.getStatus());
            this.code = error.getErrorCode();
            this.msg = error.getDescription();
            this.bizFatal = error.isBizFatal();
            if (error.getDetails() != null) {
                this.errors = new LinkedHashMap<>();
                for (Map.Entry<String, ErrorBean> entry : error.getDetails().entrySet()) {
                    this.errors.put(entry.getKey(), entry.getValue().getDescription());
                }
            }
        } else {
            this.code = null;
            this.bizFatal = false;
            this.msg = null;
            this.errors = null;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @JsonInclude(Include.NON_EMPTY)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @JsonInclude(Include.NON_EMPTY)
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @JsonInclude(Include.NON_NULL)
    public Integer getMsgTimeout() {
        return msgTimeout;
    }

    public void setMsgTimeout(Integer msgTimeout) {
        this.msgTimeout = msgTimeout;
    }

    public void setBizFatal(Boolean bizFatal) {
        this.bizFatal = bizFatal;
    }

    @JsonInclude(Include.NON_EMPTY)
    public Map<String, String> getErrors() {
        return errors;
    }

    public void setErrors(Map<String, String> errors) {
        this.errors = errors;
    }

    @JsonInclude(Include.NON_NULL)
    public Object getTryResponse() {
        return tryResponse;
    }

    public void setTryResponse(Object tryResponse) {
        this.tryResponse = tryResponse;
    }

    @JsonIgnore
    public boolean isWrapper() {
        return wrapper;
    }

    public void setWrapper(boolean wrapper) {
        this.wrapper = wrapper;
    }

    // ApiMessage 默认 toString() 只输出对象 hash，失败时调用方拼 "..." + response 只能看到
    // ApiResponse@hash，真正的 msg/code/errors 完全不可见，调试/日志排查极困难。这里暴露核心字段。

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ApiResponse[status=").append(status);
        if (httpStatus != 0) {
            sb.append(",httpStatus=").append(httpStatus);
        }
        if (code != null) {
            sb.append(",code=").append(code);
        }
        if (msg != null) {
            sb.append(",msg=").append(msg);
        }
        if (errors != null) {
            sb.append(",errors=").append(errors);
        }
        if (data != null) {
            // data 可能是整棵订单树/大列表，截断避免日志爆炸。需查看完整内容请用 JsonTool.stringify
            sb.append(",data=").append(truncate(data, 200));
        }
        appendHeaders(sb);
        sb.append("]");
        return sb.toString();
    }
}