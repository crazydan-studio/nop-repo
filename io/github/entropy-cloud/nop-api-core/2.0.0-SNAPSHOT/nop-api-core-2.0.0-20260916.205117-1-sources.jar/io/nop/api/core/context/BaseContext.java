/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.api.core.context;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.FutureHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

import static io.nop.api.core.ApiErrors.ARG_SEQ;
import static io.nop.api.core.ApiErrors.ERR_CONTEXT_ALREADY_CLOSED;

public class BaseContext implements IContext {
    static final AtomicLong s_seq = new AtomicLong();

    static final Logger LOG = LoggerFactory.getLogger(BaseContext.class);

    private final long seq = s_seq.incrementAndGet();

    private String traceId;
    private String tenantId;
    private String userId;
    private String userName;
    private String locale;
    private String timezone;
    private long expireTime;
    private String userRefNo;
    private String callIp;
    private String dynAppId;
    private String callOperationName;
    private Map<String, Object> propagateHeaders;
    private final Map<String, Object> attributes = new ConcurrentHashMap<>();

    protected final ContextTaskQueue taskQueue = new ContextTaskQueue();

    protected volatile boolean closed;

    private final String threadName;

    public BaseContext() {
        LOG.trace("nop.context-new:seq={}", seq);
        this.threadName = Thread.currentThread().getName();
    }

    public String getCreateThreadName() {
        return threadName;
    }

    public long getSeq() {
        return seq;
    }

    @Override
    public String getUserRefNo() {
        if (userRefNo == null)
            return getUserName();
        return userRefNo;
    }

    public void setUserRefNo(String userRefNo) {
        checkClosed();
        this.userRefNo = userRefNo;
    }

    @Override
    public String getCallIp() {
        return callIp;
    }

    @Override
    public void setCallIp(String callIp) {
        this.callIp = callIp;
    }

    @Override
    public String getTenantId() {
        return tenantId;
    }

    @Override
    public void setTenantId(String tenantId) {
        checkClosed();
        this.tenantId = tenantId;
    }

    @Override
    public String getUserName() {
        return userName;
    }

    @Override
    public void setUserName(String userName) {
        checkClosed();
        this.userName = userName;
    }

    @Override
    public String getUserId() {
        return userId;
    }

    @Override
    public void setUserId(String userId) {
        checkClosed();
        this.userId = userId;
    }

    @Override
    public String getLocale() {
        return locale;
    }

    @Override
    public void setLocale(String locale) {
        checkClosed();
        this.locale = locale;
    }

    @Override
    public String getCallOperationName() {
        return callOperationName;
    }

    @Override
    public void setCallOperationName(String callOperationName) {
        checkClosed();
        this.callOperationName = callOperationName;
    }

    @Override
    public Map<String, Object> getPropagateRpcHeaders() {
        return propagateHeaders;
    }

    public void setPropagateRpcHeaders(Map<String, Object> propagateHeaders) {
        checkClosed();
        this.propagateHeaders = propagateHeaders;
    }

    @Override
    public String getTimezone() {
        return timezone;
    }

    @Override
    public void setTimezone(String timezone) {
        checkClosed();
        this.timezone = timezone;
    }

    @Override
    public long getCallExpireTime() {
        return expireTime;
    }

    @Override
    public void setCallExpireTime(long expireTime) {
        checkClosed();
        this.expireTime = expireTime;
    }

    @Override
    public String getDynAppId() {
        return dynAppId;
    }

    @Override
    public void setDynAppId(String dynAppId) {
        this.dynAppId = dynAppId;
    }

    protected ContextTaskQueue getTaskQueue() {
        return taskQueue;
    }

    @JsonAnyGetter
    public Map<String, Object> getAttrs() {
        return attributes;
    }

    @Override
    public Object getAttribute(String name) {
        return attributes.get(name);
    }

    @Override
    public void setAttribute(String name, Object value) {
        checkClosed();
        if (value == null) {
            attributes.remove(name);
        } else {
            attributes.put(name, value);
        }
    }

    @Override
    public void removeAttribute(String name) {
        checkClosed();
        attributes.remove(name);
    }

    @Override
    public boolean removeAttribute(String name, Object value) {
        checkClosed();
        return attributes.remove(name, value);
    }

    @Override
    public Object getInternalContext() {
        return null;
    }

    @Override
    public void runOnContext(Runnable task) {
        checkClosed();
        if (!taskQueue.enqueue(task)) {
            IContext oldCtx = BaseContextProvider.contextHolder().get();
            try {
                BaseContextProvider.contextHolder().set(this);
                LOG.trace("nop.run-on-context-enter:seq={},createThread={}", seq, threadName);
                taskQueue.flush();
            } finally {
                LOG.trace("nop.run-on-context-leave:seq={},createThread={}", seq, threadName);
                if (oldCtx != null) {
                    BaseContextProvider.contextHolder().set(oldCtx);
                } else {
                    BaseContextProvider.contextHolder().remove();
                }
            }
        }
    }

    @Override
    public <T> T executeWithContext(Callable<T> task) throws Exception {
        checkClosed();
        IContext oldCtx = BaseContextProvider.contextHolder().get();
        if (oldCtx == this)
            return task.call();

        if (taskQueue.isProcessing()) {
            LOG.warn("nop.warn.context.concurrent-execute-with-same-context:seq={}", seq);
        }

        try {
            LOG.trace("nop.context-enter:seq={},createThread={}", seq, threadName);
            BaseContextProvider.contextHolder().set(this);
            return task.call();
        } finally {
            LOG.trace("nop.context-leave:seq={},createThread={}", seq, threadName);
            if (oldCtx != null) {
                BaseContextProvider.contextHolder().set(oldCtx);
            } else {
                BaseContextProvider.contextHolder().remove();
            }
        }
    }

    @Override
    public void execute(Runnable task) {
        checkClosed();
        if (isRunningOnContext()) {
            task.run();
            return;
        }
        runOnContext(task);
    }

    @Override
    public boolean isRunningOnContext() {
        IContext context = ContextProvider.currentContext();
        if (context == null)
            return false;
        return context.getSourceContext() == this;
    }

    @Override
    public IContext getSourceContext() {
        return this;
    }

    /**
     * BaseContext是降级实现：不提供worker线程池，任务经runOnContext投递到context任务队列，
     * 无其他处理线程时在当前调用线程上同步执行，ordered参数当前被忽略（不会选择worker线程）。
     * 需要真正的阻塞线程池语义时由具体运行时(如vert.x)提供的IContext实现覆盖。
     */
    @Override
    public <T> CompletionStage<T> executeBlocking(Supplier<?> task, boolean ordered) {
        checkClosed();
        CompletableFuture<T> future = new CompletableFuture<>();
        runOnContext(() -> {
            FutureHelper.completeAfterTask(future, () -> task.get());
        });
        return future;
    }

    @Override
    public <T> T syncGet(CompletionStage<T> future) {
        return taskQueue.syncGet(future);
    }

    public void close() {
        if (this.closed)
            return;

        LOG.trace("nop.context-close:seq={},createThread={}", seq, threadName);

        IContext context = BaseContextProvider.contextHolder().get();
        if (context == this) {
            BaseContextProvider.clear();
        }
        this.closed = true;
        this.attributes.clear();
    }

    @Override
    public String getTraceId() {
        return traceId;
    }

    @Override
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    protected void checkClosed() {
        if (closed)
            throw new NopException(ERR_CONTEXT_ALREADY_CLOSED)
                    .param(ARG_SEQ, seq);
    }
}
