/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.api.core.beans;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.nop.api.core.annotations.data.DataBean;
import io.nop.api.core.convert.ConvertHelper;
import io.nop.api.core.exceptions.NopException;
import io.nop.api.core.util.ApiStringHelper;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@DataBean
public final class ApiRequest<T> extends ApiMessage {
    private static final long serialVersionUID = -2652499046301680161L;

    /**
     * GraphQL所支持的返回结果过滤能力
     */
    private FieldSelectionBean selection;
    private T data;

    private Map<String, Object> properties;

    public static <T> ApiRequest<T> build(T data) {
        ApiRequest<T> request = new ApiRequest<>();
        request.setData(data);
        return request;
    }

    public ApiRequest<T> withHeaders(Map<String, Object> headers) {
        this.addHeaders(headers);
        return this;
    }

    public ApiRequest<T> withSelection(FieldSelectionBean selection) {
        this.setSelection(selection);
        return this;
    }

    public ApiRequest<T> withHeader(String name, Object value) {
        setHeader(name, value);
        return this;
    }

    @JsonIgnore
    public Map<String, Object> getProperties() {
        return properties;
    }

    public Object getProperty(String name) {
        if (properties == null)
            return null;
        return properties.get(name);
    }

    public String getStringProperty(String name) {
        return ConvertHelper.toString(getProperty(name));
    }

    public int getIntProperty(String name, int defaultValue) {
        return ConvertHelper.toPrimitiveInt(getProperty(name), defaultValue, NopException::new);
    }

    public Integer getIntProperty(String name) {
        return ConvertHelper.toInt(getProperty(name));
    }

    public Boolean getBooleanProperty(String name) {
        return ConvertHelper.toBoolean(getProperty(name));
    }

    public void setProperty(String name, Object value) {
        if (ApiStringHelper.isEmptyObject(value)) {
            removeProperty(name);
        } else {
            if (properties == null)
                properties = new HashMap<>();
            properties.put(name, value);
        }
    }

    public void removeProperty(String name) {
        if (properties != null)
            properties.remove(name);
    }

    public void clearProperties() {
        this.properties = null;
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public FieldSelectionBean getSelection() {
        return selection;
    }

    public void setSelection(FieldSelectionBean selection) {
        this.selection = selection;
    }

    public boolean hasSelection() {
        return selection != null && selection.hasField();
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public ApiRequest<T> cloneInstance() {
        return cloneInstance(true);
    }

    @Override
    public ApiRequest<T> cloneInstance(boolean includeHeaders) {
        ApiRequest<T> ret = new ApiRequest<>();
        if (includeHeaders && hasHeaders()) {
            Map<String, Object> headers = getHeaders();
            if (headers != null) {
                ret.setHeaders(new TreeMap<>(headers));
            }
        }
        ret.setSelection(selection);
        ret.setData(data);
        if (this.properties != null)
            this.properties = new HashMap<>(this.properties);
        return ret;
    }

    // ApiMessage 默认 toString() 只输出对象 hash，调用方拼 "..." + request 时看不到 data/属性/headers。
    // 这里暴露核心字段，便于调试与日志排查。

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ApiRequest[");
        if (data != null) {
            // data 可能是整棵请求体，截断避免日志爆炸。需查看完整内容请用 JsonTool.stringify
            sb.append("data=").append(truncate(data, 200));
        }
        if (selection != null) {
            if (sb.length() > "ApiRequest[".length())
                sb.append(",");
            sb.append("selection=").append(selection);
        }
        if (properties != null) {
            if (sb.length() > "ApiRequest[".length())
                sb.append(",");
            sb.append("properties=").append(properties);
        }
        appendHeaders(sb);
        sb.append("]");
        return sb.toString();
    }
}