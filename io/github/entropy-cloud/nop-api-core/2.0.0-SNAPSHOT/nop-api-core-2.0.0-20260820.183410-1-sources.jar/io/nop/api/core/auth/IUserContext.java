/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.api.core.auth;

import io.nop.api.core.context.ContextProvider;
import io.nop.api.core.util.IDirtyFlagSupport;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 * 用户登录后的上下文对象，存放在全局缓存中
 */
public interface IUserContext extends IDirtyFlagSupport {
    static IUserContext get() {
        return (IUserContext) ContextProvider.getContextAttr("userContext");
    }

    static void set(IUserContext context) {
        ContextProvider.setContextAttr("userContext", context);
    }

    /**
     * 用户当前sessionId
     */
    String getSessionId();

    /**
     * 用户所属租户id
     */
    String getTenantId();

    /**
     * 用户当前选择的语言设置
     */
    String getLocale();

    String getTimeZone();

    /**
     * 用户唯一标识
     */
    String getUserId();

    /**
     * 用户所属部门id
     */
    String getDeptId();

    String getDeptName();

    /**
     * 登录用户名
     */
    String getUserName();

    String getOpenId();

    /**
     * 用户昵称，显示在界面上的用户姓名
     */
    String getNickName();

    /**
     * 用户选择的当前主角色，根据角色设置可能会限制系统具有不同的功能
     */
    String getPrimaryRole();

    boolean isUserInRole(String roleId);

    boolean isUserInAnyRole(Collection<String> roleIds);

    Set<String> getRoles();

    void addRole(String roleId);

    void removeRole(String roleId);

    String getAccessToken();

    String getRefreshToken();

    void setAccessToken(String accessToken);

    void setRefreshToken(String refreshToken);

    /**
     * MFA 受限会话标志（角色级强制策略不达标时签发，设计 §4.3，W13-impl）：
     * true = 第一因子已通过但用户因子持有不满足角色策略（minMfaLevel），会话仅放行
     * MFA 绑定引导类白名单操作 + 全部 query（受限拦截分支见操作级 MFA 拦截器）。
     * <p>
     * Java {@code default} 方法（migration note）：仓库外/测试树存在多个 {@link IUserContext}
     * 外部实现类（匿名/内部类），抽象方法会编译破坏下游；缺省 false 保证老实现与老消费方
     * 零感知。{@code UserContextImpl} 覆写并提供 setter（持久化两触点白名单同步：
     * {@code UserContextImpl.serializeToJson} 与
     * {@code DaoUserContextCache.saveUserContextAsync}）。
     */
    default boolean isMfaRestricted() {
        return false;
    }

    long getLastAccessTime();

    void setLastAccessTime(long lastAccessTime);

    /**
     * 附加属性
     */
    Map<String, Object> getAttrs();

    Object getAttr(String name);

    void setAttr(String name, Object value);

    /**
     * 是否已被修改需要被保存
     */
    boolean dirty();
}