package io.nop.ai.shell.io;

import io.nop.ai.shell.NopAiShellErrors;
import io.nop.api.core.exceptions.NopException;

import java.io.PrintStream;

public class PrintStreamShellOutput implements IShellOutput {

    private final PrintStream printStream;
    private volatile boolean closed = false;

    public PrintStreamShellOutput(PrintStream printStream) {
        this.printStream = printStream;
    }

    @Override
    public void write(ShellChunk chunk) {
        if (closed) throw new IllegalStateException("output closed");
        if (chunk.isText()) {
            printStream.print(chunk.asText());
        } else if (chunk.isBinary()) {
            printStream.write(((ShellChunk.BinaryChunk) chunk).getData(), 0, ((ShellChunk.BinaryChunk) chunk).getData().length);
        }
    }

    @Override
    public void flush() {
        printStream.flush();
    }

    @Override
    public void close() {
        if (!closed) {
            closed = true;
            printStream.close();
        }
    }

    @Override
    public IShellInput asInput() {
        throw new NopException(NopAiShellErrors.ERR_AI_SHELL_OUTPUT_NOT_INPUT);
    }

    protected PrintStream getPrintStream() {
        return printStream;
    }
}
