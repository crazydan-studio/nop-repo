/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.orm.loader;

import io.nop.api.core.beans.LongRangeBean;
import io.nop.api.core.util.ICancelToken;
import io.nop.core.lang.sql.SQL;
import io.nop.dao.jdbc.IJdbcTemplate;
import io.nop.dataset.IComplexDataSet;
import io.nop.dataset.IDataRow;
import io.nop.dataset.IDataSet;
import io.nop.dataset.impl.BaseDataRow;
import io.nop.dataset.impl.SingleColumnRow;
import io.nop.dataset.impl.TransformedComplexDataSet;
import io.nop.dataset.impl.TransformedDataSet;
import io.nop.orm.IOrmDaoListener;
import io.nop.orm.IOrmSession;
import io.nop.orm.eql.ICompiledSql;
import io.nop.orm.eql.ast.SqlStatementKind;
import io.nop.orm.eql.meta.ISqlExprMeta;
import io.nop.orm.model.IEntityModel;
import io.nop.orm.persister.IPersistEnv;
import io.nop.orm.session.IOrmSessionImplementor;
import io.nop.orm.sql.GenSqlTransformer;
import jakarta.annotation.Nonnull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.Function;

import static io.nop.orm.persister.OrmAssembly.readRow;

/**
 * @author canonical_entropy@163.com
 */
public class JdbcQueryExecutor implements IQueryExecutor {
    static final Logger LOG = LoggerFactory.getLogger(JdbcQueryExecutor.class);

    private final IPersistEnv env;

    /**
     * plan 2321：分片执行引擎（fanout 资格判定在 transform 之前，三入口共用）
     */
    private final ShardFanoutEngine fanoutEngine;

    public JdbcQueryExecutor(IPersistEnv env) {
        this.env = env;
        this.fanoutEngine = new ShardFanoutEngine(this);
    }

    /**
     * plan 2321：引擎访问宿主环境的包内通道
     */
    IPersistEnv env() {
        return env;
    }

    IJdbcTemplate jdbc() {
        return env.jdbc();
    }

    @Override
    public long executeUpdate(@Nonnull IOrmSessionImplementor session, @Nonnull SQL eql) {
        ICompiledSql compiled = env.compileSql(eql.getName(), eql.getText(), eql.isDisableLogicalDelete(),
                eql.isAllowUnderscoreName(), eql.isEnableFilter());
        return executeUpdateSql(session, compiled, eql.getMarkerValues());
    }

    @Override
    public long executeUpdateSql(@Nonnull IOrmSessionImplementor session, @Nonnull ICompiledSql compiled,
                                 @Nonnull List<Object> markerValues) {
        invokeListener(compiled);

        List<Object> params = compiled.buildParams(markerValues);
        // plan 2321：fanout 判定在 transform 之前——非查询入口命中 fanout 形态一律显式失败
        fanoutEngine.assertNotFanout(compiled, params);

        SQL sql = transformEQL(session, compiled, params);
        return jdbc().executeUpdate(sql);
    }

    @Override
    public <T> T executeQuery(@Nonnull IOrmSessionImplementor session, @Nonnull SQL eql, LongRangeBean range,
                              @Nonnull Function<? super IDataSet, T> callback) {
        if (LOG.isDebugEnabled())
            eql.dump("session.executeQuery");
        ICompiledSql compiled = env.compileSql(eql.getName(), eql.getText(), eql.isDisableLogicalDelete(),
                eql.isAllowUnderscoreName(), eql.isEnableFilter());
        return executeQuerySql(session, compiled, eql.getMarkerValues(), range, callback);
    }

    @Override
    public <T> T executeQuerySql(@Nonnull IOrmSessionImplementor session, @Nonnull ICompiledSql compiled,
                                 @Nonnull List<Object> markerValues,
                                 LongRangeBean range,
                                 @Nonnull Function<? super IDataSet, T> callback) {
        invokeListener(compiled);

        List<Object> params = compiled.buildParams(markerValues);
        // plan 2321：fanout 接管（判定发生在 transform 之前，设计 §3.2）——命中 fanout 资格的
        // SELECT 按分片全集串行执行 N 份物理 SQL 并归并；非 fanout 查询走既有路径零变更
        FanoutQueryPlan fanoutPlan = fanoutEngine.planQuery(compiled, params);
        if (fanoutPlan != null) {
            return fanoutEngine.executeQuery(session, compiled, fanoutPlan, params, range, callback);
        }

        SQL sql = transformEQL(session, compiled, params);
        // 读写分离（plan 2319）：SELECT语句携带只读意图，无事务时由ReadWriteRoutingDataSource路由到从库。
        // 只传播意图，不参与路由决策。写语句/DDL等保持缺省（fail-safe主库）。
        if (compiled.getStatementKind() == SqlStatementKind.SELECT) {
            sql = SQL.begin(sql).readOnly(true).end();
        }

        return jdbc().executeQuery(sql, range, ds -> {
            ds = new TransformedDataSet(ds, compiled.getDataSetMeta(), rs -> transformRow(rs, compiled, session));
            return callback.apply(ds);
        });
    }

    @Override
    public <T> T executeStatement(@Nonnull IOrmSessionImplementor session, @Nonnull SQL eql, LongRangeBean range,
                                  @Nonnull Function<IComplexDataSet, T> callback, ICancelToken cancelToken) {
        if (LOG.isDebugEnabled())
            eql.dump("session.executeStatement");
        ICompiledSql compiled = env.compileSql(eql.getName(), eql.getText(), eql.isDisableLogicalDelete(),
                eql.isAllowUnderscoreName(), eql.isEnableFilter());
        return executeStatementSql(session, compiled, eql.getMarkerValues(), range, callback, cancelToken);
    }

    @Override
    public <T> T executeStatementSql(@Nonnull IOrmSessionImplementor session, @Nonnull ICompiledSql compiled,
                                     @Nonnull List<Object> markerValues, LongRangeBean range,
                                     @Nonnull Function<IComplexDataSet, T> callback, ICancelToken cancelToken) {
        invokeListener(compiled);

        List<Object> params = compiled.buildParams(markerValues);
        // plan 2321：fanout 判定在 transform 之前——非查询入口命中 fanout 形态一律显式失败
        fanoutEngine.assertNotFanout(compiled, params);

        SQL sql = transformEQL(session, compiled, params);
        return jdbc().executeStatement(sql, range, ds -> {
            ds = new TransformedComplexDataSet(ds, compiled.getDataSetMeta(),
                    rs -> transformRow(rs, compiled, session));
            return callback.apply(ds);
        }, cancelToken);
    }

    void invokeListener(ICompiledSql sql) {
        IOrmDaoListener daoListener = env.getDaoListener();
        if (daoListener != null) {
            for (String entityModelName : sql.getReadEntityNames()) {
                IEntityModel entityModel = env.getOrmModel().requireEntityModel(entityModelName);
                daoListener.onRead(entityModel);
            }

            String entityModelName = sql.getWriteEntityName();
            if (entityModelName != null) {
                IEntityModel entityModel = env.getOrmModel().requireEntityModel(entityModelName);
                switch (sql.getStatementKind()) {
                    case DELETE: {
                        daoListener.onDelete(entityModel);
                        break;
                    }
                    case UPDATE: {
                        daoListener.onUpdate(entityModel);
                        break;
                    }
                    case INSERT: {
                        daoListener.onSave(entityModel);
                        break;
                    }
                }
            }
        }
    }

    private SQL transformEQL(IOrmSession session, ICompiledSql compiled, List<Object> params) {
        return new GenSqlTransformer(env.getShardSelector(), env.getOrmModel(), env, session.getLoadedOrmModel(),
                this.env.getEntityFilterProvider())
                .transform(compiled.getSql(), params).end();
    }

    protected IDataRow transformRow(IDataRow rs, ICompiledSql query, IOrmSessionImplementor session) {
        Object[] row = readRow(rs, query.getColumnBinders());
        List<ISqlExprMeta> fields = query.getFieldMetas();
        if (fields.size() == 1) {
            ISqlExprMeta field = fields.get(0);
            Object value = field.buildValue(row, 0, session);
            return new SingleColumnRow(query.getDataSetMeta(), value);
        } else {
            int index = 0;
            Object[] values = new Object[fields.size()];
            for (int i = 0, n = fields.size(); i < n; i++) {
                ISqlExprMeta field = fields.get(i);
                values[i] = field.buildValue(row, index, session);
                index += field.getColumnCount();
            }
            return new BaseDataRow(query.getDataSetMeta(), true, values);
        }
    }
}