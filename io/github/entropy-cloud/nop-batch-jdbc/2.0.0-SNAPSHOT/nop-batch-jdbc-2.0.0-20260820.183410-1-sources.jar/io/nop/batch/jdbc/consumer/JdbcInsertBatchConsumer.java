/**
 * Copyright (c) 2017-2024 Nop Platform. All rights reserved.
 * Author: canonical_entropy@163.com
 * Blog:   https://www.zhihu.com/people/canonical-entropy
 * Gitee:  https://gitee.com/canonical-entropy/nop-entropy
 * Github: https://github.com/entropy-cloud/nop-entropy
 */
package io.nop.batch.jdbc.consumer;

import io.nop.batch.core.IBatchChunkContext;
import io.nop.batch.core.IBatchConsumerProvider;
import io.nop.batch.core.IBatchConsumerProvider.IBatchConsumer;
import io.nop.batch.core.IBatchTaskContext;
import io.nop.core.lang.sql.SQL;
import io.nop.core.reflect.bean.BeanTool;
import io.nop.dao.dialect.IDialect;
import io.nop.dao.jdbc.IJdbcTemplate;
import io.nop.dao.jdbc.JdbcBatcher;
import io.nop.dataset.binder.IDataParameterBinder;

import java.util.Collection;
import java.util.Map;

public class JdbcInsertBatchConsumer<S> implements IBatchConsumerProvider<S>, IBatchConsumer<S> {
    private final IJdbcTemplate jdbcTemplate;
    private final IDialect dialect;
    private final String tableName;

    private final Map<String, IDataParameterBinder> colBinders;
    private final Map<String, String> fromNameMap;

    public JdbcInsertBatchConsumer(IJdbcTemplate jdbcTemplate, IDialect dialect, String tableName,
                                   Map<String, IDataParameterBinder> colBinders,
                                   Map<String, String> fromNameMap) {
        this.jdbcTemplate = jdbcTemplate;
        this.dialect = dialect;
        this.tableName = tableName;
        this.colBinders = colBinders;
        this.fromNameMap = fromNameMap;
    }

    @Override
    public IBatchConsumer<S> setup(IBatchTaskContext context) {
        return this;
    }

    @Override
    public void consume(Collection<S> items, IBatchChunkContext context) {
        SQL sql = SQL.begin().name("batch-insert").insertInto(tableName).end();

        jdbcTemplate.runWithConnection(sql, conn -> {
            JdbcBatcher batcher = new JdbcBatcher(conn, dialect, jdbcTemplate.getDaoMetrics());
            // 开启事务可以提高性能
            batcher.setForceTxn(true);
            for (S item : items) {
                SQL insert = buildInsert(item);
                batcher.addCommand(insert, false, null);
            }
            batcher.flush();
            return null;
        });

        context.getTaskContext().incInsertCount(items.size());
    }

    SQL buildInsert(S record) {
        SQL.SqlBuilder sb = SQL.begin().name("insert:" + tableName);
        sb.insertInto(tableName);
        sb.append('(');
        boolean first = true;
        for (String colName : colBinders.keySet()) {
            String fromName = getFromName(colName);
            if (!BeanTool.hasProperty(record, fromName))
                continue;

            if (first) {
                first = false;
            } else {
                sb.append(',');
            }
            sb.append(colName);
        }
        sb.append(") values (");
        first = true;
        for (Map.Entry<String, IDataParameterBinder> entry : colBinders.entrySet()) {
            String fromName = getFromName(entry.getKey());

            if (!BeanTool.hasProperty(record, fromName))
                continue;
            if (first) {
                first = false;
            } else {
                sb.append(',');
            }

            appendParam(sb, entry.getValue(), BeanTool.getProperty(record, fromName));
        }
        sb.append(')');
        return sb.end();
    }

    String getFromName(String key) {
        if (fromNameMap == null)
            return key;
        String from = fromNameMap.get(key);
        if (from == null)
            return key;
        return from;
    }

    void appendParam(SQL.SqlBuilder sb, IDataParameterBinder binder, Object value) {
        value = binder.getStdDataType().convert(value);
        sb.typeParam(binder, value, false);
    }
}
